--
-- PostgreSQL database dump
--

\restrict khfTsZ1ktr0RAULBk6Bs28kBqKU4Bfrmf02yBc0FejfEp5oIZSwwvgwBY2kwXs5

-- Dumped from database version 16.12 (Debian 16.12-1.pgdg13+1)
-- Dumped by pg_dump version 16.12 (Debian 16.12-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accesscontrol_schema_version; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.accesscontrol_schema_version (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.accesscontrol_schema_version OWNER TO egov;

--
-- Name: boundary; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.boundary (
    id character varying(64) NOT NULL,
    tenantid character varying(64) NOT NULL,
    code character varying(64) NOT NULL,
    geometry jsonb,
    additionaldetails jsonb,
    createdtime bigint NOT NULL,
    createdby character varying(64) NOT NULL,
    lastmodifiedtime bigint,
    lastmodifiedby character varying(64)
);


ALTER TABLE public.boundary OWNER TO egov;

--
-- Name: boundary_hierarchy; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.boundary_hierarchy (
    id character varying(64) NOT NULL,
    tenantid character varying(64) NOT NULL,
    hierarchytype character varying(64) NOT NULL,
    boundaryhierarchy jsonb NOT NULL,
    createdtime bigint,
    createdby character varying(64),
    lastmodifiedtime bigint,
    lastmodifiedby character varying(64)
);


ALTER TABLE public.boundary_hierarchy OWNER TO egov;

--
-- Name: boundary_relationship; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.boundary_relationship (
    id character varying(64),
    tenantid character varying(64) NOT NULL,
    code character varying(64) NOT NULL,
    hierarchytype character varying(64) NOT NULL,
    boundarytype character varying(64) NOT NULL,
    parent character varying(64),
    ancestralmaterializedpath text,
    createdtime bigint,
    createdby character varying(64),
    lastmodifiedtime bigint,
    lastmodifiedby character varying(64)
);


ALTER TABLE public.boundary_relationship OWNER TO egov;

--
-- Name: boundary_service_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.boundary_service_schema (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.boundary_service_schema OWNER TO egov;

--
-- Name: eg_action; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_action (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    url character varying(100),
    servicecode character varying(50),
    queryparams character varying(100),
    parentmodule character varying(50),
    ordernumber bigint,
    displayname character varying(100),
    enabled boolean,
    createdby bigint DEFAULT 1,
    createddate timestamp without time zone DEFAULT now(),
    lastmodifiedby bigint DEFAULT 1,
    lastmodifieddate timestamp without time zone DEFAULT now()
);


ALTER TABLE public.eg_action OWNER TO egov;

--
-- Name: eg_address; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_address (
    housenobldgapt character varying(32),
    subdistrict character varying(100),
    postoffice character varying(100),
    landmark character varying(256),
    country character varying(50),
    type character varying(50),
    streetroadline character varying(256),
    citytownvillage character varying(256),
    arealocalitysector character varying(256),
    district character varying(100),
    state character varying(100),
    pincode character varying(10),
    id integer NOT NULL,
    version bigint DEFAULT 0,
    tenantid character varying(256) NOT NULL,
    userid bigint
);


ALTER TABLE public.eg_address OWNER TO egov;

--
-- Name: eg_address_id_seq; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.eg_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eg_address_id_seq OWNER TO egov;

--
-- Name: eg_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: egov
--

ALTER SEQUENCE public.eg_address_id_seq OWNED BY public.eg_address.id;


--
-- Name: eg_bm_generated_template; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_bm_generated_template (
    id character varying(64) NOT NULL,
    filestoreid character varying(256),
    status character varying(64),
    tenantid character varying(256) NOT NULL,
    hierarchytype character varying(128) NOT NULL,
    locale character varying(16) DEFAULT 'en_IN'::character varying,
    createdby character varying(256),
    createdtime bigint,
    lastmodifiedby character varying(256),
    lastmodifiedtime bigint,
    additionaldetails jsonb,
    referenceid character varying(256)
);


ALTER TABLE public.eg_bm_generated_template OWNER TO egov;

--
-- Name: eg_bm_processed_template; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_bm_processed_template (
    id character varying(64) NOT NULL,
    status character varying(64),
    tenantid character varying(256) NOT NULL,
    hierarchytype character varying(128) NOT NULL,
    filestoreid character varying(256),
    processedfilestoreid character varying(256),
    action character varying(64),
    createdby character varying(256),
    createdtime bigint,
    lastmodifiedby character varying(256),
    lastmodifiedtime bigint,
    additionaldetails jsonb,
    referenceid character varying(256)
);


ALTER TABLE public.eg_bm_processed_template OWNER TO egov;

--
-- Name: eg_enc_asymmetric_keys; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_enc_asymmetric_keys (
    id integer NOT NULL,
    key_id integer NOT NULL,
    public_key text NOT NULL,
    private_key text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    tenant_id text NOT NULL
);


ALTER TABLE public.eg_enc_asymmetric_keys OWNER TO egov;

--
-- Name: eg_enc_asymmetric_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.eg_enc_asymmetric_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eg_enc_asymmetric_keys_id_seq OWNER TO egov;

--
-- Name: eg_enc_asymmetric_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: egov
--

ALTER SEQUENCE public.eg_enc_asymmetric_keys_id_seq OWNED BY public.eg_enc_asymmetric_keys.id;


--
-- Name: eg_enc_symmetric_keys; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_enc_symmetric_keys (
    id integer NOT NULL,
    key_id integer NOT NULL,
    secret_key text NOT NULL,
    initial_vector text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    tenant_id text NOT NULL
);


ALTER TABLE public.eg_enc_symmetric_keys OWNER TO egov;

--
-- Name: eg_enc_symmetric_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.eg_enc_symmetric_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eg_enc_symmetric_keys_id_seq OWNER TO egov;

--
-- Name: eg_enc_symmetric_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: egov
--

ALTER SEQUENCE public.eg_enc_symmetric_keys_id_seq OWNED BY public.eg_enc_symmetric_keys.id;


--
-- Name: eg_filestoremap; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_filestoremap (
    id bigint NOT NULL,
    filestoreid character varying(36) NOT NULL,
    filename character varying(256) NOT NULL,
    contenttype character varying(100),
    module character varying(256),
    tag character varying(256),
    tenantid character varying(256) NOT NULL,
    version bigint,
    filesource character varying(64),
    createdby character varying(64),
    lastmodifiedby character varying(64),
    createdtime bigint,
    lastmodifiedtime bigint
);


ALTER TABLE public.eg_filestoremap OWNER TO egov;

--
-- Name: eg_hrms_assignment; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_hrms_assignment (
    uuid character varying(1024) NOT NULL,
    employeeid character varying(1024) NOT NULL,
    "position" bigint,
    department character varying(250),
    designation character varying(250),
    fromdate bigint,
    todate bigint,
    govtordernumber character varying(250),
    reportingto character varying(250),
    ishod boolean,
    tenantid character varying(250) NOT NULL,
    createdby character varying(250) NOT NULL,
    createddate bigint NOT NULL,
    lastmodifiedby character varying(250),
    lastmodifieddate bigint,
    iscurrentassignment boolean,
    isactive boolean,
    CONSTRAINT ck_eghrms_employee_fromto CHECK ((fromdate <= todate))
);


ALTER TABLE public.eg_hrms_assignment OWNER TO egov;

--
-- Name: eg_hrms_deactivationdetails; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_hrms_deactivationdetails (
    uuid character varying(1024) NOT NULL,
    employeeid character varying(1024) NOT NULL,
    reasonfordeactivation character varying(250),
    effectivefrom bigint,
    ordernumber character varying(250),
    remarks character varying(250),
    tenantid character varying(250) NOT NULL,
    createdby character varying(250) NOT NULL,
    createddate bigint NOT NULL,
    lastmodifiedby character varying(250),
    lastmodifieddate bigint,
    isactive boolean
);


ALTER TABLE public.eg_hrms_deactivationdetails OWNER TO egov;

--
-- Name: eg_hrms_departmentaltests; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_hrms_departmentaltests (
    uuid character varying(1024) NOT NULL,
    employeeid character varying(1024) NOT NULL,
    test character varying(250),
    yearofpassing bigint,
    remarks character varying(250),
    tenantid character varying(250) NOT NULL,
    createdby character varying(250) NOT NULL,
    createddate bigint NOT NULL,
    lastmodifiedby character varying(250),
    lastmodifieddate bigint,
    isactive boolean
);


ALTER TABLE public.eg_hrms_departmentaltests OWNER TO egov;

--
-- Name: eg_hrms_educationaldetails; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_hrms_educationaldetails (
    uuid character varying(1024) NOT NULL,
    employeeid character varying(1024) NOT NULL,
    qualification character varying(250),
    stream character varying(250),
    yearofpassing bigint,
    university character varying(250),
    remarks character varying(250),
    tenantid character varying(250) NOT NULL,
    createdby character varying(250) NOT NULL,
    createddate bigint NOT NULL,
    lastmodifiedby character varying(250),
    lastmodifieddate bigint,
    isactive boolean
);


ALTER TABLE public.eg_hrms_educationaldetails OWNER TO egov;

--
-- Name: eg_hrms_empdocuments; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_hrms_empdocuments (
    uuid character varying(1024) NOT NULL,
    employeeid character varying(1024) NOT NULL,
    documentid character varying(250) NOT NULL,
    documentname character varying(250),
    referencetype character varying(250),
    referenceid character varying(250) NOT NULL,
    tenantid character varying(250) NOT NULL,
    createdby character varying(250) NOT NULL,
    createddate bigint NOT NULL,
    lastmodifiedby character varying(250),
    lastmodifieddate bigint
);


ALTER TABLE public.eg_hrms_empdocuments OWNER TO egov;

--
-- Name: eg_hrms_employee; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_hrms_employee (
    id bigint NOT NULL,
    uuid character varying(1024) NOT NULL,
    code character varying(250),
    dateofappointment bigint,
    employeestatus character varying(250),
    employeetype character varying(250),
    active boolean,
    tenantid character varying(250) NOT NULL,
    createdby character varying(250) NOT NULL,
    createddate bigint NOT NULL,
    lastmodifiedby character varying(250),
    lastmodifieddate bigint,
    reactivateemployee boolean
);


ALTER TABLE public.eg_hrms_employee OWNER TO egov;

--
-- Name: eg_hrms_jurisdiction; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_hrms_jurisdiction (
    uuid character varying(1024) NOT NULL,
    employeeid character varying(1024) NOT NULL,
    hierarchy character varying(250) NOT NULL,
    boundarytype character varying(250) NOT NULL,
    boundary character varying(250) NOT NULL,
    tenantid character varying(250) NOT NULL,
    createdby character varying(250) NOT NULL,
    createddate bigint NOT NULL,
    lastmodifiedby character varying(250),
    lastmodifieddate bigint,
    isactive boolean
);


ALTER TABLE public.eg_hrms_jurisdiction OWNER TO egov;

--
-- Name: eg_hrms_position; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.eg_hrms_position
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eg_hrms_position OWNER TO egov;

--
-- Name: eg_hrms_reactivationdetails; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_hrms_reactivationdetails (
    uuid character varying(1024) NOT NULL,
    employeeid character varying(1024) NOT NULL,
    reasonforreactivation character varying(250),
    effectivefrom bigint,
    ordernumber character varying(250),
    remarks character varying(250),
    tenantid character varying(250) NOT NULL,
    createdby character varying(250) NOT NULL,
    createddate bigint NOT NULL,
    lastmodifiedby character varying(250),
    lastmodifieddate bigint
);


ALTER TABLE public.eg_hrms_reactivationdetails OWNER TO egov;

--
-- Name: eg_hrms_servicehistory; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_hrms_servicehistory (
    uuid character varying(1024) NOT NULL,
    employeeid character varying(1024) NOT NULL,
    servicestatus character varying(250),
    servicefrom bigint,
    serviceto bigint,
    ordernumber character varying(250),
    iscurrentposition boolean,
    location character varying(250),
    tenantid character varying(250) NOT NULL,
    createdby character varying(250) NOT NULL,
    createddate bigint NOT NULL,
    lastmodifiedby character varying(250),
    lastmodifieddate bigint,
    isactive boolean
);


ALTER TABLE public.eg_hrms_servicehistory OWNER TO egov;

--
-- Name: eg_mdms_data; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_mdms_data (
    id character varying(64) NOT NULL,
    tenantid character varying(255) NOT NULL,
    uniqueidentifier character varying(255) NOT NULL,
    schemacode character varying(255) NOT NULL,
    data jsonb NOT NULL,
    isactive boolean NOT NULL,
    createdby character varying(64),
    lastmodifiedby character varying(64),
    createdtime bigint,
    lastmodifiedtime bigint
);


ALTER TABLE public.eg_mdms_data OWNER TO egov;

--
-- Name: eg_mdms_schema_definition; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_mdms_schema_definition (
    id character varying(64) NOT NULL,
    tenantid character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    description character varying(512),
    definition jsonb NOT NULL,
    isactive boolean NOT NULL,
    createdby character varying(64),
    lastmodifiedby character varying(64),
    createdtime bigint,
    lastmodifiedtime bigint
);


ALTER TABLE public.eg_mdms_schema_definition OWNER TO egov;

--
-- Name: eg_ms_role; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_ms_role (
    name character varying(32) NOT NULL,
    code character varying(50) NOT NULL,
    description character varying(128),
    createddate timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    createdby bigint,
    lastmodifiedby bigint,
    lastmodifieddate timestamp without time zone,
    version bigint
);


ALTER TABLE public.eg_ms_role OWNER TO egov;

--
-- Name: eg_pgr_address_v2; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_pgr_address_v2 (
    tenantid character varying(256) NOT NULL,
    id character varying(256) NOT NULL,
    parentid character varying(256) NOT NULL,
    doorno character varying(128),
    plotno character varying(256),
    buildingname character varying(1024),
    street character varying(1024),
    landmark character varying(1024),
    city character varying(512),
    pincode character varying(16),
    locality character varying(128) NOT NULL,
    district character varying(256),
    region character varying(256),
    state character varying(256),
    country character varying(512),
    latitude numeric(9,6),
    longitude numeric(10,7),
    createdby character varying(128) NOT NULL,
    createdtime bigint NOT NULL,
    lastmodifiedby character varying(128),
    lastmodifiedtime bigint,
    additionaldetails jsonb
);


ALTER TABLE public.eg_pgr_address_v2 OWNER TO egov;

--
-- Name: eg_pgr_service_v2; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_pgr_service_v2 (
    id character varying(64),
    tenantid character varying(256) NOT NULL,
    servicecode character varying(256) NOT NULL,
    servicerequestid character varying(256) NOT NULL,
    description character varying(4000),
    accountid character varying(256),
    additionaldetails jsonb,
    applicationstatus character varying(128),
    rating smallint,
    source character varying(256),
    createdby character varying(256) NOT NULL,
    createdtime bigint NOT NULL,
    lastmodifiedby character varying(256),
    lastmodifiedtime bigint,
    active boolean DEFAULT true
);


ALTER TABLE public.eg_pgr_service_v2 OWNER TO egov;

--
-- Name: eg_role; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_role (
    name character varying(128) NOT NULL,
    code character varying(50) NOT NULL,
    description character varying(128),
    createddate timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    createdby bigint,
    lastmodifiedby bigint,
    lastmodifieddate timestamp without time zone,
    version bigint,
    tenantid character varying(256) NOT NULL,
    id bigint NOT NULL
);


ALTER TABLE public.eg_role OWNER TO egov;

--
-- Name: eg_roleaction; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_roleaction (
    rolecode character varying(32) NOT NULL,
    actionid bigint NOT NULL,
    tenantid character varying(50) NOT NULL
);


ALTER TABLE public.eg_roleaction OWNER TO egov;

--
-- Name: eg_token; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_token (
    id character(36) NOT NULL,
    tenantid character varying(256) NOT NULL,
    tokennumber character varying(128) NOT NULL,
    tokenidentity character varying(100) NOT NULL,
    validated character(1) DEFAULT 'N'::bpchar NOT NULL,
    ttlsecs bigint NOT NULL,
    createddate timestamp without time zone NOT NULL,
    lastmodifieddate timestamp without time zone,
    createdby bigint NOT NULL,
    lastmodifiedby bigint,
    version bigint,
    createddatenew bigint
);


ALTER TABLE public.eg_token OWNER TO egov;

--
-- Name: eg_url_shortener; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_url_shortener (
    id character varying(128) NOT NULL,
    validform bigint,
    validto bigint,
    url character varying(1024) NOT NULL
);


ALTER TABLE public.eg_url_shortener OWNER TO egov;

--
-- Name: eg_url_shorter_id; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.eg_url_shorter_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eg_url_shorter_id OWNER TO egov;

--
-- Name: eg_user; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_user (
    title character varying(8),
    salutation character varying(5),
    dob timestamp without time zone,
    locale character varying(16),
    username character varying(180) NOT NULL,
    password character varying(64) NOT NULL,
    pwdexpirydate timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    mobilenumber character varying(150),
    altcontactnumber character varying(150),
    emailid character varying(300),
    createddate timestamp without time zone,
    lastmodifieddate timestamp without time zone,
    createdby bigint,
    lastmodifiedby bigint,
    active boolean,
    name character varying(250),
    gender smallint,
    pan character varying(65),
    aadhaarnumber character varying(85),
    type character varying(50),
    version numeric DEFAULT 0,
    guardian character varying(250),
    guardianrelation character varying(32),
    signature character varying(36),
    accountlocked boolean DEFAULT false,
    bloodgroup character varying(32),
    photo character varying(36),
    identificationmark character varying(300),
    tenantid character varying(256) NOT NULL,
    id bigint NOT NULL,
    uuid character(36),
    accountlockeddate bigint,
    alternatemobilenumber character varying(50) DEFAULT NULL::character varying,
    countrycode character varying(10)
);


ALTER TABLE public.eg_user OWNER TO egov;

--
-- Name: eg_user_address; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_user_address (
    id bigint NOT NULL,
    version numeric DEFAULT 0,
    createddate timestamp without time zone NOT NULL,
    lastmodifieddate timestamp without time zone,
    createdby bigint NOT NULL,
    lastmodifiedby bigint,
    type character varying(50) NOT NULL,
    address character varying(440),
    city character varying(300),
    pincode character varying(10),
    userid bigint NOT NULL,
    tenantid character varying(256) NOT NULL
);


ALTER TABLE public.eg_user_address OWNER TO egov;

--
-- Name: eg_user_audit_table; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_user_audit_table (
    id bigint NOT NULL,
    title character varying(8),
    salutation character varying(5),
    dob timestamp without time zone,
    locale character varying(16),
    username character varying(300) NOT NULL,
    password character varying(300) NOT NULL,
    pwdexpirydate timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    mobilenumber character varying(50),
    altcontactnumber character varying(50),
    emailid character varying(128),
    active boolean,
    name character varying(100),
    gender smallint,
    pan character varying(50),
    aadhaarnumber character varying(50),
    type character varying(50),
    version numeric DEFAULT 0,
    guardian character varying(100),
    guardianrelation character varying(32),
    signature character varying(36),
    accountlocked boolean DEFAULT false,
    bloodgroup character varying(32),
    photo character varying(36),
    identificationmark character varying(300),
    tenantid character varying(256) NOT NULL,
    uuid character varying(300),
    auditcreatedby character varying(100),
    auditcreatedtime bigint
);


ALTER TABLE public.eg_user_audit_table OWNER TO egov;

--
-- Name: eg_user_login_failed_attempts; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_user_login_failed_attempts (
    user_uuid character varying(64) NOT NULL,
    ip character varying(46),
    attempt_date bigint NOT NULL,
    active boolean
);


ALTER TABLE public.eg_user_login_failed_attempts OWNER TO egov;

--
-- Name: eg_userrole; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_userrole (
    roleid bigint NOT NULL,
    roleidtenantid character varying(256) NOT NULL,
    userid bigint NOT NULL,
    tenantid character varying(256) NOT NULL,
    lastmodifieddate timestamp without time zone DEFAULT now()
);


ALTER TABLE public.eg_userrole OWNER TO egov;

--
-- Name: eg_userrole_v1; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_userrole_v1 (
    role_code character varying(50),
    role_tenantid character varying(256),
    user_id bigint,
    user_tenantid character varying(256),
    lastmodifieddate timestamp without time zone
);


ALTER TABLE public.eg_userrole_v1 OWNER TO egov;

--
-- Name: eg_wf_action_v2; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_wf_action_v2 (
    uuid character varying(256) NOT NULL,
    tenantid character varying(256) NOT NULL,
    currentstate character varying(256),
    action character varying(256) NOT NULL,
    nextstate character varying(256),
    roles character varying(1024) NOT NULL,
    createdby character varying(256) NOT NULL,
    createdtime bigint,
    lastmodifiedby character varying(256) NOT NULL,
    lastmodifiedtime bigint,
    active boolean DEFAULT true
);


ALTER TABLE public.eg_wf_action_v2 OWNER TO egov;

--
-- Name: eg_wf_assignee_v2; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_wf_assignee_v2 (
    processinstanceid character varying(64),
    tenantid character varying(128),
    assignee character varying(128),
    createdby character varying(64),
    lastmodifiedby character varying(64),
    createdtime bigint,
    lastmodifiedtime bigint
);


ALTER TABLE public.eg_wf_assignee_v2 OWNER TO egov;

--
-- Name: eg_wf_businessservice_v2; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_wf_businessservice_v2 (
    businessservice character varying(256) NOT NULL,
    business character varying(256) NOT NULL,
    tenantid character varying(256) NOT NULL,
    uuid character varying(256) NOT NULL,
    geturi character varying(1024),
    posturi character varying(1024),
    createdby character varying(256) NOT NULL,
    createdtime bigint,
    lastmodifiedby character varying(256) NOT NULL,
    lastmodifiedtime bigint,
    businessservicesla bigint
);


ALTER TABLE public.eg_wf_businessservice_v2 OWNER TO egov;

--
-- Name: eg_wf_document_v2; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_wf_document_v2 (
    id character varying(64) NOT NULL,
    tenantid character varying(64),
    documenttype character varying(64),
    documentuid character varying(64),
    filestoreid character varying(64),
    processinstanceid character varying(64),
    active boolean,
    createdby character varying(64),
    lastmodifiedby character varying(64),
    createdtime bigint,
    lastmodifiedtime bigint
);


ALTER TABLE public.eg_wf_document_v2 OWNER TO egov;

--
-- Name: eg_wf_processinstance_v2; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_wf_processinstance_v2 (
    id character varying(64),
    tenantid character varying(128),
    businessservice character varying(128),
    businessid character varying(128),
    action character varying(128),
    status character varying(128),
    comment character varying(1024),
    assigner character varying(128),
    assignee character varying(128),
    statesla bigint,
    previousstatus character varying(128),
    createdby character varying(64),
    lastmodifiedby character varying(64),
    createdtime bigint,
    lastmodifiedtime bigint,
    modulename character varying(64),
    businessservicesla bigint,
    rating smallint,
    escalated boolean DEFAULT false
);


ALTER TABLE public.eg_wf_processinstance_v2 OWNER TO egov;

--
-- Name: eg_wf_state_v2; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.eg_wf_state_v2 (
    uuid character varying(256) NOT NULL,
    tenantid character varying(256) NOT NULL,
    businessserviceid character varying(256) NOT NULL,
    state character varying(256),
    applicationstatus character varying(256),
    sla bigint,
    docuploadrequired boolean,
    isstartstate boolean,
    isterminatestate boolean,
    createdby character varying(256) NOT NULL,
    createdtime bigint,
    lastmodifiedby character varying(256) NOT NULL,
    lastmodifiedtime bigint,
    seq integer,
    isstateupdatable boolean
);


ALTER TABLE public.eg_wf_state_v2 OWNER TO egov;

--
-- Name: egov-url-shortening_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public."egov-url-shortening_schema" (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public."egov-url-shortening_schema" OWNER TO egov;

--
-- Name: egov_enc_service_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.egov_enc_service_schema (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.egov_enc_service_schema OWNER TO egov;

--
-- Name: egov_filestore_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.egov_filestore_schema (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.egov_filestore_schema OWNER TO egov;

--
-- Name: egov_hrms_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.egov_hrms_schema (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.egov_hrms_schema OWNER TO egov;

--
-- Name: egov_idgen_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.egov_idgen_schema (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.egov_idgen_schema OWNER TO egov;

--
-- Name: egov_localization_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.egov_localization_schema (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.egov_localization_schema OWNER TO egov;

--
-- Name: egov_otp_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.egov_otp_schema (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.egov_otp_schema OWNER TO egov;

--
-- Name: egov_user_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.egov_user_schema (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.egov_user_schema OWNER TO egov;

--
-- Name: egov_workflow_v2_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.egov_workflow_v2_schema (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.egov_workflow_v2_schema OWNER TO egov;

--
-- Name: id_generator; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.id_generator (
    id bigint NOT NULL,
    idname character varying(200) NOT NULL,
    tenantid character varying(200) NOT NULL,
    format character varying(200) NOT NULL,
    sequencenumber integer NOT NULL
);


ALTER TABLE public.id_generator OWNER TO egov;

--
-- Name: id_generator_id_seq; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.id_generator_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.id_generator_id_seq OWNER TO egov;

--
-- Name: id_generator_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: egov
--

ALTER SEQUENCE public.id_generator_id_seq OWNED BY public.id_generator.id;


--
-- Name: mdms_v2_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.mdms_v2_schema (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.mdms_v2_schema OWNER TO egov;

--
-- Name: message; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.message (
    id character varying(512) NOT NULL,
    locale character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    message character varying(500) NOT NULL,
    tenantid character varying(256) NOT NULL,
    module character varying(255) NOT NULL,
    createdby bigint NOT NULL,
    createddate timestamp without time zone DEFAULT now() NOT NULL,
    lastmodifiedby bigint,
    lastmodifieddate timestamp without time zone
);


ALTER TABLE public.message OWNER TO egov;

--
-- Name: pgr_services_schema; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.pgr_services_schema (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.pgr_services_schema OWNER TO egov;

--
-- Name: seq_ack_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_ack_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_ack_num OWNER TO egov;

--
-- Name: seq_advocate_code; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_advocate_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_advocate_code OWNER TO egov;

--
-- Name: seq_advocatepayment_code; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_advocatepayment_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_advocatepayment_code OWNER TO egov;

--
-- Name: seq_agency; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_agency
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_agency OWNER TO egov;

--
-- Name: seq_assesmnt_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_assesmnt_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_assesmnt_num OWNER TO egov;

--
-- Name: seq_case_advocate; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_case_advocate
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_case_advocate OWNER TO egov;

--
-- Name: seq_case_reference; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_case_reference
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_case_reference OWNER TO egov;

--
-- Name: seq_coll_rcpt_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_coll_rcpt_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_coll_rcpt_num OWNER TO egov;

--
-- Name: seq_eg_action; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_action
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_action OWNER TO egov;

--
-- Name: seq_eg_filestoremap; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_filestoremap
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_filestoremap OWNER TO egov;

--
-- Name: seq_eg_hrms_emp_code; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_hrms_emp_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_hrms_emp_code OWNER TO egov;

--
-- Name: seq_eg_ms_role; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_ms_role
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_ms_role OWNER TO egov;

--
-- Name: seq_eg_pg_txn; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_pg_txn
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_pg_txn OWNER TO egov;

--
-- Name: seq_eg_pgr_id; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_pgr_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_pgr_id OWNER TO egov;

--
-- Name: seq_eg_pt_ack; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_pt_ack
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_pt_ack OWNER TO egov;

--
-- Name: seq_eg_pt_assm; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_pt_assm
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_pt_assm OWNER TO egov;

--
-- Name: seq_eg_pt_ln; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_pt_ln
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_pt_ln OWNER TO egov;

--
-- Name: seq_eg_pt_ptid; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_pt_ptid
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_pt_ptid OWNER TO egov;

--
-- Name: seq_eg_role; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_role
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_role OWNER TO egov;

--
-- Name: seq_eg_tl_apl; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_tl_apl
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_tl_apl OWNER TO egov;

--
-- Name: seq_eg_user; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_user
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_user OWNER TO egov;

--
-- Name: seq_eg_user_address; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_user_address
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_user_address OWNER TO egov;

--
-- Name: seq_eg_wf_state_v2; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_eg_wf_state_v2
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_eg_wf_state_v2 OWNER TO egov;

--
-- Name: seq_egf_bill_dft_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_egf_bill_dft_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_egf_bill_dft_num OWNER TO egov;

--
-- Name: seq_employee_code; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_employee_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_employee_code OWNER TO egov;

--
-- Name: seq_event; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_event
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_event OWNER TO egov;

--
-- Name: seq_hearing_details; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_hearing_details
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_hearing_details OWNER TO egov;

--
-- Name: seq_message; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_message
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_message OWNER TO egov;

--
-- Name: seq_notice; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_notice
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_notice OWNER TO egov;

--
-- Name: seq_opinion_code; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_opinion_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_opinion_code OWNER TO egov;

--
-- Name: seq_parawise_comments; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_parawise_comments
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_parawise_comments OWNER TO egov;

--
-- Name: seq_personal_details; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_personal_details
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_personal_details OWNER TO egov;

--
-- Name: seq_reference_evidence; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_reference_evidence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_reference_evidence OWNER TO egov;

--
-- Name: seq_register; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_register
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_register OWNER TO egov;

--
-- Name: seq_service; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_service
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_service OWNER TO egov;

--
-- Name: seq_summon_code; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_summon_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_summon_code OWNER TO egov;

--
-- Name: seq_summon_reference; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_summon_reference
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_summon_reference OWNER TO egov;

--
-- Name: seq_swm_ctrt_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_ctrt_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_ctrt_num OWNER TO egov;

--
-- Name: seq_swm_shift_code_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_shift_code_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_shift_code_num OWNER TO egov;

--
-- Name: seq_swm_snts_trgt_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_snts_trgt_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_snts_trgt_num OWNER TO egov;

--
-- Name: seq_swm_splr_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_splr_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_splr_num OWNER TO egov;

--
-- Name: seq_swm_stf_trn_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_stf_trn_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_stf_trn_num OWNER TO egov;

--
-- Name: seq_swm_trn_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_trn_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_trn_num OWNER TO egov;

--
-- Name: seq_swm_vendor_payment_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_vendor_payment_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_vendor_payment_num OWNER TO egov;

--
-- Name: seq_swm_vhl_trip_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_vhl_trip_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_vhl_trip_num OWNER TO egov;

--
-- Name: seq_swm_vmr_trn_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_vmr_trn_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_vmr_trn_num OWNER TO egov;

--
-- Name: seq_swm_vndr_ctrt_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_vndr_ctrt_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_vndr_ctrt_num OWNER TO egov;

--
-- Name: seq_swm_vndr_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_vndr_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_vndr_num OWNER TO egov;

--
-- Name: seq_swm_vs_trn_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_swm_vs_trn_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_swm_vs_trn_num OWNER TO egov;

--
-- Name: seq_tl_app_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_tl_app_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_tl_app_num OWNER TO egov;

--
-- Name: seq_tl_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_tl_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_tl_num OWNER TO egov;

--
-- Name: seq_uc_demand_consumer_code; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_uc_demand_consumer_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_uc_demand_consumer_code OWNER TO egov;

--
-- Name: seq_ulb_code; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_ulb_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_ulb_code OWNER TO egov;

--
-- Name: seq_upic_num; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_upic_num
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_upic_num OWNER TO egov;

--
-- Name: seq_voucher_code; Type: SEQUENCE; Schema: public; Owner: egov
--

CREATE SEQUENCE public.seq_voucher_code
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seq_voucher_code OWNER TO egov;

--
-- Name: service; Type: TABLE; Schema: public; Owner: egov
--

CREATE TABLE public.service (
    id bigint NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    enabled boolean,
    contextroot character varying(50),
    displayname character varying(100),
    ordernumber bigint,
    parentmodule character varying(100),
    tenantid character varying(50) NOT NULL
);


ALTER TABLE public.service OWNER TO egov;

--
-- Name: eg_address id; Type: DEFAULT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_address ALTER COLUMN id SET DEFAULT nextval('public.eg_address_id_seq'::regclass);


--
-- Name: eg_enc_asymmetric_keys id; Type: DEFAULT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_enc_asymmetric_keys ALTER COLUMN id SET DEFAULT nextval('public.eg_enc_asymmetric_keys_id_seq'::regclass);


--
-- Name: eg_enc_symmetric_keys id; Type: DEFAULT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_enc_symmetric_keys ALTER COLUMN id SET DEFAULT nextval('public.eg_enc_symmetric_keys_id_seq'::regclass);


--
-- Name: id_generator id; Type: DEFAULT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.id_generator ALTER COLUMN id SET DEFAULT nextval('public.id_generator_id_seq'::regclass);


--
-- Data for Name: accesscontrol_schema_version; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.accesscontrol_schema_version (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-02-09 05:24:45.470974	0	t
2	20170404105602	create action service data	SQL	V20170404105602__create_action_service_data.sql	1088244516	egov	2026-02-09 05:24:45.601013	50	t
3	20170418143202	updated constraints	SQL	V20170418143202__updated_constraints.sql	1751612411	egov	2026-02-09 05:24:45.838953	34	t
4	20170424181300	updated contextroot column size in service table	SQL	V20170424181300__updated_contextroot_column_size_in_service_table.sql	-881688592	egov	2026-02-09 05:24:45.905315	9	t
5	20170526125200	create role	SQL	V20170526125200__create_role.sql	-789651706	egov	2026-02-09 05:24:45.94028	8	t
6	20170529112100	drop tenantid from action	SQL	V20170529112100__drop_tenantid_from_action.sql	-612552893	egov	2026-02-09 05:24:45.964749	18	t
7	20170530152300	alter id to bigint in eg ms role	SQL	V20170530152300__alter_id_to_bigint_in_eg_ms_role.sql	804729830	egov	2026-02-09 05:24:46.008066	12	t
8	20170530155100	drop id column in eg ms role	SQL	V20170530155100__drop_id_column_in_eg_ms_role.sql	1777745195	egov	2026-02-09 05:24:46.037193	4	t
\.


--
-- Data for Name: boundary; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.boundary (id, tenantid, code, geometry, additionaldetails, createdtime, createdby, lastmodifiedtime, lastmodifiedby) FROM stdin;
098443ce-1c97-40d3-aec1-44a2e45d22da	pg	PG_CITYA	{"type": "Polygon", "coordinates": [[[74.8, 31.5], [74.9, 31.5], [74.9, 31.7], [74.8, 31.7], [74.8, 31.5]]]}	{}	1781073055245	system	1781073055245	system
a1fb63a5-8305-4365-a3f3-e86337b6c809	pg	PG_CITYA_B1	{"type": "Polygon", "coordinates": [[[74.83, 31.57], [74.87, 31.57], [74.87, 31.63], [74.83, 31.63], [74.83, 31.57]]]}	{}	1781073055245	system	1781073055245	system
215072ee-890f-4140-9451-f3c08929e614	pg	PG_CITYA_Z1	{"type": "Polygon", "coordinates": [[[74.82, 31.55], [74.88, 31.55], [74.88, 31.65], [74.82, 31.65], [74.82, 31.55]]]}	{}	1781073055245	system	1781073055245	system
f971f0f0-f691-4b3d-bde1-a539daf5029c	pg	PG_STATE	{"type": "Polygon", "coordinates": [[[74.0, 30.0], [78.0, 30.0], [78.0, 33.0], [74.0, 33.0], [74.0, 30.0]]]}	{}	1781073055245	system	1781073055245	system
8cf59d36-879b-498d-886c-969b799b9ed0	pg	SUN01_LOCALITY	{"type": "Point", "coordinates": [74.87155, 31.63089]}	{}	1781073055245	system	1781073055245	system
d160ceda-65a5-4d2a-b19d-e69ef9be2c22	pg	SUN02_LOCALITY	{"type": "Point", "coordinates": [74.85, 31.61]}	{}	1781073055245	system	1781073055245	system
78120481-4402-4284-a81c-c8f2b00e58ad	pg	SUN03_LOCALITY	{"type": "Point", "coordinates": [74.84, 31.60]}	{}	1781073055245	system	1781073055245	system
88ba1d4c-540f-4351-9289-becd79cfdeae	pg.citya	PG_CITYA_ADMIN_CITY	{"type": "Polygon", "coordinates": [[[77.17, 28.56], [70.11, 22.50], [77.58, 13.05], [86.42, 23.77], [77.17, 28.56]]]}	{}	1781072283555	system	1781072283555	system
665a5db2-b61f-4730-b769-fee204b70a0a	pg.citya	Z1_ADMIN_ZONE	{"type": "Polygon", "coordinates": [[[77.17, 28.56], [70.11, 22.50], [77.58, 13.05], [86.42, 23.77], [77.17, 28.56]]]}	{}	1781072283555	system	1781072283555	system
e7675727-dcfa-46b7-aa92-09bacb36f673	pg.citya	Z2_ADMIN_ZONE	{"type": "Polygon", "coordinates": [[[77.20, 28.60], [70.15, 22.55], [77.60, 13.10], [86.45, 23.80], [77.20, 28.60]]]}	{}	1783555200000	system	1783555200000	system
a04109d4-ace4-4608-9903-e279d4d9c158	pg.citya	W1_ADMIN_WARD	{"type": "Point", "coordinates": [74.871552, 31.63089]}	{}	1783555200000	system	1783555200000	system
8c1db4e2-50d7-4f1f-b3ed-0620944eafa9	pg.citya	W2_ADMIN_WARD	{"type": "Point", "coordinates": [74.9, 31.6]}	{}	1783555200000	system	1783555200000	system
d6fa339e-c7b3-4d0e-8ef4-d5f80837c8a0	pg.citya	W3_ADMIN_WARD	{"type": "Point", "coordinates": [74.85, 31.65]}	{}	1783555200000	system	1783555200000	system
\.


--
-- Data for Name: boundary_hierarchy; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.boundary_hierarchy (id, tenantid, hierarchytype, boundaryhierarchy, createdtime, createdby, lastmodifiedtime, lastmodifiedby) FROM stdin;
53ad64eb-6ea1-4e5b-927f-fa46a76cf77f	pg	ADMIN	[{"active": true, "boundaryType": "State", "parentBoundaryType": null}, {"active": true, "boundaryType": "City", "parentBoundaryType": "State"}, {"active": true, "boundaryType": "Zone", "parentBoundaryType": "City"}, {"active": true, "boundaryType": "Block", "parentBoundaryType": "Zone"}, {"active": true, "boundaryType": "Locality", "parentBoundaryType": "Block"}]	1781072811606	system	1781072811606	system
7c3ee1b7-0d7c-4f1b-bf98-2d21482bd7dc	pg.citya	ADMIN	[{"active": true, "boundaryType": "City", "parentBoundaryType": null}, {"active": true, "boundaryType": "Zone", "parentBoundaryType": "City"}, {"active": true, "boundaryType": "Ward", "parentBoundaryType": "Zone"}]	1783555200000	system	1783555200000	system
\.


--
-- Data for Name: boundary_relationship; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.boundary_relationship (id, tenantid, code, hierarchytype, boundarytype, parent, ancestralmaterializedpath, createdtime, createdby, lastmodifiedtime, lastmodifiedby) FROM stdin;
e0e17092-8f46-4412-ab8f-2b54adf1341e	pg	PG_CITYA	ADMIN	City	PG_STATE	PG_STATE|PG_CITYA	1781073055245	system	1781073055245	system
356f2eb0-d5dc-4ff0-b495-d1f207b5c5c2	pg	PG_CITYA_B1	ADMIN	Block	PG_CITYA_Z1	PG_STATE|PG_CITYA|PG_CITYA_Z1|PG_CITYA_B1	1781073055245	system	1781073055245	system
885fd3f4-6a66-4b74-8d7c-954e69833447	pg	PG_CITYA_Z1	ADMIN	Zone	PG_CITYA	PG_STATE|PG_CITYA|PG_CITYA_Z1	1781073055245	system	1781073055245	system
70517d85-02e4-45dd-a931-1743329ee392	pg	PG_STATE	ADMIN	State	\N	PG_STATE	1781073055245	system	1781073055245	system
efbe8abb-e405-46af-9155-9508574cf794	pg	SUN01_LOCALITY	ADMIN	Locality	PG_CITYA_B1	PG_STATE|PG_CITYA|PG_CITYA_Z1|PG_CITYA_B1|SUN01_LOCALITY	1781073055245	system	1781073055245	system
4ba318df-1337-47c0-8e2a-561b2952641d	pg	SUN02_LOCALITY	ADMIN	Locality	PG_CITYA_B1	PG_STATE|PG_CITYA|PG_CITYA_Z1|PG_CITYA_B1|SUN02_LOCALITY	1781073055245	system	1781073055245	system
77281ff2-34ef-4d35-b5bb-fcb453c76ee7	pg	SUN03_LOCALITY	ADMIN	Locality	PG_CITYA_B1	PG_STATE|PG_CITYA|PG_CITYA_Z1|PG_CITYA_B1|SUN03_LOCALITY	1781073055245	system	1781073055245	system
7af4fb46-91bc-40b3-bad5-41339464f48d	pg.citya	PG_CITYA_ADMIN_CITY	ADMIN	City	\N	PG_CITYA_ADMIN_CITY	1781072303298	system	1781072303298	system
d35f7376-f2e0-42b3-8a68-fa57ec7a56d9	pg.citya	Z1_ADMIN_ZONE	ADMIN	Zone	PG_CITYA_ADMIN_CITY	PG_CITYA_ADMIN_CITY|Z1_ADMIN_ZONE	1781072303298	system	1781072303298	system
e244488b-2bc5-4ad7-9bf3-167fd13ef410	pg.citya	Z2_ADMIN_ZONE	ADMIN	Zone	PG_CITYA_ADMIN_CITY	PG_CITYA_ADMIN_CITY|Z2_ADMIN_ZONE	1783555200000	system	1783555200000	system
61dd8a2d-5b43-4ee1-b5b4-81d29b766b6e	pg.citya	W1_ADMIN_WARD	ADMIN	Ward	Z1_ADMIN_ZONE	PG_CITYA_ADMIN_CITY|Z1_ADMIN_ZONE|W1_ADMIN_WARD	1783555200000	system	1783555200000	system
bd68986e-ed79-4307-a04e-1f816b4ddd9f	pg.citya	W2_ADMIN_WARD	ADMIN	Ward	Z1_ADMIN_ZONE	PG_CITYA_ADMIN_CITY|Z1_ADMIN_ZONE|W2_ADMIN_WARD	1783555200000	system	1783555200000	system
3a82bc2f-8fd3-4209-b379-636a19f1c795	pg.citya	W3_ADMIN_WARD	ADMIN	Ward	Z2_ADMIN_ZONE	PG_CITYA_ADMIN_CITY|Z2_ADMIN_ZONE|W3_ADMIN_WARD	1783555200000	system	1783555200000	system
\.


--
-- Data for Name: boundary_service_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.boundary_service_schema (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	20230728110535	boundary-service ddl	SQL	V20230728110535__boundary-service_ddl.sql	1587416147	egov	2026-07-10 10:43:52.90786	24	t
2	20231025110679	boundary hierarchy ddl	SQL	V20231025110679__boundary_hierarchy_ddl.sql	38639821	egov	2026-07-10 10:43:53.003697	19	t
3	20231031120752	boundary relationship ddl	SQL	V20231031120752__boundary_relationship_ddl.sql	1434917045	egov	2026-07-10 10:43:53.0576	14	t
\.


--
-- Data for Name: eg_action; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_action (id, name, url, servicecode, queryparams, parentmodule, ordernumber, displayname, enabled, createdby, createddate, lastmodifiedby, lastmodifieddate) FROM stdin;
\.


--
-- Data for Name: eg_address; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_address (housenobldgapt, subdistrict, postoffice, landmark, country, type, streetroadline, citytownvillage, arealocalitysector, district, state, pincode, id, version, tenantid, userid) FROM stdin;
\.


--
-- Data for Name: eg_bm_generated_template; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_bm_generated_template (id, filestoreid, status, tenantid, hierarchytype, locale, createdby, createdtime, lastmodifiedby, lastmodifiedtime, additionaldetails, referenceid) FROM stdin;
\.


--
-- Data for Name: eg_bm_processed_template; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_bm_processed_template (id, status, tenantid, hierarchytype, filestoreid, processedfilestoreid, action, createdby, createdtime, lastmodifiedby, lastmodifiedtime, additionaldetails, referenceid) FROM stdin;
\.


--
-- Data for Name: eg_enc_asymmetric_keys; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_enc_asymmetric_keys (id, key_id, public_key, private_key, active, tenant_id) FROM stdin;
1	822595	kOYrI8AmwiqKxhIEQFl3pCU6rLFLYjx+toLxqAfQ9C66U5wQF7ko6yOx0QHUvULfxgNZERlBH7rGd61iohPgCd+oE6cym5FXO+GTKZGuLwxoOvCYV78tQ6S8AQfLufzekeVrXKyM1ywvMZzuetmuOX9yvIoHHTdqkKfHqkCIO91EadFSpyF2/g1VRF0GQeBicUKLZpCkGFCxQiA8CDf4QHN9ODjc4mzLIi4rtLmKcvojMQTA8kwOrU/j/9ypwKibtNk0WZaPDQ+P0su+bPZd0BZNhtlnEAWWbD76OjKf0X/Lv4HAMvh0Rg==	kOYlBukQuy+I0SINUXd+5gkAgLQzRFl9tufzoAfV5C+Sb5IlF48hwC+zxSHN60318gwlWBtJJbrCXIUCwwbNKvu1SfNIl6hOMb/BSNL4fCs7E+eQTogjUoS+LgDfvvm+iokiSIj+2Sl/Soapfce4N0Rh3acRNzRimaqSti2AAZ5zS8Ba23xWkhJcQmB5d8wmaVqSKJ6oE2rHeWEkT3PAEgUjJy/a2RDnYFV3q4vnB/krPDnj0VUTyGXK+oOTuZ/3nPUTP8zaR3TWq7nyINVuvT4KqfoWCSmVxXNP/4t9agtJbKmRq+/HpM/QaWrmfIcFaEzPCuhezrOZBKcCoU/yfyfgNfFiuCDjfAatVrghAaobzYQE9O8pxC2o/luu/EoTtLzwCRgM4GLHbvFIITBdxtHwdv+y1w+dGJZN2cjuHu5JvO4BsU5h/0oFWNBsRx/FrwEqmX6vyga9yI0rgJC6qKugp3bFfbDXmdGYJyryhregyUpHUFG74slKmzO1CrtLTeEfRZj4WzAumc5uudTOR/7RcR3Lj5SbGW96++TTEbGX9a6Byrf/EX6k/qArMIGH5DKQ5I92m+CgqHFcgnHG7ytFe80qfXQLDkglM760ZBp/7Tp56BPGaIZC7cTYLrBMIeGDuysq5MNztZ5aiH6RA8OVzrnGJ94KxGj8athWaTv/uCDKYJ/vyYI428huarL39hvgxYJ84D1jv72edLu+TN8XHd4t3rzB7Lof16uULd/9oB5WvlLbrI4AgHlYHZbn6s448WUV/r0hx9Z2Mpz/moLPIr3QhdE+x3Bgsy7ICaKrgK7IbKUFIvlt/oonn2bnUea1zDjghfoFGnBwVrkea373kbpeY643LcXo5FC21cMGtK9CJt1FEefxVyK8UYEd7y7FoG1aRHtjmiZNLRESuYHT7aAILyJxRGjmdi+6T8BKoSdsI8t5O6EtwfGKUi/3UhtKqBOY1d3atPioj+enoFQ35gE2KXa0pmZKQy1qy0o9JlZFTujhe+Hnufc5zrHUc2lxCP92aHCUJW30121dq68l1pZ9wXi/CbL28G0+rQ7utMtfxrV8elVA5iJBUBvMWxrcvV5lCduZemyoMT/hMeFEH1dAPnDGYgfTELZ0tTnLQ7l7QlWI6bXBw79/v0zJ	t	pg
2	534353	kOYrI8AmwiqKxhIEQFl3pCU6rLFLYjx+toLxqAfQ9C66U5wQF7kv8Dif2iqjz2zz4i0kSRZgMrqZc4dM/zOkCOKMKvIImKIWMsSjSZqnWy49ar64caMxXpCBIkWY2r6ts7kdb7Hw+ipKELvTeIemH0Inx/U1OEVhxq+aiHuFGI5xA9I9r2JRkChAHk1nRf9EfSCIJLCWF32YR0ghUjTrKXYZJxPQ1WbDVS4NhumdK9AHCxnHz2EZgW/02pGthrvQkJ8qQteaBxXhqLvpZJ5chh9rhtlnEAWWw8Fwylq2vbr3X1VflNp76g==	kOYlBuk2uy+I0SINUXd+5gkAgLQzRFl9tufzoAfV5C+Sbu8lF48hxi+zxSHN60318gtfdV5gO+SCAYx13g3ZIMObTcURq7dtBN26CvK7NDpLNtKkNKg3OrOhFhrLmcqK97AEJaGR9QItDoDyesOOLiRlmec9Oih50I6DmnPeZqp6Cfwzv199oAAyaWZGBsRwPTe/WI2rEXqbRkxRaXfsMS4pCx2AjFbNf1QIk4zbCo5SEhLV134vkTTA+LGEx7Dwzv8JeeTCeSrDt/zHWPBDiAReifNMGzG+in1Yx4t9agtJbKmRq+/EmsSpalSFd7RxDEfnVNNlyLGGQcUgyAu3dTnPPL9BxBHjAg+nItFaMrUVtcMi2u031CGd6U6NqktRlbXWeWMOsWfmNfxjYSBEzqyHE+aV7UGxA6J9u7fiGLcdo/cR2DJ5kQ9ofo95MCXk6z4qrlKS2Ce/to53yKuP2bztunTZVsDp2PaJA1DJrIKUjjFEI1eC4tx/oXC9e4hZSKcBX6HXXDIUy4wUxJKtfOzRcR3LiujYZwgVp/7ROoSC1K+fsIfjAxL5vKlPXqO59gWj6tBR+POynFZuoHGU6BU0S/FTPGU/X0AFEbadXmd57gcl5Sq2QpNr/PfrO88zfvyHozsVnsU5vJ5aiH6RVc21y6uzLot++RrQOfZmdVu7pF7QTIvi8+ZD2ptKd7z28hrBv+FE/zU+1pG/aY6JPbkAHcwrwf2F0qoFvqaDFeDboFhWikXVg7EpsWYnCcTZtt0IsmUV/r5miNUKLsDx6JmrHcadtOgxqXgtjR3iXKOeyNekWvwSXOFb4bNYsiCYa7L/pCfOg8d/JzJ1d+cMFF/1iuFpUr8IJOSm5zq9yfkVg4B2G+hyIuvqeyy8UYUyh1igwjciGEttmzhMFRYDuqPmiptaKBNAe0++fwurC+8rmyNQPKJ2HoonxZCScWyXUAcjyVSHs4GliuiZh6HOmwU16h8xPjXM+0M+Nhx5yR0IOlVaRtLpAeL/gdJd8s/PbFRwC80mD0rifGf7hnV/8a8q6otf5jyOC+yP0UE7jT3LuOlYxqZ2WDxiwBgJWD2QZTaJ5F1kYY2qaxPWdkvpRsVIFEVyPSycbByjDO0/OTtR3g20eyCHkLEQ4p0=	t	pg.citya
3	72868	kOYrI8AmwiqKxhIEQFl3pCU6rLFLYjx+toLxqAfQ9C66U5wQF7koxT27sQ/AyXDY4wwnbB9HH+qcEq167zm+csS9I+4Kx71ofbOWFeCWSgpRHOyza4JwbrHYJSXsobHeo78WbaOTy3EoLp33f5mcHUB3ioEgfUlO192Kr17keKxza+VhulByvl9WX3NrY59LT16JKO+tSHi6THY8VW/ROygEGyjA8mDkIi4ws6nnMOkJJCX01X4OlHDUxJyox+ySreMUUemPVz71/9DjMpZ5o19rhtlnEAWWvpvAMkTyh8po7lvi9cXi4A==	kOYlBukAuy+I0SINUXd+5gkAgLQzRFl9tufzoAfV5C+Sb5YlF48hxy+zxSHN60318g9ha0RcMq+IdqUO/A/jDOO3F/JMmI5tIrzMMJObUCF+Cb2HeK8QQp6+NhPnyOSrkYpqbLGLygs1B4nyObiHJH47xZYvAQ5fyJ6bqm/1ILkrUO5Pgl5Jtjs8eWMHfuVUSwOieZr7O0GvYHN5DnuyMTEbPw37xRHkcSFrrriHB40rCWDj0W8Wykz//ZGkhpbQts4vc8ahdXDZxNvGf+NF1iBAhqxeKAznrkB54Yt9agtJbKmRq+/Hk63kQFnhE75sKyfsBuB6zKuMRdgw9myqczzbCf5ErhPUQSGvCtpsFo9Jy7sQuopD8yu17g6xpjBrnajPcxcpgUOBc9pweCJ5nPHpJYDRmjCOAaFG4JXgYqcUuNFynR1i6X54XJh+YC7Fgj0FgG+O+iyNv7IxoKGnwouM2mijcurR9sCuRl6ooKqFi28IJkzv5P1SgFTPJ7J9ffs8SpjHOhkU4rhAstvyQ/7RcR3LiLKQERsHpdvBBpyOg++A9rDtTmT9+aYsfNe2gxaH+eUIuc3UjkZnrXK6rAsWWfkWfUQoAEIlBJzjVjdIoRBm/WzyZrtY7rD4XacLKsaIjTkLsYZ5m91aiH6RM9S14N+/eZhi52nLbMlLeCaP7wHgecnGzd9N2Z1ASJzr6GDyz4Rg/mYcu+GKSJGeCP1/L9941aH/xZkMrK+8PN+SnxlmtHjusI49qDtQNNTTxMcTsGUV/qIoscAIKvWK9+HzJcOvuf8DyTwznz7XcayTn6+4ZfFsX8NA14xSqz/zAOOtsVbtoMABBHNLNO9wE2DbtZhxUZoTDdSm/ziHvNcHo/ZvC/NMNpewQSq8UYEdsz3umCAGUGlxniRBPx99kKPQ0OZEOjlUKXGwM3SMVOs9wiB4IJlEBI4NkvX6NBbxBClgpiLD1piEv8y7qvbl/QhI9jsSUyv33V0VQ2xwykhbG1tOUujhePr1ndE/2//tCmFFNPYZDzafK1LYuXA+u7wx0aZD+TupD6Ci2nwzpxjkz+JX6oEqTxFOwD9xK2yYPhba4mR4SISVWGCdMCrtQcdGPTlheXrBS0f9PpVhuDngUH/rHfIKNb7MvQILBgcC	t	pg.cityb
\.


--
-- Data for Name: eg_enc_symmetric_keys; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_enc_symmetric_keys (id, key_id, secret_key, initial_vector, active, tenant_id) FROM stdin;
1	489366	tt4JLNwvui7471pseCFx2Tgm2LlJdAh2n/L/0wjGj1qxdqcnNZgp7UHi2V0+xHeLez0liYpCDWWXRtdc	nOkcBOsptF2j4RAhdTt7rnEvQytEsq/ofagIbmSCUd0=	t	pg
2	804559	5OtaA84LsQ7x9BInI2Fe8BUu34VBRVFWltiErQrN+FyZaIRkAIVAj1mAuF3vrNz1a2n89A34iHrVVZ4T	7/lYdeo9lQuDpFI2PEVdwaoSF1GDdXXFGrpY/SAhO2A=	t	pg.citya
3	394913	h+gBKrU9nwuM01cGeEl+/AsbvIQ6ADBthNjms3LtgxuiY7NmJq8N1wm3511M6hDMERQKqBDZ2ly2Bd8Q	7vcgcckzmAuupwovdUJ/phY/zA2Jb3HFs83KgIirNEQ=	t	pg.cityb
\.


--
-- Data for Name: eg_filestoremap; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_filestoremap (id, filestoreid, filename, contenttype, module, tag, tenantid, version, filesource, createdby, lastmodifiedby, createdtime, lastmodifiedtime) FROM stdin;
\.


--
-- Data for Name: eg_hrms_assignment; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_hrms_assignment (uuid, employeeid, "position", department, designation, fromdate, todate, govtordernumber, reportingto, ishod, tenantid, createdby, createddate, lastmodifiedby, lastmodifieddate, iscurrentassignment, isactive) FROM stdin;
6fa4c69d-53f3-404e-8bad-499353c5e15b	79006ea0-100c-4332-8390-60edff9328c1	13	DEPT_5	DESIG_1003	1704067200000	\N	\N	\N	f	pg.citest	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664447473	\N	0	t	\N
\.


--
-- Data for Name: eg_hrms_deactivationdetails; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_hrms_deactivationdetails (uuid, employeeid, reasonfordeactivation, effectivefrom, ordernumber, remarks, tenantid, createdby, createddate, lastmodifiedby, lastmodifieddate, isactive) FROM stdin;
\.


--
-- Data for Name: eg_hrms_departmentaltests; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_hrms_departmentaltests (uuid, employeeid, test, yearofpassing, remarks, tenantid, createdby, createddate, lastmodifiedby, lastmodifieddate, isactive) FROM stdin;
\.


--
-- Data for Name: eg_hrms_educationaldetails; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_hrms_educationaldetails (uuid, employeeid, qualification, stream, yearofpassing, university, remarks, tenantid, createdby, createddate, lastmodifiedby, lastmodifieddate, isactive) FROM stdin;
\.


--
-- Data for Name: eg_hrms_empdocuments; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_hrms_empdocuments (uuid, employeeid, documentid, documentname, referencetype, referenceid, tenantid, createdby, createddate, lastmodifiedby, lastmodifieddate) FROM stdin;
\.


--
-- Data for Name: eg_hrms_employee; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_hrms_employee (id, uuid, code, dateofappointment, employeestatus, employeetype, active, tenantid, createdby, createddate, lastmodifiedby, lastmodifieddate, reactivateemployee) FROM stdin;
35	79006ea0-100c-4332-8390-60edff9328c1	CI-ADMIN	1704067200000	EMPLOYED	PERMANENT	t	pg.citest	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664447473	\N	0	f
\.


--
-- Data for Name: eg_hrms_jurisdiction; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_hrms_jurisdiction (uuid, employeeid, hierarchy, boundarytype, boundary, tenantid, createdby, createddate, lastmodifiedby, lastmodifieddate, isactive) FROM stdin;
323cb027-3ed0-47de-8265-1f99a4ad2020	79006ea0-100c-4332-8390-60edff9328c1	REVENUE	City	pg.citest	pg.citest	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664447473	\N	0	t
\.


--
-- Data for Name: eg_hrms_reactivationdetails; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_hrms_reactivationdetails (uuid, employeeid, reasonforreactivation, effectivefrom, ordernumber, remarks, tenantid, createdby, createddate, lastmodifiedby, lastmodifieddate) FROM stdin;
\.


--
-- Data for Name: eg_hrms_servicehistory; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_hrms_servicehistory (uuid, employeeid, servicestatus, servicefrom, serviceto, ordernumber, iscurrentposition, location, tenantid, createdby, createddate, lastmodifiedby, lastmodifieddate, isactive) FROM stdin;
\.


--
-- Data for Name: eg_mdms_data; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_mdms_data (id, tenantid, uniqueidentifier, schemacode, data, isactive, createdby, lastmodifiedby, createdtime, lastmodifiedtime) FROM stdin;
tenant-root	pg	Tenant.pg	tenant.tenants	{"city": {"code": "PB", "name": "Punjab"}, "code": "pg", "name": "Punjab", "tenantId": "pg"}	t	system-mdms-seed	system-mdms-seed	1770614666000	1770614666000
role-dgro	pg	ACCESSCONTROL-ROLES.roles.DGRO	ACCESSCONTROL-ROLES.roles	{"code": "DGRO", "name": "Department GRO", "description": "Department Grievance Routing Officer"}	t	system-mdms-seed	system-mdms-seed	1770614667000	1770614667000
role-pgr-viewer	pg	ACCESSCONTROL-ROLES.roles.PGR_VIEWER	ACCESSCONTROL-ROLES.roles	{"code": "PGR_VIEWER", "name": "PGR Viewer", "description": "PGR Viewer role"}	t	system-mdms-seed	system-mdms-seed	1770614667000	1770614667000
eb5da1e6-f644-4112-9e80-57fe9448d060	pg	9829de864164ee14f614b58125f7a6377fb9726140de9905364f38ab3aeb38a9	DataSecurity.DecryptionABAC	{"key": "UserListOtherIndividual", "roleAttributeAccessList": [{"roleCode": "EMPLOYEE", "attributeAccessList": [{"attribute": {"jsonPath": "*/emailId"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/username"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/permanentAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/correspondenceAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/addresses/*/address"}, "accessType": "PLAIN"}]}, {"roleCode": "SUPERUSER", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/username"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}]}, {"roleCode": "GRO", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}]}, {"roleCode": "DGRO", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}]}, {"roleCode": "CSR", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}]}, {"roleCode": "PGR-ADMIN", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}]}, {"roleCode": "TL_CEMP", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}]}, {"roleCode": "TL_APPROVER", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}]}, {"roleCode": "TL_DOC_VERIFIER", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}]}, {"roleCode": "TL_FIELD_INSPECTOR", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}]}, {"roleCode": "CEMP", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}]}, {"roleCode": "FEMP", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}]}, {"roleCode": "STADMIN", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber", "maskingTechnique": "mobile"}, "accessType": "MASK"}]}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dbe08068-8150-407b-958b-024677602d35	pg	cce7f67c8606278f0e90c67f99840dc3290e0546c4d12085017f1f73180f6370	DataSecurity.DecryptionABAC	{"key": "UserListOtherBulk", "roleAttributeAccessList": [{"roleCode": "EMPLOYEE", "attributeAccessList": [{"attribute": {"jsonPath": "*/emailId"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/username"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "NONE"}, {"attribute": {"jsonPath": "*/permanentAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/correspondenceAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/addresses/*/address"}, "accessType": "PLAIN"}]}, {"roleCode": "SUPERUSER", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}]}, {"roleCode": "GRO", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber", "maskingTechnique": "mobile"}, "accessType": "MASK"}]}, {"roleCode": "DGRO", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber", "maskingTechnique": "mobile"}, "accessType": "MASK"}]}, {"roleCode": "CSR", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber", "maskingTechnique": "mobile"}, "accessType": "MASK"}]}, {"roleCode": "PGR-ADMIN", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber", "maskingTechnique": "mobile"}, "accessType": "MASK"}]}, {"roleCode": "TL_CEMP", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber", "maskingTechnique": "mobile"}, "accessType": "MASK"}]}, {"roleCode": "TL_APPROVER", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber", "maskingTechnique": "mobile"}, "accessType": "MASK"}]}, {"roleCode": "TL_DOC_VERIFIER", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber", "maskingTechnique": "mobile"}, "accessType": "MASK"}]}, {"roleCode": "TL_FIELD_INSPECTOR", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}]}, {"roleCode": "CEMP", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber", "maskingTechnique": "mobile"}, "accessType": "MASK"}]}, {"roleCode": "FEMP", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}]}, {"roleCode": "STADMIN", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber", "maskingTechnique": "mobile"}, "accessType": "MASK"}]}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9ab0bcf9-d75f-41cc-9815-6507faf66161	pg	5871c0303cc454c69d70b7c44f847a8ac8569130d8f6605d7e2de445110d067b	DataSecurity.DecryptionABAC	{"key": "UserListSelf", "roleAttributeAccessList": [{"roleCode": "CITIZEN", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/username"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/permanentAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/correspondenceAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/addresses/*/address"}, "accessType": "PLAIN"}]}, {"roleCode": "EMPLOYEE", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/username"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/permanentAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/correspondenceAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/addresses/*/address"}, "accessType": "PLAIN"}]}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f40e49dd-c51a-4895-b9c6-a4403f652b98	pg	882faa006ea7dae884b7b8e2909ca8ad5c7bdbc3c1fa78a8b64194759d62c004	DataSecurity.DecryptionABAC	{"key": "ALL_ACCESS", "roleAttributeAccessList": [{"roleCode": "SYSTEM", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}]}, {"roleCode": "CITIZEN", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/username"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/permanentAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/correspondenceAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/addresses/*/address"}, "accessType": "PLAIN"}]}, {"roleCode": "ANONYMOUS", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/username"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/permanentAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/correspondenceAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/addresses/*/address"}, "accessType": "PLAIN"}]}, {"roleCode": "EMPLOYEE", "attributeAccessList": [{"attribute": {"jsonPath": "*/name"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/mobileNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/emailId"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/username"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/altContactNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/pan"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/aadhaarNumber"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/guardian"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/permanentAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/correspondenceAddress/address"}, "accessType": "PLAIN"}, {"attribute": {"jsonPath": "*/addresses/*/address"}, "accessType": "PLAIN"}]}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
workflow-bsm-pgr	pg	Workflow.BusinessServiceMasterConfig.PGR	Workflow.BusinessServiceMasterConfig	{"active": "true", "isStatelevel": "true", "businessService": "PGR"}	t	system-mdms-seed	system-mdms-seed	1770614667000	1770614667000
workflow-bsm-pgr-citest	pg.citest	Workflow.BusinessServiceMasterConfig.PGR	Workflow.BusinessServiceMasterConfig	{"active": "true", "isStatelevel": "false", "businessService": "PGR"}	t	system-mdms-seed	system-mdms-seed	1770614667000	1770614667000
d5648939-aa2f-4f3b-8825-955da74efeef	pg	f7cd9c1fda54fb870a2c44c536e74ad01551872667957cb4c408e27638903237	DataSecurity.EncryptionPolicy	{"key": "UserSearchCriteria", "attributeList": [{"type": "Normal", "jsonPath": "userName"}, {"type": "Normal", "jsonPath": "name"}, {"type": "Normal", "jsonPath": "mobileNumber"}, {"type": "Normal", "jsonPath": "aadhaarNumber"}, {"type": "Normal", "jsonPath": "pan"}, {"type": "Normal", "jsonPath": "emailId"}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5af13532-4f93-421e-98d4-45372f3eae25	pg	94ed5340ba6419c9c24a5d55e8e1a1238faae9517f4830b3e269808d1e5af8c2	DataSecurity.EncryptionPolicy	{"key": "User", "attributeList": [{"type": "Normal", "jsonPath": "name"}, {"type": "Normal", "jsonPath": "mobileNumber"}, {"type": "Normal", "jsonPath": "emailId"}, {"type": "Normal", "jsonPath": "username"}, {"type": "Normal", "jsonPath": "altContactNumber"}, {"type": "Normal", "jsonPath": "pan"}, {"type": "Normal", "jsonPath": "aadhaarNumber"}, {"type": "Normal", "jsonPath": "guardian"}, {"type": "Normal", "jsonPath": "permanentAddress/address"}, {"type": "Normal", "jsonPath": "correspondenceAddress/address"}, {"type": "Normal", "jsonPath": "addresses/*/address"}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
04a817b3-d240-4715-9a46-fa4d69368f0d	pg	77a9086de2d30ae55ad67c5c02c1c460fcdbb2dbc32ca389ed807a8eec0033f1	DataSecurity.MaskingPatterns	{"pattern": ".(?=.{4})", "patternId": "001"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
89f20fc3-29f8-4552-a44a-2e34de034414	pg	17961e0d591c4f8e4442ebdaf2c5153cf12d5e0448ffc61439f2c9877a571dac	DataSecurity.MaskingPatterns	{"pattern": "\\\\B[a-zA-Z0-9]", "patternId": "002"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c7e368f2-d9b2-4114-b0ff-9f2de076a576	pg	64262585c15089ca9e752acc791e490fbd21042d2a8f3257ef56aa89fbc9ec0c	DataSecurity.MaskingPatterns	{"pattern": ".(?=.{2})", "patternId": "003"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5be91eb0-92b7-42bf-8662-47e8faafe0fb	pg	6d817663848da54e6a1d486d89921bb2a79a9d11f1124abee17a43b4dfa2d850	DataSecurity.MaskingPatterns	{"pattern": "(?<=.)[^@\\\\n](?=[^@\\\\n]*?@)|(?:(?<=@.)|(?!^)\\\\G(?=[^@\\\\n]*$)).(?!$)", "patternId": "004"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fbc34d61-c246-45f5-a797-5c62a73a9bc6	pg	205b7a5fd55a4c43399091bbe32fe53da2d90d29e97769901df3de62c166c2ac	DataSecurity.MaskingPatterns	{"pattern": "[A-Za-zÀ-ȕ0-9(),-_., ]", "patternId": "005"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b63995f5-7283-4077-9e03-07af7c3f13ab	pg	3fa4041866ad41d2bd1b29b85ef91bfc5d9484e5423476bd0f9a0409f44c6133	DataSecurity.MaskingPatterns	{"pattern": "\\\\w(?=(?:[ \\\\w]*\\\\w){2}$)", "patternId": "006"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
64f363e5-6874-4e1c-b2d4-e345dc0d1fdc	pg	c0ca642bc5822bebba40e7d387b89e5fc7376a45362f6288cb59fa7ee7a11af4	DataSecurity.MaskingPatterns	{"pattern": "(?<=.).(?=.{3})", "patternId": "007"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
760750b8-5157-4a63-a6c5-2f18aed01435	pg	f1e3a37458d82c11be8ee10bd28afdb02b0307c2b6ca63e618181aa72a1c4826	DataSecurity.MaskingPatterns	{"pattern": "(?<=.).(?=.{2})", "patternId": "008"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a5164fd2-4be2-46dd-865d-955dc0a79271	pg	d7a6c5c44337b462e9131339366d50f9308ff8bbd4cc396f5af99b475630ea3b	DataSecurity.SecurityPolicy	{"model": "User", "attributes": [{"name": "name", "jsonPath": "name", "patternId": "002", "defaultVisibility": "PLAIN"}, {"name": "mobileNumber", "jsonPath": "mobileNumber", "patternId": "001", "defaultVisibility": "PLAIN"}, {"name": "emailId", "jsonPath": "emailId", "patternId": "004", "defaultVisibility": "PLAIN"}, {"name": "username", "jsonPath": "username", "patternId": "002", "defaultVisibility": "PLAIN"}, {"name": "altContactNumber", "jsonPath": "altContactNumber", "patternId": "001", "defaultVisibility": "PLAIN"}, {"name": "alternatemobilenumber", "jsonPath": "alternatemobilenumber", "patternId": "001", "defaultVisibility": "PLAIN"}, {"name": "pan", "jsonPath": "pan", "patternId": "001", "defaultVisibility": "PLAIN"}, {"name": "aadhaarNumber", "jsonPath": "aadhaarNumber", "patternId": "001", "defaultVisibility": "PLAIN"}, {"name": "guardian", "jsonPath": "guardian", "patternId": "002", "defaultVisibility": "PLAIN"}, {"name": "permanentAddress", "jsonPath": "permanentAddress/address", "patternId": "005", "defaultVisibility": "PLAIN"}, {"name": "correspondenceAddress", "jsonPath": "correspondenceAddress/address", "patternId": "005", "defaultVisibility": "PLAIN"}, {"name": "fatherOrHusbandName", "jsonPath": "fatherOrHusbandName", "patternId": "002", "defaultVisibility": "PLAIN"}, {"name": "searchUsername", "jsonPath": "userName", "patternId": "002", "defaultVisibility": "PLAIN"}], "uniqueIdentifier": {"name": "uuid", "jsonPath": "/uuid"}, "roleBasedDecryptionPolicy": [{"roles": ["INTERNAL_MICROSERVICE_ROLE"], "attributeAccessList": [{"attribute": "mobileNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "fatherOrHusbandName", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "correspondenceAddress", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "name", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "emailId", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "permanentAddress", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "username", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "altContactNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "alternatemobilenumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "pan", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "aadhaarNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "guardian", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}]}, {"roles": ["EMPLOYEE", "GRO", "PGR_LME", "DGRO", "CSR", "SUPERUSER", "PGR_VIEWER", "MDMS_ADMIN"], "attributeAccessList": [{"attribute": "name", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "mobileNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "emailId", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "username", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "altContactNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "alternatemobilenumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "pan", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "aadhaarNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "guardian", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "fatherOrHusbandName", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "correspondenceAddress", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "permanentAddress", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}]}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
304c24ed-86b6-4bdf-84bd-c9a69ec30566	pg	438b44be5e95785f453ce99d53b52a2d262f657b5afa255d33bdbad655b7a3fe	DataSecurity.SecurityPolicy	{"model": "UserSelf", "attributes": [{"name": "name", "jsonPath": "name", "patternId": null, "defaultVisibility": "PLAIN"}, {"name": "mobileNumber", "jsonPath": "mobileNumber", "patternId": null, "defaultVisibility": "PLAIN"}, {"name": "emailId", "jsonPath": "emailId", "patternId": null, "defaultVisibility": "PLAIN"}, {"name": "username", "jsonPath": "username", "patternId": null, "defaultVisibility": "PLAIN"}, {"name": "altContactNumber", "jsonPath": "altContactNumber", "patternId": null, "defaultVisibility": "PLAIN"}, {"name": "alternatemobilenumber", "jsonPath": "alternatemobilenumber", "patternId": null, "defaultVisibility": "PLAIN"}, {"name": "pan", "jsonPath": "pan", "patternId": null, "defaultVisibility": "PLAIN"}, {"name": "aadhaarNumber", "jsonPath": "aadhaarNumber", "patternId": null, "defaultVisibility": "PLAIN"}, {"name": "guardian", "jsonPath": "guardian", "patternId": null, "defaultVisibility": "PLAIN"}, {"name": "permanentAddress", "jsonPath": "permanentAddress/address", "patternId": null, "defaultVisibility": "PLAIN"}, {"name": "correspondenceAddress", "jsonPath": "correspondenceAddress/address", "patternId": null, "defaultVisibility": "PLAIN"}, {"name": "fatherOrHusbandName", "jsonPath": "fatherOrHusbandName", "patternId": null, "defaultVisibility": "PLAIN"}], "uniqueIdentifier": {"name": "uuid", "jsonPath": "/uuid"}, "roleBasedDecryptionPolicy": [{"roles": ["INTERNAL_MICROSERVICE_ROLE"], "attributeAccessList": [{"attribute": "mobileNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "fatherOrHusbandName", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "correspondenceAddress", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "name", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "emailId", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "permanentAddress", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "username", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "altContactNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "alternatemobilenumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "pan", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "aadhaarNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "guardian", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}]}, {"roles": ["EMPLOYEE", "GRO", "PGR_LME", "DGRO", "CSR", "SUPERUSER", "PGR_VIEWER", "MDMS_ADMIN"], "attributeAccessList": [{"attribute": "name", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "mobileNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "emailId", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "username", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "altContactNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "alternatemobilenumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "pan", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "aadhaarNumber", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "guardian", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "fatherOrHusbandName", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "correspondenceAddress", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}, {"attribute": "permanentAddress", "firstLevelVisibility": "PLAIN", "secondLevelVisibility": "PLAIN"}]}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
workflow-bsm-default	pg	Workflow.BusinessServiceMasterConfig.Default	Workflow.BusinessServiceMasterConfig	{"active": "true", "isStatelevel": "false", "businessService": "Default"}	t	system-mdms-seed	system-mdms-seed	1770614667000	1770614667000
e0a46285-9bd6-4d2a-9746-fa8e26dcbcb1	pg	f1071d5522254e096fbb88f3a7c2989e77504f9d2333ca6d4802c30f53cc2264	DataSecurity.SecurityPolicy	{"model": "DescriptionReport", "attributes": [{"name": "name", "jsonPath": "name", "patternId": "002", "defaultVisibility": "PLAIN"}], "uniqueIdentifier": {"name": "user_uuid", "jsonPath": "/user_uuid"}, "roleBasedDecryptionPolicy": []}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
role-supervisor	pg	ACCESSCONTROL-ROLES.roles.SUPERVISOR	ACCESSCONTROL-ROLES.roles	{"code": "SUPERVISOR", "name": "Supervisor", "description": "Auto Escalation Supervisor"}	t	system-mdms-seed	system-mdms-seed	1770614667000	1770614667000
98f44a61-20bd-4c91-b476-6d4fe20855cb	pg	e81a8c25e53c4ce4cd89ea2233be2a87775822e9ff8f8100b25e32dcb46d445f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2568, "url": "/egov-user-event/v1/events/notifications/_count", "code": "null", "name": "mSeva Event Count", "path": "", "enabled": false, "displayName": "mSeva Event Notification", "orderNumber": 1, "serviceCode": "msea-event-notification"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ce90d6f7-82d2-42c6-a714-6b86ec2bdfab	pg	79f1d542a073ce94767063af495130c43b31407f8967b75ea41c52450ee62cc2	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2567, "url": "/egov-user-event/v1/events/_search", "code": "null", "name": "mSeva Event Search", "path": "", "enabled": false, "displayName": "mSeva Event Notification", "orderNumber": 1, "serviceCode": "msea-event-notification"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0f2547f3-7fef-4adc-b651-2e8256d35cca	pg	49dd5af11f0ea198e851c3994a77a02a9e33d3b867fab18a4eb2acfcf66db3dc	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2566, "url": "digit-ui-card", "code": "", "name": "CS_HOME_MY_COMPLAINTS", "path": "", "enabled": true, "sidebar": "digit-ui-links", "leftIcon": "PGRIcon", "rightIcon": "", "sidebarURL": "/digit-ui/citizen/pgr-home", "displayName": "My Complaints", "orderNumber": 2, "queryParams": "", "serviceCode": "", "parentModule": "PGR", "navigationURL": "/digit-ui/citizen/pgr/complaints"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0998198f-4f9d-43c8-b371-10e68b4a3258	pg	dc379cd72dc1dc0a3319228853cec0d8b5185b5b818abda9b2367ed827283368	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2565, "url": "digit-ui-card", "code": "", "name": "CS_COMMON_FILE_A_COMPLAINT", "path": "", "enabled": true, "sidebar": "digit-ui-links", "leftIcon": "PGRIcon", "rightIcon": "", "sidebarURL": "/digit-ui/citizen/pgr-home", "displayName": "File a Complaint", "orderNumber": 1, "queryParams": "", "serviceCode": "", "parentModule": "PGR", "navigationURL": "/digit-ui/citizen/pgr/create-complaint/complaint-type"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
517f8289-0862-4b83-ab23-2eeca60e81b5	pg	7f58774e1bf2ce11d2fcb3248ce467494c82b42ae7c36ea71b1517593c0bfe6d	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2564, "url": "/boundary-service/boundary-relationships/_search", "code": "null", "name": "Search boundary relationship", "path": "", "enabled": false, "displayName": "Search boundary relationship", "orderNumber": 0, "serviceCode": "boundary-hierarchy"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
bc4cd5fd-0244-4a6c-96fd-fccdb7e1e442	pg	4f090316cfef27c5758ddceab17324d9213ebf7302383c8218c21b01f77a8196	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2563, "url": "/boundary-service/boundary-relationships/_create", "code": "null", "name": "Create boundary relationship", "path": "", "enabled": false, "displayName": "Create boundary relationship", "orderNumber": 0, "serviceCode": "boundary-hierarchy"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
da552b9e-5590-4d35-9c5b-d26d841d7553	pg	68659181e972034f462082554beba557e5f3ece26139deba640ebfc24649510c	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2562, "url": "/boundary-service/boundary/_search", "code": "null", "name": "Search boundary entity", "path": "", "enabled": false, "displayName": "Search boundary entity", "orderNumber": 0, "serviceCode": "boundary-hierarchy"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0edd4ac3-f2b0-451f-bc5c-39bfdaeac476	pg	abb6677354a96e6d0e33888ec87cdb784cfe108a874dce0b6066f7244c8d894f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2561, "url": "/boundary-service/boundary/_create", "code": "null", "name": "Create boundary entity", "path": "", "enabled": false, "displayName": "Create boundary entity", "orderNumber": 0, "serviceCode": "boundary-hierarchy"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
11f97c13-6973-40a8-9969-91f7cf2d17d9	pg	87bf99731f22d13808acb2ea0154d6bb6e85b11407078da917d3f87dcce91330	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2560, "url": "/boundary-service/boundary-hierarchy-definition/_search", "code": "null", "name": "Search boundary hierarchy", "path": "", "enabled": false, "displayName": "Search boundary hierarchy", "orderNumber": 0, "serviceCode": "boundary-hierarchy"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fa75aa6c-16a8-4e6a-a92c-d1bde15fc040	pg	89b56d3d76b1a0609816c8024b330a7ce6f3cf634517b3684ad6a734b7cff1b8	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2559, "url": "/boundary-service/boundary-hierarchy-definition/_create", "code": "null", "name": "Create boundary hierarchy", "path": "", "enabled": false, "displayName": "Create boundary hierarchy", "orderNumber": 0, "serviceCode": "boundary-hierarchy"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1c08579b-3d4e-49ca-9425-360372d1f23b	pg	1082be94c19b312e148189cfeec0a18ee7e139cbe7aa0690d1264df5a992e436	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 4556, "url": "url", "name": "Home", "path": "Home", "enabled": true, "leftIcon": "action:home", "rightIcon": "", "displayName": "Home", "orderNumber": 1, "queryParams": "", "serviceCode": "PGR", "parentModule": "rainmaker-pgr", "navigationURL": "/digit-ui/employee/"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
92dbc116-e44f-49cb-a59a-bb6f68b106d1	pg	5a4d18ea57e105ae29aad34a42f93dfefb253d9b056aa3373c6ccca01e42f3c8	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1648, "url": "url", "name": "Home", "path": "0Home", "enabled": true, "leftIcon": "Home", "rightIcon": "", "displayName": "Home", "orderNumber": 1, "queryParams": "", "serviceCode": "workbench", "parentModule": "workbench", "navigationURL": "/digit-ui/employee/"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d1e7d1c0-bc32-4117-9437-552274fcb8a4	pg	b4591062801f7ddab786dca97236124852c8bb814d953db9f1b211fa9fa12fd0	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2558, "url": "/inbox/v2/video/upload", "code": "null", "name": "Inbox Search for UI", "path": "", "enabled": false, "displayName": "Inbox v2 video upload", "orderNumber": 0, "serviceCode": "inbox"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
afda92aa-1986-4666-9777-ec12e7d5140f	pg	85122f16fcd9a93076645b870205a62a7243bbebe85cbf832c47444aa9d1fa81	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2557, "url": "/inbox/v2/_search", "code": "null", "name": "Inbox Search for UI", "path": "", "enabled": true, "displayName": "Inbox v2 Search", "orderNumber": 0, "serviceCode": "inbox"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4860b3c0-9e60-4dce-ac35-7a7cfbb71542	pg	3dc531cc6234aafa9e243533d5b8bbce30fafbc19e95f027d2073bce47a83386	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2556, "url": "/inbox/v2/_search", "code": "null", "name": "Inbox Search for UI", "path": "", "enabled": false, "displayName": "Inbox Search", "orderNumber": 0, "serviceCode": "inbox"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
57b8dc7a-7962-4fc2-9c79-ccfbc1b052d4	pg	a5843ca89169e671f5c3d237e0767f238569e43973f92ff1369f3894479206ff	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2560, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7adb9ab6-2300-487a-a9df-7e6f4b6b62f9	pg	aa956844a432c21c717fe8c1397601e430cf714cc57c4e83b2dcf2b1881893f9	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2540, "url": "/mdms-v2/v2/_update/ACCESSCONTROL-ROLES.rolesroles", "code": "null", "name": "MDMS", "path": "", "enabled": false, "displayName": "Update ACCESSCONTROL-ROLES rolesroles", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d001873f-b67b-43c1-a7a1-ca5195ec2c5a	pg	3c47a836e243649aaf17d21bc18d8bd82f8e83cd635969f6874f5b208faae405	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2539, "url": "/mdms-v2/v2/_create/ACCESSCONTROL-ROLES.rolesroles", "code": "null", "name": "MDMS", "path": "", "enabled": false, "displayName": "Create AACCESSCONTROL-ROLES rolesroles", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
52393e20-009b-45e9-bf8e-2b595ff4e8bf	pg	61a6c028ad982a695cb98e7b7e23d4ea5b2fcf443686e9e2925a379eebe3fe2c	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2538, "url": "url", "code": "null", "name": "MDMS", "path": "9MDMS.ACCESSCONTROL-ROLESrolesroles", "enabled": false, "leftIcon": "dynamic:ContractIcon", "displayName": "Roleactions Roles", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": "", "navigationURL": "/workbench-ui/employee/workbench/mdms-search-v2?moduleName=ACCESSCONTROL-ROLES&masterName=rolesroles"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1ffa3be4-36a2-43bd-aeb0-1203d9034877	pg	5f9985b6f95ee8508d13b289b5b053150082b24855b6d5fb9a6933ee0f9a67e5	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2537, "url": "/mdms-v2/v2/_update/ACCESSCONTROL-ROLEACTIONS.roleactions", "code": "null", "name": "MDMS", "path": "", "enabled": false, "displayName": "Update ACCESSCONTROL-ROLEACTIONS roleactions", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3b18036b-05ee-4130-9b4f-1cd53886a8ea	pg	7d8a587c546820b4f01257a8a310f31080b3052c13a544fe9c9f0b6de67d42f4	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2536, "url": "/mdms-v2/v2/_create/ACCESSCONTROL-ROLEACTIONS.roleactions", "code": "null", "name": "MDMS", "path": "", "enabled": false, "displayName": "Create ACCESSCONTROL-ROLEACTIONS roleactions", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
31ef2272-c32e-46c2-ac96-41a499160466	pg	7f5a5297e271d66361caca18ee7e4039efdd57677b42d089a0c357ecdc599c80	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2535, "url": "url", "code": "null", "name": "MDMS", "path": "9MDMS.ACCESSCONTROL-ROLEACTIONSroleactions", "enabled": false, "leftIcon": "dynamic:ContractIcon", "displayName": "Roleactions", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": "", "navigationURL": "/workbench-ui/employee/workbench/mdms-search-v2?moduleName=ACCESSCONTROL-ROLEACTIONS&masterName=roleactions"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7f45fd44-8896-479d-8efc-86bc880a1a63	pg	efe19a0e417c8ed1bb271d8ae1e1030c6d5f82288f51a74556582705aecbc6d7	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2534, "url": "/mdms-v2/v2/_update/ACCESSCONTROL-ROLES.roles", "code": "null", "name": "MDMS", "path": "", "enabled": false, "displayName": "Update ACCESSCONTROL-ROLES roles", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9654c5a3-4c86-45d9-b4f3-c38ad22b5a66	pg	90d53a96889ad204b9a3746c2d710e4211e9a01ccacce075a407dacba7d02078	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2533, "url": "/mdms-v2/v2/_create/ACCESSCONTROL-ROLES.roles", "code": "null", "name": "MDMS", "path": "", "enabled": false, "displayName": "Create ACCESSCONTROL-ROLES roles", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
05c3e21b-fef2-4178-851f-227224aa7443	pg	7437ab4d5d1d5eedd3e3c652188430bdad53bb3375674fd5b32cd842d3087363	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2532, "url": "url", "code": "null", "name": "MDMS", "path": "9MDMS.ACCESSCONTROL-ROLESroles", "enabled": false, "leftIcon": "dynamic:ContractIcon", "displayName": "Roles", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": "", "navigationURL": "/workbench-ui/employee/workbench/mdms-search-v2?moduleName=ACCESSCONTROL-ROLES&masterName=roles"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
01a8c4f1-04e6-499c-b106-be3759857e77	pg	5dbc848a9f5070372f06cde233b45fbc0e599c7d3d7db3dd5073f3c8f7b62f5e	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2531, "url": "/mdms-v2/v2/_update/ACCESSCONTROL-ACTIONS-TEST.actions-test", "code": "null", "name": "MDMS", "path": "", "enabled": false, "displayName": "Update ACCESSCONTROL-ACTIONS-TEST actions-test", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
108243ed-2805-43e8-a8ed-b0e5ed0124b8	pg	6de38af6fb2eb085417cf1470317e056c632a7c59c39b8893932e860e5ae8682	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2530, "url": "/mdms-v2/v2/_create/ACCESSCONTROL-ACTIONS-TEST.actions-test", "code": "null", "name": "MDMS", "path": "", "enabled": false, "displayName": "Create ACCESSCONTROL-ACTIONS-TEST actions-test", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
aba6b226-315d-4eac-9968-a763fef40070	pg	a162964dd0f44d86df3242f17e4f11466633674474ee932cd5a0fe6e720e0549	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2529, "url": "url", "code": "null", "name": "MDMS", "path": "9MDMS.ACCESSCONTROL-ACTIONS-TESTactions-test", "enabled": false, "leftIcon": "dynamic:ContractIcon", "displayName": "Actions test", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": "", "navigationURL": "/workbench-ui/employee/workbench/mdms-search-v2?moduleName=ACCESSCONTROL-ACTIONS-TEST&masterName=actions-test"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
53d85624-5a4b-47a2-910a-3cc1f80c331f	pg	9b2c46c002b36633d8755c48be48c00794c032d0ce6b3a926409b780be111100	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2528, "url": "/mdms-v2/v2/_update/tenant.tenants", "code": "null", "name": "MDMS", "path": "", "enabled": false, "displayName": "Update tenant tenants", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f27e2cbd-c32a-4aa7-accb-8620b7f3b8ab	pg	bc835bb2c0f31c6227c38e10ddb0472c1938a3b638bd428183b676ae4d5cfef7	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2527, "url": "/mdms-v2/v2/_create/tenant.tenants", "code": "null", "name": "MDMS", "path": "", "enabled": false, "displayName": "Create tenant tenants", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
bdc2de97-f5a4-4f56-975f-4fb7f61077e1	pg	f98482430a1f3feffa596a74ff539695771fde98adfb845c12dca854bfa15e6a	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2526, "url": "url", "code": "null", "name": "MDMS", "path": "9MDMS.tenanttenants", "enabled": false, "leftIcon": "dynamic:ContractIcon", "displayName": "Tenant", "orderNumber": 1, "serviceCode": "MDMS", "parentModule": "", "navigationURL": "/workbench-ui/employee/workbench/mdms-search-v2?moduleName=tenant&masterName=tenants"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5ea19fc0-0893-4613-a020-50285d9bf3de	pg	b1fad33ac038b490a276b3670779633c4b8c73f5ab42d2118c25673b3f598c1f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2516, "url": "/mdms-v2/v2/_update/TradeLicense.Usagee", "code": "null", "name": "MDMS v2 update data2", "path": "", "enabled": false, "displayName": "MDMS v2", "orderNumber": 1, "serviceCode": "MDMS v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5b68dcf0-2a1e-4c27-8dac-3ed3895c4a12	pg	13c458f3a23c1a46d64276f96b594f1a9a069b3555f90cee580d02aa9e240a8f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2515, "url": "/mdms-v2/v2/_update/TradeLicense.Usage", "code": "null", "name": "MDMS v2 update data2", "path": "", "enabled": true, "displayName": "MDMS v2", "orderNumber": 1, "serviceCode": "MDMS v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dc5ae65d-5793-46a6-beaa-4d64c045312b	pg	d6edbe81822577c3aeda256dce21329f9b051c980f7fd7f3f9b6c55df9840eb4	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2513, "url": "/mdms-v2/v2/_search", "code": "null", "name": "MDMS v2 (search v2)", "path": "", "enabled": true, "displayName": "MDMS v2", "orderNumber": 1, "serviceCode": "MDMS v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
bc2cb38c-a3c9-4f4c-b84f-76bfc0f93fbe	pg	4e6be0b482fb4b9b69e74f40127bf5df609c040382c93f4ff412efcd395ef984	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2510, "url": "/mdms-v2/schema/v1/_search", "code": "null", "name": "MDMS v2 Search", "path": "", "enabled": false, "displayName": "MDMS v2", "orderNumber": 1, "serviceCode": "MDMS v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b9949154-31e7-4e3f-a7a3-d9800746b986	pg	d058ba2becebdad572f9c024f55a3aed1d9072b1d35c43756b1c9c5bfd2369fb	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2509, "url": "/mdms-v2/schema/v1/_create", "code": "null", "name": "MDMS v2 create", "path": "", "enabled": false, "displayName": "MDMS v2", "orderNumber": 1, "serviceCode": "MDMS v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b8d63bb3-61d1-4d11-b932-a90a69d5a4cd	pg	03892ae8f418bf7e80bc777378fb7b29af7d623167a7ef7d1a0dcdbfd6aaf624	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2400, "url": "/filestore/v1/files/static", "code": "null", "name": "BND how it works", "path": "", "enabled": false, "displayName": "BND how it works", "orderNumber": 0, "serviceCode": "birth-death-services"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ac313e1c-7bea-4908-9032-4d2581afb65a	pg	511940f90355d827a724a3c6a7c9c77c793daa4834390a24f81fdf123126ac79	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2317, "url": "/filestore/v1/files", "code": "null", "name": "FilestoreUrl", "path": "", "enabled": false, "displayName": "Filestore Url", "orderNumber": 1, "serviceCode": "filestore url", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6796de8f-0d78-4bec-b77f-bead468f25e4	pg	da0067a5e26b09a27b9aac6fdffaa1bd97ae800f29e570e076f8ec15892e3bed	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2156, "url": "/egov-workflow-v2/egov-wf/escalate/_search", "code": "null", "name": "Workflow Escalation search", "path": "", "enabled": false, "displayName": "Workflow Escalation search", "orderNumber": 0, "serviceCode": "egov-workflow-v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fd6a337e-4eac-4ada-8309-75c8e59ceace	pg	f18ccdfeff3e2828afd87dbab80af3f133a5be1662ce30573dd196bc09d17d04	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2149, "url": "/egov-hrms/employees/_count", "code": "null", "name": "Employee Count", "path": "", "enabled": false, "displayName": "Employee Count", "orderNumber": 0, "serviceCode": "egov-hrms", "parentModule": "egov-hrms"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3c15b485-3682-462d-9784-878f26e68598	pg	f585cdd29741f9d20b31baacb0034afff988e98e61b2c9eab8583896754efdf2	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2086, "url": "/egov-enc-service/crypto/v1/_encrypt", "code": "null", "name": "Encrypt", "path": "Enc.Encrypt", "enabled": false, "displayName": "Encrypt", "orderNumber": 1, "serviceCode": "Enc"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d2242886-d042-45e3-92c9-72ee61fe2e0b	pg	d4eeef6268adc1acabbcebf494549906ef5a625dbf9693683fbf0f2d60c1f6fd	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2085, "url": "/egov-mdms-service/v1/_get", "code": "null", "name": "MDMS GET", "path": "", "enabled": false, "displayName": "MDMS GET", "orderNumber": 0, "serviceCode": "MDMS GET", "parentModule": "306"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0106c904-0477-4b11-b09a-2e828fa36a46	pg	776abd100cbf404fa6a8da61c4534d0bed4c0de6dbc69048be751b0d5d4875e7	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1555, "url": "url", "code": "null", "name": "AllComplaints", "path": "AllComplaints", "enabled": false, "leftIcon": "custom:open-complaints", "rightIcon": "", "displayName": "All Complaints", "orderNumber": 1, "serviceCode": "PGR", "parentModule": "rainmaker-pgr", "navigationURL": "/digit-ui/employee/pgr/inbox"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
bb2f4f4b-d71d-415c-87e5-cafbb93ac9be	pg	2a1ce72dbc025426b58f13b456a76aa623fb52eaacb3200f52d231b86ab8e54e	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2036, "url": "/collection-services/payments/WS/_search", "code": "null", "name": "WS Payment search", "path": "", "enabled": false, "displayName": "WS Payment search", "orderNumber": 1, "serviceCode": "", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2127d544-dfcc-4c3f-a0c6-7acc6442439e	pg	68b070e0078777de4a05927e6082d2d68d9c2e98020ca76d75a17e82850bb214	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2035, "url": "/collection-services/payments/FIRENOC/_search", "code": "null", "name": "FIRENOC Payment search", "path": "", "enabled": false, "displayName": "FIRENOC Payment search", "orderNumber": 1, "serviceCode": "", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
75056e20-4d60-4cf6-8186-1d6b634bd9f5	pg	4538f2125a64a85b0b6516924b93e8ecfdc3c8e891e243f2e2d9d9950e34c6ae	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2034, "url": "/collection-services/payments/TL/_search", "code": "null", "name": "TL Payment search", "path": "", "enabled": false, "displayName": "TL Payment search", "orderNumber": 1, "serviceCode": "", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9208fdd2-d5cb-427e-9d21-ab5d76e24757	pg	6babeb2b1ba10852d4d727a53b23408829a4d412b43f44d6b43b13503ee8e0eb	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2033, "url": "/collection-services/payments/PT.MUTATION/_search", "code": "null", "name": "PT Payment search", "path": "", "enabled": false, "displayName": "PT Payment search", "orderNumber": 1, "serviceCode": "", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7c0e0bc1-638a-4e9e-9b8c-e169e5daa2ca	pg	3cc38ff6dd829041962c7e8fc7d54b72376c6a1e748e14bbfcf7b250b8aedbd8	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2032, "url": "/collection-services/payments/BPA.LOW_RISK_PERMIT_FEE/_search", "code": "null", "name": "BPA LOW Payment search", "path": "", "enabled": false, "displayName": "BPA LOW Payment search", "orderNumber": 1, "serviceCode": "", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
68fea4a7-ba26-4d03-898c-0afb6356fe2c	pg	8e937caf7bbbf2c27f81929631176e57e1c6fa2ce4c7e9eab5de1bcecfdbb349	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2031, "url": "card", "code": "", "name": "ReceiptCancellation", "path": "receipts", "enabled": false, "leftIcon": "action:receipt", "rightIcon": "", "displayName": "ReceiptCancellation", "orderNumber": 25, "queryParams": "", "serviceCode": "", "parentModule": "", "navigationURL": "receipts/search"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
89be7eaa-a9fa-4381-9662-0966a56b6760	pg	5170d59abc3e80c841dcd0e592f9e78c53a748d6a9ec8d31f2543dea063e63e5	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2030, "url": "url", "code": "null", "name": "ReceiptCancellation", "path": "", "enabled": false, "leftIcon": "action:receipt", "displayName": "ReceiptCancellation", "orderNumber": 24, "serviceCode": "", "parentModule": "", "navigationURL": "receipts/search"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
85643d9c-c22b-4f91-9784-08a25e6e7dc0	pg	86e5411e25e6407392a7574b74dc23c7ebcb9718e00a607df9e6f4b5b8f5e501	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2029, "url": "/collection-services/payments/PT/_search", "code": "null", "name": "PT Payment search", "path": "", "enabled": false, "displayName": "PT Payment search", "orderNumber": 1, "serviceCode": "", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
601c55b8-58a1-4ff1-9b9c-f3126917a719	pg	cf66a328bcf1a5ded10f5e6efe3d770286cd2478cdc65e4882418e5b04ca51e4	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2028, "url": "/collection-services/payments/PT/_workflow", "code": "null", "name": "PT Receipt Update", "path": "", "enabled": false, "displayName": "PT Receipt Update", "orderNumber": 1, "serviceCode": "", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
02a3bf59-1ae2-4fe2-8ccc-d75c3075978e	pg	32fd518cfa5936f50f51efca5c48cdd387f35b794e03664f422abe19df473e06	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2027, "url": "/egov-workflow-v2/egov-wf/process/_count", "code": "null", "name": "WorkflowProcessCount", "path": "", "enabled": false, "displayName": "Workflow Count", "orderNumber": 1, "serviceCode": "", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
007cf714-c330-4dad-b506-bcfc90e45db4	pg	5938b92ef92629300659d3c8dcd64a4b087f95ee6d32a448e28dc68dfd3548c2	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2024, "url": "url", "code": "null", "name": "BillAmendment", "path": "", "enabled": false, "leftIcon": "action:receipt", "displayName": "BillAmendment", "orderNumber": 23, "serviceCode": "", "parentModule": "", "navigationURL": "bill-amend/search"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a9b009bc-72a1-49d2-96bb-5204f4a65b21	pg	d0723b5e3d9ac8d48065790f434833d5bd402c81b8b105b401a224f251db2b26	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2023, "url": "/sw-calculator/sewerageCalculator/_applyAdhocTax", "code": "null", "name": "Add adhoc tax to sewerage", "path": "", "enabled": false, "displayName": "Add adhoc tax", "orderNumber": 0, "serviceCode": "sw-calculator"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5fdde95d-4d61-4010-8348-adf200990c0e	pg	ce217b6025b10ace137a2c966d14dd3b2be9561f4f0af89b1be4e9ad1145523c	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2022, "url": "/ws-calculator/waterCalculator/_applyAdhocTax", "code": "null", "name": "Add adhoc tax", "path": "", "enabled": false, "displayName": "Add adhoc tax", "orderNumber": 0, "serviceCode": "ws-calculator"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
255cdb2d-b4e1-4802-9813-979d21e4737d	pg	2e295cce3c7f2017854ffb65bd3ba0d0582106de53aa264f976e63e60d3e2560	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2021, "url": "/report/pgr/GROPerformanceReport/_get", "code": "null", "name": "GROPerformanceReport", "path": "PGR Report", "enabled": false, "displayName": "PGR Report", "orderNumber": 0, "serviceCode": "PGRReports"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e43fc098-e28a-4bbf-b59d-b3b81c1c1658	pg	981d0e15382f0d67cec3e7970d15c556419be8be8e9256dc03a6fea90fb8a3f9	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2020, "url": "/report/pgr/LMEPerformanceReport/_get", "code": "null", "name": "LMEPerformanceReport", "path": "PGR Report", "enabled": false, "displayName": "PGR Report", "orderNumber": 0, "serviceCode": "PGRReports"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
144f95c1-8720-46c8-aa54-97dde13c01e8	pg	e3bbca4bbfafde3516ab24ea59b3e251d27e1d49684073ed96e95da0e4faa444	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2019, "url": "/report/pgr/DescriptionReport/_get", "code": "null", "name": "DescriptionReport", "path": "PGR Report", "enabled": false, "displayName": "PGR Report", "orderNumber": 0, "serviceCode": "PGRReports"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
056aadc7-c7ec-4444-a4a1-14fc5c216037	pg	07bdb9dc175e308841894d1746b1e9ae8743442c72d156f523c9379165b33a0a	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2018, "url": "/report/pgr/ULBReport/_get", "code": "null", "name": "ULBReport", "path": "PGR Report", "enabled": false, "displayName": "PGR Report", "orderNumber": 0, "serviceCode": "PGRReports"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
805ae7a7-916e-43d1-915b-d99c4af2a52b	pg	d7f73f2cbab14ec87355f97fa52899ced39f9709ad828a09023d85183e71fad7	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2017, "url": "/report/pgr/GROPerformanceReport/metadata/_get", "code": "null", "name": "PGR-GROPerformanceReport-Metadata", "path": "PGR Report", "enabled": false, "displayName": "Rainmaker PGR report", "orderNumber": 1, "serviceCode": "PGRReports", "parentModule": "147"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
18cde675-4fdc-446d-817b-b0ab00aed592	pg	9d994fb376da0240b5f37e1624688991e168b14805a4b5f2b82352591b5a9382	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2016, "url": "/report/pgr/LMEPerformanceReport/metadata/_get", "code": "null", "name": "PGR-LMEPerformanceReport-Metadata", "path": "PGR Report", "enabled": false, "displayName": "Rainmaker PGR report", "orderNumber": 1, "serviceCode": "PGRReports", "parentModule": "147"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4d135627-a3b1-45b5-b69c-3c089e96b125	pg	3aed961045b93d8f60be5e8f8bf22eff8734aed10a7e45b4b153bd2a7a2c33e8	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2015, "url": "/report/pgr/ULBReport/metadata/_get", "code": "null", "name": "PGR-ULBReport-Metadata", "path": "PGR Report", "enabled": false, "displayName": "Rainmaker PGR report", "orderNumber": 1, "serviceCode": "PGRReports", "parentModule": "147"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
239357a8-46e2-428d-88cf-7f10259a263f	pg	87ef60971173e58d0be9ff03db6e968f496440772e71544c85c400ba010c6d7d	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2014, "url": "/report/pgr/DescriptionReport/metadata/_get", "code": "null", "name": "PGR-DescriptionReport-Metadata", "path": "PGR Report", "enabled": false, "displayName": "Rainmaker PGR report", "orderNumber": 1, "serviceCode": "PGRReports", "parentModule": "147"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
10d6dcb3-621c-47fc-bf03-03d15356eb3e	pg	e7c2ce6b9e1800bc02431457044b0c685e29c02194e8f5466dde3f9eedb06f9d	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2013, "url": "url", "code": "null", "name": "GROPerformanceReport", "path": "Complaints.PGR Reports.GROPerformanceReport", "enabled": false, "leftIcon": "action:assignment", "rightIcon": "", "displayName": "GRO Performance Report", "orderNumber": 6, "serviceCode": "PGR", "parentModule": "pgr", "navigationURL": "report/pgr/GROPerformanceReport"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8f89b756-0c41-4ba7-8d96-7f6c9667fa54	pg	f43d8ef843489909d34e78d44c33f941e5cfa68bb20478947cd8cafeb022b925	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2012, "url": "url", "code": "null", "name": "LMEPerformanceReport", "path": "Complaints.PGR Reports.LMEPerformanceReport", "enabled": false, "leftIcon": "action:assignment", "rightIcon": "", "displayName": "LME Performance Report", "orderNumber": 6, "serviceCode": "PGR", "parentModule": "pgr", "navigationURL": "report/pgr/LMEPerformanceReport"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
883fb365-b8cf-4f48-93a8-8553ec721f79	pg	ad515e7a5678b18bdf1f2f2a50ff363c6be01908bd5fc90486fbe0edee71d022	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2025, "url": "url", "code": "null", "name": "DescriptionReport", "path": "Complaints.PGR Reports.DescriptionReport", "enabled": false, "leftIcon": "action:assignment", "rightIcon": "", "displayName": "Description Report", "orderNumber": 6, "serviceCode": "PGR", "parentModule": "pgr", "navigationURL": "report/pgr/DescriptionReport"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c035cbc7-eee6-4520-be80-5b71f81455ba	pg	d020b04dbabd90aae70aa05b26536c9a77c9d11bff94b53d00b8669c25a7a781	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2026, "url": "url", "code": "null", "name": "ULBReport", "path": "Complaints.PGR Reports.ULBReport", "enabled": false, "leftIcon": "action:assignment", "rightIcon": "", "displayName": "ULB Report", "orderNumber": 6, "serviceCode": "PGR", "parentModule": "pgr", "navigationURL": "report/pgr/ULBReport"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9ab4d2de-a4e0-423c-a046-11bfead9570a	pg	1fca001c4ac090488ff7677a1ca82ac1a98ed3e6a9d9257df2003aadd214b283	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2009, "url": "/pgr-services/v2/request/_count", "code": "null", "name": "Search PGR Request", "path": "", "enabled": false, "displayName": "Count PGR Request", "orderNumber": 0, "serviceCode": "pgr-services", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
89e82efb-c5b2-45bd-a1ad-657d33fb6882	pg	09124d06961e5b657a9813fc586486be1013b693af0e6c0ec856da1c7c247e88	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2008, "url": "/pgr-services/v2/request/_search", "code": "null", "name": "Search PGR Request", "path": "", "enabled": false, "displayName": "Search PGR Request", "orderNumber": 0, "serviceCode": "pgr-services", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
045347e2-8d89-4b13-a9cf-c388405ad822	pg	86665da0a458a4414649bdb1d23cf43f880051987581b3794298fa3145d8f441	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2007, "url": "/pgr-services/v2/request/_update", "code": "null", "name": "Update PGR Request", "path": "", "enabled": false, "displayName": "Update PGR Request", "orderNumber": 0, "serviceCode": "pgr-services", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1cc0758c-25c9-4f03-b22d-d58af0683ec9	pg	1ed1d61d04816b289dea0c6276336e62a95fe2ad0642ad6c731ef8b5b28991df	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 63, "actionid": 254, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
40489f54-f46d-429b-901d-833f7ab14f84	pg	6db0181592a75d133170c77acfc75cd32a106aa04f4f80be894bf191e96384dd	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2006, "url": "/pgr-services/v2/request/_create", "code": "null", "name": "Create PGR Request", "path": "", "enabled": false, "displayName": "Create PGR Request", "orderNumber": 0, "serviceCode": "pgr-services", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
390bf6a7-d6d5-4730-b91d-a164ba10ddaf	pg	b5f5128abcc67ff163d3c81b94887b5a0bde15dedf8ddfbfaa3f25f42eeb2863	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2562, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b52fa966-2749-49e1-955f-65135b8f6eb6	pg	fdbf60ec93a1e5981a867ea6f6148f3f823e7f2124ba81e1f57d72f473019281	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2005, "url": "/egov-searcher/locality/noc-services/_get", "code": "null", "name": "Locality searcher endpoint for Noc Servcies", "path": "", "enabled": false, "displayName": "Noc locality searcher", "orderNumber": 0, "serviceCode": "egov-searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
608c4390-28a6-405c-a9da-99269f0f5cd0	pg	4741cc08fb6e17aac8dd9b7d21f8daaf656e56fd756520bd67dda5f35a6d6344	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2004, "url": "quickAction", "name": "search NOC application", "path": "Noc.Search NOC Application", "enabled": false, "leftIcon": "communication:business", "tenantId": "pg", "createdBy": null, "rightIcon": "", "createdDate": null, "displayName": "Search NOC Application", "orderNumber": 1, "queryParams": "", "quickAction": false, "serviceCode": "", "parentModule": "", "navigationURL": "noc/search", "lastModifiedBy": null, "lastModifiedDate": null}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2a8ad7bd-7942-4027-887f-9b76e303381d	pg	7a996c3f381abcd68e5befdc2e90c2c90fc83d513df6e6fe899bef8aa1365cc0	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2003, "url": "/noc-services/v1/noc/_update", "code": "null", "name": "NOC Update", "path": "", "enabled": false, "displayName": "Update", "orderNumber": 0, "serviceCode": "NOC"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e78e51f9-5493-4471-b5cd-10e7acf53f78	pg	9325f16d80a37de13d1675a20f75eecedc9b8b40afef1dc9275e33502b89eda8	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2002, "url": "/noc-services/v1/noc/_search", "code": "null", "name": "NOC Search", "path": "", "enabled": false, "displayName": "Search", "orderNumber": 0, "serviceCode": "NOC"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9c45c0cd-1aff-4dbc-a86a-508e82acba18	pg	bfb73101aab1c7e8e7dca18c5771251c971347a63aaa55ec79d511dad47a2021	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2001, "url": "/noc-services/v1/noc/_create", "code": "null", "name": "NOC Create", "path": "", "enabled": false, "displayName": "Create", "orderNumber": 0, "serviceCode": "NOC"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0fc8a662-1646-4ce6-9b4b-72d0efd2cbfb	pg	f20831f23dbc05f2e199588c6c567e3762aec212a9de95bb08e69d10b4212d28	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 2000, "url": "/localization/messages/v2/_search", "code": "null", "name": "LocalizationMessagesSearch", "path": "", "enabled": false, "displayName": "Localization Messages Search", "orderNumber": 1, "serviceCode": "localisation search", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4a5e3af0-8541-40ec-af37-3e4c9ed0eb3e	pg	afa53de83b0b9087a21a9a6be61ddc3fd189904668c6956d785603d310e5ad6a	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1990, "url": "/land-services/v1/land/_search", "code": "null", "name": "BPA-Land-Search", "path": "", "enabled": false, "displayName": "Land Search", "orderNumber": 0, "serviceCode": "BPA"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
92b5f6ce-3627-4e2a-b456-f0a847d6e566	pg	942993bdcc78e5f9d38b69c3f2044c143229122868135efc1e4bfcf0e14da033	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1989, "url": "/land-services/v1/land/_update", "code": "null", "name": "BPA-Land-Update", "path": "", "enabled": false, "displayName": "Land Update", "orderNumber": 0, "serviceCode": "BPA"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
55206cd1-cbbe-4c3a-8a84-bfc50232a788	pg	09a49349e773bbd2105e860dbf48869fbd7ee16f03c64c4f1585e486a9cb0a3f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1988, "url": "/land-services/v1/land/_create", "code": "null", "name": "BPA-Land-Create", "path": "", "enabled": false, "displayName": "Land Create", "orderNumber": 0, "serviceCode": "BPA"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
008a647f-52c8-42ae-b095-252272bb9ae5	pg	107c4cffdbb4f6a42031f167b05f728431e8e1d641ce0e277dfc64475d87980f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1999, "url": "/egov-pdf/download/PT/ptreceipt", "code": "null", "name": "ptreceipt search", "path": "", "enabled": false, "displayName": "ptreceipt search", "orderNumber": 9, "serviceCode": "egov-pdf"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
01b90aea-1c46-4ca9-9940-64a700545bda	pg	26e0554bb2b40c787674651f49bad1175f9c2c633204cfc253e3c52a3fdaacd3	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1998, "url": "/egov-pdf/download/PT/ptbill", "code": "null", "name": "ptbill search", "path": "", "enabled": false, "displayName": "ptbill search", "orderNumber": 8, "serviceCode": "egov-pdf"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8f5158a7-2dcc-4927-bd31-d67111268846	pg	263b64cdf8a86d4856abf6772040a7e273d59a00688bb780984f58058f0a46fe	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1997, "url": "/egov-pdf/download/PT/ptmutationcertificate", "code": "null", "name": "ptmutationcertificate search", "path": "", "enabled": false, "displayName": "ptmutationcertificate search", "orderNumber": 7, "serviceCode": "egov-pdf"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9693d385-98dd-42f3-a4d7-03e4e87833cd	pg	067b8048393b6356491d717d86d39955e550545e15540fbdd59a34491afda15e	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1996, "url": "/egov-pdf/download/TL/tlbill", "code": "null", "name": "tlbill search", "path": "", "enabled": false, "displayName": "tlbill search", "orderNumber": 6, "serviceCode": "egov-pdf"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
905ce33a-254b-4b4d-9a75-30020f14082c	pg	0505913c0826444facde8eeea9357e1662e40ad807d14d668e083ac985cfed6d	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1995, "url": "/egov-pdf/download/TL/tlrenewalcertificate", "code": "null", "name": "tlrenewalcertificate search", "path": "", "enabled": false, "displayName": "tlrenewalcertificate search", "orderNumber": 5, "serviceCode": "egov-pdf"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a2147713-aeae-40a1-b95c-5b550d285cb4	pg	3396c08d8af059c311555527c9f2dec2f5713a89ce5fb598708727542f863c46	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1994, "url": "/egov-pdf/download/TL/tlcertificate", "code": "null", "name": "tlcertificate search", "path": "", "enabled": false, "displayName": "tlcertificate search", "orderNumber": 4, "serviceCode": "egov-pdf"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9395769c-74fb-4e4e-ac16-6b2abd5f98f3	pg	e14f3b60123d5237931702c21189b389d5aae58b03104c48373ec9121853757e	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1993, "url": "/egov-pdf/download/TL/tlreceipt", "code": "null", "name": "tlreceipt search", "path": "", "enabled": false, "displayName": "tlreceipt search", "orderNumber": 3, "serviceCode": "egov-pdf"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6b116c44-d60c-4d38-9c30-2e4b074b5f46	pg	7ebc0a4fadda3ffaac8c7b6491441576c737b61ff746e8507ea7c587c105de43	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1992, "url": "/egov-pdf/download/BILL/consolidatedbill", "code": "null", "name": "consolidatedbill search", "path": "", "enabled": false, "displayName": "consolidatedbill search", "orderNumber": 2, "serviceCode": "egov-pdf"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fd351f62-c33f-46cc-9507-9ded2510a312	pg	ab9c00bc8c774ceab12308526cac77567f622ff360abdad4db61ba8c9b05d144	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1991, "url": "/egov-pdf/download/PAYMENT/consolidatedreceipt", "code": "null", "name": "consolidatedreceipt search", "path": "", "enabled": false, "displayName": "consolidatedreceipt search", "orderNumber": 1, "serviceCode": "egov-pdf"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b703ba75-b82a-4352-aa16-f63f52af00de	pg	e7780c627f9d23454fad7511b2ddf3530f4f7a4fe538d980a40af62e06c88af1	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1985, "url": "/egov-searcher/locality/ws-services/_get", "code": "null", "name": "Locality searcher endpoint for WS", "path": "", "enabled": false, "displayName": "WS-Service locality searcher", "orderNumber": 0, "serviceCode": "egov-searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2efb0027-dc48-4a8f-987b-61754881f197	pg	6eb7d6aef91f602ecfdc7eef12ebdec11c7a103105504104c45e6173275e6530	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1984, "url": "/egov-searcher/locality/sw-services/_get", "code": "null", "name": "Locality searcher endpoint for SW", "path": "", "enabled": false, "displayName": "SW-Service locality searcher", "orderNumber": 0, "serviceCode": "egov-searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
752c08ce-82c8-4cea-accc-c7a25a517122	pg	9f146af2da7d2cd84703364a32429fe7dd2e697c5b3a57b76420ec4a399617f5	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1983, "url": "url", "code": "null", "name": "Remittance Pending Report", "path": "Finance.Reports.Revenue Reports.Remittance Pending Report", "enabled": false, "leftIcon": "editor:insert-chart", "displayName": "Remittance Pending Report", "orderNumber": 6, "serviceCode": "FinanceReport", "parentModule": "", "navigationURL": "services/EGF/report/remittance/pending/form"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a4f0630d-bcf4-49c3-8781-26855fcb6d24	pg	5ec49b4785bc460d261b6ae8243b09ec93cf7e3fe7bf5367857280bcb2d92c55	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1982, "url": "url", "code": "null", "name": "Dishonored Cheque Report ", "path": "Finance.Reports.MIS Reports.Dishonored Cheque Report", "enabled": false, "leftIcon": "editor:insert-chart", "displayName": "Dishonored Cheque Report ", "orderNumber": 7, "serviceCode": "FinanceReport", "parentModule": "", "navigationURL": "services/collection/report/dishonouredcheque/searchform"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2bd1d751-2ed2-43d2-9a3b-bd5c7291d405	pg	ec888fb5df5c36bbb5e62ac3281e0f65c375747b6ceb3025f4aa7099549eb068	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1981, "url": "url", "code": "null", "name": "Dishonor Cheque/DD", "path": "Finance.Administration.Dishonor Cheque/DD", "enabled": false, "leftIcon": "editor:insert-chart", "displayName": "Dishonor Cheque/DD", "orderNumber": 1, "serviceCode": "FinanceAdmin", "parentModule": "", "navigationURL": "services/collection/dishonour/cheque/form"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
42d41b67-11e5-4419-94cc-cc61515cf48b	pg	9f82520721b655c1af1293e23e25d01ccf88b276cf57f8ee6f51026c5196ae70	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1980, "url": "url", "code": "", "name": "rainmaker-localization-screen", "path": "Localization", "enabled": false, "leftIcon": "places:business-center", "rightIcon": "", "displayName": "Localization", "orderNumber": 5, "queryParams": "", "serviceCode": "", "parentModule": "", "navigationURL": "integration/ui-localisation/localization"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
369d4063-6ff0-4dcc-b9c4-6fd011ba08ce	pg	11883c487532c574a8e4926757e2b621f1190ac0b4bf44b9a0e5628e26bd7898	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1979, "url": "url", "code": "null", "name": "Remittance Collection Report", "path": "Finance.Reports.Revenue Reports.Remittance Collection Report", "enabled": false, "leftIcon": "editor:insert-chart", "displayName": "Remittance Collection Report", "orderNumber": 6, "serviceCode": "FinanceReport", "parentModule": "", "navigationURL": "services/EGF/report/remittance/collection/form"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4c5fd8c4-c6ae-4f6c-9ef0-5210c02a71c2	pg	89ba6a7c9544b8f0dbdef9dd8aa85ee093739a471a3b9d29e040a781f7045971	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1978, "url": "/property-services/property/_migration", "code": "null", "name": "Migrate Property v1 to v2", "path": "", "enabled": false, "displayName": "Migrate Property v1 to v2", "orderNumber": 5, "serviceCode": "property-services"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6b66a5c4-23d0-43fa-b3bc-00e1ba22245f	pg	7e6c6979b900fc38b168c6d32cb79527767c7169a584a7426066a720caa59236	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1977, "url": "/dashboard-ingest/ingest/migrate/paymentsindex-v1/v2", "code": "null", "name": "Dashboard Payments-v1", "path": "", "enabled": false, "displayName": "DSS", "orderNumber": 0, "serviceCode": "DSS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5fd4abb2-c445-480d-9837-49d5b64dcc9d	pg	50c8f964d01b8954ddf648f4c497162d7bf62a43df83230c6761926956ca0663	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1976, "url": "/egov-searcher/locality/BPAREG/_get", "code": "null", "name": "Locality searcher endpoint for BPA", "path": "", "enabled": false, "displayName": "BPA locality searcher", "orderNumber": 0, "serviceCode": "egov-searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
55f0e7e0-50f7-48d8-a079-6437ee6c7e63	pg	ba5f68b3fe1d79179c93cb984a674980f8ab1d512e23fa95c78635e386322dc6	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1975, "url": "/egov-searcher/locality/bpa-services/_get", "code": "null", "name": "Locality searcher endpoint for BPA", "path": "", "enabled": false, "displayName": "BPA locality searcher", "orderNumber": 0, "serviceCode": "egov-searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d242fb75-6c5c-43be-9dc5-ed11298d8efb	pg	0bc960e0cbe1d9877f8176abb71e13243e64169304608f566d1fed2b0254f4f1	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1972, "url": "/bpa-services/v1/bpa/_permitorderedcr", "code": "null", "name": "BPA-PermitOrderEDCR Report", "path": "", "enabled": false, "displayName": "Apply", "orderNumber": 0, "serviceCode": "BPA"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8dda6e03-f5ff-4bb7-ada7-5b06095d210d	pg	e0e68956c8af9dc87fea0560c559b54c360aa5099f2ce671d1dcc27bce2f5ed9	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1971, "url": "url", "code": "null", "name": "Reopening Closed Period", "path": "Finance.Period End Activities.Close Period", "enabled": false, "leftIcon": "editor:insert-chart", "displayName": "Reopening Closed Period", "orderNumber": 4, "serviceCode": "FinanceMaster", "parentModule": "", "navigationURL": "services/EGF/closedperiod/search/reopen"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fa76889c-a9a1-41d7-a3a7-ccaf55f97ad5	pg	d4f91bc74b6d0c37512faa3561b20543054269117db43195953280ddf69aea76	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1970, "url": "/dashboard-ingest/ingest/paymentsindex-v1/v2", "code": "null", "name": "Dashboard Payments-v1", "path": "", "enabled": false, "displayName": "DSS", "orderNumber": 0, "serviceCode": "DSS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
96a8d685-a31c-4802-8863-a93dd68e4639	pg	e144b449c8931281f342806bd4e2032dcb643ff4c40fe80e6f4554a9ce57f04e	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1969, "url": "/egov-searcher/locality/pt-services/_get", "code": "null", "name": "Locality searcher endpoint for PT Service", "path": "", "enabled": false, "displayName": "PT locality searcher", "orderNumber": 0, "serviceCode": "egov-searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3c7ed834-a5ae-407f-9d57-088e204756bc	pg	879326e1d0e483d425cf8069507c4b7ae39e9c6c03899cf09d3616aeafbeafac	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1968, "url": "/egov-searcher/locality/PT/_get", "code": "null", "name": "Locality searcher endpoint for PT", "path": "", "enabled": false, "displayName": "PT locality searcher", "orderNumber": 0, "serviceCode": "egov-searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fd86ec7a-0321-4942-9060-78d175c7cf26	pg	4404becdfb295e6e3c8d58513e034ad06a25678ea278f66fab1d36afda1acfdc	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1965, "url": "/dashboard-ingest/update/publish", "code": "null", "name": "Dashboard Api W&S to update", "path": "", "enabled": false, "displayName": "DSS", "orderNumber": 0, "serviceCode": "DSS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cabcccc1-42ee-4649-8876-5bd12ee09601	pg	aff148a55b2e3d5fc086ac84dabf90d5351bd9f2df3fd75f1f218e8be79786ca	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1964, "url": "/dashboard-ingest/ingest/upload", "code": "null", "name": "Dashboard Static Upload", "path": "", "enabled": false, "displayName": "DSS", "orderNumber": 0, "serviceCode": "DSS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cc97e972-ff99-41f4-ac79-0d6dc7908d53	pg	f8b97705c03ad54ce8621e9e4460a6f90f4e23ab8b16a503dd53dcf260796133	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1963, "url": "/dashboard-ingest/ingest/migrate/collectionsindex-v1/v1", "code": "null", "name": "Dashboard collectionsindex-v1", "path": "", "enabled": false, "displayName": "DSS", "orderNumber": 0, "serviceCode": "DSS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d846be73-6700-4c06-bc5a-6c7824d79470	pg	d1ba7c26fc75e25563dd37da68701c409c11cad1a343be4ba6d742e5f1ab4a97	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1967, "url": "/sw-calculator/sewerageCalculator/_estimate", "code": "null", "name": "Calculate Fee For Sewerage Application", "path": "", "enabled": false, "displayName": "Fee Calculation For Sewerage Application", "orderNumber": 0, "serviceCode": "sw-calculator"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
34ff7c0a-606c-40f2-9d4a-cc185e203661	pg	cc08b5937bc638db7380cd77d2cb98a7c0d54833c069504520559c0a5ff24ae4	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1966, "url": "/ws-calculator/waterCalculator/_estimate", "code": "null", "name": "Calculate Fee For Water Application", "path": "", "enabled": false, "displayName": "Fee Calculation For Water Application", "orderNumber": 0, "serviceCode": "ws-calculator"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f961ad5b-7d2e-4d40-9710-be21a3d2dc8d	pg	e6caedcaf853a3c1d4930e7c18396670db753e27dca90db3ca506557372a6704	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1961, "url": "/egov-searcher/bill-genie/seweragebills/_get", "code": "null", "name": "Search Sewerage Bill", "path": "", "enabled": false, "displayName": "Search Sewerage Bill", "orderNumber": 2, "serviceCode": "Searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
798beaf6-1511-425b-8e92-af67e5dd00b7	pg	680bfbc7e508754d15af02a4e269d413c31877cd7074ed669de64f8b1d96f02c	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1960, "url": "/egov-searcher/bill-genie/waterbills/_get", "code": "null", "name": "Search Water Bill", "path": "", "enabled": false, "displayName": "Search Water Bill", "orderNumber": 1, "serviceCode": "Searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
85e8a795-99d0-47cb-ad7f-04cc61e4d34e	pg	d515c2ad87ab7ea1906095007820de8f94047b79d7e4521a9520a1f4379dc122	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1959, "url": "url", "code": "null", "name": "Surrendered Cheque", "path": "Finance.Reports.MIS Reports.Surrendered Cheque", "enabled": false, "leftIcon": "editor:insert-chart", "displayName": "Surrendered Cheque", "orderNumber": 6, "serviceCode": "FinanceReport", "parentModule": "", "navigationURL": "services/EGF/report/cheque/surrendered/form"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
474bcefb-089e-475f-9e3c-282ff92c16dc	pg	0b64afb8da01c2461b8789c91c4042bc63b39ae65dbf9c9bf5b9d2c067ec92da	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1958, "url": "card", "code": "", "name": "rainmaker-common-wns", "path": "", "enabled": false, "leftIcon": "places:business-center", "rightIcon": "", "displayName": "SURE Dashboard", "orderNumber": 2, "queryParams": "", "serviceCode": "integration", "parentModule": "", "navigationURL": "integration/dss/home"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5631133a-1c9f-4dd9-a68b-e0627aec1ed7	pg	3d555802754448a3de0864749845fa963ae9b4c0a5fb37b530347a3a84f409f6	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1956, "url": "/pt-calculator-v2/billingslab/mutation/_update", "code": "null", "name": "MutationBillingSlabUpdate", "path": "", "enabled": false, "displayName": "Mutation Billing Slab Update", "orderNumber": 1, "serviceCode": "pt-calculator-v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
461f28cc-44f2-4bdc-90c9-9b20731291c5	pg	2219641ead956d537b4f34690a5e82722ceefebd7b6824c7526bad7ce58c00b4	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1955, "url": "/pt-calculator-v2/billingslab/mutation/_search", "code": "null", "name": "MutationBillingSlabSearch", "path": "", "enabled": false, "displayName": "Draft Search", "orderNumber": 1, "serviceCode": "pt-calculator-v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
32142e73-6d79-422b-885e-7a6dddcee0ff	pg	519918cb19cfed9b0ca53ecb445d07f3dab75b72aade3a161daedb1eb588a44c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 61, "actionid": 582, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
549d42d5-37ab-48ba-9456-d799581b0dbd	pg	9588b0da6767a59cdfc63d7d4e9dc3d1295207bbc32938913a5d74c1d3c5a7f4	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1954, "url": "/pt-calculator-v2/billingslab/mutation/_create", "code": "null", "name": "MutationBillingSlabCreate", "path": "", "enabled": false, "displayName": "Draft Search", "orderNumber": 1, "serviceCode": "pt-calculator-v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
aea5104f-8f5c-4a18-a975-b4718c0f871c	pg	bfafa4145b0897b0d79821d3bc1b0a7c15384981538969814e601c1d38140696	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1950, "url": "quickAction", "name": "search BPA application", "path": "Building Plan Approval.Search Application", "enabled": false, "leftIcon": "communication:business", "tenantId": "pg", "createdBy": null, "rightIcon": "", "createdDate": null, "displayName": "Search Application", "orderNumber": 1, "queryParams": "", "quickAction": false, "serviceCode": "", "parentModule": "", "navigationURL": "egov-bpa/search", "lastModifiedBy": null, "lastModifiedDate": null}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
edf18d67-2907-4a92-bc26-8ff215b4a15d	pg	0372f3a4b5288fffad59bb6c2997ba9631c71abaa2cbdc0f4b71e79f4f106e5e	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1949, "url": "url", "code": "null", "name": "Dashboard Overview", "path": "Dashboard.Overview", "enabled": false, "leftIcon": "places:business-center", "rightIcon": "", "displayName": "Overview", "orderNumber": 3, "serviceCode": "DSS", "parentModule": "dss-dashboard", "navigationURL": "integration/dss/overview"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2fd250d1-8857-4051-81c0-59569add468d	pg	84e1804d3687190b32c020278c7a8284d8aaca23e8a6ca94671fb39b927b9658	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1948, "url": "/dashboard-analytics/dashboard/getDashboardConfig/overview", "code": "null", "name": "DSS Dashboard Config Overview", "path": "", "enabled": false, "displayName": "DSS", "orderNumber": 0, "serviceCode": "DSS", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
082505a9-173c-4448-87cc-5cae594055a3	pg	e53144c1b9477037ff513cf735750a009856d899d0a76b94554442c117297963	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1947, "url": "card", "code": "", "name": "rainmaker-citizen-edcrscrutiny", "path": "", "enabled": false, "leftIcon": "custom:edcr", "rightIcon": "", "displayName": "eDCR Scrutiny", "orderNumber": 1, "queryParams": "", "serviceCode": "", "parentModule": "", "navigationURL": "edcrscrutiny/home"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
646aeb09-dd38-4468-ba32-232d8a88d611	pg	96bafbed1a33670ac21089862c7d11cbe3540a0dc6abe95be0fa275f1eaecbf9	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1944, "url": "/property-services/assessment/_update", "code": "null", "name": "Update Assessment registry", "path": "", "enabled": false, "displayName": "Update Assessment Registry", "orderNumber": 1, "serviceCode": "property-services"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
efa06e13-a638-4709-a019-c4af9299492f	pg	d20d2fbd70e312afe0dcfbeea1a564d16a301b9e1c97b72b6584741d14be588d	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1943, "url": "/property-services/assessment/_create", "code": "null", "name": "Create Assessment registry", "path": "", "enabled": false, "displayName": "Create Assessment Registry", "orderNumber": 1, "serviceCode": "property-services"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ee93bdff-bca4-4dc2-b4a1-ae0352cd8dff	pg	6bd9b17aee1ff29763835efab3e42e8cd1b1135386b0166bf20e83befe2a5e9d	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1923, "url": "url", "code": "null", "name": "Dashboard PGR", "path": "Dashboard.PGR", "enabled": false, "leftIcon": "places:business-center", "rightIcon": "", "displayName": "PGR", "orderNumber": 6, "serviceCode": "DSS", "parentModule": "dss-dashboard", "navigationURL": "integration/dss/pgr"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f9c532b1-abf0-4f78-9e12-3f153d19a708	pg	a24f7136fafbdbea75536a9264406a4da063c1de6fe73e524f6bdd2d92f1c2bc	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1942, "url": "/egov-searcher/locality/BPAREG/_get", "code": "null", "name": "Locality searcher endpoint for BPA Reg", "path": "", "enabled": false, "displayName": "BPA locality searcher", "orderNumber": 0, "serviceCode": "egov-searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
29919993-33b1-4f84-9d33-372c661b66ec	pg	89bbb9887612ff4cb4cc95d74d9fa4e0ae9a82602b0859ce604ea749fc9f254c	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1941, "url": "/sw-calculator/sewerageCalculator/_calculate", "code": "null", "name": "Sewerage Calculation", "path": "", "enabled": false, "displayName": "Sewerage Calculation", "orderNumber": 0, "serviceCode": "sw-calculator"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0a1b778d-4251-49b7-a5af-70b9acec18a6	pg	aab55ff105a51ac24c2803d123167cb576f9a195848f9dcf1f521c6a14ad18f5	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1940, "url": "/sw-services/swc/_search", "code": "null", "name": "Search Sewerage Connection", "path": "", "enabled": false, "displayName": "Search Sewerage Connection", "orderNumber": 0, "serviceCode": "sw-services"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1bc81e54-5610-4a39-a029-5d73ae4ec048	pg	f57c20cd56436db45c5b00a3159afff499ae52fcc137002ecd727533c2ed8820	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1939, "url": "/sw-services/swc/_update", "code": "null", "name": "Update Sewerage Connection", "path": "", "enabled": false, "displayName": "Update Sewerage Connection", "orderNumber": 0, "serviceCode": "sw-services"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ab7d88aa-3728-4fb4-b3c9-794bfaf43fa1	pg	4a50f7b69482f4c3b34db00f23f25ab1adbf5701a54b4ad2a1d2495a17269584	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1938, "url": "/sw-services/swc/_create", "code": "null", "name": "Create Sewerage Connection", "path": "", "enabled": false, "displayName": "Create Sewerage Connection", "orderNumber": 0, "serviceCode": "sw-services"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f4c75707-76dc-4110-8a51-aeac54749da7	pg	e28db5fa684a6e354617fdc64538d58377d156e18ba490d94561a5dba790dfbb	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1937, "url": "/ws-calculator/waterCalculator/_calculate", "code": "null", "name": "Calculate Water Bill", "path": "", "enabled": false, "displayName": "Calculate Water Bill", "orderNumber": 0, "serviceCode": "ws-calculator"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
65cb3139-64d2-491d-894f-1e6cd6b7b592	pg	928fff950997bf8013bc49f7ef20fb5d4dfe89755ca7b9999725a0f91934112d	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1936, "url": "/ws-calculator/meterConnection/_search", "code": "null", "name": "Search Meter Reading", "path": "", "enabled": false, "displayName": "Search Meter Reading", "orderNumber": 0, "serviceCode": "ws-calculator"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d6b2c1dc-d519-4c71-80aa-c35d5d23ed81	pg	5f420d84baef2eb7a295a33d09f386512945bc960a2b76b2497947f84b904481	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 60, "actionid": 604, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ccc4301d-f6b8-411f-93a3-dbebadc17336	pg	85ea2a5f6762400fbc87bdbc8e7b0f71f999fd645a03c8bf5910fe9d933449b1	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1935, "url": "/ws-calculator/meterConnection/_create", "code": "null", "name": "Enter Meter Reading", "path": "", "enabled": false, "displayName": "Enter Meter Reading", "orderNumber": 0, "serviceCode": "ws-calculator"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b7ccf439-1c9c-42f8-b13e-2dae0c50428a	pg	86e20e7278924ba42975315a8dbe53907a92d8acbd4a87bc659177c2cc5b95c4	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1901, "url": "/ws-services/wc/_update", "code": "null", "name": "Update Water Connection", "path": "", "enabled": false, "displayName": "Update Water COnnection", "orderNumber": 0, "serviceCode": "ws-services"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8b9b011d-bb14-4400-ad16-1b6367c307a9	pg	7fd5f1a51609443b93466f989b6595505308ecc499ad0158f0027d295cc40fee	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1900, "url": "/ws-services/wc/_search", "code": "null", "name": "Search Water Connection", "path": "", "enabled": false, "displayName": "Search Water COnnection", "orderNumber": 0, "serviceCode": "ws-services"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
061acf73-4fdb-4c12-84dc-c2cb9fc5c0db	pg	f13dfb48c36bfa00ede176ad64a2484e8016d2308e419b30bc0d757537ad20ad	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1899, "url": "/ws-services/wc/_create", "code": "null", "name": "Create Water Connection", "path": "", "enabled": false, "displayName": "Create Water COnnection", "orderNumber": 0, "serviceCode": "ws-services"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
61ba68b6-f880-4866-813f-a514421b3161	pg	ddedb9bfa4b36da260f12d240534e3d95c961ef1be9432fa3b0126d596dc49ec	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1934, "url": "/egov-searcher/locality/fireNoc/_get", "code": "null", "name": "Locality searcher endpoint for PT", "path": "", "enabled": false, "displayName": "FIRENOC locality searcher", "orderNumber": 0, "serviceCode": "egov-searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ab5285ef-1b2e-4689-98d4-5f628616acc6	pg	a035f31ae449de1759d88ab2eaf1ca0f4f7337f51ab76b02b23dc89df868e59f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1933, "url": "/egov-searcher/locality/tl-services/_get", "code": "null", "name": "Locality searcher endpoint for TL", "path": "", "enabled": false, "displayName": "TL locality searcher", "orderNumber": 0, "serviceCode": "egov-searcher"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c9821f41-819f-41d3-8515-da28b82b97cf	pg	076484c72c59b2b0eed70dc10efa5f7892d3e2542c6be6c5c0f02e3b857519ad	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1932, "url": "quickAction", "code": "null", "name": "FIRE-NOC", "path": "FIRE-NOC.Search", "enabled": false, "leftIcon": "social:people", "displayName": "Search Fire Noc", "orderNumber": 3, "serviceCode": "FIRE-NOC", "parentModule": "", "navigationURL": "fire-noc/search"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
aa0bde22-5d27-4a7f-bba1-d0210527a44f	pg	2e0be3469a06892cce1993e65b40d77935181c52ed172197c41f3578715a82b0	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1929, "url": "quickAction", "code": "null", "name": "TradeLicenseApplication", "path": "TradeLicense.Apply", "enabled": false, "leftIcon": "places:business-center", "displayName": "Apply TL", "orderNumber": 13, "serviceCode": "TradeLicense", "parentModule": "", "navigationURL": "/digit-ui/employee/tl/new-application"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d945b5d5-952d-4575-844b-379aaec07c09	pg	9750dae737866b66b02568e1151f2a8ba83da588f4614e6b679b1458c3e3a4b3	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1928, "url": "quickAction", "code": "", "name": "rainmaker-common-tradelicence", "path": "", "enabled": false, "leftIcon": "places:business-center", "rightIcon": "", "displayName": "Search TL", "orderNumber": 2, "queryParams": "", "serviceCode": "", "parentModule": "", "navigationURL": "/digit-ui/employee/tl/inbox"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5262530c-4338-40b3-84b9-a237678d6aa7	pg	e638e96367b684e96357934bcf87b745e19d07be78a1f93e736d47953a5d7f10	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1927, "url": "quickAction", "code": "", "name": "rainmaker-common-complaints", "path": "", "enabled": false, "leftIcon": "action:announcement", "rightIcon": "", "displayName": "Search Complaints", "orderNumber": 2, "queryParams": "", "serviceCode": "", "parentModule": "", "navigationURL": "/digit-ui/employee/pgr/inbox"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5949fae1-6ec7-4db9-ab8c-6df839cbed2b	pg	00a1070252bf8698c8ba093f1076cf242b9e39ae32df2333c4539681bfd20cac	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1926, "url": "quickAction", "name": "Assess And Search Properties", "path": "Property Tax.Assess And Search Properties", "enabled": false, "leftIcon": "communication:business", "tenantId": "pg", "createdBy": null, "rightIcon": "", "createdDate": null, "displayName": "Search Property", "orderNumber": 1, "queryParams": "", "quickAction": false, "serviceCode": "", "parentModule": "", "navigationURL": "/digit-ui/employee/pt/inbox", "lastModifiedBy": null, "lastModifiedDate": null}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e1215c3e-97d3-4ba6-8005-603c23398079	pg	c427ad33fe031b38b6217440b7013e76e92bb6f512c6f82137b0b8eec9d42464	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1925, "url": "quickAction", "code": "null", "name": "CreateComplaint", "path": "Complaints.CreateComplaint", "enabled": false, "leftIcon": "content:add", "rightIcon": "", "displayName": "File Complaint", "orderNumber": 1, "quickAction": false, "serviceCode": "PGR", "parentModule": "rainmaker-pgr", "navigationURL": "/digit-ui/employee/pgr/complaint/create"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4a04893e-f93b-4ea7-a111-148af47c8dcb	pg	4c9ae4fcfc9a59ff114358bdcc5e252bcf2b05276e7865a992365474abba88d8	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1872, "url": "/pdf-service/v1/_createnosave", "code": "null", "name": "Pdf Generator createnosave", "path": "", "enabled": false, "displayName": "Pdf Generator createnosave", "orderNumber": 3, "serviceCode": "pdf-generator-createnosave"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
09dbb2aa-90eb-40fb-82a6-e00bcfe34a73	pg	51558f2500a39b6c2d3c48cec25189f60c7fa4903dfd33ddd42f7172a9e898f4	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1835, "url": "/pdf-service/v1/_search", "code": "null", "name": "Pdf Generator search", "path": "", "enabled": false, "displayName": "Pdf Generator search", "orderNumber": 2, "serviceCode": "pdf-generator-search"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
77909aec-b18d-4cb4-b2b8-2b37ed0ef6b5	pg	b50bd96bdc8551f78f41b018919634f5fc587f7cf878a4b92aa8a3ba6019c5f0	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1834, "url": "/pdf-service/v1/_create", "code": "null", "name": "Pdf Generator create", "path": "", "enabled": false, "displayName": "Pdf Generator create", "orderNumber": 1, "serviceCode": "pdf-generator-create"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
45ee2760-2d10-4df7-a7e5-89c105852ab4	pg	f93ff574f38062371bb6d0d211e9f7023f9117de992e59d5cbb8282ae3bc6099	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1814, "url": "card", "code": "", "name": "rainmaker-citizen-complaints", "path": "", "enabled": false, "leftIcon": "custom:account-alert", "rightIcon": "", "displayName": "Complaints", "orderNumber": 2, "queryParams": "", "serviceCode": "", "parentModule": "", "navigationURL": "/digit-ui/citizen"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
39dd18ed-4eac-4256-abda-f3a6cf4a9af1	pg	43e11f69711a115dbaa41f8e5d0d957633b164e3d370e9368f3203e76e82f928	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1807, "url": "url", "code": "null", "name": "TradeLicense", "path": "TradeLicense", "enabled": false, "leftIcon": "places:business-center", "rightIcon": "", "displayName": "Trade License", "orderNumber": 13, "serviceCode": "TradeLicense", "parentModule": "", "navigationURL": "/digit-ui/citizen/"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
51274911-6d5a-4d78-9017-d85a03e0b4da	pg	7d97ee8bc37b98dfff5c89b5716c8f2dd9b83d06fb5e8c7e37b291023855a5ea	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2559, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
bcd0c26c-b76d-4545-9315-1ebcdf16c760	pg	fc8a9261219d08fe915a3f8c523a4361f7c1fe98efef3b9a7a45ea75dea59cad	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1806, "url": "url", "name": "PropertyTax", "path": "Property Tax", "enabled": false, "leftIcon": "communication:business", "rightIcon": "", "displayName": "Property Tax", "orderNumber": 1, "queryParams": "", "serviceCode": "", "parentModule": "", "navigationURL": "/digit-ui/citizen"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f9abcdda-e569-40ff-baa4-039b7ca67020	pg	76c73b9ca31a557ea266b0642bbbf7e125c42ffa7d57c7b22d81eb57fe74ae0a	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1805, "url": "url", "code": "null", "name": "Complaints", "path": "Complaints", "enabled": false, "leftIcon": "custom:account-alert", "rightIcon": "", "displayName": "Complaints", "orderNumber": 1, "serviceCode": "PGR", "parentModule": "rainmaker-pgr", "navigationURL": "/digit-ui/citizen/pgr/complaints"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1fd2fd64-e04d-44c0-bcd6-a8abf165343a	pg	bac1ca68c5793b62db8af146989dc134a6d30181da8a23fd7bd699a88360dc23	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1779, "url": "card", "code": "", "name": "rainmaker-common-hrms", "path": "", "enabled": false, "leftIcon": "social:people", "rightIcon": "", "displayName": "HRMS", "orderNumber": 2, "queryParams": "", "serviceCode": "", "parentModule": "", "navigationURL": "/digit-ui/employee/hrms/inbox"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
bca70bc6-3cca-47b6-aaa9-c0c2f80c21c5	pg	b1539da723f76528c31df4fd966d45218a68680e3a916a9e80ea4c50cb680a67	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1775, "url": "card", "code": "", "name": "rainmaker-common-complaints", "path": "", "enabled": false, "leftIcon": "action:announcement", "rightIcon": "", "displayName": "Complaints", "orderNumber": 2, "queryParams": "", "serviceCode": "", "parentModule": "", "navigationURL": "/digit-ui/employee/pgr/inbox"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
eb570d03-9dc1-4aef-8733-e9f69b31cb56	pg	aed62017f4e65e8677392faeb6a62542c5e1c0394642d7d6efcfbdbe419fde45	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1773, "url": "url", "code": "null", "name": "HRMS", "path": "HRMS.Search", "enabled": false, "leftIcon": "social:people", "displayName": "Search Employee", "orderNumber": 2, "serviceCode": "HRMS", "parentModule": "", "navigationURL": "/digit-ui/employee/hrms/inbox"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
41660bd7-286b-4db5-bd44-327eb83fe0ef	pg	478149fe1f72839f4468fa75b44f59793d5bcf7ef579352a0a8c9267989e9d99	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1752, "url": "/egov-hrms/employees/_search", "code": "null", "name": "Employee Search", "path": "", "enabled": false, "displayName": "Employee Search", "orderNumber": 0, "serviceCode": "egov-hrms", "parentModule": "egov-hrms"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
41447ea8-1ae5-4249-b285-ef8b6be70051	pg	e8e63b67bf0d590aa7e563748bbf339868ee479bdd928a967f1d07a843d16ce3	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1751, "url": "/egov-hrms/employees/_update", "code": "null", "name": "Employee Update", "path": "", "enabled": false, "displayName": "Employee Update", "orderNumber": 0, "serviceCode": "egov-hrms", "parentModule": "egov-hrms"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6cbc21f3-1113-4fb8-91b1-a5a4a7f0500a	pg	367070852414759806765e31ee8abe4d177c73bb6b3488fb3de301597c005425	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1750, "url": "/egov-hrms/employees/_create", "code": "null", "name": "Employee Create", "path": "", "enabled": false, "displayName": "Employee Create", "orderNumber": 0, "serviceCode": "egov-hrms", "parentModule": "egov-hrms"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
224db3b7-1dc9-4e24-97d9-98b7d1b3dc1c	pg	b7daf2e7198dd244e3fbcb49b14a7ffa0531459855fb004be567d2ee4f967b3f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1743, "url": "/egov-workflow-v2/egov-wf/businessservice/_search", "code": "null", "name": "BusinessService Search", "path": "", "enabled": false, "displayName": "BusinessService Search", "orderNumber": 0, "serviceCode": "egov-workflow-v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
592e864c-b0ea-40c9-a583-8b15d68109f0	pg	19184b5fee65d6e2814db761e9b4c39b3a8ef0cb9ffbe880c7da72ec066e1fac	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1742, "url": "/egov-workflow-v2/egov-wf/businessservice/_update", "code": "null", "name": "BusinessService Update", "path": "", "enabled": false, "displayName": "BusinessService Update", "orderNumber": 0, "serviceCode": "egov-workflow-v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
297f1b8b-aac0-44f9-904c-98b4052c2e48	pg	8c36703bc48164eea4ca018c96a9540f12592f1c7773b234421daea548f3e67a	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1741, "url": "/egov-workflow-v2/egov-wf/businessservice/_create", "code": "null", "name": "BusinessService Create", "path": "", "enabled": false, "displayName": "BusinessService Create", "orderNumber": 0, "serviceCode": "egov-workflow-v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c109f8a7-2953-4148-b5d8-03c646bc3044	pg	7df56f709ccdcc6d89011f62b5ad655ea15ae5ef4bdc14dd0e1b90611d65b0a5	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1734, "url": "/localization/messages/v1/_upsert", "code": "null", "name": "LocalizationMessagesUpsert", "path": "", "enabled": false, "displayName": "Localization Messages Upsert", "orderNumber": 1, "serviceCode": "filestore url", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
170d7f77-e479-456d-b7ff-e625430432f2	pg	ab6e876102a7723ab57e6892f60be96625bc255dea2523373fb3f4af33937fcd	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 59, "actionid": 605, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9a0272b5-0fc4-4e6d-8b8b-f463adc9e343	pg	33b23b707006638dbda4fc0e44e076ac8057627888b29f892bef8a1920fcace1	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1730, "url": "/egov-workflow-v2/egov-wf/process/_search", "code": "null", "name": "Workflow search", "path": "", "enabled": false, "displayName": "Workflow search", "orderNumber": 0, "serviceCode": "egov-workflow-v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7628e255-a5e3-4db3-bab1-c7edec9a3cbc	pg	a7f4d52ce5f6d4bc89ceb84ac53594fe827f17f7b0948e0ea52e0787363652f7	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1729, "url": "/egov-workflow-v2/egov-wf/process/_transition", "code": "null", "name": "Workflow transition", "path": "", "enabled": false, "displayName": "Workflow transition", "orderNumber": 0, "serviceCode": "egov-workflow-v2", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
78f06d6a-4eb2-4bd1-a4cb-65f3e5854e90	pg	803bcb3e6f1d2d77607b8b5a2c4312cfc3f14aa5f74a5cfbd6a0ca1b33dff893	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1700, "url": "/user/users/_updatenovalidate", "code": "null", "name": "updateUsernovalidate", "path": "", "enabled": false, "displayName": "Update User novalidate", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9e86fb9d-5b5a-4e00-9cca-5ff63bbbff1d	pg	1ff7a44227126d63f175d3d3477ef270bbae8c94d859430a47922f2988fb90e2	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2561, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
eb77fb21-8f99-4390-8fa5-ec9afed35a4b	pg	73cef288fe632bbf9ca116b6f0dad7d6ef00c88727642b48b9d08a80b3ce5715	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1690, "url": "url", "code": "null", "name": "TradeLicenseSearch", "path": "TradeLicense.Search", "enabled": false, "leftIcon": "places:business-center", "displayName": "Search", "orderNumber": 13, "serviceCode": "TradeLicense", "parentModule": "", "navigationURL": "/digit-ui/employee/tl/inbox"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
45c83631-cb11-4826-bf7b-66926b8b1910	pg	f34eca3eac5ef928803da61e2889d8286d4e46cae3e497e30aef63ee81883d57	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1678, "url": "/egov-common-masters/businessDetails/_create", "code": "null", "name": "businessDetails create", "path": "", "enabled": false, "displayName": "", "orderNumber": 0, "serviceCode": "Collections", "parentModule": "", "navigationURL": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9fc76a6a-20c3-4697-b9be-e2cc3b092f6f	pg	5251c27b91bcb05105a0a6cab80b6384649ec53b6fc6184ac7006310f05aa513	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1677, "url": "/egov-common-masters/businessCategory/_create", "code": "null", "name": "business category create", "path": "", "enabled": false, "displayName": "business category search", "orderNumber": 0, "serviceCode": "Collections", "parentModule": "", "navigationURL": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
75c8e23b-5d31-419f-bb05-50ecaea1da2d	pg	b1d5f336668d105e98eea4b35c9ec5c4ab012e48350c78d64484b8a9d43b4197	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1676, "url": "/egov-common-masters/businessDetails/_search", "code": "null", "name": "businessDetails search", "path": "", "enabled": false, "displayName": "", "orderNumber": 0, "serviceCode": "Collections", "parentModule": "", "navigationURL": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2db9d03a-3b13-48c7-aaed-e90ae986ae7b	pg	4b01bef3104280e7be499b73f07dee47255e1a62b79eda85b46e1cdccd3c943b	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1675, "url": "/egov-common-masters/businessCategory/_search", "code": "null", "name": "business category search", "path": "", "enabled": false, "displayName": "business category search", "orderNumber": 0, "serviceCode": "Collections", "parentModule": "", "navigationURL": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f5e564f3-f627-4c55-a029-6192122f34f7	pg	fb974b22c23412d835c794068df2f48abedb3b99dc147b988f18fcc568f6a814	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1577, "url": "url", "name": "Assess New Property", "path": "Property Tax.Assess New Property", "enabled": false, "leftIcon": "communication:business", "tenantId": "pg", "createdBy": null, "rightIcon": "", "createdDate": null, "displayName": "Assess New Property", "orderNumber": 1, "queryParams": "", "serviceCode": "", "parentModule": "", "navigationURL": "/digit-ui/employee/pt/inbox", "lastModifiedBy": null, "lastModifiedDate": null}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2982b26e-805b-4884-a7a0-9cfe7300fb3d	pg	fb001baaef647a3e75bea9e4e2c79efca3b039962b2737bfa9171a0e1a0c2a31	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1559, "url": "url", "code": "null", "name": "CreateComplaint", "path": "Complaints.CreateComplaint", "enabled": false, "leftIcon": "content:add", "rightIcon": "", "displayName": "Create Complaint", "orderNumber": 1, "serviceCode": "PGR", "parentModule": "rainmaker-pgr", "navigationURL": "/digit-ui/employee/pgr/complaint/create"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a5db3d89-365b-49e9-9135-b0b20136b8a2	pg	7fd1246cff376ca86080561c10d4b31a24c48e07f634628d71415d8d0f1bedae	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1557, "url": "url", "code": "null", "name": "OpenComplaints", "path": "Complaints.MyComplaints", "enabled": false, "leftIcon": "action:announcement", "rightIcon": "", "displayName": "Open Complaints", "orderNumber": 1, "serviceCode": "PGR", "parentModule": "rainmaker-pgr", "navigationURL": "/digit-ui/employee/pgr/inbox"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6a4bf9fc-cc57-435e-8145-ba8ff2bcdc9c	pg	effb4f795d2bc1732d6800c3c62f9c5fe0b6b84f42d8475d560e9fe8286b0765	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1556, "url": "url", "code": "null", "name": "Home", "path": "Home", "enabled": true, "leftIcon": "action:home", "rightIcon": "", "displayName": "Home", "orderNumber": 1, "serviceCode": "PGR", "parentModule": "rainmaker-pgr", "navigationURL": "/digit-ui/employee"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
44ce28d9-841e-468e-9ea7-bb10926bf035	pg	a0cba32aacca0fdec66a1f78e55678741397b3d0261c29f686f5e634f55aba36	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1531, "url": "/localization/messages/v1/_search", "code": "null", "name": "LocalizationMessagesSearch", "path": "", "enabled": false, "displayName": "Localization Messages Search", "orderNumber": 1, "serviceCode": "filestore url", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0c1b564c-556d-4692-a8bb-35eb868ec87f	pg	be9537a5361d0e9fb2fe532d15f3f7d5640eb62f5316172e9e45127bc03277ce	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1530, "url": "/localization/messages/v1/_update", "code": "null", "name": "LocalizationMessagesUpdate", "path": "", "enabled": false, "displayName": "Localization Messages Update", "orderNumber": 1, "serviceCode": "filestore url", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
92b56f4a-e8f1-4740-a86a-56811afec17a	pg	bb83a87e9eb54ef6570e0204291eefb720b2e62ed70211f37375b8e776846016	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1529, "url": "/localization/messages/v1/_create", "code": "null", "name": "LocalizationMessagesCreate", "path": "", "enabled": false, "displayName": "Localization Messages Create", "orderNumber": 1, "serviceCode": "filestore url", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
15e1d863-ca95-4f22-ae29-d064aa85f549	pg	af8215a2d394aa4fe8efabcb12a77e70df718dae3e84bb36f9291e6fba586db6	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1528, "url": "/filestore/v1/files/url", "code": "null", "name": "FilestoreUrl", "path": "", "enabled": false, "displayName": "Filestore Url", "orderNumber": 1, "serviceCode": "filestore url", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a318c0d0-ab3b-40a4-9770-edbd3115ed70	pg	d4fb55d1b433c3920c54adbeaa2450b356d40cb5bb3651fdaf41008534c2f2a8	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1523, "url": "/egov-location/location/v11/tenant/_search", "code": "null", "name": "Resolve Tenant from Lat/Lng", "path": "Location.Search Tenant Resolve", "enabled": false, "displayName": "Tenant Search", "orderNumber": 0, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f7d726bc-efa7-453b-b0a5-c6ab69240bcf	pg	4bf0a26064276c9693f000fa2cbe1aefdb0a3359a3b135499f73f6b55c8c9361	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1522, "url": "/egov-location/location/v11/geography/_search", "code": "null", "name": "Get GeoJSON and other geographical data of requested tenant", "path": "Location.Search Geography GeoJSON", "enabled": false, "displayName": "Geographical Search", "orderNumber": 0, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
745d4e3a-eedb-4a2c-8fb2-7682fb2c9af1	pg	b28d49859ed91a126b650ee453e85363ebd2cbec3af1c106ec5069bbdece6b35	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1519, "url": "/filestore/v1/files/metadata", "code": "null", "name": "Uploaded File MetaData", "path": "", "enabled": false, "displayName": "Uploaded File MetaData", "orderNumber": 1, "queryParams": null, "serviceCode": "FILE_METADATA", "parentModule": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c5b77138-bc98-4429-acba-bdee36057773	pg	4cd0675c09cd9593e8bc69a6c18a66af31aa8e83edf2a25ded80a0edd56f3418	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1429, "url": "/egov-location/location/v11/boundarys/_search", "code": "null", "name": "Search Boundaries With Mdms", "path": "Location.Search Boundary", "enabled": false, "displayName": "Boundaries Mdms Search", "orderNumber": 3, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
511ffa58-a231-4a7c-890d-8e0e57003d79	pg	9b55fd5c0aea30eb0a01e82a614623e6357c9da020449c29a002110e0f656326	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 797, "url": "/egov-common-masters/departments/v1/_search", "code": "null", "name": "View Department", "path": "Administration.Department.View Department", "enabled": true, "displayName": "View Department", "orderNumber": 3, "serviceCode": "DEPT", "parentModule": "273"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
05864a09-7937-43b0-8067-eb9e9d253d69	pg	ed423e1bb930ea262f88a9496a3ee48315571c49fb9a74e841a458ca59b74fdc	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 796, "url": "/egov-common-masters/departments/v1/_search", "code": "null", "name": "Modify Department", "path": "Administration.Department.Modify Department", "enabled": true, "displayName": "Modify Department", "orderNumber": 2, "serviceCode": "DEPT", "parentModule": "273"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ee1f9507-4ae8-4f7d-bcff-fbdd18faba89	pg	62d4deaa5381475cdf958c9d8838a203df60ce60e3e5b78c8a2d34a128916020	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 795, "url": "/egov-common-masters/departments/v1/_create", "code": "null", "name": "Create Department", "path": "Administration.Department.Create Department", "enabled": true, "displayName": "Create Department", "orderNumber": 1, "serviceCode": "DEPT", "parentModule": "273"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4dc0f948-c0e5-4e0f-907d-a469c1211331	pg	ca1066bd9a1941acbd29fbb4ab5036b8042b180c3717cfe6789f8900e75447aa	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 697, "url": "/user/users/{id}/_updatenovalidate", "code": "null", "name": "UpdateUserWithoutValidation", "path": "Administration.UpdateUserWithoutValidation", "enabled": true, "displayName": "UserRole Mapping", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e289a896-00ee-4a81-b4ff-5c5095853d59	pg	03f6b2109a78e9d4e5813ac8d44bd50a324d84d380f345fb9ac3c4a37e8b7a81	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 1221, "url": "/access/v1/roles/mdms/_search", "name": "Get Roles from MDMS", "path": "AccessControl", "enabled": false, "displayName": "Get Roles from MDMS", "orderNumber": 0, "serviceCode": "AccessControl"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c5e7163c-2aa0-465e-a4e3-e79aeb49e2f7	pg	e5f9ef12d4305a503cabd7c865b359eb5db9359736903e22bcea0a74006afbb3	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 870, "url": "/access/v1/actions/mdms/_get", "code": "null", "name": "Get Actions from MDMS", "path": "Access Control.Get Actions from MDMS", "enabled": false, "displayName": "Get Actions from mdms", "orderNumber": 1, "serviceCode": "AccessControl", "parentModule": "221"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b9328634-29fa-4565-946a-cfea4dce9261	pg	6e65aa8dd9544ca2cfaefb19ba2b02e4fed8a8f708db98614756b782f0740eeb	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 979, "url": "/egov-location/hierarchytypes/{code}", "code": "null", "name": "Update HierarchyType", "path": "Location.Update HierarchyType", "enabled": false, "displayName": "Update HierarchyType", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
09611aee-d365-43a7-8ae4-6dfa1c88a250	pg	41c9886e7cbbf5eb4d6a2ee07b04f5d991d3b83e8af1d9b3a417c4e0e91461e6	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 978, "url": "/egov-location/crosshierarchys/{code}", "code": "null", "name": "Update CrossHierarchy", "path": "Location.Update CrossHierarchy", "enabled": false, "displayName": "Update CrossHierarchy", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
72551115-0799-4293-8623-93867afa7d5d	pg	b4af80862c26ae83c992146a4e2288e00b1906f639dfbc3c082f7a48fb07c799	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 977, "url": "/egov-location/boundarytypes/{code}", "code": "null", "name": "Update BoundaryType", "path": "Location.Update BoundaryType", "enabled": false, "displayName": "Update BoundaryType", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e494b2c2-cb1b-4e8f-b544-3d2d9c3c669b	pg	113be2b79e4df3b9ecb90ca08f217bc686a3e2c6cd543101869915de291e0caf	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 976, "url": "/egov-location/boundarys/{code}", "code": "null", "name": "Update Boundary", "path": "Location.Update Boundary", "enabled": false, "displayName": "Update Boundary", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
14819bc9-d787-4b59-8724-0948ae3ae58c	pg	7d9ba9beaa8e61ab474ef44f265f50e0d8bbaaad1f798072475092e5958bf499	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 954, "url": "/egov-mdms-service/v1/_search", "code": "null", "name": "MDMS Search", "path": "", "enabled": false, "displayName": "MDMS Search", "orderNumber": 0, "serviceCode": "MDMS Search", "parentModule": "306"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
98b1cff9-88c1-41dc-a41b-9effbbc1213a	pg	8467919dcb9ee878494c2dcdc5c9fc053c7f7d10e4ace9fbb87f5639682c3589	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 948, "url": "/egov-location/hierarchytypes", "code": "null", "name": "Create HierarchyType", "path": "Location.Create HierarchyType", "enabled": false, "displayName": "Create HierarchyType", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f0aef138-3fb0-4fcb-908b-675ca83f919a	pg	b06d6dc0039ab3e29fcfd955b74047b195cf6bd5f2a828adfc128de237bc7f76	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 947, "url": "/egov-location/boundarys", "code": "null", "name": "Create Boundary", "path": "Location.Create Boundary", "enabled": false, "displayName": "Create Boundary", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4ff54c68-28b2-4865-abf1-849687cb79c0	pg	e2575160941e17b482467bf3a72c99a166bf14f1d12f3663d864f26ad2663f96	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2562, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
18c441ed-9799-4a94-ab87-44722374f873	pg	bae47fa6e6c9fa174e308a0b46bc17d24213c2b2f7787b0f366efde7f801a14b	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 883, "url": "/egov-location/crosshierarchys/_search", "code": "null", "name": "Search Cross Hierarchy", "path": "Location.Search Cross Hierarchy", "enabled": false, "displayName": "Search Cross Hierarchys", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
534e6a74-454b-4243-9a5f-885b444b5b84	pg	2151b315fd4c92748a93a9927245ae63589d06ccb1c3417f618ee2877c910ff6	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 874, "url": "/egov-location/hierarchytypes/_search", "code": "null", "name": "SearchHierarchyTypes", "path": "Location.SearchHierarchyTypes", "enabled": false, "displayName": "Search HierarchyTypes", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2730d640-cef7-41bf-a437-7058eb80af72	pg	66c53205a33a9d80d596f65d150496202391763d6308b51d9adb3f44ebfcdc8d	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 873, "url": "/egov-location/boundarytypes/_search", "code": "null", "name": "SearchBoundaryType", "path": "Location.SearchBoundaryType", "enabled": false, "displayName": "Search BoundaryType", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
154e97a0-bc3a-47bf-ba5f-3be9f498e243	pg	d84c22c0c4e4eaa5bb2e01437278485bcb605dcf173179dca8da7a0ef75df316	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 798, "url": "/egov-common-masters/departments/v1/_update", "code": "null", "name": "Update Department", "path": "Administration.Department.Update Department", "enabled": false, "displayName": "Update Department", "orderNumber": 2, "serviceCode": "DEPT", "parentModule": "273"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
97c337ea-82ce-4de2-8266-34ec3bd293a0	pg	7233d9509a37bb95e6da98414ec2331c986262726408fe87c7f4f03ea7c50442	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 789, "url": "/egov-common-masters/businessDetails/_getBusinessTypes", "code": "null", "name": "GetBusinessTypes", "path": "Collection.Collection Masters.GetBusinessTypes", "enabled": false, "leftIcon": "editor:collections", "displayName": "Business Types", "orderNumber": 1, "serviceCode": "COLLECTION-MASTERS"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
25b7b034-1e80-4818-8e1f-79076e4555cb	pg	eb9ae73fc2590a704c10cc9325ea7eabda23ece98350e596374d2d24b80db30f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 733, "url": "/egov-common-masters/modules/_search", "code": "null", "name": "SearchModules", "path": "Employee Management.Employee Masters.SearchModules", "enabled": false, "displayName": "Search Modules", "orderNumber": 1, "serviceCode": "EIS Masters"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cccf8cfb-2348-4203-b7ca-8c55196c6739	pg	2eae7fc612b06202675a609f5682cd14b7029f410577ee1fc4003f71f8a000ce	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 732, "url": "/egov-location/boundarys/isshapefileexist", "code": "null", "name": "isShapeFileExist", "path": "Location.isShapeFileExist", "enabled": false, "displayName": "Is ShapeFile ExistOrNot", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5f37c4b7-72f0-4453-91b9-e36ef6ebcddd	pg	88e74e569c78a9affbaa78a6de24ca8cb5c1469b83201ee4e554e841a12fbcb0	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 731, "url": "/access/v1/roles/_update", "code": "null", "name": "updateRoles", "path": "Access Control.updateRoles", "enabled": false, "displayName": "Update Roles", "orderNumber": 1, "serviceCode": "AccessControl"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
345c2708-1784-4ef8-b013-fb2ba39a4959	pg	42565497ef42d9615807dfef20285b7b42cf0fb09c9a9a7a5bf864b94b2509dc	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 730, "url": "/access/v1/roles/_create", "code": "null", "name": "CreateRoles", "path": "Access Control.CreateRoles", "enabled": false, "displayName": "Create Roles", "orderNumber": 1, "serviceCode": "AccessControl"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9f259d9b-2818-4d82-a83d-a497984483b7	pg	96c3e4437f45b78001c3a1a9784198cdd1de1fb596b08c96b956ccb68187638c	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 729, "url": "/access/v1/roles/_search", "code": "null", "name": "SearchRoles", "path": "Access Control.SearchRoles", "enabled": false, "displayName": "Search Roles", "orderNumber": 1, "serviceCode": "AccessControl"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ac2ca75d-d6fd-4003-94ac-23e981b8dfb5	pg	b62058f37b5f542c323b6bdf332fd58c6180933db4a3a1a7aaebb78757d687b9	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 728, "url": "/access/v1/role-actions/_create", "code": "null", "name": "CreateRoleActions", "path": "Access Control.CreateRoleActions", "enabled": false, "displayName": "Create Role actions", "orderNumber": 1, "serviceCode": "AccessControl"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f00e65ec-1eb1-4189-b2e0-c5f625a1f464	pg	f189f02aba7431b5f03b5d26631f8ba1c3c54391cebdeb6c76539cecbdf3a769	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 727, "url": "/access/v1/actions/_update", "code": "null", "name": "UpdateActions", "path": "Access Control.UpdateActions", "enabled": false, "displayName": "Update Action", "orderNumber": 1, "serviceCode": "AccessControl"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d51d1f86-59ff-4e78-8651-0f8364803986	pg	741ba4d97973342072e29784d4c222d6bb9443b4e91924647dfb279de7c4164f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 726, "url": "/access/v1/actions/_create", "code": "null", "name": "CreateActions", "path": "Access Control.CreateActions", "enabled": false, "displayName": "Create Action", "orderNumber": 1, "serviceCode": "AccessControl"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0bba068a-1275-4bad-bc82-2b7fb0d35f69	pg	52f5fdee86bacee36a9ce2b146d08f0bbf40c878b5c7b5543873c97382d7c7d9	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 725, "url": "/access/v1/actions/_validate", "code": "null", "name": "ValidateAction", "path": "Access Control.ValidateAction", "enabled": false, "displayName": "Validate Action", "orderNumber": 1, "serviceCode": "AccessControl"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
db23f5e7-bd3c-4fc7-9a25-beddad00be1a	pg	bc5e73596b99d759bc66a4b1f32cfac8cc3f55b38f7e628f13c6bbb07d51ce3a	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 724, "url": "/access/v1/actions/_search", "code": "null", "name": "SearchActions", "path": "Access Control.SearchActions", "enabled": false, "displayName": "Search Actions", "orderNumber": 1, "serviceCode": "AccessControl"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b77cc9f5-5c30-4700-8f8d-950fcd7af859	pg	39f37e13f35557a8e21304c879886f9d5f8bd778e3dda21d1d1c2cebee57f483	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 701, "url": "/user/_logout", "code": "null", "name": "Delete Token", "path": "Administration.Delete Token", "enabled": false, "displayName": "Delete Token", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6eab9b22-60a2-4812-857d-92a1c36e5254	pg	baa3b58c92d3aa0934ddbe2356e67450262551acc9aae4e7672ae75debcf7d88	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 700, "url": "/user/password/nologin/_update", "code": "null", "name": "UpdatePasswordForNonLoggedInUser", "path": "Administration.UpdatePasswordForNonLoggedInUser", "enabled": false, "displayName": "UpdatePassword For NonLogged InUser", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2b66d5aa-5f07-4e7e-a6a6-6b4e9172619c	pg	0c73222b145d2ea360c0bfef1991a3dba7e3b9c9e074aa555f1d6d4e40a0afb0	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 699, "url": "/user/password/_update", "code": "null", "name": "Update Password", "path": "Administration.Update Password", "enabled": false, "displayName": "Update Password", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
caaf3539-6584-4e3f-82b8-788f29075bad	pg	d8a43731eea79e3c027c25a6e3b77f3a68626cda964b5a89a55d07b55978901c	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 698, "url": "/user/profile/_update", "code": "null", "name": "Profile Update", "path": "Administration.Profile Update", "enabled": false, "displayName": "Profile Update", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a6068356-e2a6-4b66-b76a-30273a01161f	pg	0269da81243878f4d5182c4c8e290fba40430f8ec1adc6e1c3fcac20ff49f10f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 696, "url": "/user/_details", "code": "null", "name": "Get User", "path": "Administration.Get User", "enabled": false, "displayName": "Get User Details", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9bbacbbe-0207-46a5-8a91-28894b1cdbd9	pg	38a70d747f1e0e3a21b5b2259e887342d524c62c3ef11b866ac1ffe9791c1df8	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 695, "url": "/user/v1/_search", "code": "null", "name": "Search User Details", "path": "Administration.Search User Details", "enabled": false, "displayName": "Search User Details", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
67ca1346-e481-4df6-adb9-9d77ddcdf2cc	pg	9d7cca3c3497608c11e547e2d4c938e2c288d27cfc9174445dabb27bfd13450d	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 694, "url": "/user/citizen/_create", "code": "null", "name": "Create Citizen", "path": "Administration.Create Citizen", "enabled": false, "displayName": "Create Citizen", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d2107c01-e190-4693-a70c-974abfec8d8b	pg	ad02154412f44a8df0c6aacb2a0588ea57ad2954ab6e8087725a58fa23bce3fb	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 693, "url": "/otp/v1/_search", "code": "null", "name": "SearchOtp", "path": "Otp.SearchOtp", "enabled": false, "displayName": "Search Otp", "orderNumber": 1, "serviceCode": "OTP", "parentModule": "247"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e594da44-f87d-446b-a653-10469a099ef8	pg	78ca406940552be3ea9a86a7cb26c891f91656896e47c7742635a088a6a8841a	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 692, "url": "/otp/v1/_validate", "code": "null", "name": "ValidateOtp", "path": "Otp.ValidateOtp", "enabled": false, "displayName": "Validate Otp", "orderNumber": 1, "serviceCode": "OTP", "parentModule": "247"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
81ed7f23-a065-498c-8f6f-1973fa0c2e39	pg	07aab54f22ffe7d17107dafd0d62107237e2d84330d4311fe79eb7aaea9f4550	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 691, "url": "/otp/v1/_create", "code": "null", "name": "CreateOtp", "path": "Otp.CreateOtp", "enabled": false, "displayName": "Create Otp", "orderNumber": 1, "serviceCode": "OTP", "parentModule": "247"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b761c846-bdc2-4824-b13e-9529d376d7cd	pg	0436056fd740917f9cc4facc2d311870b979b98871c543e1b8661797edcac883	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 627, "url": "/egov-location/boundarys/_search", "code": "null", "name": "Search Boundary", "path": "Location.Search Boundary", "enabled": false, "displayName": "Search Boundary", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cd8b78a0-67d6-4f4f-98d9-c39faf6258f1	pg	73ad0b6629cb0cd5114d2b9f73a93ee04d74efc3b3bd9ca33a4d9bc0d7711ebf	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 623, "url": "/egov-idgen/id/_generate", "code": "null", "name": "GenerateNumber", "path": "Administration.GenerateNumber", "enabled": false, "displayName": "Generate Number", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2f4ef09e-ed52-48d3-810b-2d9d6bee5b6b	pg	4828b3ab3c1143d393b29c4ad6597813dd408d4f04f35f479460f56bb44ab1e3	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 58, "actionid": 594, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
acddd6a0-7079-4c52-9eb1-91e784ec26dc	pg	29455213ed309180e548b4883cf39b129a9c4757081973ebd7abd74013b6c157	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 605, "url": "/user/users/_createnovalidate", "code": "null", "name": "CreateUsernovalidate", "path": "Administration.CreateUsernovalidate", "enabled": false, "displayName": "Create User novalidate", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3df4f300-a2c8-42c8-94e3-4aac3da04538	pg	314dcd2a3958c7f687d3bb95061e74f3fd0e58465d95a80caeafdb71ef32e1ff	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 604, "url": "/user/_search", "code": "null", "name": "SearchUser", "path": "Administration.SearchUser", "enabled": false, "displayName": "Search User", "orderNumber": 1, "serviceCode": "ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fc5c33ba-ee15-4518-827b-ada04fc752a8	pg	093882cf08f22f0907e47b292d14f59b2bfd8352462bc7ba0d052a2667fe61c6	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 594, "url": "/access/v1/actions/_get", "code": "null", "name": "Get All Actions", "path": "Access Control.Get All Actions", "enabled": false, "displayName": "Get All Actions", "orderNumber": 1, "serviceCode": "AccessControl"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f04145bf-8d64-44b6-8645-cadbda76add5	pg	83c9f5624a3a176d7a4e40a78fc6e398331b9d07bdd7df23b73f2b75e49d5647	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 582, "url": "/egov-common-masters/categories/_search", "code": "null", "name": "SearchCategories", "path": "Employee Management.Employee Masters.Category.SearchCategories", "enabled": false, "displayName": "Search Categories", "orderNumber": 0, "serviceCode": "Category"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
17f49bdd-31cb-497d-9242-ed556a67f55f	pg	d77f0afe387c98f893510a0a17e9255c8902d5474432166c998051692d822add	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 355, "url": "/egov-common-masters/relationships/_search", "code": "null", "name": "SearchRelationship", "path": "Employee Management.Employee Masters.SearchRelationship", "enabled": false, "displayName": "SearchRelationship", "orderNumber": 0, "serviceCode": "EIS Masters", "parentModule": "71"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7ba87297-0f7e-45a0-870f-42fdf7d90cef	pg	6b3616e93daa77e7f9b2b7a20751f7ffde0ef3ca6d39f99de673ae834a3359b6	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2562, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8ded28a9-5270-461d-94f2-002c63bef17a	pg	853dd6d18b911a41e3810fe84bf67b1d939b115116f8c42523e85d403ebcdf0c	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 353, "url": "/egov-common-masters/genders/_search", "code": "null", "name": "SearchGender", "path": "Employee Management.Employee Masters.SearchGender", "enabled": false, "displayName": "SearchGender", "orderNumber": 0, "serviceCode": "EIS Masters", "parentModule": "71"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7802578d-b6f8-4acc-ae44-e36f4221c709	pg	f2e4bcf599bf7c0daf9709771e685dcb97df7e8fc456b3ba045da14338e00483	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 290, "url": "/boundarys", "code": "null", "name": "BoundarySearch", "path": "Location.BoundarySearch", "enabled": false, "displayName": "BoundarySearch", "orderNumber": 0, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fa9c3fc9-c0ca-43aa-ba9c-1a24e5b122bb	pg	e95b62de3637b031ea46f8d8af2c0ed364e8e5d2de200e82b838621ea67c0918	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 278, "url": "/v1/files/tag", "code": "null", "name": "filesearchbytag", "path": "", "enabled": false, "displayName": "filesearchbytag", "orderNumber": 1, "serviceCode": "filesearchbytag", "parentModule": "76"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
321e5b08-70a2-4ce3-8d31-10beb07c8335	pg	14e251df6791710daa3a80ea15b4d315b9cc8e4cda06b6577593a9cf8fbea12f	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 277, "url": "/v1/files/id", "code": "null", "name": "filesearch", "path": "", "enabled": false, "displayName": "filesearch", "orderNumber": 1, "serviceCode": "filesearch", "parentModule": "76"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d648fe47-991a-4533-b333-630fb602d5dc	pg	3e69305363cec82c3558adab90080b3953c8b03979c5ab36316ea2d0777337e7	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 276, "url": "/v1/files", "code": "null", "name": "uploadfiles", "path": "", "enabled": false, "displayName": "uploadfiles", "orderNumber": 1, "serviceCode": "uploadfiles", "parentModule": "76"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b04f8635-8553-4987-9170-4386c3580984	pg	5575b73f9c0cb9fd1fa2637e426b58ddb2668fb68c1140c9c8ed018c30638b61	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 266, "url": "/boundarys/boundariesByBndryTypeNameAndHierarchyTypeName", "code": "null", "name": "Get Boundaries by boundarytype and hierarchy Type", "path": "Location.Get Boundaries by boundarytype and hierarchy Type", "enabled": false, "displayName": "Get Boundaries by boundarytype and hierarchy Type", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
662dec02-a543-42f0-833a-4bbe9eee4c9e	pg	267c8f3acdee0f63bf8ebec3a61aba985a104b62e4b78bc820b7bb983114a1a5	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 265, "url": "/boundarytype/create", "code": "null", "name": "Create Boundary Type", "path": "Location.Create Boundary Type", "enabled": false, "displayName": "Create Boundary Type", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d2e340a7-8896-4a5e-b9a4-572a8e5397be	pg	d10bf91a40ffea2fefe73de9bf32f482f3091a5d3c31984c44a63c84a30c04da	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 264, "url": "/crosshierarchys/{code}", "code": "null", "name": "Get Cross Hierarchy By Code", "path": "Location.Get Cross Hierarchy By Code", "enabled": false, "displayName": "Get Cross Hierarchy By Code", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f254ee7e-b6b8-4d6a-bdf6-e9ada3045f72	pg	51217c0c2562e631e8ea2aaa09dc6351e2c8a12d14f855d6dd648adadb1b2e22	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 263, "url": "/egov-location/crosshierarchys", "code": "null", "name": "Cross Hierarchys", "path": "Location.Cross Hierarchys", "enabled": false, "displayName": "Cross Hierarchys", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c8b06b51-dafa-4d1d-9d45-e7cca731778f	pg	481bdd833693875900c08abc81f04a95a3f47323583587eb8704759f9c8b9dc2	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 262, "url": "/hierarchytypes/{code}", "code": "null", "name": "Get Heirarchy Type By Code", "path": "Location.Get Heirarchy Type By Code", "enabled": false, "displayName": "Get Heirarchy Type By Code", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
68330a97-b92e-402e-b4ec-b8de48615e35	pg	f15d25cc20b12a77f4fdb895185ab19f2d51daf7cb877c7c32ca3ac5d2479a37	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 261, "url": "/hierarchytypes", "code": "null", "name": "Get Heirarchy Type", "path": "Location.Get Heirarchy Type", "enabled": false, "displayName": "Get Heirarchy Type", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8c606ac6-c8d8-44ba-b58d-7e1e79550895	pg	2f2ac525b419b399381f5408bb36ff2ea5c7960f27a525dea4b41ec99ba54eec	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 260, "url": "/city/getCitybyCityRequest", "code": "null", "name": "Get City By City Request", "path": "Location.Get City By City Request", "enabled": false, "displayName": "Get City By City Request", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
44879ca3-f302-4fb9-b6c5-188df691efc8	pg	0b31f1c24a84b530c31feca9d307e523d12084c872ff622747bb57e0e4c0fcd9	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 259, "url": "/city", "code": "null", "name": "Get City", "path": "Location.Get City", "enabled": false, "displayName": "Get City", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
218102ef-0f40-4be4-a220-c15ccb3d2c13	pg	0abf7ae2c1c364c39aed397f7766e3d88c7d2e3f49947d328550ec0450006d6d	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 258, "url": "/egov-location/boundarytypes/getByHierarchyType", "code": "null", "name": "Get BoundaryTypes By Heirarchy Type", "path": "Location.Get BoundaryTypes By Heirarchy Type", "enabled": false, "displayName": "Get BoundaryTypes By Heirarchy Type", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
52e0bd81-2be8-4975-8a49-621520ca04b1	pg	766a37c59392ead8cdd8882a17385768778cbef86aa0271ab75eb2c952080f42	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 257, "url": "/egov-location/boundarytypes", "code": "null", "name": "Get Boundary Type", "path": "Location.Get Boundary Type", "enabled": false, "displayName": "Get Boundary Type", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
96a6d774-9223-4733-b13e-f5394420d5c0	pg	b8d6b456ff3c932de1da558a93c11fd8c377d9910efd9ce755923a96cc92ab84	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2562, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
394c31a3-6bc1-4562-a61f-42f93f2c95a2	pg	ff147f0444b0c7875581bd767adace2c9e1b3b0d89a24cf2701d36461701f149	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 256, "url": "/boundarys/{code}", "code": "null", "name": "Get Boundaries by Code", "path": "Location.Get Boundaries by Code", "enabled": false, "displayName": "Get Boundaries by Code", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
57ecb3bb-8f10-474d-904d-fca53f85b4e8	pg	368f106f92a6e49d51fdd08afc782e6f58a7bb373545691cb99e385aca67a0ec	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 255, "url": "/boundarys/getLocationByLocationName", "code": "null", "name": "Get Location by Location Name", "path": "Location.Get Location by Location Name", "enabled": false, "displayName": "Get Location by Location Name", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e1aa941a-95f8-4450-a89c-8ce12d71fcc4	pg	fcf79ab64f6ae1246d88e5bb955d5d70331083c82767151cedf2a60ccdb06c4c	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 254, "url": "/egov-location/boundarys/childLocationsByBoundaryId", "code": "null", "name": "Get Child locations by Boundary", "path": "Location.Get Child locations by Boundary", "enabled": false, "displayName": "Get Child locations by Boundary", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
75c754c5-e4e6-4e97-937f-98b1d05038c8	pg	de648bd11238776e14e64c9f2db961c9f7ebf33364945ef10ae5ca2187ae4797	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 253, "url": "/egov-location/boundarys/getByBoundaryType", "code": "null", "name": "Get Boundary by Boundary Type", "path": "Location.Get Boundary by Boundary Type", "enabled": false, "displayName": "Get Boundary by Boundary Type", "orderNumber": 1, "serviceCode": "LOCATION_MS", "parentModule": "67"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1f65e6b2-899a-48b0-a8c6-00a017d4526b	pg	c53d7098529a3f64d269d77fb0bdd964bef0d4ec0dfb42d0493e37b15cf3efbf	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 207, "url": "/egov-common-masters/departments/_search", "code": "null", "name": "CommonDepartmentsSearch", "path": "Employee Management.Employee Masters.CommonDepartmentsSearch", "enabled": false, "displayName": "CommonDepartmentsSearch", "orderNumber": 0, "serviceCode": "EIS Masters", "parentModule": "71"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5876c92a-73c8-4fad-ac00-f60115ddfa4d	pg	43fb7e5b2ca06fc9e9a33ad163c9d36176fa626a3d30f3b494bd25c5c298ae20	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"id": 14, "url": "/filestore/v1/files/id", "code": "null", "name": "Get File by FileStoreId", "path": "PGR.Get File by FileStoreId", "enabled": false, "displayName": "Get File by FileStoreId", "orderNumber": 0, "queryParams": "fileStoreId=", "serviceCode": "PGR", "parentModule": "PGR"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6b477438-3ad9-43a4-a0fc-b1abf8725c0e	pg	f9c5beb3ac6fc33f070922e5a4c40a3be5884bef72262d54d0145ff46882c312	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2568, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3915a0c0-453c-4309-a89e-a1a2e295d4a3	pg	e4dcc945a036a3530864afd28e9ed6f36111784b4e072938a41fa2b11e9d7515	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2568, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0736a6ef-66cc-4aac-a29a-3bf032dac200	pg	b649ae9c5d44fd0774125796d7e51fd1653620bd4758e51b84066e725bb4c999	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2568, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
29aee88d-bbed-4a40-961f-8dc1634fd468	pg	79ef376ead958eb2609885beee139981c3f779d97c4dcd0982103ee395778a2d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2568, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9aa30ed3-9ee8-4941-8176-a66e6e8d6d32	pg	692551ccc383a3525895b225a719245aaee425fc61a5d83d0512ec97ee88be0a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2567, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
79e55f3f-3860-4f1c-a9f7-c7c74436b269	pg	c3bb28fa05c8d65107cbcdbad5e17a1b44e662fbabb0d17bec633e891d5347fd	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2567, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ab062238-7227-4e33-a7f6-00d465efe246	pg	043640001d2e9c52af46b75b07bad11f1494d7d42e643116eea0efb26e16116f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2567, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1f1c272f-da7d-4d14-a6fb-1293a8879968	pg	7a01765a2abc197162d1e858fbad1bf97c33cfbb489438f10bb8145bf973dc35	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2567, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9c11be8b-fcd7-4ba1-b09b-452ac4be5d55	pg	e8f6f18ec3244e27241ae26fea8db17bf5c035e1c234e384274838aee46a49e0	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2566, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
489d52de-d4e2-4d87-9de0-cd92d61b8f2a	pg	6b5fbcb40288b0da7975ea16ba854e0f9bdfd7802448e6d33623b2e61025b23d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2565, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5d533ede-225c-413d-bcc8-ffad83ef6fac	pg	7ad1c3b8c67f934f73669be67d9604fa590dc8f4988b5e4b486b4e0fc0ce09af	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2560, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
54321b17-5bd4-49b0-add3-a44a375f310d	pg	d883427cfc1778e3f49ff680d76d804bcea6ae9da034a0e40aeee20d9e9b42b4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2560, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
49dbe6d1-155b-4ba9-b643-ee3e9fe39093	pg	ee9b72b9fcbf2dc4c8ba98447f2f4d7b4584133175f7cfd81e554152f4de060b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2560, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3db6955d-972e-4d85-bd8d-6370d4f1d0f6	pg	886e8888edc3f3c683db0a87c7c183a4082c841fb0bef8294cafd09be0b6eb76	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2560, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
560a78f2-ac51-4b76-b680-72e5ac50e03f	pg	6ba23b30758878220b9eda1f616f43db07bdb1de36ea71bfbfaeb440dc0db48f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2562, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
17256769-72fd-47e1-add2-3c832c8241ea	pg	e4db40d456ebec1e626fe10511cf038bc3c721248f62ccdf31a59fa2cc6ca4e9	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2563, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ae548e98-ad74-4487-8fd6-de799d0bde1c	pg	ec28558214ee1c11d5382bc39facccecae3dde275e64c55c6c48f6f659b1700d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2564, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2e8f41ec-1cdf-4907-a6bf-3c3a926db2e9	pg	cc4258153cfae764d9d8987a206d703aa82b9696887159a4ac78d82d92f71f6b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2564, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cf706d12-6ed3-444d-b2f2-db1b03455434	pg	182a82dced440a2b855e689f5bce4fd376339c1557c990d10562fbc5a9b5f890	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2564, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4bfe8cba-1c07-4fe6-a413-2e86b4582a67	pg	17f8416d06380468761966ae3632e1cec6a09b11bef66c6bdc4ad3fabf60b910	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2564, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c4b21e62-c565-475a-9101-dd5deb8adf82	pg	f18c3db0c4a39982a00b2e07400a69de8d25da2fe0c5204294c59fd3c262d771	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1101, "actionid": 2564, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8d046bcc-4188-4f0c-af6a-82837c413361	pg	3642c4183ecf565cd359eaad81fb2a3ec7e7a0af4013df7fb6f657a7b83482eb	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1100, "actionid": 2558, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fa770ece-aa2f-4804-91fa-d627ce1fd23c	pg	82aa5fb0547acd229d8619c43444ddb75938c29ce487e10282a208e69cc7691c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1099, "actionid": 2557, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
35f1a557-588a-40c9-bae3-bc01fd503afe	pg	da39c19492475aad4a6cdcbb1937e53b5c74335f3d0af14519f6c89072cba3b9	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1098, "actionid": 2557, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ffc3d1e5-ecf2-45d2-b43f-7a9e8c8036ba	pg	30ce82b8a2f3c241143b6a57072c3e0cadca51a98fae5f0c4dc259bc6208fe2c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1097, "actionid": 2557, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7e68c38f-9949-404e-8b6a-a3fdbe1e9fdc	pg	7e7cffaf21529457f2dc8c7fe94284cf45a75db60b26923b195ca1855b5aa516	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1096, "actionid": 2557, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f75d64f4-f434-479f-b59b-4c5a3dd4f290	pg	33b8120824da06a7c71dc2fbb5ff5496e04f557564ca8de944012ff5322f0569	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1095, "actionid": 2556, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
abe0500c-45a6-4390-a2f5-9e17e6396279	pg	5b355c08aecc132cebee9458c1a24c792eca30a12d9083ea0406d8a3b6c9f7fa	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1094, "actionid": 2556, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
50189638-f271-49ea-9f04-6eac1e6fe208	pg	15c33e0cfc3b40392421acc68a852935d95b627073c6c9b259521206df9d819d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1093, "actionid": 2556, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b68082a7-833f-42d8-8ab5-f5ba27a6c39f	pg	a1dea2e39f1a7e5c56d4e6847df833b5397eb8a86a2ba5ec3065377773038df0	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1092, "actionid": 2556, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d05ea37a-55a6-488e-80e6-778f0d705f24	pg	77a07de7b9790c8737f2cc2829fd731dd2b9c0f73db722aded68e39cb6024f06	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1091, "actionid": 2556, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6775306e-1c50-4d63-a39f-0c4b0eb38dc7	pg	5d1df909557ee337a5cbaa094f60f2e0cec29f102d57550b96d647ae01add508	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1087, "actionid": 1556, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dec9a5f5-0051-4c48-b5d3-cea5f5127727	pg	f5879df8f3cfe4a33658024652ff80d3691730f65f101b3cd784eeeaea6acbe5	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1085, "actionid": 1556, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d462e760-bbb4-4637-b336-e2d752844ca3	pg	1c6d39a1ca9f4b4de8acd1300693274c558c2821d8bd873eaab57ce08c510fde	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1082, "actionid": 1429, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ba467a1c-129c-45f4-bfbe-dcab1648cd6d	pg	3bccb581a57c526b30db1f888492e94b6ddf872c09f12ee0277600836ec59de6	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1076, "actionid": 2025, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d25ccf9a-c14b-42cb-b220-f5f814ef9b7f	pg	c8b7dc6d1eaa4b45fd95b1edea21a01572097078dcc698700b68f62d054b90f9	egov-hrms.EmploymentTest	{"code": "PRELIMS", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5365b377-f85b-46d0-9de1-be95e612ea5c	pg	6e61bcb1f015e7c1a11fbfa7c6cb864c790f30219240756a484f1503a14bcbfb	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1066, "actionid": 604, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5c50a1b9-9193-43bd-baff-b8ed8f28a297	pg	35af067396aec87afcbf3b3616e262125ebddb838957a60bea7cc2338d2679be	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1065, "actionid": 604, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
aa1e99e0-15fc-46cc-94d2-e9903e5905dc	pg	b4aa7bf205e01cea249ce2fa34bc235b08886531bc2722f6d23d4d157b5f8352	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1064, "actionid": 604, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
66096ece-f15a-4425-bbca-c351a7b13f73	pg	107b3e5dcaac54caf2083031f36e4f8832125337c067402621729aa9ff9e31fc	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1063, "actionid": 604, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b46cd421-22df-44e2-aaaa-0bc1eaae338d	pg	b9f144ea5a2fb560a7e63ea6c6583733a655ac76bf7e0367313da96a197cd8ac	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1050, "actionid": 2540, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ce921ffc-9c0a-4f91-8aa4-4327081baf25	pg	a4c06df26d9f7c396605f89c6695bae1736a6055bd4cbc7aeedae6bdd3f54611	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1049, "actionid": 2539, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cbdc3661-cc43-4a0a-8842-c14852b5445b	pg	8187774c59771493a531a3fabb722af963aac0ed6c818956086cf41b96ee6bac	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1048, "actionid": 2538, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b883b284-d61c-43d8-8afd-4847d0870534	pg	6d40628869df586a8113ff76ea74a2824b8eba668d3b995e6a93652a2e385810	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1047, "actionid": 1734, "rolecode": "LOC_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
81c18025-15a5-495c-8eb3-9c9725567c9e	pg	9887ff7a3a1f8144862f1de7022dbc3e516caabcb29df933140e45371e2f525e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1046, "actionid": 2537, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
46f4d740-0476-4ea6-a705-530a5d8a66e7	pg	3394e48823bb0f0fc3e1fc0dc34e17dee1844d502bf1909ef11c5f923e0b3518	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1045, "actionid": 2536, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7428e460-485f-4029-8d7c-0fcb2648c9c0	pg	b9af7369130889a952ecaab9861279fcc8a5ea98a356bd2001499b0428369704	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1044, "actionid": 2535, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5772e22a-b7e3-41a9-b3be-2f6173af11f3	pg	ee1782e561e09eaac0046a0f250eaf78b6a144be6e5624f19d3d30013a253d49	egov-hrms.EmploymentTest	{"code": "APTITUDETEST", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d503d6c1-68f7-4de2-a34f-9fe1648dd6e3	pg	f9b96dbadfdd18f8736109526cd9d4f89c628082cd83547eeef086b8f494ba5f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1043, "actionid": 2534, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fe71a2d8-b283-4473-adc2-e410c297fd2a	pg	db3fc37df8b4beabb31a32e4a93aeb5c777aa266b7d4fab1986a691c8693d94f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1042, "actionid": 2533, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e82c248d-5040-4b32-8542-e7a4ddd2d20b	pg	a5f7e8eb81fbefe02105d6fa84cbee38afdb620bf23c3ea03231698d0568ff44	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1041, "actionid": 2532, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cafdb864-b6d2-452d-80c8-686f84ebba10	pg	b522166df7131aa252f829026b073080b54667ccdfca1104e4d3d2fb0c3d46f7	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1040, "actionid": 2531, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4e547468-63d4-4cc9-8162-30876c24be4a	pg	60c09b3171198871f657e1ff0fbbd212fdffea4d66cc929408d7a813b4782b78	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1039, "actionid": 2530, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ca395e4b-a9b5-49ea-8661-16279f92891b	pg	3668e9591672ce240dca901ff46748fa73993d87e3936d809a338dabfa54b5ff	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1038, "actionid": 2529, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d7617c7b-6c62-4e71-8119-89bcdf590dff	pg	f5452f3469e501186e53f1e8433d8e87eb9d9b3e5f6e9d411d92712d8ad8087f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1037, "actionid": 2528, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
07060875-61c1-4a55-b782-dccfd2e38ec6	pg	b9738ab92d130dc5d4249ae82c873bb8c893a188bb14c3b52a859836bdd0d5d8	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1036, "actionid": 2527, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2edafc65-de3a-4cde-9131-3c99cf533fad	pg	7d501c8c5b86f19f176df33de0df0539871d15b3ef3b06ec02422d13aa75b56a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1035, "actionid": 2526, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
54031ad6-a8e8-41d7-9f21-c74892a7c58c	pg	e2fb293d66322bd39338b431f828f00135af44bb1eb62b401a92c700b765cc2e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1034, "actionid": 1556, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d746bd68-278d-4d39-a596-cd1a963bbc7a	pg	5886a56d7b352e5d0eb71e71b7940020067a2bd5cfc00bfefa2f8366d379b360	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1033, "actionid": 699, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
37c66bc8-bd32-4614-9c9c-56a9aad4b0e9	pg	558207002ff29516abf7508f8c1889ae919dce5b9f2b50fe67db612f747f37f4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1032, "actionid": 698, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e3ee64c1-fb00-48a4-826d-0c08ec0c8ca0	pg	6fee2a402b3dee51168fdfb528f6982e9ef5c318f4ea8cb8bf0f36c310def685	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1031, "actionid": 2516, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1af3e0b4-17fa-4284-821d-677f595bceb6	pg	7d45a8a2852315a30cf867fd25351a6bf8cb1c76e0babb04ef43b2dce7873d57	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1030, "actionid": 2515, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2e17b4e9-186e-44c4-9aba-bcf5377a0f66	pg	baf38b22737800d0233de72f8090844466ff3d5ffe6ebba40fe268b9cdc86f0b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1029, "actionid": 2513, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b87e803d-68c1-43fb-b3d1-3086854625d7	pg	f4685debb0ed46258d5f2715884b989eefc4e85e2e115f22c502285f9c7e669a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1028, "actionid": 2510, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3de2551b-66b5-4121-bed5-5210923708f5	pg	f54dc3d29f1e933460725cc64896f530142008ac0f4d580eadd0fab91facc305	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1027, "actionid": 2509, "rolecode": "MDMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6db6dfcf-ad7a-42d8-854d-6dbab4863251	pg	a2d2f4c804179544054b7eb74282e3aa6bc85cb197923bf96a5ca8a2c9d73677	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1024, "actionid": 695, "rolecode": "REINDEXING_ROLE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
319d3a87-47cc-433b-a67a-1c83f3bfd2f3	pg	a91aba9809cd5012096dc809df5ebe2d961ce90b3cbd4c5c48282c71faf0ebba	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 990, "actionid": 701, "rolecode": "COMMON_EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8a0857ab-e9bf-488e-81c5-64a0471587d0	pg	1177685d29659237fb9a9442891604692f6df005cb97b2662fc1427866bd2b49	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 989, "actionid": 699, "rolecode": "COMMON_EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
52d01dc8-8c35-42de-a0c9-7153f66d92f9	pg	a21ec00481d22281b0912924b0de48925f97e05fba01aa24b4061520142a7f59	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 988, "actionid": 698, "rolecode": "COMMON_EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6371765f-f1fa-456f-9890-ebdba5a5c973	pg	c8b78349226d9f2af49243fa0f6c5b6f0634dcd96ce2038001413b5ad38bbfd3	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 968, "actionid": 698, "rolecode": "HRMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
441d9a21-19a3-4c1a-aa78-16f85bb5421e	pg	4308b0daf92b964480e606fa8048005c83597849073bd49cca01197064b63784	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 934, "actionid": 2317, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
17a826f4-ee4d-4913-94e4-e86211404c4a	pg	058dbfa1d06e9b07b5c9dc136ee5b9240b6bb006c5943ab1832225b195179dd2	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 933, "actionid": 2317, "rolecode": "HRMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b17760da-ae5b-4bb5-b0dc-3974f804f84b	pg	5fd3260cce2904c956d4e1b1f3be360228b92fd2e836084e72de92c82154a23f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 931, "actionid": 2317, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c9b8604d-fdd9-401b-850e-a8ee2342622c	pg	8fa3a6d842b4cf3e21cf9007f49e68df46401e1b1bf58802f867d07975a6e3c4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 930, "actionid": 2317, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8bc953e3-f331-40e4-9afe-b207e2991dce	pg	0e34f4757f2ecb834f32bf36d5d42e48e7185415e65c66e22146ed372b7b5064	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 923, "actionid": 2317, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1484eda9-1fc8-46d4-968d-4b5e3b3cfdfe	pg	ea0dd63b54e5ed2ec4824697f2df4bf96ba8ec7f630b4867e3540f207c505fcc	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 921, "actionid": 2317, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9fd3560e-8441-4124-80ba-23f8be30e66b	pg	22cc763196d451fcd6ff333cb911a7c3570774a6057e298283e20cc037ee3efe	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 887, "actionid": 699, "rolecode": "SUPERVISOR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a6e3f272-a7b1-42dc-afb0-c38125370543	pg	a8cd1535e4b1e957fe53ddb83c10b926627fa53bbfba3aad700ed42f70ebc013	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 886, "actionid": 2008, "rolecode": "SUPERVISOR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
df4a3238-80ea-4dbf-8af2-81a819cd7758	pg	da95a22ba9e43566baff8bc6d614567851d657de28fe8de311a9689c0478cc32	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 885, "actionid": 2007, "rolecode": "SUPERVISOR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c06d51c6-a72d-40e2-8461-3917ba48baed	pg	23c8ff9434e77f980410602121ddb36264c8ca6daff4a84a4f5279f6095892af	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 877, "actionid": 2156, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b5f9d19e-7808-46a7-b129-0910b066b62d	pg	dccc9154a4a0b8bcd92c71aec19307a19002f7da44681d55b71051b6ff972df0	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 852, "actionid": 2156, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
bd076358-4c17-4ccc-b289-f2c35d30f0a9	pg	36d00f37f9792a202763bc6da9fffc44d2337505d79d8bc64bf438a1b225e8f0	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 850, "actionid": 2156, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7ff7e8f6-a0c7-42de-ab75-7d2702825359	pg	0ef46324dd0c37cdb2346551e472629d9b55dee340927f6bca44e132153a1e40	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 849, "actionid": 2156, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0a5fa9dd-32bb-4f29-b5d0-0e32d4713897	pg	85f5babc45526c31ae9c05a91abb93f5bcd893a772c3f0f903cecd1d755edace	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 848, "actionid": 2156, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0246b82f-4a97-44e6-bb9f-09210536960c	pg	0892e16b6a7a1d8540b8c223b6d2f74e08988fd899704eef10c9f3c3ccfead93	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 840, "actionid": 1750, "rolecode": "HRMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4381b765-b771-44f6-8ea6-832ca3e903b0	pg	7efca3e26355d0d20a9a38a97ead5afca3969fbddd7929349dac4f6eb397d7e4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 839, "actionid": 1752, "rolecode": "HRMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2acc943d-aba1-4a34-a3b1-00c4479ee979	pg	0659d6599378803a81d086bde669285b3f702e4e730d55239edaf74d8cdde4bd	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 835, "actionid": 1752, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dec6db38-03d4-4f9d-b3ba-160a5ca24c4c	pg	2ef6e25e9b8cdb0225720962109de32b8912a673f88b531c823d080ff9fbccaa	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 834, "actionid": 2149, "rolecode": "HRMS_ADMIN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
89642676-906a-4367-a45e-3e9c2d02ca46	pg	7355b875c53e60faf12211bbcca0241abd1eb4891a10a59207c488ce7b7bd9c7	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 833, "actionid": 2149, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dc2492ea-07bd-467b-b763-942c7caf5918	pg	44f084778721eed4791d3e2a35fa36623bbea83aa8c6854776e6e2c974f0f48f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 793, "actionid": 1991, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8cc8d7f5-68fe-4672-b564-345f496d7b0b	pg	92cd30abf4002396e106a1b4e5914cfb97cc9bec61966e11c09ddd0b669fce49	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 746, "actionid": 2009, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9e7bb185-0f53-4b4d-b2a4-df15e8362db2	pg	3d06e685fa24791349dd98f023580cf8ac04f072bd25b8c8373f3d6cc90543f6	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 745, "actionid": 1743, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d1e8eb7a-5f9d-43d6-8af4-1a61ca7e3e60	pg	f9787e1d703aa44fc7ae9d5139be46352d8b7d6bf89b022add4502a6f5ab0499	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 744, "actionid": 1743, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cf234885-6b60-4e6d-a29f-aac8c981183b	pg	4435b82b4b15621006b3d2d78ec99549ce801a6a1c7863092f5f208a74ddead5	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 743, "actionid": 1743, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d24a439f-11c3-470f-a1f2-e288220a1e4d	pg	c6d829b62bf1541f37cc79339cae65d03fab8c865d40426013e181a1f21b17a2	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 742, "actionid": 1730, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0aed0fc4-0a29-4046-93ca-d496e1bb0b0f	pg	4b7d7485d3f9462aebd007a328b1ddb88428968dc31db35e4e2f50639eb5c2b6	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 741, "actionid": 1730, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
75a9e0b2-76f9-4269-ad31-07eb648a0f6b	pg	f3d46abd7e4b136c1f25b35d7e5e561941e842b1523335fd662771bbebef3a2e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 713, "actionid": 699, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
721941fb-cd16-40e3-8114-225f58d95621	pg	a2dc5c9e25b022cc07c1e24ab701c4517757255ec8bffb747ac854ee53c46ee5	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 712, "actionid": 699, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1cdeaf5c-e3fd-4f42-a28a-21087bdcfa17	pg	1411cc7afa4d725a90b3a42dde9e787653e46bb4b533e37875e8152e8523450a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 601, "actionid": 2036, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
33c94d4d-e6c9-4f66-8b81-03cff6b4f46b	pg	b8a3b5ad1f1ef8fbc5577717478d645997d003a528e652040452ee93765d06e5	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 599, "actionid": 2035, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
11e1dfa4-b43a-497c-92b7-2bd460bd9fca	pg	062bfb3462b38204e9ff837b2b34ac9ab886b87e465ab47b08b6f41eac1ad686	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 594, "actionid": 2034, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3ad14300-097d-48fb-ac65-cc31369a931c	pg	98514c685ae9bb05c9a9901a8d404cf891b882d436deba6377f822f8831622fc	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 591, "actionid": 2033, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9c795d37-07e7-4d69-a514-a0ed0eb80777	pg	070de5bf8537139c8827e4a7978458c310181551bac0cb0072d0d1b1477cee8d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 590, "actionid": 2032, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7276a1a8-da8f-473f-b4ac-589e9f1b7700	pg	93c46209303102433b16450a1aa4da1b4fad7a38eba250047ae7ed0f0186b745	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 578, "actionid": 2030, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
68a3fe98-ae68-44fa-b62f-aea0110b5c3a	pg	289522e69c9e9c202aac98e5099cee0daebbcbbcc644342fc2cc35716cee10be	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 576, "actionid": 2029, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3a24f9a7-fe93-4c2b-8998-0af30e632047	pg	f3ba6d6defce092f0e6e10e4927e57ce3665b39822eca83af01ddd3b768cd34d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 575, "actionid": 2036, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d29d78d1-a725-4393-b8a6-cbab860326f0	pg	d1535c2f4b98bfcb9ad5f1a52254d36839246253b7e2b08a68677988d3ebed4d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 574, "actionid": 2029, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
45d5bbfb-46f2-4b92-8cae-7a73496017ab	pg	c07b5f5d8e5c6bbbc868739a0b4ddb7bb7bf1cd6e0d71ecd726e23680d028095	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 533, "actionid": 2021, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
70d373f3-4a36-4e83-8638-1bddad3641e8	pg	585f7ddbcb6a7f82822bc89e242e7368caf8e83fda6c8d93cc23669a969582b1	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 532, "actionid": 2021, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d63fa12d-26bc-4df3-8d5b-5e8e38c83263	pg	fee7236e7e5b4ff323c4629a542ce0f4329a3a347871ec6e4d36349ea898a767	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 531, "actionid": 2020, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
01ee8592-f90b-4f83-a4a4-2b3203e060eb	pg	902840f8f1b19d11bf2e771032261392f2371ee5de47f166255946deeb0b8725	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 530, "actionid": 2020, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d5e9cf71-aa3e-4316-a421-25aa927df987	pg	bbb951e2a9a18c28edb4a203f1682a27e87320fa69bdc7c1f86fb498247e296f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 529, "actionid": 2020, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dcd1e3a5-c613-4828-bfb1-38d4b1148014	pg	302f420b10ed00202ad3a7ee69f69813070b10472f27197a623afd117456bbcc	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 527, "actionid": 2018, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1b7452a3-54c5-4a6e-8527-72a6dabe4e9f	pg	7d1d8810f4e816a68500461a4b4b05548d478329e01bbd4cd33d34cec21cb581	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 526, "actionid": 2018, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
66859d60-a827-4d72-85a8-34e43a1b0c24	pg	4180a608091b7806de593a512644a6c6e7f5bc3fe348eaaa145c9e8f26049b8e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 523, "actionid": 2015, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7a93179d-246e-40c2-b967-c0bbfe6f775a	pg	2a13117a43b7d8f411aecd4df31d006b6616494d2c2f0d10cb2db0103d73132b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 522, "actionid": 2015, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e4ccdbb8-7e97-4c4d-956c-058e6574c8fe	pg	ec8524ad7be665760b86301185752dc16c3bf0fb91b9bd34b3a442070893acaa	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 519, "actionid": 2026, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3a4cfb36-9af6-4fd2-96a3-55f3a4c248a2	pg	64cd711a9ca0318d0fb436b6b851a621926d79381c6f9a354d7d01c0056d8974	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 517, "actionid": 2009, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
07104373-fc72-443c-81e8-842634c1ce95	pg	98fc63722176ec03decd008397702e61225a2131eddfa5d88b1e3cad8a8728eb	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 516, "actionid": 2009, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e109971b-8491-4d67-87f3-794d97a3f29d	pg	ce9f6c2110875a0b9ebee1257e3a60793af2a3762aaa7da0cee758eb970a02fc	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 515, "actionid": 2009, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8012b7e0-73dc-4b73-9209-366b822b52d9	pg	b93a4314629dcd424d712e750bcebf718b9c8ea82bfa9240d9af8240b14973d8	egov-hrms.EmploymentTest	{"code": "MAINS", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e65f11ba-725e-44a5-a448-51db8733ce7c	pg	78a596a24ceaee20c010a732eebabdc02c484eefb33779066124bc47ec540c72	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 514, "actionid": 2009, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1841abdd-65ed-479a-8c3c-b042e796953a	pg	2de982f2dad239313677d6ed65bf67ea13f3dc14e69b5a19e410f4c6fb457b0a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 499, "actionid": 2008, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8b80962a-9f66-4550-a9c9-7ae7f4d5837d	pg	f153dda54cbaf2f3141871c46c33d3d698af9f032bddee734959e4fde7f67333	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 498, "actionid": 2007, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
edc7a548-9bdd-4855-beb2-3371a6081a64	pg	e0666adeeed759d466dc5a7419c63fd23944946e3c2ebf9b270595a95cdacd2e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 496, "actionid": 2008, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3ea1e843-2776-4f5c-b98f-a393b53995b7	pg	d75de2b4deb10933ac5c84a34e769030ae8ee8513b9040ebe392eb32e4be26a7	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 495, "actionid": 2008, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2d7f5526-bfe1-4c21-977e-3cf6847de209	pg	c5feb2191e372dbd5a79d08ff66c788756c1e68e308bccd92063416df129c51c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 494, "actionid": 2008, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
662b7042-d9a1-4040-9edc-0ed032c28c08	pg	a78e5d994947cb98a0bcddc6cca3a6c59576ef6a8500ecd997c5548b72ea8423	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 492, "actionid": 2007, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
86d260de-8877-4a64-b84d-5c1eb7128aea	pg	b49eb89e533a6f29e6dee5c8dc9fb57e0c93da4973a8547573e1e4d162f03caf	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 491, "actionid": 2007, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
af6eeec0-3d96-4a59-bc03-6df25c3a343f	pg	12e69d2c18297df1d7eb6cac64d516fda06f8985b60f6f6903b1e83c910d7e32	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 490, "actionid": 2007, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
38791df0-5c1a-4322-889f-38e300ed23ea	pg	ad4397d79c1efb8bfc7c83221c9efb2a8c537a430df2bf5a5f0d16448cd52717	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 489, "actionid": 2006, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
de028871-e47c-46f9-b3ca-5091969b8167	pg	2b5606216cba0b8dd5d99a23b6b07701f46adb248e6b8b0c050fb29f5e73df7e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 488, "actionid": 2006, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7e69b42e-4796-4298-b829-accdea7e1d87	pg	11e45fae976ab916ba2c563656b9cc3f39b7fcd90f33cfb5024bdebd54ee29a4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 482, "actionid": 2006, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0d66efb3-13c7-477c-b086-0762d07f2df0	pg	1864cf7e9ef55084d19f18084ca781a0c0f96a265a9dfabb740bf9ba14077adf	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 489, "actionid": 2006, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0e2599de-434d-4424-a664-2bbe5e70724c	pg	cac2a01710591f76fb3c9f3ea397c5fb7bd010c76059aff727f203337b35f69d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 481, "actionid": 623, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
538667f5-06ee-4dfd-a84e-a77b0deb54f6	pg	86862537e5f859566c1b98ca3599f1479187951b0526ac2a8336a00e3a6c8f1c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 480, "actionid": 2000, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2fc69396-226f-4bbc-8ad1-103e39c135cf	pg	9318a02e3b8ec29d326f6688f634559560811f39928afeb7e54738ce1a9efcad	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 479, "actionid": 2003, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5f201695-4a29-461e-82ab-8ccd42faabf4	pg	d94a18b13df62ec9b55b378c20f61b714ab0523644dd8217adb126c91d814d84	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 477, "actionid": 2001, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
08547d10-25da-4464-ae1d-f3eacbd5a7d8	pg	04abb9257e7999faae967704174561b45e34d0990c2d002bc76bb9cf0bccfdf4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 475, "actionid": 2000, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ab0752dc-1517-4ecb-85f8-0e7e4cbc1330	pg	be4d110166c9c4490fd086d53f33562e4bba13ccac3266dc3e65d68100b9c429	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 474, "actionid": 2000, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a918ad0e-2254-42d5-a657-6b079fbc7fbe	pg	c5825c21ad5d0ec2600eee28b245a061a330d6a9e1e2db6c9e3466bc778c5c0e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 464, "actionid": 1990, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
26cb36ad-9db6-4ab8-842b-6bfe2b6d416c	pg	56bf18aa8d2f261b1331143590371ba2421e371cbb6031eb5f479a7907df068c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 453, "actionid": 1989, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
37951f67-e0f4-44cc-ab41-e826a5b0c50f	pg	212a078c50075fbd9567c138357a1bc468ab8e1e9d4bf60301f5fa3a47f014be	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 450, "actionid": 1999, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d152d535-81b8-4508-a87d-99862bc25069	pg	bab6301501ff2d3d43b8984f2567be3cfca343fafc36262bbc3574fb39bafe0a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 434, "actionid": 1998, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c12a5d74-c06d-428f-9701-2fbdaeee3fc3	pg	1ed1420c86d9d4d4ed39b6c5e6c9016252201957c595f45d7eafc154603aae2b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 433, "actionid": 1997, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
381e7d59-0115-4697-aa0b-5d37edbae60d	pg	c31931089aa9f5a4db528fd56523a208abc69c5cb00bfde5828ffbd0a9336dae	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 432, "actionid": 1996, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8b9574d9-ea28-4ea6-a774-5237639c602a	pg	6a612e685cbee0751ad8709748e95fb79520ff6c3b4e96d1fd55b5c24986a126	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 431, "actionid": 1995, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9c3e4a82-2172-4dcb-a0d2-19b7d4a6354f	pg	0218cfed662440004b9f5e12f6304782cc4222869ff97273d91ce0ee8d79ffc2	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 430, "actionid": 1994, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
caddbab5-724a-4e75-83ec-6e2c278d3077	pg	e982a910e2b056665fdfe543bba8922f5a53ce82e0085cce49d741379e8f46f1	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 429, "actionid": 1993, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e5e96102-b490-4485-8165-05c63b0b3db6	pg	18303338495b196b0fad4c21ba24a4f2238c657ce746c5236f44b1a4cbf1096d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 428, "actionid": 1992, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
27ebb648-30c0-4ad6-8cff-a160f577d2eb	pg	0944ed3ebec09190d57a4c17953805e7a21a86317031797300d719568a4e0860	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 427, "actionid": 1991, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5910f02e-ad98-4e67-92de-87384fe0aeb6	pg	58404bd2c2ae9b28b9f91873f664e40e95ad2f69e6fc2fe070965a597132641b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 426, "actionid": 1983, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3d12dfcb-242f-4b15-8323-a13c5069c82c	pg	bd8efd576f846736a8f9240e6676bfef40ae45ad5b47ffe6c2d8efd690cdc392	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 424, "actionid": 1982, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3b7dd977-0bc1-4935-9b8f-cc63a552f724	pg	58dc559e9db558d31a1bc79bad395e22b3405007a3a399bd06b007a75e1f77ef	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 421, "actionid": 1981, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5b8d909b-18ed-458b-b2bf-bfb7548a19ba	pg	da557d94cc67d7ae5873e55d93f3d31e6f65ea600dc4daf0770ddca22f2c66a6	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 420, "actionid": 1980, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d0c65b2e-a781-4082-aae9-097404055163	pg	ef94abab5f22b44887a8a3a48848f217deb21f09105a7b9918114bd37d45e197	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 419, "actionid": 1979, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f67cd3fc-2afa-4afb-bebc-5e30c4cce348	pg	68f4a21332f3274f80a3cb29197b03488a1afd6c5a6c8d9a1f8d3c92b9ef9fc0	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 416, "actionid": 1942, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dea33765-fd54-44a6-b8b9-45f55dbcef1c	pg	b4ea68d6e714ba87f3f7059745a67ee6327dfd44596e87edcf53e7aaadb1e0e6	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 415, "actionid": 1978, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0f28b4d6-aa11-4a13-8ae4-587f72371207	pg	920c8cdd42d9e154739e6eaa5774fb112660a87116a774836d452e9ee7a2183d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 414, "actionid": 1977, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
118fd055-99c9-46e0-89c1-4ee7d59aa943	pg	579b9a60e29c2748d9aff26c7ea71b597a09dd041bc5cccde6f691d8c18a1859	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 405, "actionid": 1972, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8ed81248-dec1-4258-b1b4-fa733b5f61f8	pg	dc6e4fa3f140e684e5388aafa36d62950ea59eb976c9e75a3f009ed028af4770	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 393, "actionid": 1971, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6ec3140f-834c-4161-beed-13378ebf8f8f	pg	6ab3ad0678f09a4d89702c8b5fcd430aae2ed1cdae7f3ed2acb00128724cf7b4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 391, "actionid": 1970, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9720cb65-d4f5-465a-8173-462851a228a3	pg	68f6bd3cb3eab9bbe3fed0c61a37bcf45c744beb4c15386b5b3575db54261fd6	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 375, "actionid": 1967, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
675f0926-0b94-413d-a33f-0c2bcac4aba2	pg	54e345a5aa4bc308db11481452de6625a33f8bd813d14985f2bfed50f59a1e31	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 369, "actionid": 1966, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
48352681-f178-484e-b43a-8c990c468858	pg	1d101df41031fcf3b1efae71d1f0f4f8a4f22cf0a9cdf18cd208ab33f5068398	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 351, "actionid": 1939, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
67863ef7-1627-4ccd-9286-62f41e210a44	pg	77f84e158f71be0881bf0f69bab1b0f9e4001d2e9ea628cb465463da5be95e70	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 338, "actionid": 1901, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
decc3a44-4934-401f-9ded-4f61396d5e5b	pg	946728ca1a929ff712c9422d4e69144eba0788340a1c8261f783d1083c88249e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 335, "actionid": 1961, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
33f42403-1bbe-4fa2-a988-23aae76a08db	pg	9f851f1bba58984a684e83a33c9e2a4a4fdbea48ba083474f27e583230a99d9f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 329, "actionid": 1960, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
186a158b-386e-41ca-b035-b7f8b0595bd5	pg	684d1cddaa29f974fad9d42d0ef3c1b5c5cf056f86465f8152c8db4150a6b3ed	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 323, "actionid": 1959, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f817f565-2581-4625-8d3c-48c0ac2148fc	pg	3bb4d4f36498b20a2d3945dd85121af4fec202086445aab91820088f93b4f688	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 320, "actionid": 1956, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
daf88ce7-e1ea-4c8d-9cfc-9d1508a13b0e	pg	1eb3705fc08a3bfc1c03421f3e601fb00afb4696a364919e40e11ecb035e629c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 319, "actionid": 1955, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1d6a6f6e-00c8-4289-9689-796d51a79fa0	pg	cbc1311b5ff8550b3d6ec862078b446747ad680d8b63c03e487649b54a6bef9e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 317, "actionid": 1955, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5c68ff5f-2eb8-40b4-b44e-8ac06eee8aa6	pg	3663f05d985693fa226eee2a1a7ba355bcb15b6a7f7a6d99f75fb8ede1087af7	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 316, "actionid": 1954, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5f22ed25-5632-45dc-b26c-1b50e3571ccc	pg	25e311b5f4c378a97f594d6516fd1ad26d7bcebb66a46d76b0d2be67ed52610c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 309, "actionid": 1944, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
88f4ff71-1e06-477b-92f4-31fd89ddf301	pg	6dc95f330b701d0a2fd50e2974656e8fef343ba5b041ee3ccd2d1c1e36790dd6	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 308, "actionid": 1943, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
65ad366e-025d-44e9-beed-b930a64185e8	pg	5f8e22b06b8f6ce4ead4e235f83bb810a364342ca2b6a2546f33636342c9575a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 305, "actionid": 1944, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
195951ce-4cd8-42d5-85e4-89a78d10087b	pg	6856041ae2fef6d527d991ba563031f6c97d2bc171f38ec7dd66c4f3660c09e3	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 304, "actionid": 1943, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
877d9e63-9dc9-4c99-8c1a-86939677ebbf	pg	0ccb0b085a865ce1ad3277d2bfac7e33ac765e8a9828729ba55183a51f42b6f6	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 303, "actionid": 1942, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
760e4ee0-aa99-4d08-af23-99e0059672ce	pg	01bcaa995e6f9057405ad16bdac6be12eb122f27b2ca091b89a0b63175bfd510	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 297, "actionid": 1940, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e1dfb54f-dcce-417f-95d2-bba9a350b3db	pg	9a1a6631f4b0af9e27fe9d468085a87dafec3edac99cb3366959776623c8320d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 296, "actionid": 1938, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8174b778-6379-4a0c-b005-9b6830916306	pg	1b011e1eb61321ca638fc40793c8d06fc65967289c324627994e67ed46526fcf	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 294, "actionid": 1936, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d1fbebdc-f019-40b5-9aee-bfff164bfd4c	pg	e566e031731e9cdb524cb2be1a77939289082de4ab7bcde842b629b0550348c4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 289, "actionid": 1899, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
aab6cbe8-36ec-4372-9d69-77336e65a61d	pg	82834b1923bf308a482d557b812acabce156fa3f524159c14ae5f50904e2d751	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 288, "actionid": 1900, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
560f0c78-5b06-414c-9ad7-4f75c49139ce	pg	75faa04b9f5f1d584e14ebc27b8b31e7fabadb15be4be68514b0c933f1fde5ac	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 287, "actionid": 1934, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c7112637-afe4-4332-a780-924929dc49b1	pg	507ab91f9277be444207894955a481e976fb3dc69e8a1f2b1862272c91e9005a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 286, "actionid": 1934, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
98e7570e-d9cc-432a-b041-c505a336bd73	pg	1c88937cc450385bc3bb8a88f4ecf516f86a3bb4d77b86f6f589d68f7a90517a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 285, "actionid": 1933, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
eec85ffc-f950-4112-b6dc-308fb6999b03	pg	285ef660b8c101086b3e790eb07c7853b23f9031ac3d47f35eaf06ab669da774	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 278, "actionid": 1927, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f61deeaa-4d87-4b8a-936b-f5fd7b21a349	pg	1c560b3bdb814d9e98e4b4146da71c98676c2cac9727d232a2c26e2553fec37b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 277, "actionid": 1925, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
42a4580c-d515-43e5-b5f4-6a6fcaf279c5	pg	ba0291bbe1736fe7b731e690bb0ed220bcd5977bedba70ba4f6b9f3f829e3438	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 269, "actionid": 1872, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f14a8e0a-4db1-4a32-abc6-5c8312af6053	pg	7df23c9facbcab32f0832a87927c4f468f74843a6ed603fbbfb83a1ed79a1409	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 268, "actionid": 1835, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6647f12a-87dc-42de-98eb-b8f93c665280	pg	f388e704eeefcc8c18e33b74189565d62f44a599dc6f654aae13552d16cc62bf	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 267, "actionid": 1834, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
65776480-2e86-4f81-b285-a2bdbc3e95dc	pg	de7da79a016e7f0e844cb5c0a8d41c32b9ca49f2d6e2fe75bf388c2cb096886c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 266, "actionid": 1872, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
44ef4ed1-2a65-43f8-9cfe-af662e5ec1d7	pg	6338e242b3ffb76efac7f63f1f3cafc0967e90466c9fdedd32eb65d350bc04ae	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 265, "actionid": 1872, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9cccc9aa-4968-4879-a7ef-f456f336a5b3	pg	592a431317305e8fb48c9d6876025389c9bdb271b354104ea3f526337c5471de	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 260, "actionid": 701, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
46cb1b4b-5aa9-4e15-abc2-c9f62660062f	pg	de3aaa89edcc37ef5c916f04128c0802efcb1aa11c45a238798988dd38970deb	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 259, "actionid": 1835, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7c126637-0d48-4de9-b225-d98c87f5fe64	pg	48451589ae5af98aab0d1cba9f7e19905f69c385c9fb892f9a810c783094d675	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 258, "actionid": 1835, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f82e9df6-5bc6-45d0-ab18-565fdba40b7c	pg	8add9d6cfd8b2ac20018cba1e81c517a8b5451241cdbf398b6c66a99aa61b73c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 257, "actionid": 1834, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ed73889e-8920-48e9-9906-ce0080bfaa07	pg	ad9a01413fde10f5e769eab192fc6a2c060398e5c16d4b2b34d64d8a8187923e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 256, "actionid": 1834, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
288a1884-b798-4bc6-983e-b3a69af33cfc	pg	f4e20b67651ca9d59187770659ebbec93d6d72cb252d42d5c4bc3cddfdcb0a21	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 255, "actionid": 1814, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ccc2908c-b41f-463b-a629-84b7c5290adf	pg	82b0f917a46e9c13e1888d0e8f27105a3137a1fef0bae29c1cab2ec02b4274ed	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 254, "actionid": 1807, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dacb5aa7-ea52-460b-bc69-7f9a6a8f430e	pg	1b000626227e7ceb2baa419cfae42596cf6e6dcb79f1a4cccd0651ec8ddc920d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 253, "actionid": 1806, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
61eb48ad-82b5-4250-b0ff-22e30984fc94	pg	eda43897690d8910c97d1d09ade50433f0e1fa3afeadf2ef8975199552990b22	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 252, "actionid": 1805, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c2060700-dd93-40d9-b381-0854c81beaea	pg	788ef87cedfb8862dc6041c4a35889e0cb351b312b3d5fbc8a5e068718e31d29	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 251, "actionid": 1752, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3e7b22f5-3905-451e-8fbf-4eeae950483d	pg	655d5700044d129a729919661888830b97f0da5859bdce18d335c21209daeab3	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 249, "actionid": 1779, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1be96620-5c46-43e2-a99f-2ce47143b7bc	pg	85e275b778c92c5df8e345336893b6247e661213fae3f896fd068edf23dc286b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 247, "actionid": 1775, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
92e8ed6d-5332-420e-bd07-37816cc2c678	pg	768d4a841c0a94acf7d7e50ebf45b696fbafaf5764cc7160c059ce5e51715b40	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 246, "actionid": 1752, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
11a14c67-ce19-4b90-b6b5-b025b95d0ab9	pg	5195d59e0093c16a07c8eb501c1f8efa2ff922b124bd2bc46ce8ea0f70d1f881	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 245, "actionid": 1775, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e44a7b05-a52a-40d0-a95c-6051fbe77527	pg	b951ec009e482735658278929d5a674b0ef0ff4a58c26c6c19b4186ef2595477	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 244, "actionid": 1775, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8db4faaa-37da-4c16-84ae-d9df50774e2f	pg	4d335d921c533481d62c5dd1bc039851ff310db3a46536b2acd3f9336f6b7cb1	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 243, "actionid": 1773, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
94e7e64a-a09a-46ba-b170-6288d4cc41b5	pg	6f936ebf89d5dc7460bf7356d2ee5886bd5de9386ede896d3777326c4a726eee	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 242, "actionid": 1752, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9080be0c-c337-44cb-bb5e-b39e87d3af75	pg	3b5f4377334d91f5c36e9bceb340aa897bcd6a22c307ba413b8d5ead398b83f3	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 241, "actionid": 1752, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d2a98276-49b4-4f64-9353-c995cd1e8cfe	pg	1669c2f82c6a43f8daab0999925872cc88ef0ac92df753cc477e76d2c483f9b9	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 240, "actionid": 1752, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dca7ba65-1736-42fe-ac05-339bad32953e	pg	e83beb96af63b362d346459eb5b22c82298036c8c569c911851c7cb618c85809	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 239, "actionid": 1751, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
645230a1-a316-4026-bb50-1535b7e55ce4	pg	2f27b582ae91ed5dbdf42931eb9133b755002fe5e0f477b33ec8ad17984f716d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 238, "actionid": 1751, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
05953518-8980-4e48-89e4-b1bf9e383364	pg	bb6d27aee86cbe3d797a2d18f5046296863581647a1cfe8aa19414f1e549d847	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 237, "actionid": 1750, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
af0d9045-40d2-4e19-9f3e-8107b2d1b057	pg	9dc06bd7fcd94602bd5591262aecf68d2cda3a8a10f543d1a317b7ba77c7a6ac	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 236, "actionid": 1743, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0ee25e71-7584-4e95-9b4e-bbeaa8774705	pg	a3d7c7cd40a4889445cb81661a4d574253014ff224423b9ec6b5998a25f4cf70	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 235, "actionid": 1743, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
902bdd23-48a6-4d54-bca7-f5d08e4a9c7f	pg	f4250cf5dbd771dc90183be90a7f63160f326a006abac504f86fd365320e2a8d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 234, "actionid": 1743, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2cfed482-3c96-41e2-b3b7-d58f03593417	pg	35b322c4173b7626953ff3c2da355a5fa7247dff25ec87f0a873c9b1828bc169	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 233, "actionid": 1742, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
259f704a-3508-4936-a360-22f35e4d00d0	pg	13b1a73f06a15123d9eff848c29a05c8535a2b9c84561e9dfb02bc8955bd9285	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 232, "actionid": 1741, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6314e808-b3f5-4293-a03c-f7311d42389c	pg	9dff66e56269fb58218cfbe4cafa5c186f5f8b9284e0e0f99657b1e60fac1c81	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 231, "actionid": 1734, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
546015d7-03bd-4e91-a6d2-581221a3957e	pg	fe7695ce209f3d628934d3b15d4544c4131d82bb0bd21335e310e8a18480c11a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 230, "actionid": 1730, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fb043c00-6079-43a1-b863-1dbd14ea9ecb	pg	23663c8ad8655aaf915b31b7b113e28fdc6284a48a23597c60dd5135ce3c2362	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 229, "actionid": 1730, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
50ab5639-22b1-40d6-a84a-77dd05b3de67	pg	a496dbbd73abf15a3c45ab3ab3e236a9b4ff304281795b132690a4f002c81be7	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 228, "actionid": 1730, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0501e939-4a01-4aca-98b2-17449cb7dd9b	pg	9d26a1c74ca14cba5c39fe1599bf8f7313e97d7caf87245b399402f8f8dae534	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 227, "actionid": 1730, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fc824842-65c0-46c2-8a9c-a2a998055182	pg	c6a6c9ea184f3bdc08f62fa156923f0658554daa34ce6f72771d0701fc44dd95	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 226, "actionid": 1729, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
bb1f3db6-8968-4b5b-ba1a-318c10737ec9	pg	43635504c726bfb86f49fcad5cb2f084c3d5719207a829b87bc774801b0b667b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 225, "actionid": 1729, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e3de64a5-bc6b-4f73-8138-bc9949b7d85e	pg	eb43cdc9f58483e4761702c94734bc99fa9b3e00a723e3f2403b2c9d606d272d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 224, "actionid": 1729, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f73d5207-e8c7-49bd-ba6d-cef2782c3806	pg	ea71ba74972ca8a67de79a0517013c3790d10be37720bd9ece967fe05ff0d98e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 223, "actionid": 1700, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e0c65186-fb5d-4be9-97f6-f9ab1fc50ad7	pg	66abdafe33a7a3164e0971010084eaf42e7f7f4bd057cd31b4ec588765637fb2	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 188, "actionid": 1678, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
16400267-0388-4b3b-b8ba-048097a3fe7e	pg	57bd52fa26ecf45bebade604ee97c76d31ea67f7b2d92fa133c14c85a6123278	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 187, "actionid": 1677, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a5133266-03ed-464f-9d1e-2e6b9a62eed5	pg	d7798d16a7ce78fda0a613c9330dbcf9129bbe049889696ad87665c44ba6bbed	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 186, "actionid": 1676, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7ea83a66-8e75-4fc4-8e63-33db2ff0f5cc	pg	2c575ae1d2e28cd48f2b49fa611b780bfb241d560f9acf43a85839deea099e78	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 185, "actionid": 1675, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5e271f2d-7bff-4147-9862-d965bd7c9a41	pg	bcc63e185d849d7a28b47782fe17eb9df9cac9251282675357cf7200893bab32	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 183, "actionid": 1556, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a3c47d82-de66-4d25-b25f-c1cbada8702e	pg	3cb216ba483fa1f6d6c1f3e0388cf6c47d1615d71cbeb4842ef2feeac3f8ec82	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 182, "actionid": 1556, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d10e0057-5100-4aed-882d-807df362537f	pg	87ad61b8ce0ce0bab7f71d1f7286f31a713adaf73e2d974a13305ab725cc6235	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 180, "actionid": 1577, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8c04a98e-ed29-411d-8998-abf4251e64e7	pg	a423d4118eeeddcf044699ea5e6c01f9a4db096a1aa3db01ed8f0db19af50102	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 172, "actionid": 870, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7afdac55-35d8-4896-a427-ec8c40525031	pg	2d793b41ccb779a65249d1fb6a06ad378af24ede152d7f6a744657cd2f8a68e1	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 171, "actionid": 870, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b21371a3-b67d-4692-9a44-6c7e600fd3c0	pg	4782d0f3edd0b18b6b267e19178f9892a4d4b123584f26f62a9c5b9112f7b078	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 169, "actionid": 870, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f10971de-dc18-4042-b399-14ef7cc78351	pg	5fc8152c4d216dac8deaeb179746bf78e1f218cc0a35c859ffd4d9d6e0a0effd	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 168, "actionid": 870, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4eb1e541-03b5-4300-8ba6-a2b11ca9d792	pg	ac3644a94f6ed7516c030a2ed4750cbbab2a1fd77ca3abfd6d00d277818504a8	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 167, "actionid": 1559, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4a5f186b-b4ae-4ac2-9593-861b3e62dfc2	pg	840190c425244af2edfaa6e81adbc0d82803bdc472f347d86755071e257d4193	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 166, "actionid": 1556, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f80f986b-b90f-4e31-b94e-0eae49a336b4	pg	8387dd9c7eb2dda24a486a0a7c0d1ffb00dcec0da47e4dcfb775c58e318ef429	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 165, "actionid": 1557, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
493c2bed-8590-4833-9807-7da378321f7a	pg	3e3a57d8ecf61b9b1fb4093d8ccfe017b26d62fb12c600cf6128c3945d13fecc	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 163, "actionid": 1557, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
66c0a73a-33eb-4a93-9471-c0a888c0e1ba	pg	470c42903f05b5bb8d426d6366e2265ff154ad3dd72c535cac03c11e5f238995	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 162, "actionid": 1429, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4c5e2fce-3861-484d-859f-a4d418288c9f	pg	d79c18d03695e8f79094ff55e94d0f5aa0a61fe349e5160d514e33a8076d7b36	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 161, "actionid": 1429, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
10739322-7b51-4801-944e-6ecedd09bec5	pg	dc290263d886d02847c6989e6cd44efc664d29f512771851a08c282a3e2a843a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 160, "actionid": 1429, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dcb18b73-f057-437a-94e7-24e43055d175	pg	65e09f1f79c4ef462ffeaee35464f21b2b6dfb3acdf525d0de1a73e77213a30a	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 159, "actionid": 1429, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b81a40ac-8097-4883-93c0-35b989660d5b	pg	071444ece26facafcf650a825070d13f519a89f4b0f6b47d68564f486412ffdc	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 158, "actionid": 698, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7b05d432-4afe-4c14-a43d-39fd4b332269	pg	c266f828430713ed52abc04c017ef14d468b50e692d3787875366b1dfa350aab	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 157, "actionid": 695, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
133d68b7-846f-4afc-8169-2e3c8e29d842	pg	68b36244167c5d7f0b957fb930aee3ab6190e989cbd77729b1c03de44a977fff	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 156, "actionid": 1523, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b787ba73-6641-48de-9362-ab56b4fa5293	pg	36af90b8168ce0cbcee77b6edebb8d99b0943789ce4a66aa07426dda2afb4c56	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 155, "actionid": 605, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
64a10d79-701e-43ee-bb7c-e8da0da5e74f	pg	093e0407cc8ff8662a7c5be4c2f45f7aef7d022b4c194fd8a9db6a85c2c60d3e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 153, "actionid": 700, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2e1476b2-e960-492f-8142-b3ddb14ff41d	pg	ff64eb0a07fe77eab8ff6778e4861dcb91d510d13ee96ed55ea42eeb49c92d56	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 152, "actionid": 700, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ec3a41e6-1785-410d-84c0-4e2f32b2f885	pg	1b7fc4f23d1209215a52a0b3e52c424b08795878a0982f9150bfe53041e0286d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 151, "actionid": 700, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4ed22839-8118-45d4-b9eb-ae421ff885f2	pg	d0a599d8a026246b36a7dc0cc048e175e9806ad9e0b6261b4adc7c29053748c3	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 149, "actionid": 699, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d1a88240-7067-47d1-9718-f772456c2ffc	pg	e1ee818f929d54e792df288986751073eceae59501b23db0c2c64ea408c187d2	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 148, "actionid": 699, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1138b9c0-b25b-4c85-8346-35399f6a8fbb	pg	2c2b2de7b3a17d4fc8d3750d112cbb000dbd1f0fbc685deae010be27b73b6cb2	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 147, "actionid": 699, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b77dd822-c8db-49e6-9c93-19c991f3900a	pg	5cdeb7d9f00639c90670066e088e167f3b842106818a94c967273c2715bb060b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 145, "actionid": 695, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
aeadc90d-3d88-4e6b-9e7f-e9902d7e5505	pg	cf12aa740a79133a0e846e5ed5a02f5f54488390f865d0fe920d6d7b18bedac9	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 144, "actionid": 695, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c909ec8e-0106-45f7-b249-fe16a9a1795b	pg	aee59fb0469570966291b46e9ff9cedfe846d951b90efe6141cdf07d1dc24a57	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 142, "actionid": 698, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
bcbccb4f-a9ee-4bce-9f9d-1ef6329c1a10	pg	1f5d45c020d68e4b5b8635e170129604eec17fa78e90487c9d6457b05eddf5c0	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 140, "actionid": 701, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b347159c-7d65-4250-9980-7353999480f8	pg	c3976c0ff9fa475dcc1f1fb4effd95bd867721fbc8ce055e028e65f3ebe3ba77	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 139, "actionid": 697, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
aeb2bc0d-0bf9-4997-ac20-2694df5ff8f7	pg	97aa25e99e64a12fc90db6eed3f87948574672c2fde9181299c7b5be51fe65cf	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 134, "actionid": 1531, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1fce699b-89e4-4efc-ad75-4e6e50f1ef47	pg	32dd487a93495d99e9a05e7186f7bded025cda48fd3fccf8a6d798f07f13b694	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 133, "actionid": 1530, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9329157d-57ae-4caa-8232-aee425bf429d	pg	f1a051c4b95c1bd9d238357f15fb24a3978021c188b156d6f234dfd28398b369	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 132, "actionid": 1529, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e0981b34-6ce7-46ba-b7c6-9f46eb416115	pg	034a0d4e6db6d200dd63252127595c595baa5e92e5c48c62be4a40e28cc5edd7	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 131, "actionid": 1528, "rolecode": "GRO", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
97f1f803-dc41-4cca-9352-43a1870ddf6a	pg	b02754bffdea64628fd292f54cfd528fab3163df846c322786025d1777ff0ca4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 130, "actionid": 1531, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
977cc318-c36b-4f01-80ac-717652ae436a	pg	8921e15d06101997c986792dec53676bc2f2467243de4d1ae9080810e75e0bca	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 129, "actionid": 1529, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
63adc1f9-61e9-444d-81d0-24ae0a7cdb21	pg	c4fe9c44894a1909801cc765b0eff94350fbcb39666d382a7a1e125d31f40315	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 128, "actionid": 1528, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ee05dbd9-4ce5-4e40-b301-29270eacfcbc	pg	8f7fb1bf6b542d358dc546837f5e37fa100fc0d6ab5b16d8b05531a1da5b8460	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 127, "actionid": 1531, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9c087e9e-36d3-4328-a5a3-8dd4a4bf8fa4	pg	1b7d57e78c4838b86ff055ba389e69071f735477c78d3d5bb240ed42b0079f87	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 126, "actionid": 1530, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
39a0ceab-3ce5-4ce5-b79d-7c447630ec19	pg	ef4fcde6f88a9c94fa5ff59fde22f1fac0722132f5928c15c9ce4f0f86faff53	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 125, "actionid": 1529, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2cd644b8-8e2e-49ee-986a-d2fc1dfd3643	pg	b579eaa8307645c9f242a4df69c8f8218d8a13b1e6bb5935b484d3c1ba418e10	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 124, "actionid": 1528, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
da9efa0b-fb70-43fc-ba9a-00750aacc19e	pg	8d2748e8156b4441c2f039a1cb1f7b2d805f0c68e825af22604ebe8ea215c224	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 123, "actionid": 1531, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
12bef83d-87a0-40ff-8694-b7ea54ec80e2	pg	090f707f142da43e86e8273002c1af333e7e54bfb9a3719dd211a8edb2525173	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 122, "actionid": 1530, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ea88e62f-8619-4fa3-acb3-30a38bd61afd	pg	84e08f4fe9eeefd973d38e8311938fa68a79d414f588abed4fb28f89efaea3f9	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 121, "actionid": 1529, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
487aff72-7286-4840-959a-be120cb8b905	pg	db5447b39677fae4fa2190aed6ca2050e3d9d4bee0bedb27d773d91df34dda4d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 120, "actionid": 1528, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
89b3208e-48ce-4fa6-bf68-eeb8f1332b6f	pg	b64b73bb336946ab77ca6e04c4785a36e64258dba822fbc990dee1fb39ce7a13	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 119, "actionid": 1523, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7312c09d-bb5f-4b13-8f06-d7f1732504e1	pg	8359190d58279f4b6b2736c8f9869ce7661878b2e5cd4e3f86cf1dcb14e9a5a2	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 118, "actionid": 1522, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3ef2c291-c7ab-445b-a1d6-ba152bd960ee	pg	4ff53f55b5ff6679adf447213effca76bd493b5ca532fcdab46b45ce17437dbb	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 117, "actionid": 1523, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
29b369a0-d5e8-432f-baf4-ce4351d09967	pg	e08c9c09860521a23dc866c5a6b53b849ab51d4707e4ef354492f85bd6aa68ba	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 116, "actionid": 1522, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4d82dd83-f7e4-4e5f-8a49-5f6c56862bc7	pg	95267a8049e2ebd2dbdf604eddfc035610a81e606e2d5f026bee4c1f0b2442db	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 115, "actionid": 698, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9c15750e-8a0a-4024-bcac-24068015cf58	pg	f7d9f4b291a6f3674f969ecc5273324b0e57814e65b93c2ed15b9b03c3c5b6f1	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 114, "actionid": 698, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f5d7da1f-cc5a-49b5-af5c-3d450deb2b6e	pg	d6528d5bef28bb201e3c9205158099ce61fd65984396bca3d1cfb5b4cd616a13	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 113, "actionid": 1519, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2b91352e-3d97-4f42-8c39-5698a6192d76	pg	cad3db417d2505d17a0e4f0f5abf9c2ad1cc5c643287b5c5fe2f6f79403ceefb	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 101, "actionid": 1429, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
44845418-006c-4e48-9a98-4da0a46ffcf8	pg	414e2e5498fd92710982544e5c565c16c752e05aac3dc89c4e7335403bdeeda7	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 100, "actionid": 1221, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b75a629d-a2ec-4370-8857-23530cce9b89	pg	387f3281b3404f039dbfbf47987222fcb95fb5dcd0fe05a41f7a1a39cfc39f17	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 98, "actionid": 979, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
397fff0f-f739-44d1-8161-4fde3d6a02c6	pg	4f4bd84dcb7b36371e6a15e72d05abe8f76e767607f2e52075cc344315d4eee4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 97, "actionid": 978, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0f183e83-e31d-4afe-bab1-258e63e13146	pg	0f82b462dbf88b13478454b96125f43202a8c3c3370fd5700f0ed65b98d7dd71	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 96, "actionid": 977, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cfb5c7e0-3ee9-40af-8959-948d6ba82019	pg	8282af95d445a2dd45e40c311a8e5442621c1ba22248ffbf83ba6286336253e8	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 95, "actionid": 976, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
33a8deeb-7f4a-48e1-955b-7e4bf8fad857	pg	a28e83151caa6a93b6a67499b17bcf6c1ba7219cfc07670f609e1e106f116611	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 94, "actionid": 954, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
46d7c52b-1556-4b23-bf27-14833f506079	pg	c08f5bbde9281181d2984ebb03991ef833eb5477ec33240c43663b1592dbf296	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 93, "actionid": 948, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
84eed12e-6401-4624-bbd8-e85e07ea11a8	pg	b0d5eeb75c2fa92db4b1909f101574b5960c057faf4b0cd33edcc2168b8bc808	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 92, "actionid": 947, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cf04ea6e-b868-485d-9fe1-8a45f0bceabc	pg	3e628f34be49249ccb0d758a8f0a05825f2242c338a0a9569676fe74108b5a40	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 91, "actionid": 883, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7d06969c-4bcb-4fa3-842c-7788c9677be8	pg	be90656c605397a5ca68c801f6d8416f045db0d2daae7656ac75df61ccf3d71b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 90, "actionid": 874, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
107feb82-aaa0-4586-9fea-3001bf6e7ae9	pg	026f82311f0c8c694cfcba2f04dc2df745d4bd4b0dfab81c298feca6f2040d21	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 89, "actionid": 873, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a284af11-a228-4100-b391-de24243d8f8f	pg	effcb050bc5d96d2caf18c2c9b8e7b34de14adc080929c1ddb61d6e7e53efeaf	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 88, "actionid": 353, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a5dc1933-c132-486e-88a4-e7814977e4ca	pg	0ecc8c98700380cbd5b3e326a6e63a7a39fbc7fc02fd1f15ab1faf08351a2f2f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 87, "actionid": 627, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e6233c0c-a9c6-4432-9038-f8a6834abd0f	pg	a65e99f5bfb999712f21d9a983b1b45c3b144df031412c98be0c653f9d7a1bf4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 83, "actionid": 870, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e0987485-c078-43f1-9226-4eb16c835390	pg	57b848fedfcb095b5a1740d2403f7132f8227cb59c0a73381011648b04dc2f58	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 82, "actionid": 701, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ac69a32f-0144-4dc0-b684-e45cd8e529a4	pg	ae1eb762577fd0b4f61dae04fde183f6fdd9b09c805547ada18663697fdc7509	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 81, "actionid": 701, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b95524e4-2767-4569-a7b3-0eaa43e49a33	pg	de436521fe0c59f952dd822f504722c25d9d4fa0af6711d80278c9ceed0751c0	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 80, "actionid": 798, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2b099472-0774-46c4-9ee7-d08f1879a001	pg	e3cb47bba7ad2b9df292c7884db75a641be7ffd05766f28a67004a6e4c94b884	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 79, "actionid": 797, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a2506feb-87ff-4801-84db-111820417d8e	pg	84d64efd7ac9289d88c48307e47b8495ec74e9e2d9f84ec5f0c320a2d0b103c4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 78, "actionid": 796, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
960e9760-5a22-439a-a30e-e207c39e2903	pg	1c9ed0afede14311cd463636123809b7a89eb461f528c988076e6180ac9844fb	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 77, "actionid": 795, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
64bf51ea-434f-41d9-b0a0-4460844c6384	pg	7fabea114ea9d070e19ee85286a2c853f07bc013c165aa5e289103530906cec2	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 76, "actionid": 733, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
043922f6-fd3d-4760-8854-90bc4d3b8b7d	pg	2cd5237ea87f47f89eab1c60214da5ee1ebcaf6c6cf2da747f904a704c937676	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 75, "actionid": 732, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dfc729bb-db90-4ccf-bdde-93314ef4f734	pg	c196f73371e57f206949d3d60bbf624a9448cca3cef2a7bc5c2ed136773854a0	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 74, "actionid": 731, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5ed24b69-c56d-42ac-831a-57134a12771f	pg	300dba4ce8ceb2eb782f024172a56e4472076cf07e05816db9fb28becada98de	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 73, "actionid": 730, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
16c11555-59a3-4736-b395-5e3cfe4c3087	pg	7fdfb048a6e732b85ff41021cb62bcb332d4e45757d32639509ecd56e2acbce7	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 72, "actionid": 729, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6652acfd-b9e6-4547-b3dd-215bc12d25a4	pg	b0e2a0dd9ec3212f82e14ddfd6e685e133ecc27d306b238ff0d3c3bb2bf19f3e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 71, "actionid": 728, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
00a5f35e-9693-476c-8b95-c8834b99125e	pg	24e3fe04a0e001589822c1fb88188d84f17cbaf42a262416bd5bc32e21b44f84	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 70, "actionid": 727, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a52a38dd-e63d-4998-904e-335ff6f5a459	pg	6c821606fe8f3ca682be00e9e9e0a4b6482b34109619692d7e2bb596b918e792	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 69, "actionid": 726, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f4aacd11-407d-4402-a468-bbda600d75ff	pg	d0fb3c5623ec9538db082f9a9fd5e6e82d386eb21ed432a5d942b96e514d37bf	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 68, "actionid": 725, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
59d8d637-1ac8-4829-84fa-0984a6278168	pg	8deef8bbe7b5f37ecc5a5eb3efd88f2969437f425d6f55a17b3464f3ba89a998	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 67, "actionid": 724, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
09c29b4f-4480-4ed6-9f3a-a6445fd16c82	pg	dda909e163d71df6c4a929d4bfbeb08520c1ba34c3aab2e820e5310c8730d720	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 66, "actionid": 627, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f58efa7c-4120-40ea-89db-a12ea8aacedf	pg	1cde343daa87308ab4d9cd9ff71898694e76496a4bd2e8c76148749fecb61bf6	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 65, "actionid": 623, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2677f8f0-8286-4733-bb0c-dd303439d624	pg	6e7911b124577e981c71357cbb0d09551aa282c6f4b49bab8041966276688aec	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 64, "actionid": 254, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e566a754-8424-49cd-af8e-6e6b5ff3d4d2	pg	fb19ff3824ad3a9f1cda8ed892a08ddc5e1548855df75290a6652224b9e17758	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 57, "actionid": 594, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
800d1463-7022-4c3a-b20e-54f11ff60486	pg	5be4e6cfe9d42b567ab23b1f69699e5ce6a28b43cb3af80c032b8a9f3c43be07	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 56, "actionid": 695, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
521a123e-9fc1-4b48-bfd6-1617d2d12fe5	pg	59733f844ea6cd15e5bc10e4ec0d3e0ba0117097528e193c3bec6f70d23b3aa5	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 55, "actionid": 355, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0159fb6c-4fdb-4a93-b561-bd4148faab70	pg	44408ddacc1523f31e7aab5132383114e7875f8736f465af6346801214d4ff9c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 54, "actionid": 353, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
06224f4a-0dac-4885-b117-f8b83ef73807	pg	81ce38d5774d369963689ba610c4079b913d4d7847c9855b7cfe32dc19f3c11d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 51, "actionid": 355, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d47b53cf-3c09-4b48-b00b-36b8e23bf550	pg	4aa3083b498bb8f0624f023dd52f830f4964ed8e8405e69a1a37196817005f3d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 50, "actionid": 353, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8042c791-0488-48eb-a4d6-92e055d58368	pg	d2d1b6d7788b51354db921a37f8ca2d71f277eaeb53782011c20480f289916cd	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 49, "actionid": 207, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b2429f5b-b20c-4c55-a374-aa6c18522eab	pg	34ac0aa26a61e90c2ce156fe8d488d0dfc50e822366891cb6120c72a407bdc35	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 48, "actionid": 258, "rolecode": "EMPLOYEE", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
59fd1f6d-cf34-4416-bca4-28c10c7576fe	pg	2011cef2acf81b01d8e724e4bea1b517fbfa5357bba3d87ad000fa20bae916df	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 38, "actionid": 701, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6f10da07-0a18-4b0e-ab65-d57598cc6431	pg	f7d63ac6019718be1b199d5ec1199f4aaf16de5e6f4bb6538dc4155dd66c1b62	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 37, "actionid": 700, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fcefb4c8-e0b0-405f-a6d3-e0289d0edf30	pg	4f6e497ebd38943bf06890d621dc6e359a4ab0152f0f481f0fcdcf9d836ebce6	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 36, "actionid": 699, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fef9f53e-ac30-4d3b-baef-af01d3986d93	pg	9da9430f426b9dc2697c3661abe29933ad446355b41aec27b7fd5e05f9a8e1d3	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 35, "actionid": 698, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6b3e163e-b490-477c-bfb9-52ed7dc1b284	pg	dbf15e5ce5f2320f796debc64b9c47a5e96687de1f66191fbcfa884697714672	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 34, "actionid": 697, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6bf4b903-d729-42a9-9895-acfab4b6039c	pg	3d2f4a7ea87c6966983f258b448ce27f515f6878cc9acf8e65bae597ff28a2cc	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 32, "actionid": 290, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
111856d8-94b8-4cd1-b7dd-6289e2779e78	pg	07a75de8afcbdb2d36f41e69bafa1d647dca7c086c7fddb8335de4bfdfc28130	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 31, "actionid": 696, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cf5a3be5-aee2-4bbf-b827-3d96fa2b2fa9	pg	4b095ad4b9e3cee9b8839c599e6676a691210a18434c84fa01807b8f2e87f42f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 30, "actionid": 695, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a9a72574-a8b4-4471-ad06-463e1288ca97	pg	a38dfb73178f5ba0ad16e70fe4ca7d84409d6b2aeb0ff2735dab9a994fc41937	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 29, "actionid": 694, "rolecode": "CITIZEN", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
84730a36-aa9f-4c9d-a44f-cd3537567fc6	pg	894590cd99ab5b21d885646d48d6f765763435b1e3ccdff56e38b8d7e1aea341	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 28, "actionid": 694, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
10e654aa-8165-4f5a-8ecb-3b2dfdd115c1	pg	dae86604fd0c9c28f54df276e4cd164d8decc97e603b00687f1e398dae3e496e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 27, "actionid": 278, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4c289693-fdfb-44a8-9185-e389ebc0af02	pg	7be519455d11bc5abfca3dabf03c80fd87f4d9bf27fdbad96dff04d116109e53	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 26, "actionid": 277, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
87e6811d-63e2-4524-a95c-995532aef756	pg	73ab871f0b4e4e10e6b8c9b4df71ac872afc7ab35e770859b74f7c10c8cb6fe4	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 25, "actionid": 276, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0163dc88-658a-4a90-bf04-437693ae20df	pg	d8bb15207f561146bade59c5b9c119c78c9e84cb37762eb277db1f9f2044197e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 24, "actionid": 693, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2237e329-41d0-48bb-9d0c-1650cbb925d4	pg	665f5a2567412d5a9f3458717eaafdf899b134bb6a8f093e81ce36081877bdf7	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 23, "actionid": 692, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
00cb785a-ff3e-488f-84e4-0178e02dadc7	pg	88774c86d81965fa8b698f930e5833420b6032871f39e5a639deb3a19059a535	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 22, "actionid": 691, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
536e3465-146c-4eec-85b6-a7f4242209cb	pg	a9396bbe82261342ab00656f70d5e134025219622ff09e63374b03f80f4c1906	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 14, "actionid": 266, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fec05394-8526-4cab-bfe2-ef5940497f13	pg	317fab4299ac00aeda2cca310a496db8c9470591e4dc952cf32200c5a9c0df7b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 13, "actionid": 265, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2c390854-5f02-487a-aefc-c7205901617c	pg	5e2cbc60c13e78f8827ce8cabfe24b1b1ce82151510c35475fa61cf241396339	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 12, "actionid": 264, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7ad898c8-d612-4794-8702-7aaae304a165	pg	90a05af4415f4e0b9c7294006f6aa57fea724b71182205748e296cc46567284b	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 11, "actionid": 263, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0a6f0bd1-d7d1-478c-a7bc-c0b42299060b	pg	69c91950970ef5f523f5c3774cfaaa90de5a7474846d11544b26b2f472cbab27	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 10, "actionid": 262, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7b15568f-065f-48b9-aa26-08a862c6be61	pg	9a040b8c57198e3872e56d3439b1a10839ccae95ad0a5739bae9fecfc11fced8	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 9, "actionid": 261, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
bfec03e8-100e-41ac-a60b-7c2580c53d1a	pg	c7293e03d1c57b3b06c7cdb8f5d35ecf831d9bfebfccdeb3df5482e4ac3c546c	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 8, "actionid": 260, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
35877794-a25c-4c63-ba96-ab0a14c91cbe	pg	3953e45c4818d6415a6ba61eb437e883d69a43fa4e9a216ec7354e31c30cf142	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 7, "actionid": 259, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ed926875-2fc6-4329-981d-53ca0ada6aec	pg	d6235f1643cc129c098667f5607510e823987de3e8128051cde98e5ca1a0decd	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 6, "actionid": 258, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0b42c38c-53e2-428b-84dd-ec7666ff33a6	pg	e8c6483d851045e99fc9c49e351705d1d2d8b130b571f033571189436b9407ac	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 5, "actionid": 257, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4d290990-fed7-4bd5-a600-61ffb9a8e70a	pg	802f4156070f544fc8275700639447133441521f41708979d698b82d1719e971	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 4, "actionid": 256, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
32686b39-5d73-49a2-9a54-8d41c2113202	pg	809bc952c69458e2eeeadc72fa3f95503036ab3f731ba77e7ef69281ee36fe9e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 3, "actionid": 255, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f6fb944b-4951-4ced-b751-de3ee002381d	pg	4a1428bccb2a51bf081bd0d28200c6b9924199cd743381a76ae055536b3dcc27	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 2, "actionid": 254, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
85c9775e-162d-4939-ac0b-cb970715d365	pg	be3e69c8552865b8313cea62c896b79d08158d943882b5b2e9e8bf19ad0f4b8f	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 1, "actionid": 253, "rolecode": "SUPERUSER", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a62b33dd-60ee-45f4-afa5-31d2256f5b37	pg	6e83e179fe2463785fc6df459d4598e30bcf8831609c45ddccb653b59e45b68e	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 745, "actionid": 1729, "rolecode": "CSR", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b26379b1-b047-4f51-9127-a8e6be6d7df9	pg	6d4ccbfafc7de1eef40b4be4934ba5217bb12a3b37e30082e62ad7009552f60d	ACCESSCONTROL-ROLEACTIONS.roleactions	{"id": 745, "actionid": 1729, "rolecode": "PGR_LME", "tenantId": "pg", "actioncode": ""}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e98cfee6-3dc6-42ab-a1dd-49e8c2f3af0e	pg	157863b908edfe94c6b767c0315165f84d26ce20b708db8af19766a96f975bb9	ACCESSCONTROL-ROLES.roles	{"code": "TICKET_REPORT_VIEWER", "name": "Report Viewer", "description": "One who will view the reports of tickets"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a8c939bb-6108-4994-aac5-84398ece1f2d	pg	47170e983c27408b53a065cf954ae439c7500c22ee96751d30cba07a2eee966d	ACCESSCONTROL-ROLES.roles	{"code": "PGR_LME", "name": "Complaint Resolver", "description": "One who will resolve complaints"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ee732c43-4367-4706-88df-f92730f37902	pg	aba232a466c823afa382219cdbae7ed87cbc8046f9747a9571f22bcb915d0e91	ACCESSCONTROL-ROLES.roles	{"code": "GRO", "name": "Complaint Assessor", "description": "One who will assess & assign complaints"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1a6fe2cf-2f77-4ae5-ab7b-907bff2c03ac	pg	272689c4e9576e424df20bca09339e1d993cfed8aa154395d85acaedbc0cec5e	ACCESSCONTROL-ROLES.roles	{"code": "CSR", "name": "Complainant", "description": "One who will create complaints"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
02ac2515-0145-4487-9d0a-f6e04cec99a6	pg	7f555489f87b3e530966b2a11d7ae6e048ef90c7c8da0504d61fcb5004e9ac1d	ACCESSCONTROL-ROLES.roles	{"code": "LOC_ADMIN", "name": "Localisation admin", "description": "LOC_ADMIN"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
49c99b1a-71d1-4e0a-8b56-698b9b96c099	pg	1bcaf9ad6d80439df411f35e7f74cf8be7c1c1de7e3b0ff5cc436a3d9951ce37	ACCESSCONTROL-ROLES.roles	{"code": "MDMS_ADMIN", "name": "MDMS ADMIN", "description": "MDMS User that can create and search schema"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3853e856-ec41-491a-8b55-dce9b06efcc6	pg	202f1c86d385a0cfd04a96061a0312ff02e1614f90117eec61390b8a63b5bd3f	ACCESSCONTROL-ROLES.roles	{"code": "REINDEXING_ROLE", "name": "Reindexing Role", "description": "Role for reindexing for encrypted data access"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
037ebe29-3d4b-483e-b0e9-c263a3c4a5a9	pg	0c576081018117feddfc49892374a0b8a549f7bc17a3878386d236677e3550de	ACCESSCONTROL-ROLES.roles	{"code": "INTERNAL_MICROSERVICE_ROLE", "name": "Internal Microservice Role", "description": "Internal role for plain access"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1fcc7212-2320-4cf1-8ad2-1b0af20445fd	pg	9c31f533fa0d4cd87baa88455501751d8a126b325269d41060d6e8bd4319276f	ACCESSCONTROL-ROLES.roles	{"code": "COMMON_EMPLOYEE", "name": "Basic employee roles", "description": "Basic employee roles"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9beb4f33-b1b2-44f9-a0a2-83f9a238b6f8	pg	39aada8cc74c13cfc6696d1437c6b3d3311e53a98a8bb312a5997436e27cb342	ACCESSCONTROL-ROLES.roles	{"code": "SYSTEM", "name": "System user", "description": "System user role"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a6674ce0-467f-4a9a-a085-602ef597415b	pg	d7537d03da2078f117e306de760e0ee9a50d7734aca62d32b60dba90d2147696	ACCESSCONTROL-ROLES.roles	{"code": "SUPERVISOR", "name": "Auto Escalation Supervisor", "description": "Escalation to particular role"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8a9fc579-7458-4d57-970c-204986e64a4d	pg	adf5c5e0f94708983358f0fe3b1f8498fdc12a3615ee5c4d97fcffbe691ef0a7	ACCESSCONTROL-ROLES.roles	{"code": "AUTO_ESCALATE", "name": "Auto Escalation Employee", "description": "Auto Escalation Employee"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
de576462-abb3-4168-b4eb-15d74f9db209	pg	9574fd7c89a20234e602b4c9cea820e0cdcdd812b0bfad5c3032b9c121665e9e	ACCESSCONTROL-ROLES.roles	{"code": "QA_AUTOMATION", "name": "QA Automation", "description": "QA Automation"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d4a3e927-4b72-4484-8935-e697db84990d	pg	285381ae0f9e3b68ad1c794cc86cd0f19f4a05e1d00f82862428701515513fe3	ACCESSCONTROL-ROLES.roles	{"code": "HRMS_ADMIN", "name": "HRMS Admin", "description": "HRMS Admin"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
75b8cb6b-5ed1-4602-bb7b-aee8f722780e	pg	d152fb9523c59ec39759522de322e178c585e7644e69ccbbf77c2b3b0f20c724	ACCESSCONTROL-ROLES.roles	{"code": "SUPERUSER", "name": "Super User", "description": "System Administrator. Can change all master data and has access to all the system screens."}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7c1e0cfe-79a8-45c4-a4db-3d965f1d403e	pg	df87a9ba264c01321ac243ad46add4787ad13c9a13b7a45823ede3f6444852a4	ACCESSCONTROL-ROLES.roles	{"code": "EMPLOYEE", "name": "Employee", "description": "Default role for all employees"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d2a106d8-005e-4ef3-8104-fba93d0c247e	pg	0b303dd0ce3ab27c557c65acf9d9071ac97bf0846d3ae5a5cb15253cb697ea99	ACCESSCONTROL-ROLES.roles	{"code": "CITIZEN", "name": "Citizen", "description": "Citizen who can raise complaint"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
94251dd5-b2c7-4cfe-af56-a91f09c8329d	pg	456b68a3345b31a74bfde1d2ebe00a602bbbe4b4d8369896e76ed4d5e102502a	ACCESSCONTROL-ROLES.roles	{"code": "ANONYMOUS", "name": "Anonymous User", "description": "Anonymous User to be used in case of no auth"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
76927703-a6fd-4192-afc6-9c7ba40afb23	pg	9be5a187689c51d1b1e1f7e451adcffa2c3bfad1bedcf3ab47d4cd536f113d2d	ACCESSCONTROL-ROLES.roles	{"code": "WORKFLOW_ADMIN", "name": "WORKFLOW ADMIN", "description": "WORKFLOW User that can create and search Workflow"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
acd76f05-53d8-4591-8fbf-0c0c7c88ca6c	pg	2215b79651c369c9c941a0fd58ebebd6a14c2596ea98cb8304377bafd110370c	common-masters.Department	{"code": "CENTER", "name": "Center", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8a6b9737-9c20-4213-909c-6dd162d1afca	pg	702f50156ef6805e5b3bfb0fb6674f857fa0989c49a9ad53c9fc671dbe0d5a67	common-masters.Designation	{"code": "COMM", "name": "Commissioner", "active": true, "description": "Commissioner"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ebe9c7d6-8b94-470f-8e4a-60f02158a402	pg	cd109a200d8b97e0de3855e8128ffe1e7ffeccb8ab6b1f9f0225a997ba295f49	common-masters.GenderType	{"code": "MALE", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8a4eb565-fb52-4a76-a050-72d8a6fab681	pg	25f1014a1655b088fefdf9243db06ea4cdf35afe8a57023fd9b7015af0331e58	common-masters.GenderType	{"code": "FEMALE", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0d646692-c356-4e1b-a31c-2ff44043b13c	pg	31cc7c129034c3f79d01aa2b202382087810c43fafa06dfe0e810b80cfd1dcd8	common-masters.GenderType	{"code": "TRANSGENDER", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
58fae0c2-1491-4814-bd9b-47f4ce1c4abd	pg	f6734ad57526435f866e443ea1b3f2a7464b8a5544b71106237893313a4bd272	common-masters.GenderType	{"code": "OTHERS", "active": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
67bac536-5402-4871-a8f0-be5360200cf3	pg	99ca5739ac392cbd869fbbc0d24c8b8240e3f89b13233fc545cca81cbaf47101	common-masters.IdFormat	{"format": "PG-PGR-[cy:yyyy-MM-dd]-[SEQ_EG_PGR_ID]", "idname": "pgr.servicerequestid"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e71837f1-b810-4fcc-ad15-d14df78c9735	pg	7b478258536577d39e5db64bce94ca34c40d25f19a1eee0402afdfa32ad42821	egov-hrms.Specalization	{"code": "ARTS", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
33ad5e8c-4599-403d-9efe-d1ec3b039f85	pg	526bf7290e8e640c695326eac7e244445f71ca423d14e8b4a79a19e7db74a22c	egov-hrms.Specalization	{"code": "SCIENCE", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
467ecb87-9be4-4044-89a6-16d45f6adcc3	pg	2fd45638617790334c8733991fb1d798a2f1f2b683239a8c67ad2ac6c8fdb74b	common-masters.StateInfo	{"code": "pg", "name": "Demo", "logoUrl": "https://s3.ap-south-1.amazonaws.com/works-dev-asset/mseva-white-logo.png", "bannerUrl": "https://s3.ap-south-1.amazonaws.com/pb-egov-assets/pb.testing/Punjab-bg-QA.jpg", "languages": [{"label": "ENGLISH", "value": "en_IN"}, {"label": "ಕನ್ನಡ", "value": "ka_IN"}], "qrCodeURL": "https://lh3.googleusercontent.com/-311gz2-xcHw/X6KRNSQTkWI/AAAAAAAAAKU/JmHSj-6rKPMVFbo6oL5x4JhYTTg8-UHmwCK8BGAsYHg/s0/2020-11-04.png", "statelogo": "https://s3.ap-south-1.amazonaws.com/pg-egov-assets/pg.citya/logo.png", "defaultUrl": {"citizen": "/user/register", "employee": "/user/login"}, "logoUrlWhite": "https://egov-dev-assets.s3.ap-south-1.amazonaws.com/digit.png", "hasLocalisation": true, "localizationModules": [{"label": "rainmaker-abg", "value": "rainmaker-abg"}, {"label": "rainmaker-common", "value": "rainmaker-common"}, {"label": "rainmaker-noc", "value": "rainmaker-noc"}, {"label": "rainmaker-pt", "value": "rainmaker-pt"}, {"label": "rainmaker-uc", "value": "rainmaker-uc"}, {"label": "rainmaker-pgr", "value": "rainmaker-pgr"}, {"label": "rainmaker-tl", "value": "rainmaker-tl"}, {"label": "rainmaker-hr", "value": "rainmaker-hr"}, {"label": "rainmaker-test", "value": "rainmaker-test"}, {"label": "finance-erp", "value": "finance-erp"}, {"label": "rainmaker-receipt", "value": "rainmaker-receipt"}, {"label": "rainmaker-dss", "value": "rainmaker-dss"}, {"label": "rainmaker-fsm", "value": "rainmaker-fsm"}, {"label": "rainmaker-workbench", "value": "rainmaker-workbench"}, {"label": "rainmaker-schema", "value": "rainmaker-schema"}, {"label": "rainmaker-mdms", "value": "rainmaker-mdms"}, {"label": "rainmaker-im", "value": "rainmaker-im"}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
567adebd-9cab-4c22-b180-72fa99844167	pg	3b99e7f9ef22310d79294d0882ba37fdcdc5758912d9b52a4a367aa67eb69a8b	RAINMAKER-PGR.ServiceDefs	{"name": "Request spraying/ fogging operations", "active": true, "keywords": "mosquito, menace, fog, spray, kill, health, dengue, malaria, disease, clean", "menuPath": "Mosquitos", "slaHours": 336, "department": "DEPT_3", "serviceCode": "RequestSprayingOrFoggingOperation"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
dcb3f5bc-167f-468d-aecd-ad9f66a4c1af	pg	a31482c78e570b4458d2a380c2f1854461d4ef7e100f88e43349debfb946d4eb	common-masters.uiHomePage	{"redirectURL": "all-services", "appBannerMobile": {"code": "APP_BANNER_MOBILE", "name": "App Banner Mobile View", "enabled": true, "bannerUrl": "https://s3.ap-south-1.amazonaws.com/egov-qa-assets/app-banner-mobile.jpg"}, "appBannerDesktop": {"code": "APP_BANNER_DESKTOP", "name": "App Banner Desktop View", "enabled": true, "bannerUrl": "https://s3.ap-south-1.amazonaws.com/egov-qa-assets/app-banner-web.jpg"}, "citizenServicesCard": {"code": "HOME_CITIZEN_SERVICES_CARD", "name": "Home Citizen services Card", "props": [{"code": "ACTION_TEST_MCOLLECT", "name": "Miscellaneous Collection", "label": "ACTION_TEST_MCOLLECT", "enabled": true, "navigationUrl": "/digit-ui/citizen/mcollect-home"}, {"code": "CITIZEN_SERVICE_PT", "name": "Property Tax", "label": "MODULE_PT", "enabled": true, "navigationUrl": "/digit-ui/citizen/pt-home"}, {"code": "CITIZEN_SERVICE_TL", "name": "Trade Licence", "label": "MODULE_TL", "enabled": true, "navigationUrl": "/digit-ui/citizen/tl-home"}, {"code": "ACTION_TEST_BPA_STAKEHOLDER_HOME", "name": "Online Building Permit System", "label": "ACTION_TEST_BPA_STAKEHOLDER_HOME", "enabled": true, "navigationUrl": "/digit-ui/citizen/obps-home"}, {"code": "ACTION_TEST_WATER_AND_SEWERAGE", "name": "Water & Sewerage", "label": "ACTION_TEST_WATER_AND_SEWERAGE", "enabled": true, "navigationUrl": "/digit-ui/citizen/ws-home"}, {"code": "ACTION_TEST_FIRE_NOC", "name": "Fire No Objection Certificate", "label": "ACTION_TEST_FIRE_NOC", "enabled": true, "navigationUrl": "/citizen/fire-noc/home"}, {"code": "ACTION_TEST_BIRTH_CERTIFICATE", "name": "Birth Certificate", "label": "ACTION_TEST_BIRTH_CERTIFICATE", "enabled": true, "navigationUrl": "/digit-ui/citizen/birth-citizen/home"}, {"code": "ACTION_TEST_DEATH_CERTIFICATE", "name": "Death Certificate", "label": "ACTION_TEST_DEATH_CERTIFICATE", "enabled": true, "navigationUrl": "/digit-ui/citizen/death-citizen/home"}], "enabled": true, "sideOption": {"name": "DASHBOARD_VIEW_ALL_LABEL", "enabled": true, "navigationUrl": "/digit-ui/citizen/all-services"}, "headerLabel": "DASHBOARD_CITIZEN_SERVICES_LABEL"}, "whatsNewSection-disabled": {"code": "WHATSNEW", "name": "What's New", "enabled": true, "sideOption": {"name": "DASHBOARD_VIEW_ALL_LABEL", "enabled": true, "navigationUrl": "/digit-ui/citizen/engagement/whats-new"}, "headerLabel": "DASHBOARD_WHATS_NEW_LABEL"}, "informationAndUpdatesCard": {"code": "HOME_CITIZEN_INFO_UPDATE_CARD", "name": "Home Citizen Information and Updates card", "props": [{"code": "CITIZEN_MY_CITY", "name": "My City", "label": "CS_HEADER_MYCITY", "enabled": true, "navigationUrl": ""}, {"code": "CITIZEN_EVENTS", "name": "Events", "label": "EVENTS_EVENTS_HEADER", "enabled": true, "navigationUrl": "/digit-ui/citizen/engagement/events"}, {"code": "CITIZEN_DOCUMENTS", "name": "Documents", "label": "CS_COMMON_DOCUMENTS", "enabled": true, "navigationUrl": "/digit-ui/citizen/engagement/docs"}, {"code": "CITIZEN_SURVEYS", "name": "Surveys", "label": "CS_COMMON_SURVEYS", "enabled": true, "navigationUrl": "/digit-ui/citizen/engagement/surveys/list"}], "enabled": true, "sideOption": {"name": "DASHBOARD_VIEW_ALL_LABEL", "enabled": true, "navigationUrl": ""}, "headerLabel": "CS_COMMON_DASHBOARD_INFO_UPDATES"}, "whatsAppBannerMobile-disabled": {"code": "WHATSAPP_BANNER_MOBILE", "name": "WhatsApp Banner Mobile View", "enabled": true, "bannerUrl": "https://s3.ap-south-1.amazonaws.com/egov-qa-assets/whatsapp-mobile.jpg", "navigationUrl": "https://api.whatsapp.com/send?phone=918744060444&text=mSeva"}, "whatsAppBannerDesktop-disabled": {"code": "WHATSAPP_BANNER_DESKTOP", "name": "WhatsApp Banner Desktop View", "enabled": true, "bannerUrl": "https://s3.ap-south-1.amazonaws.com/egov-qa-assets/whatsapp-web.jpg", "navigationUrl": "https://api.whatsapp.com/send?phone=918744060444&text=mSeva"}}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b6928999-d759-467c-ac31-5ae772e78de6	pg	1a2bb136332122036861aec3d0c05826795bc6a12c46d44fe53d61e2b8e5a0bd	common-masters.wfSlaConfig	{"slotPercentage": 33, "middleSlabColor": "#EEA73A", "negativeSlabColor": "#F44336", "positiveSlabColor": "#4CAF50"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
13fbdb93-904b-4235-8e37-b196b4824786	pg	1cb6c2ba6cf789f083588eefdf3cb32179ea203803027ecb674c127bd451b088	egov-hrms.DeactivationReason	{"code": "OTHERS", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
af056165-4ac5-420d-ae99-da7607bbb4b3	pg	809e8672d4aa45315c892efdb2e3913ac2590bdc4d30973e5e3e501f2795e097	egov-hrms.DeactivationReason	{"code": "ORDERBYCOMMISSIONER", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
eb3eb801-86f6-4ad3-a628-45d8fc4f77a6	pg	71e3ba2f621a40b58555d7f6234911cf0718b3dc06fb85543e93635d04338548	egov-hrms.Degree	{"code": "MATRICULATION", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5ad3df1e-f0c3-4e8f-a858-f8c5b0c25164	pg	5630a0605e577dbb9b4a76648c6dfde85aca2912effb793dce6b27761596039a	egov-hrms.Degree	{"code": "10+2/EQUIVALENTDIPLOMA", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a6a2ef0c-efab-4166-8611-b1b833a85a49	pg	a3bd8357a82ff729164bc295497c6ebda1bc6c62803d6f3c3d6d82e652264926	egov-hrms.Degree	{"code": "B.A/B.SC./B.COM/BBA", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
45a1e960-5fef-4b39-8c72-c7a8c2e1a613	pg	2316bdafeb0a39c99e31bbfe849612e77c6a52d35c753aed828424b14978f0f0	egov-hrms.Degree	{"code": "LLB/LLM", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e46bc463-dab0-42c8-a9ed-9e88b94c6f53	pg	9936d7ef572848d2de5277009738078d2b03ac79672a5df2d8c507845f61e45d	egov-hrms.Degree	{"code": "B.E/B.TECH.", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b9757844-0e6f-4a4d-830b-1e422b02a7b0	pg	b2809648abbce98a1dc8d9d5d2ad74a3a7691cbc9d086a4f54732fd83ff3c4bb	egov-hrms.Degree	{"code": "M.A/M.COM./M.SC.", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e7e97848-bb1f-4296-9a2f-b91f927fa8a9	pg	7c0e68dcb015611f4f8dbe2c2783d2648cdbb1526f6096bf21a990e9ab4f0f2f	egov-hrms.Degree	{"code": "M.E/M.TECH.", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7e25b246-566e-4a3b-a696-66c5afe34dd5	pg	99f048938981f201fd17749059149f7a84e1d666dcf8148e5e300a79064d032d	egov-hrms.Degree	{"code": "MBA/PGDM", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8319fbcf-f953-4937-90a6-9fa48e72844a	pg	8d8ea339f664379d2bed11843310d6a2d0730ff301c7232b0090b43a68bdb4c9	egov-hrms.Degree	{"code": "DOCTORATE", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ba2656ff-031b-454c-b919-2ce1802f47eb	pg	4e9a04fd6b4b85999100b17d07177db10c98aa73705cf661d6d5d5a3583bc2eb	egov-hrms.Degree	{"code": "OTHER", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cd9a9c7f-3584-4382-ac32-b91976b03c28	pg	8b411c00de85db3d1d4d80b70aba5249a8dc0dd7f7f60de90aa76f7298f9d8de	egov-hrms.EmployeeStatus	{"code": "EMPLOYED", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
225b32ed-8cd1-4848-9ddd-b0e31256ddf2	pg	8664f8ef4381c13badcb369b7dd65b5d49fd144af905711a3a42c17485d7a3c4	egov-hrms.EmployeeStatus	{"code": "RETIRED", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0fa12710-5c99-4a23-8782-bb35f65155e7	pg	a8b8663396602477fcdfc56b1e48c616e3e7eb4a161b5e1ec60dfd72ae00e66c	egov-hrms.EmployeeStatus	{"code": "RESIGNED", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
625af874-de45-4efe-911e-060c0d68d312	pg	7dd579237c4fd4692186342416cfa2eb56a47c596cdf6f59798ea4457a69d111	egov-hrms.EmployeeStatus	{"code": "TERMINATED", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1cc0642c-4ffe-4333-a39a-c8baf33c2b28	pg	23e5afe43927be2db2956474caeb24032cfa17cf67e71767e241528933cf808e	egov-hrms.EmployeeStatus	{"code": "DECEASED", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
94c6f8d3-7273-4fa8-8f63-fd413b7818c3	pg	9ca26b0b653416a237fd2763994ffce4f77e52610e5fb85ee380fa2d2724bbd9	egov-hrms.EmployeeStatus	{"code": "SUSPENDED", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
616e7fe2-7e3e-43e9-8330-bcf98e32d9b9	pg	76aa8231df2aa6682f49228aa1a1cea2e582b8430a9465148b026596924ab317	egov-hrms.EmployeeStatus	{"code": "TRANSFERRED", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
f7150848-3fc8-4209-97fe-d7b7edc37993	pg	2693ed6075326fa5afd36b63114b278bbe935d9616cc19a068106cf8c3d6011e	egov-hrms.EmployeeType	{"code": "PERMANENT", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6a7d6544-717b-4fef-9c68-95222c2e9f6e	pg	c919fff63c191a6083878f03e8a8ecb7d9484f36e13a89780ae992507048e54f	egov-hrms.EmployeeType	{"code": "TEMPORARY", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ff3764ff-3f27-492d-a86b-aba01f4359b3	pg	37ae153e3a32d927f9d7ffe84a53886bb41dbccbaa0814186f3758645d5c9f40	egov-hrms.EmployeeType	{"code": "DAILYWAGES", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b9a3710f-9f98-4c93-b51f-3a8d036fc919	pg	e0955c00cee8595331fc3dd3ba0e9f80245fbee0c530f8d44d5c0c045246ed9b	egov-hrms.EmployeeType	{"code": "CONTRACT", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
aae3f98d-7012-4b87-b60a-fdb6c132d591	pg	80ec82fb712442603a5a492f23fccac277323025739565479212186fa8f53f5b	egov-hrms.EmployeeType	{"code": "DEPUTATION", "active": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
80d0d0f6-0521-4f99-bde0-1926e51b35f7	pg	b7963f8371fea0aae1fb0be623c75d72ec11bfb258fbf2824e6bdae4b3378d99	INBOX.InboxQueryConfiguration	{"index": "inbox-pgr-services", "module": "RAINMAKER-PGR", "sortBy": {"path": "Data.service.auditDetails.createdTime", "defaultOrder": "ASC"}, "sourceFilterPathList": ["Data.currentProcessInstance", "Data.service.serviceRequestId", "Data.service.address.locality.code", "Data.service.applicationStatus", "Data.service.citizen", "Data.service.auditDetails.createdTime", "Data.auditDetails", "Data.tenantId"], "allowedSearchCriteria": [{"name": "area", "path": "Data.service.address.locality.code.keyword", "operator": "EQUAL", "isMandatory": false}, {"name": "status", "path": "Data.currentProcessInstance.state.uuid.keyword", "operator": "EQUAL", "isMandatory": false}, {"name": "assignedToMe", "path": "Data.workflow.assignes.*.uuid.keyword", "operator": "EQUAL", "isMandatory": false}, {"name": "fromDate", "path": "Data.service.auditDetails.createdTime", "operator": "GTE", "isMandatory": false}, {"name": "toDate", "path": "Data.service.auditDetails.createdTime", "operator": "LTE", "isMandatory": false}, {"name": "complaintNumber", "path": "Data.service.serviceRequestId.keyword", "operator": "EQUAL", "isMandatory": false}, {"name": "mobileNumber", "path": "Data.service.citizen.mobileNumber.keyword", "operator": "EQUAL", "isMandatory": false}, {"name": "tenantId", "path": "Data.service.tenantId.keyword", "operator": "EQUAL", "isMandatory": false}, {"name": "assignee", "path": "Data.currentProcessInstance.assignes.uuid.keyword", "operator": "EQUAL", "isMandatory": false}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0eb85ed7-fb61-4d86-a803-08ab1e4d86e6	pg	618236d9e50cae30d3ffc09509cce2d23c2f63cea5a2c402ef1022a634c5a928	RAINMAKER-PGR.ServiceDefs	{"name": "Others", "order": 6, "active": true, "keywords": "other, miscellaneous,ad,playgrounds,burial,slaughterhouse, misc, tax, revenue", "menuPath": "", "slaHours": 336, "department": "DEPT_10", "serviceCode": "Others"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
200a5d2c-6326-4465-ad50-1028ed9973d7	pg	3209714d2eb0424463febe037709d1a05dadcb2d44c56fac7ab0b2eb63f61b57	RAINMAKER-PGR.ServiceDefs	{"name": "Park requires maintenance", "active": true, "keywords": "open, defecation, waste, human, privy, toilet", "menuPath": "Parks", "slaHours": 336, "department": "DEPT_5", "serviceCode": "ParkRequiresMaintenance"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4dddf16f-bb81-4b95-9aa6-a92fe084d9ba	pg	8b75d2734e008e4eeb3c01eb19b9fd620efc211c30f2528d07d6c5212074cc96	RAINMAKER-PGR.ServiceDefs	{"name": "Open Defecation", "active": true, "keywords": "open, defecation, waste, human, privy, toilet", "menuPath": "OpenDefecation", "slaHours": 336, "department": "DEPT_3", "serviceCode": "OpenDefecation"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
86cc3524-d84d-449a-93f2-2cb69c396bc1	pg	fde2581b6ae874a3ebfc7292873e1520d170d9bfda54b601b7bc132ecc12545a	RAINMAKER-PGR.ServiceDefs	{"name": "Cutting/trimming of tree required", "active": true, "keywords": "tree, remove, trim, fallen, cut, plant, branch", "menuPath": "Trees", "slaHours": 336, "department": "DEPT_5", "serviceCode": "CuttingOrTrimmingOfTreeRequired"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3b801a2f-6a60-4174-8123-ebc770f0bb75	pg	c4c18a87679b920a67de5e2bcef58f2bf53cdc69b8007e69f1414dfa24e85283	RAINMAKER-PGR.ServiceDefs	{"name": "Illegal Cutting of trees", "active": true, "keywords": "tree, cut, illegal, unathourized, remove, plant", "menuPath": "Trees", "slaHours": 336, "department": "DEPT_5", "serviceCode": "IllegalCuttingOfTrees"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b7a02ea9-0715-4901-be05-87f13ddf123d	pg	d13784be2b06cb1f1fd02aaaf3955221081e1ea6cefc785b4331598489954a1c	RAINMAKER-PGR.ServiceDefs	{"name": "Illegal parking", "active": true, "keywords": "illegal, parking, car, vehicle, space, removal, road, street, vehicle", "menuPath": "LandViolations", "slaHours": 336, "department": "DEPT_6", "serviceCode": "IllegalParking"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a7b5ddea-e0e4-41d5-9e87-b914d8e9d254	pg	acfc88dcf316fb72ea7b8e7ab2fb75f3c9fd27d09da48ef948a9bb05f3e4f8cc	RAINMAKER-PGR.ServiceDefs	{"name": "Illegal constructions", "active": true, "keywords": "illegal, violation, property, public, space, land, unathourised, site, construction, wrong, build", "menuPath": "LandViolations", "slaHours": 336, "department": "DEPT_6", "serviceCode": "IllegalConstructions"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4fc80e51-0213-4f32-9ad4-f5f7afe2f0c9	pg	08bcfcc187c07ab8360741ce8b415933386610b616aaa7b5a8e79e6215bd8e11	RAINMAKER-PGR.ServiceDefs	{"name": "Illegal shops on footpath", "active": true, "keywords": "illegal, shop, footpath, violation, property, public, space, land, unathourised, site, construction, wrong", "menuPath": "LandViolations", "slaHours": 336, "department": "DEPT_6", "serviceCode": "IllegalShopsOnFootPath"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
457ca570-3057-46f7-b393-ba9edddbdee5	pg	52c5dfbce2e9c8b2bd1a163fce7eedadba2c3ada55c2fa7dc60dda6c381c41ed	RAINMAKER-PGR.ServiceDefs	{"name": "No water/electricity in public toilet", "active": true, "keywords": "toilet, public, restroom, bathroom, urinal, electricity, water, working", "menuPath": "PublicToilets", "slaHours": 336, "department": "DEPT_3", "serviceCode": "NoWaterOrElectricityinPublicToilet"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
db69c436-afe4-415c-b769-98c42faa296f	pg	71a153d1fead021601206a7f75819c1290727db0480fff4362725cde18a28ccb	RAINMAKER-PGR.ServiceDefs	{"name": "Public toilet damaged", "active": true, "keywords": "toilet, public, restroom, bathroom, urinal, block, working", "menuPath": "PublicToilets", "slaHours": 336, "department": "DEPT_3", "serviceCode": "PublicToiletIsDamaged"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6289c23e-abde-4841-8c03-e967f73caa79	pg	98028661d2544afb899cfef5b3801d13d351f443affd7d21fc25077d3d923e57	RAINMAKER-PGR.ServiceDefs	{"name": "Dirty/smelly public toilet", "active": true, "keywords": "toilet, public, restroom, bathroom, urinal, smell, dirty", "menuPath": "PublicToilets", "slaHours": 336, "department": "DEPT_3", "serviceCode": "DirtyOrSmellyPublicToilets"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7d5c2e51-e2e2-44a1-993b-0d955e880471	pg	cd31f8eabdd1453409c4438fef3b64ad5a4537292442d6db0def4f3ead948d3b	RAINMAKER-PGR.ServiceDefs	{"name": "Dead animals", "active": true, "keywords": "stray, cow, cows, cattle, bull, bulls, graze, grazing, dung, menace", "menuPath": "Animals", "slaHours": 336, "department": "DEPT_3", "serviceCode": "DeadAnimals"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e2e4f1d4-2d36-43ec-bd4c-896aa60653f7	pg	6437703971569eb090fe603cdb6cf8d172e83eebb2d814089f330c68a90fe89c	RAINMAKER-PGR.ServiceDefs	{"name": "Stray animals", "active": true, "keywords": "stray, dog, dogs, menace, animal, animals, attack, attacking, bite, biting, bark, barking", "menuPath": "Animals", "slaHours": 336, "department": "DEPT_3", "serviceCode": "StrayAnimals"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4a3a727a-59be-45cf-a4e1-15ef1a153cf1	pg	7369b4e6aaaac7c675933f7b6ed83ae430a7e838910ddff84593d97b776545f8	RAINMAKER-PGR.ServiceDefs	{"name": "Construction material lying on the road", "active": true, "keywords": "illegal, shop, footpath, walk, remove, occupy, path", "menuPath": "RoadsAndFootpaths", "slaHours": 336, "department": "DEPT_4", "serviceCode": "ConstructionMaterialLyingOntheRoad"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cdcb74eb-81f0-4170-a6dd-c575537c52fc	pg	605198eb5c17c2730aaeda35f8e08af766816edc20108b2fa9e881737f4641a5	RAINMAKER-PGR.ServiceDefs	{"name": "Damaged/blocked footpath", "active": true, "keywords": "footpath, repair, broken, surface, damage, patch, hole, maintenance, walk, path", "menuPath": "RoadsAndFootpaths", "slaHours": 336, "department": "DEPT_4", "serviceCode": "DamagedOrBlockedFootpath"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
2bea4554-0271-4eb6-86d0-5bbada247c50	pg	5108cd9845f39676ca27c01c9318e9bfa8f94b04e7134bfeb8a2021fce17e07a	RAINMAKER-PGR.ServiceDefs	{"name": "Manhole cover is missing/damaged", "active": true, "keywords": "road, street, manhole, hole, cover, lid, footpath, open, man, drainage, damage, repair, fix", "menuPath": "RoadsAndFootpaths", "slaHours": 336, "department": "DEPT_4", "serviceCode": "ManholeCoverMissingOrDamaged"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fe672748-67f4-4bd9-8088-6b0963d66703	pg	a8e2093b11f4cf933c4793a107ee653069283ac886abc462ff157ac7169c6307	RAINMAKER-PGR.ServiceDefs	{"name": "Water logged road", "active": true, "keywords": "road, drainage, water, block, puddle, street, flood, overflow, rain", "menuPath": "RoadsAndFootpaths", "slaHours": 336, "department": "DEPT_4", "serviceCode": "WaterLoggedRoad"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
55c86529-f026-435a-94df-1c3fd9ad13a1	pg	dbd2af1cf0ecbcd6c1cc0ac53eb99e7189637d77bc978122a66806476d12cb26	RAINMAKER-PGR.ServiceDefs	{"name": "Damaged road", "active": true, "keywords": "road, damage, hole, surface, repair, patch, broken, maintenance, street, construction, fix", "menuPath": "RoadsAndFootpaths", "slaHours": 336, "department": "DEPT_4", "serviceCode": "DamagedRoad"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fb47bf88-b426-42e4-87dc-32099b2bd608	pg	c1509b5e9b213a67458a8cf5e73b4442c48db2158f94e1da655d2f2064c61048	RAINMAKER-PGR.ServiceDefs	{"name": "Water pressure is very less", "active": true, "keywords": "water, supply, connection, damage, repair, broken, pipe, piping, tap", "menuPath": "WaterandSewage", "slaHours": 336, "department": "DEPT_4", "serviceCode": "WaterPressureisVeryLess"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
cebb1165-5568-469f-b23a-9dff215f7d2d	pg	acb340a9ff7ae2d77259c882dda51c5abc8bb142b486b1f26b1072e4cf8a8a44	RAINMAKER-PGR.ServiceDefs	{"name": "Broken water pipe / Leakage", "order": 3, "active": true, "keywords": "water, supply, connection, damage, repair, broken, pipe, piping, tap", "menuPath": "WaterandSewage", "slaHours": 336, "department": "DEPT_4", "serviceCode": "BrokenWaterPipeOrLeakage"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
3c57b210-9bf8-4e1e-a7df-e168db07c59c	pg	b5fb30535085de936a29538389630800739f8722ee3c60457a4bfc1e4b886b7c	RAINMAKER-PGR.ServiceDefs	{"name": "Dirty water supply", "active": true, "keywords": "water, supply, connection, drink, dirty, contaminated, impure, health, clean", "menuPath": "WaterandSewage", "slaHours": 336, "department": "DEPT_4", "serviceCode": "DirtyWaterSupply"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
9ac108de-8a8a-4784-bd26-3c285bb35038	pg	e546182e78b1205318256ac994a0f202f36b3ba4bbbe3bf06a165777fd34dc1b	RAINMAKER-PGR.ServiceDefs	{"name": "No water supply", "active": true, "keywords": "water, supply, connection, drink, tap", "menuPath": "WaterandSewage", "slaHours": 336, "department": "DEPT_4", "serviceCode": "NoWaterSupply"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
73a53952-75a2-435a-a54d-da5dedad4366	pg	8172c4f6af02aa670ff3988527fdd8e2431c493488d162d743f95ed91ce28cfb	RAINMAKER-PGR.ServiceDefs	{"name": "Shortage of water", "active": true, "keywords": "water, supply, shortage, drink, tap, connection,leakage,less", "menuPath": "WaterandSewage", "slaHours": 336, "department": "DEPT_4", "serviceCode": "ShortageOfWater"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
13a41f7e-65a7-4c45-87a8-b62ce3c327a4	pg	eaf8f7b12778e92822bc189d66eb68d32cf5452501a6f754a78d912fc9d8357e	RAINMAKER-PGR.ServiceDefs	{"name": "Block / Overflowing sewage", "order": 2, "active": true, "keywords": "water, supply, connection, damage, repair, broken, pipe, piping, tap", "menuPath": "WaterandSewage", "slaHours": 336, "department": "DEPT_4", "serviceCode": "BlockOrOverflowingSewage"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ce628b6c-6391-43d4-9f98-b38aefd8bf85	pg	e2fa26754783d193afe9f910b5552cdf8a7f4dba65500faa8ae4152c70424a93	RAINMAKER-PGR.ServiceDefs	{"name": "Illegal discharge of sewage", "active": true, "keywords": "water, supply, connection, damage, repair, broken, pipe, piping, tap", "menuPath": "WaterandSewage", "slaHours": 336, "department": "DEPT_4", "serviceCode": "illegalDischargeOfSewage"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
38f3867d-b46a-4827-8084-6a94e66b3f53	pg	fe3cc5febeca4a53e4d15fa0e81be3d6c69b5d5a8f466d3abb74eda04fbf827a	RAINMAKER-PGR.ServiceDefs	{"name": "Overflowing/Blocked drain", "active": true, "keywords": "drain, block, clean, debris, silt, drainage, water, clean, roadside, flow, remove, waste, garbage, clear, overflow, canal, fill, stagnate, rain, sanitation, sand, pipe, clog, stuck", "menuPath": "Drains", "slaHours": 336, "department": "DEPT_4", "serviceCode": "OverflowingOrBlockedDrain"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
78a8ff27-6009-43ba-99d7-8a2f8e517fc5	pg	be5eda57a41acf74b015df1a4b24e5a175eda088833515ec7825788715820de2	RAINMAKER-PGR.ServiceDefs	{"name": "Burning of garbage", "active": true, "keywords": "garbage, remove, burn, fire, health, waste, smoke, plastic, illegal", "menuPath": "Garbage", "slaHours": 336, "department": "DEPT_3", "serviceCode": "BurningOfGarbage"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8dc80e12-47c3-4abf-a460-304cf979e8d8	pg	d0d9fb62d6848179c23f4e4c9f0ff09f2156a1b47fe5b39b4e2a346056670f88	RAINMAKER-PGR.ServiceDefs	{"name": "Damaged garbage bin", "active": true, "keywords": "garbage, waste, bin, dustbin, clean, remove, sanitation, overflow, smell, health, throw, dispose", "menuPath": "Garbage", "slaHours": 336, "department": "DEPT_3", "serviceCode": "DamagedGarbageBin"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
49e6b340-f4b7-47dc-9f19-9917af943dd8	pg	e9a1b5b0512ce027fa62d39b67900dd216bd582ca85d08535f66ef4f45afe878	RAINMAKER-PGR.ServiceDefs	{"name": "Garbage needs to be cleared", "order": 4, "active": true, "keywords": "garbage, collect, litter, clean, door, waste, remove, sweeper, sanitation, dump, health, debris, throw", "menuPath": "Garbage", "slaHours": 336, "department": "DEPT_3", "serviceCode": "GarbageNeedsTobeCleared"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c8e54525-c25a-4424-bb74-00e7429fb0fb	pg	e950e23e70f51e054882787770097f64e41352a334f02eb8d0545a57bf98a67c	RAINMAKER-PGR.ServiceDefs	{"name": "Streetlight not working", "order": 1, "active": true, "keywords": "streetlight, light, repair, work, pole, electric, power, repair, fix", "menuPath": "StreetLights", "slaHours": 336, "department": "DEPT_1", "serviceCode": "StreetLightNotWorking"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7117299d-5a8d-4617-8657-8ec06368bca1	pg	b222848808278f4f692118befce1e677df2c27e5bb963220aabacb88e0ecde48	RAINMAKER-PGR.ServiceDefs	{"name": "Non sweeping of road", "order": 5, "active": true, "keywords": "garbage, collect, litter, clean, door, waste, remove, sweeper, sanitation, dump, health, debris, throw", "menuPath": "Garbage", "slaHours": 336, "department": "DEPT_3", "serviceCode": "NonSweepingOfRoad"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
344495fc-c324-4923-b8b4-b8f44eda6093	pg	49b2ab679a5b95b6334884b2b0391f1cdd7cdab8dd476be8380a8c22f23e481a	RAINMAKER-PGR.ServiceDefs	{"name": "No streetlight", "active": true, "keywords": "streetlight, light, repair, work, pole, electric, power, repair, damage, fix", "menuPath": "StreetLights", "slaHours": 336, "department": "DEPT_1", "serviceCode": "NoStreetlight"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
bcbaec41-909d-47ff-b495-c43cd90f0095	pg	cc59ecfba912b1fa3df332fbf36038931503b17dfc8398bf2e04c35431d7bf0e	RAINMAKER-PGR.UIConstants	{"REOPENSLA": 432000000}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
8dc76ad4-dfc4-4ba6-9bb6-1b026ef1c69f	pg	43b53bde3abdfb2f034bbd43e5705add60fbdf6dafdd6201f021adbdca907834	tenant.citymodule	{"code": "Workbench", "order": 13, "active": true, "module": "Workbench", "tenants": [{"code": "pg.cityb"}, {"code": "pg.cityc"}, {"code": "pg.citya"}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b9e3602f-93a4-4bff-a33d-13c7a37d6ddd	pg	d9868411078f0cb5f54bbb65772a65786ad585ec888bdc465545205c6da22b1f	tenant.citymodule	{"code": "PGR", "order": 2, "active": true, "module": "PGR", "tenants": [{"code": "pg.citya"}, {"code": "pg.cityb"}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
abfd3107-2234-4df7-921b-dc270dbcecbb	pg	e8e4c0b369aec423c9f50a87e2e8adfb84115951ccb375583435681ea9a57158	tenant.citymodule	{"code": "HRMS", "order": 2, "active": true, "module": "HRMS", "tenants": [{"code": "pg"}, {"code": "pg.citya"}, {"code": "pg.cityb"}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
aa330faa-55c0-4b96-a936-b796f37a090a	pg	5190036c90bc19082e2a1cda0c8e3b30e40fbce184cebc12fac476dae11eaa88	tenant.tenants	{"city": {"code": "1013", "name": "City A", "captcha": null, "ddrName": "DDR A", "latitude": 31.3260152, "ulbGrade": "Municipal Corporation", "localName": null, "longitude": 75.5761829, "regionName": null, "districtCode": "CITYA", "districtName": null, "shapeFileLocation": null, "districtTenantCode": "pg.citya"}, "code": "pg.citya", "name": "City A", "type": "CITY", "logoId": "https://s3.ap-south-1.amazonaws.com/pg-egov-assets/pg.citya/logo.png", "address": "City A Municipal Corporation", "emailId": "citya@gmail.com", "imageId": null, "pincode": [143001, 143002, 143003, 143004, 143005], "domainUrl": "https://www.egovernments.org", "twitterUrl": null, "description": "City A", "facebookUrl": null, "OfficeTimings": {"Mon - Fri": "9.00 AM - 6.00 PM"}, "contactNumber": "001-2345876"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c484e9d2-acf9-4aad-8af7-802f3e2771ac	pg	33552d7944d29db95d3abfda24a528d39c715f4852c7e4181f62271ccdc8c6ef	tenant.tenants	{"city": {"code": "107", "name": "City B", "captcha": null, "ddrName": "DDR A", "latitude": 31.6339793, "ulbGrade": "Municipal Corporation", "localName": null, "longitude": 74.8722642, "regionName": null, "districtCode": "CITYB", "districtName": null, "shapeFileLocation": null, "districtTenantCode": "pg.cityb"}, "code": "pg.cityb", "name": "City B", "type": "CITY", "logoId": "https://s3.ap-south-1.amazonaws.com/pg-egov-assets/pg.cityb/logo.png", "address": "City B Municipal Corporation Address", "emailId": "cityb@gmail.com", "imageId": null, "pincode": [143006, 143007, 143008, 143009, 143010], "domainUrl": "https://www.egovernments.org", "twitterUrl": null, "description": null, "facebookUrl": null, "OfficeTimings": {"Sat": "9.00 AM - 12.00 PM", "Mon - Fri": "9.00 AM - 6.00 PM"}, "contactNumber": "0978-7645345", "helpLineNumber": "0654-8734567"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
56039d41-c9f5-42f0-823c-8112e69fcc45	pg	c38ce6813d86df987616cc4d1a80b301c3141b0b71b73d76734e5beeda4fe3fc	Workflow.AutoEscalationStatesToIgnore	{"state": ["INITIATED", "PENDINGAPPROVAL"], "module": "TL", "businessService": "NewTL"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
47215ddc-cdc9-4021-81ef-9b6137c9123a	pg	e08f0fc8b81e33183a57e2d0fdf93aefb2a75b1c10208502e948a55ea39cd673	Workflow.BusinessService	{"uuid": "2b75575a-f84d-11e8-8eb2-f2801f1b9fd1", "getUri": "", "states": [{"uuid": "bf5fd4f4-f7df-11e8-8eb2-f2801f1b9fd1", "state": "INITIATED", "actions": [{"uuid": "4bd0f10a-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "CITIZEN,TL_CEMP", "action": "APPLY", "stateId": "bf5fd4f4-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fd8c8-f7df-11e8-8eb2-f2801f1b9fd1"}], "tenantId": "pg", "isStartState": "true", "UpdateAllowed": "false", "isTerminateState": "false", "applicableActions": "INITIATE", "businessServiceId": "NewTL", "docUploadRequired": "false", "applicableNextStates": "APPLIED"}, {"uuid": "bf5fd8c8-f7df-11e8-8eb2-f2801f1b9fd1", "state": "APPLIED", "actions": [{"uuid": "4bd0f2a4-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "SYSTEM_PAYMENT", "action": "PAY", "stateId": "bf5fd8c8-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fdaee-f7df-11e8-8eb2-f2801f1b9fd1"}, {"uuid": "4bd0f3ee-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "CLERK", "action": "CANCEL", "stateId": "bf5fd8c8-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fe0fc-f7df-11e8-8eb2-f2801f1b9fd1"}, {"uuid": "4bd0f524-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "CLERK", "action": "REJECT", "stateId": "bf5fd8c8-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fe318-f7df-11e8-8eb2-f2801f1b9fd1"}, {"uuid": "543f802e-f952-11e8-8eb2-f2801f1b9fd1", "roles": "TL_APPROVER", "action": "APPROVE", "stateId": "bf5fe444-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fdfbc-f7df-11e8-8eb2-f2801f1b9fd1"}], "tenantId": "pg", "isStartState": "false", "UpdateAllowed": "true", "isTerminateState": "false", "applicableActions": "Reject,Pay,Cancel,Mark", "businessServiceId": "NewTL", "docUploadRequired": "false", "applicableNextStates": "Paid,Cancelled,Rejected"}, {"uuid": "bf5fdaee-f7df-11e8-8eb2-f2801f1b9fd1", "state": "PAID", "actions": [{"uuid": "4bd0faa6-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "CLERK", "action": "CANCEL", "stateId": "bf5fdaee-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fe0fc-f7df-11e8-8eb2-f2801f1b9fd1"}, {"uuid": "4bd0fc54-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "CLERK", "action": "REJECT", "stateId": "bf5fdaee-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fe318-f7df-11e8-8eb2-f2801f1b9fd1"}, {"uuid": "4bd0feac-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "CLERK", "action": "MARK", "stateId": "bf5fdaee-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fdaee-f7df-11e8-8eb2-f2801f1b9fd1"}, {"uuid": "4bd10136-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "CLERK", "action": "FORWARD", "stateId": "bf5fdaee-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fdd28-f7df-11e8-8eb2-f2801f1b9fd1"}], "tenantId": "pg", "isStartState": "false", "UpdateAllowed": "true", "isTerminateState": "false", "applicableActions": "Approve,Cancel,Reject,Mark", "businessServiceId": "NewTL", "docUploadRequired": "false", "applicableNextStates": "Intermediate"}, {"uuid": "bf5fdd28-f7df-11e8-8eb2-f2801f1b9fd1", "state": "FIELDINSPECTION", "actions": [{"uuid": "4bd1041a-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "TL_FIELD_INSPECTOR", "action": "CANCEL", "stateId": "bf5fdd28-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fe0fc-f7df-11e8-8eb2-f2801f1b9fd1"}, {"uuid": "4bd1064a-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "TL_FIELD_INSPECTOR", "action": "REJECT", "stateId": "bf5fdd28-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fe318-f7df-11e8-8eb2-f2801f1b9fd1"}, {"uuid": "4bd108ac-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "TL_FIELD_INSPECTOR", "action": "MARK", "stateId": "bf5fdd28-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fdd28-f7df-11e8-8eb2-f2801f1b9fd1"}, {"uuid": "4bd10de8-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "TL_FIELD_INSPECTOR", "action": "FORWARD", "stateId": "bf5fdd28-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fe444-f7df-11e8-8eb2-f2801f1b9fd1"}], "tenantId": "pg", "isStartState": "false", "UpdateAllowed": "", "isTerminateState": "false", "applicableActions": "", "businessServiceId": "NewTL", "docUploadRequired": "", "applicableNextStates": "Approved,Cancelled,Rejected"}, {"uuid": "bf5fdfbc-f7df-11e8-8eb2-f2801f1b9fd1", "state": "APPROVED", "actions": [{"uuid": "4bd11770-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "TL_APPROVER", "action": "CANCEL", "stateId": "bf5fdfbc-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fe0fc-f7df-11e8-8eb2-f2801f1b9fd1"}], "tenantId": "pg", "isStartState": "false", "UpdateAllowed": "true", "isTerminateState": "true", "applicableActions": "CANCEL", "businessServiceId": "NewTL", "docUploadRequired": "true", "applicableNextStates": ""}, {"uuid": "bf5fe0fc-f7df-11e8-8eb2-f2801f1b9fd1", "state": "CANCELLED", "actions": [{"uuid": "4bd112e8-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "", "action": "", "stateId": "bf5fe0fc-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": ""}], "tenantId": "pg", "isStartState": "false", "UpdateAllowed": "true", "isTerminateState": "true", "applicableActions": "", "businessServiceId": "NewTL", "docUploadRequired": "false", "applicableNextStates": ""}, {"uuid": "bf5fe318-f7df-11e8-8eb2-f2801f1b9fd1", "state": "REJECTED", "actions": [{"uuid": "4bd115fe-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "CITIZEN,TL_CEMP", "action": "REINITIATE", "stateId": "bf5fe318-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fd4f4-f7df-11e8-8eb2-f2801f1b9fd1"}], "tenantId": "pg", "isStartState": "false", "UpdateAllowed": "true", "isTerminateState": "true", "applicableActions": "Reapply", "businessServiceId": "NewTL", "docUploadRequired": "true", "applicableNextStates": "Initiated"}, {"uuid": "bf5fe444-f7df-11e8-8eb2-f2801f1b9fd1", "state": "PENDINGAPPROVAL", "actions": [{"uuid": "4bd10f50-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "TL_APPROVER", "action": "APPROVE", "stateId": "bf5fe444-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fdfbc-f7df-11e8-8eb2-f2801f1b9fd1"}, {"uuid": "4bd11086-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "TL_APPROVER", "action": "CANCEL", "stateId": "bf5fe444-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fe0fc-f7df-11e8-8eb2-f2801f1b9fd1"}, {"uuid": "4bd111a8-f7d3-11e8-8eb2-f2801f1b9fd1", "roles": "TL_APPROVER", "action": "REJECT", "stateId": "bf5fe444-f7df-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fe318-f7df-11e8-8eb2-f2801f1b9fd1"}], "tenantId": "pg", "isStartState": "false", "UpdateAllowed": "", "isTerminateState": "false", "applicableActions": "", "businessServiceId": "NewTL", "docUploadRequired": "", "applicableNextStates": ""}, {"uuid": "9d458700-f894-11e8-8eb2-f2801f1b9fd1", "state": "", "actions": [{"uuid": "2efb9036-f895-11e8-8eb2-f2801f1b9fd1", "roles": "CITIZEN,TL_CEMP", "action": "INITIATE", "stateId": "9d458700-f894-11e8-8eb2-f2801f1b9fd1", "tenantId": "pg", "nextStateId": "bf5fd4f4-f7df-11e8-8eb2-f2801f1b9fd1"}], "tenantId": "pg", "isStartState": "true", "UpdateAllowed": "true", "isTerminateState": "false", "applicableActions": "INITIATE", "businessServiceId": "NewTL", "docUploadRequired": "false", "applicableNextStates": "Initiated"}], "postUri": "", "tenantId": "pg", "businessService": "NewTL"}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
22fcc569-d23d-4e85-a2cb-1528123d8c0a	pg	9c1639a0d054ead7762c28dc39d4faace7bd3c2beb39dadf044bdd15a3662d5d	Workflow.BusinessServiceConfig	{"code": "NEWTL", "isStateLevel": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7a114c79-20af-4062-b49d-c6b8d8aae969	pg	0c5d9c83e755ff20012541233d8dec09a5bded28ac0007b76328de484bf77700	Workflow.BusinessServiceConfig	{"code": "FIRENOC", "isStateLevel": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0567bd73-cd4f-4228-a180-ed1b32312ea1	pg	pg.citest	tenant.tenants	{"city": {"code": "PG_CITEST", "name": "CI Test", "districtName": "CI Test"}, "code": "pg.citest", "name": "CI Test", "type": "CITY", "tenantId": "pg.citest"}	t	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664445675	1778664445675
f9b4725c-cc90-422b-9511-6a9d8d5444d0	pg.citest	DEPT_36	common-masters.Department	{"code": "DEPT_36", "name": "WATER DEPARTMENT", "active": true}	t	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664445960	1778664445960
d60fb222-278f-4082-888f-488f27022116	pg.citest	DEPT_37	common-masters.Department	{"code": "DEPT_37", "name": "ELECTRIC DEPARTMENT", "active": true}	t	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664446073	1778664446073
f9913463-e26d-4184-ae20-a32131c44fbd	pg.citest	DESIG_1002	common-masters.Designation	{"code": "DESIG_1002", "name": "engineer", "active": true, "department": ["DEPT_36"], "description": "engineer - WATER DEPARTMENT"}	t	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664446474	1778664446474
f5f27b3d-865c-4327-823c-65b2b359265b	pg.citest	DESIG_1003	common-masters.Designation	{"code": "DESIG_1003", "name": "LME", "active": true, "department": ["DEPT_37"], "description": "LME - ELECTRIC DEPARTMENT"}	t	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664446586	1778664446586
81dd9ccb-61de-449d-bdf9-61bb19821484	pg.citest	TabBroken	RAINMAKER-PGR.ServiceDefs	{"name": "tab broken", "active": true, "keywords": "", "menuPath": "Water not coming", "slaHours": 1, "department": "DEPT_36", "serviceCode": "TabBroken"}	t	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664446999	1778664446999
7030dafd-802c-42be-a222-93f15ee78e8a	pg.citest	DEPT_5	common-masters.Department	{"code": "DEPT_5", "name": "Horticulture", "active": true}	t	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664447391	1778664447391
7e623113-912c-471c-90cd-a44b4fa05d61	pg	CFC	ACCESSCONTROL-ROLES.roles	{"code": "CFC", "name": "CFC", "description": "CFC"}	t	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664447418	1778664447418
theme-config-data-001	pg	themeconfig	common-masters.ThemeConfig	{"id": "themeconfig", "code": "themeconfig", "name": "themeconfig", "colors": {"grey": {"bg": "#E6E6E6", "mid": "#EEEEEE", "dark": "#787878", "light": "#FAFAFA", "lighter": "#F2F2F2", "disabled": "#C5C5C5"}, "link": {"hover": "#204F37", "normal": "#204F37"}, "text": {"muted": "#787878", "heading": "#204F37", "primary": "#1D2433", "secondary": "#5F5C62"}, "error": "#E02D3A", "border": "#D6D5D4", "digitv2": {"chart-1": "#204F37", "chart-2": "#FEC931", "chart-3": "#2A5084", "chart-4": "#E02D3C", "chart-5": "#128F21", "alert-info": "#2A5084", "primary-bg": "#FFF4D6", "alert-info-bg": "#EAF1F5", "alert-error-bg": "#FEF1F2", "header-sidenav": "#204F37", "alert-success-bg": "#E0F2E1", "text-color-disabled": "#B1B4B6"}, "primary": {"dark": "#204F37", "main": "#FEC931", "light": "#FFF4D6", "accent": "#204F37", "selected-bg": "#FFF4D6"}, "success": "#128F21", "info-dark": "#2A5084", "secondary": "#1D2433", "error-dark": "#8B0000", "input-border": "#E1E6EF", "warning-dark": "#9E5F00"}, "version": "1"}	t	system-mdms-seed	system-mdms-seed	1770614666000	1770614666000
14382e2e-9112-4902-95d5-56b1cf6109bc	pg	CMS|All	CMS-BOUNDARY.HierarchySchema	{"hierarchy": "ADMIN", "department": "All", "moduleName": "CMS", "lowestHierarchy": "Locality", "highestHierarchy": "Zone"}	t	system	system	1781073905029	1781073905029
19cef8a4-ac24-45ef-9c4e-19c9ece74d87	pg	HRMS|All	CMS-BOUNDARY.HierarchySchema	{"hierarchy": "ADMIN", "department": "All", "moduleName": "HRMS", "lowestHierarchy": "Locality", "highestHierarchy": "Zone"}	t	system	system	1781073905029	1781073905029
95952ec6-63c6-4b0d-a2c7-43c009d53a43	pg	CRS_BOUNDARY_DATA	CRS-ADMIN-CONSOLE.adminSchema	{"title": "CRS_BOUNDARY_DATA", "properties": {"numberProperties": [{"name": "CRS_LAT", "type": "number", "isRequired": true, "description": "Latitude", "orderNumber": 2}, {"name": "CRS_LONG", "type": "number", "isRequired": true, "description": "Longitude", "orderNumber": 3}], "stringProperties": [{"name": "CRS_BOUNDARY_CODE", "type": "string", "isRequired": true, "description": "Boundary Code", "orderNumber": 1, "freezeColumn": true}]}, "campaignType": "all"}	t	system	system	1781073905029	1781073905029
c674e5c2-7983-459b-bb0f-6929245fea2b	pg.citya	CMS|All	CMS-BOUNDARY.HierarchySchema	{"hierarchy": "ADMIN", "department": "All", "moduleName": "CMS", "lowestHierarchy": "Ward", "highestHierarchy": "Zone"}	t	system	system	1781074295688	1783641600000
a51e8099-4433-4409-b0ac-5b5873d78957	pg.citya	HRMS|All	CMS-BOUNDARY.HierarchySchema	{"hierarchy": "ADMIN", "department": "All", "moduleName": "HRMS", "lowestHierarchy": "Ward", "highestHierarchy": "Zone"}	t	system	system	1781074295688	1783641600000
91e3b381-dfc4-4dfd-9768-3f193e57c088	pg.citya	CRS_BOUNDARY_DATA	CRS-ADMIN-CONSOLE.adminSchema	{"title": "CRS_BOUNDARY_DATA", "properties": {"numberProperties": [{"name": "CRS_LAT", "type": "number", "isRequired": true, "description": "Latitude", "orderNumber": 2}, {"name": "CRS_LONG", "type": "number", "isRequired": true, "description": "Longitude", "orderNumber": 3}], "stringProperties": [{"name": "CRS_BOUNDARY_CODE", "type": "string", "isRequired": true, "description": "Boundary Code", "orderNumber": 1, "freezeColumn": true}]}, "campaignType": "all"}	t	system	system	1781074295688	1781074295688
dashboard-config-data-002	pg	default	dss.DashboardConfig	{"id": "default", "allowedRoles": ["SUPERVISOR", "PGR_SUPERVISOR", "GRO", "DGRO", "PGR_LME", "PGR_ADMIN", "SUPERUSER"], "numberFormat": {"en_IN": "#,##0.00", "pt_PT": "#.##0,00", "fr_FR": "# ##0,00", "default": "#,##0.00"}}	t	system-mdms-seed	system-mdms-seed	1770614666000	1770614666000
956a5be3-d952-4291-842a-c94653946ac1	pg.citya	common-masters.Department.DEPT_1	common-masters.Department	{"code": "DEPT_1", "name": "Street Lighting & Electrical", "active": true}	t	system-mdms-seed	system-mdms-seed	1783555200000	1783555200000
2cade399-9d00-4423-8ddf-eda05af5c904	pg.citya	common-masters.Department.DEPT_2	common-masters.Department	{"code": "DEPT_2", "name": "Roads & Public Works", "active": true}	t	system-mdms-seed	system-mdms-seed	1783555200000	1783555200000
07da774b-1bc0-4154-b542-0ad17b645374	pg.citya	common-masters.Department.DEPT_3	common-masters.Department	{"code": "DEPT_3", "name": "Health & Sanitation", "active": true}	t	system-mdms-seed	system-mdms-seed	1783555200000	1783555200000
9c2e1397-8a1e-49ac-83c0-50c784db5133	pg.citya	common-masters.Department.DEPT_4	common-masters.Department	{"code": "DEPT_4", "name": "Water Supply & Sewerage", "active": true}	t	system-mdms-seed	system-mdms-seed	1783555200000	1783555200000
form-validations-email-001	pg	email	common-masters.FormValidations	{"regex": "^[^\\\\s@]+@[^\\\\s@]+\\\\.[^\\\\s@]+$", "fieldType": "email"}	t	system-mdms-seed	system-mdms-seed	1770614666000	1770614666000
form-validations-name-001	pg	name	common-masters.FormValidations	{"regex": "^(?!.*[ _-]{2})(?!^[\\\\s_-])(?!.*[\\\\s_-]$)(?=^[\\\\p{L}][\\\\p{L}\\\\p{N} _\\\\-\\\\(\\\\)]{0,29}$)^.*$", "fieldType": "name"}	t	system-mdms-seed	system-mdms-seed	1770614666000	1770614666000
form-validations-postalcode-001	pg	postalCode	common-masters.FormValidations	{"regex": "^[0-9]{5}$", "fieldType": "postalCode"}	t	system-mdms-seed	system-mdms-seed	1770614666000	1770614666000
complaint-hierarchy-definition-data	pg	PGR	RAINMAKER-PGR.ComplaintHierarchyDefinition	{"hierarchyType": "PGR", "active": true, "levels": [{"levelCode": "CATEGORY", "order": 1, "parentLevel": null, "isFreeText": false, "isLeafServiceCode": false, "label": "Category"}, {"levelCode": "SUB_TYPE", "order": 2, "parentLevel": "CATEGORY", "isFreeText": false, "isLeafServiceCode": true, "label": "Sub-Type"}]}	t	system-mdms-seed	system-mdms-seed	1785200000000	1785200000000
complaint-hierarchy-data-001	pg	PGR.Garbage	RAINMAKER-PGR.ComplaintHierarchy	{"hierarchyType": "PGR", "levelCode": "CATEGORY", "code": "Garbage", "parentCode": null, "name": "Garbage", "order": 1, "active": true, "path": "Garbage"}	t	system-mdms-seed	system-mdms-seed	1785200000000	1785200000000
complaint-hierarchy-data-002	pg	PGR.StreetLights	RAINMAKER-PGR.ComplaintHierarchy	{"hierarchyType": "PGR", "levelCode": "CATEGORY", "code": "StreetLights", "parentCode": null, "name": "Street Lights", "order": 2, "active": true, "path": "StreetLights"}	t	system-mdms-seed	system-mdms-seed	1785200000000	1785200000000
complaint-hierarchy-data-003	pg	PGR.BurningOfGarbage	RAINMAKER-PGR.ComplaintHierarchy	{"hierarchyType": "PGR", "levelCode": "SUB_TYPE", "code": "BurningOfGarbage", "parentCode": "Garbage", "name": "Burning of garbage", "order": 2, "active": true, "path": "Garbage.BurningOfGarbage", "department": "DEPT_3", "slaHours": 336, "keywords": "garbage, remove, burn, fire, health, waste, smoke, plastic, illegal"}	t	system-mdms-seed	system-mdms-seed	1785200000000	1785200000000
complaint-hierarchy-data-004	pg	PGR.DamagedGarbageBin	RAINMAKER-PGR.ComplaintHierarchy	{"hierarchyType": "PGR", "levelCode": "SUB_TYPE", "code": "DamagedGarbageBin", "parentCode": "Garbage", "name": "Damaged garbage bin", "order": 3, "active": true, "path": "Garbage.DamagedGarbageBin", "department": "DEPT_3", "slaHours": 336, "keywords": "garbage, waste, bin, dustbin, clean, remove, sanitation, overflow, smell, health, throw, dispose"}	t	system-mdms-seed	system-mdms-seed	1785200000000	1785200000000
complaint-hierarchy-data-005	pg	PGR.GarbageNeedsTobeCleared	RAINMAKER-PGR.ComplaintHierarchy	{"hierarchyType": "PGR", "levelCode": "SUB_TYPE", "code": "GarbageNeedsTobeCleared", "parentCode": "Garbage", "name": "Garbage needs to be cleared", "order": 4, "active": true, "path": "Garbage.GarbageNeedsTobeCleared", "department": "DEPT_3", "slaHours": 336, "keywords": "garbage, collect, litter, clean, door, waste, remove, sweeper, sanitation, dump, health, debris, throw"}	t	system-mdms-seed	system-mdms-seed	1785200000000	1785200000000
complaint-hierarchy-data-006	pg	PGR.NonSweepingOfRoad	RAINMAKER-PGR.ComplaintHierarchy	{"hierarchyType": "PGR", "levelCode": "SUB_TYPE", "code": "NonSweepingOfRoad", "parentCode": "Garbage", "name": "Non sweeping of road", "order": 5, "active": true, "path": "Garbage.NonSweepingOfRoad", "department": "DEPT_3", "slaHours": 336, "keywords": "garbage, collect, litter, clean, door, waste, remove, sweeper, sanitation, dump, health, debris, throw"}	t	system-mdms-seed	system-mdms-seed	1785200000000	1785200000000
complaint-hierarchy-data-007	pg	PGR.StreetLightNotWorking	RAINMAKER-PGR.ComplaintHierarchy	{"hierarchyType": "PGR", "levelCode": "SUB_TYPE", "code": "StreetLightNotWorking", "parentCode": "StreetLights", "name": "Streetlight not working", "order": 1, "active": true, "path": "StreetLights.StreetLightNotWorking", "department": "DEPT_1", "slaHours": 336, "keywords": "streetlight, light, repair, work, pole, electric, power, repair, fix"}	t	system-mdms-seed	system-mdms-seed	1785200000000	1785200000000
complaint-hierarchy-data-008	pg	PGR.NoStreetlight	RAINMAKER-PGR.ComplaintHierarchy	{"hierarchyType": "PGR", "levelCode": "SUB_TYPE", "code": "NoStreetlight", "parentCode": "StreetLights", "name": "No streetlight", "order": 6, "active": true, "path": "StreetLights.NoStreetlight", "department": "DEPT_1", "slaHours": 336, "keywords": "streetlight, light, repair, work, pole, electric, power, repair, damage, fix"}	t	system-mdms-seed	system-mdms-seed	1785200000000	1785200000000
\.


--
-- Data for Name: eg_mdms_schema_definition; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_mdms_schema_definition (id, tenantid, code, description, definition, isactive, createdby, lastmodifiedby, createdtime, lastmodifiedtime) FROM stdin;
tenant-schema-001	pg	tenant.tenants	Tenant master	{"type": "object", "title": "Tenant master", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "name"], "x-unique": ["code"], "properties": {"city": {"type": "object", "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "captcha": {"type": ["string", "null"]}, "ddrName": {"type": ["string", "null"]}, "latitude": {"type": "number"}, "ulbGrade": {"type": ["string", "null"]}, "blockCode": {"type": ["string", "null"]}, "localName": {"type": ["string", "null"]}, "longitude": {"type": "number"}, "regionName": {"type": ["string", "null"]}, "districtCode": {"type": ["string", "null"]}, "districtName": {"type": ["string", "null"]}, "shapeFileLocation": {"type": ["string", "null"]}, "districtTenantCode": {"type": ["string", "null"]}}}, "code": {"type": "string"}, "name": {"type": "string"}, "type": {"type": ["string", "null"]}, "logoId": {"type": ["string", "null"]}, "parent": {"type": ["string", "null"]}, "address": {"type": ["string", "null"]}, "emailId": {"type": ["string", "null"]}, "imageId": {"type": ["string", "null"]}, "pincode": {"type": "array", "items": {"type": "number"}}, "tenantId": {"type": "string"}, "domainUrl": {"type": ["string", "null"]}, "twitterUrl": {"type": ["string", "null"]}, "description": {"type": ["string", "null"]}, "facebookUrl": {"type": ["string", "null"]}, "OfficeTimings": {"type": "object", "properties": {"Sat": {"type": "string"}, "Mon - Fri": {"type": "string"}}}, "contactNumber": {"type": ["string", "null"]}, "helpLineNumber": {"type": ["string", "null"]}}}	t	system-mdms-seed	system-mdms-seed	1770614666000	1770614666000
tenant-schema-002	pg	tenant.citymodule	City module configuration	{"type": "object", "title": "City module configuration", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["module", "code", "active", "order", "tenants"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "order": {"type": "number"}, "active": {"type": "boolean"}, "module": {"type": "string"}, "tenants": {"type": "array", "items": {"type": "object", "required": ["code"], "properties": {"code": {"type": "string"}}}}}, "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1770614666000	1770614666000
64ba13dc-5b8b-47e0-9646-b2ab48fc81d1	pg	DataSecurity.DecryptionABAC	DataSecurity.DecryptionABAC	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["key", "roleAttributeAccessList"], "x-unique": ["key"], "properties": {"key": {"type": "string"}, "roleAttributeAccessList": {"type": "array", "items": {"type": "object", "required": ["roleCode", "attributeAccessList"], "properties": {"roleCode": {"type": "string"}, "attributeAccessList": {"type": "array", "items": {"type": "object", "required": ["attribute", "accessType"], "properties": {"attribute": {"type": "object", "required": ["jsonPath"], "properties": {"jsonPath": {"type": "string"}, "maskingTechnique": {"type": "string"}}}, "accessType": {"type": "string"}}}}}}}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b7779eca-1c6b-47dc-a448-c807055ad9bb	pg	DataSecurity.EncryptionPolicy	DataSecurity.EncryptionPolicy	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["key", "attributeList"], "x-unique": ["key"], "properties": {"key": {"type": "string"}, "attributeList": {"type": "array", "items": {"type": "object", "required": ["jsonPath", "type"], "properties": {"type": {"type": "string"}, "jsonPath": {"type": "string"}}}}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7d22588c-8704-45a0-8b2a-9d7dbe6a9606	pg	DataSecurity.MaskingPatterns	DataSecurity.MaskingPatterns	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["patternId", "pattern"], "x-unique": ["patternId"], "properties": {"pattern": {"type": "string"}, "patternId": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
ab2954d8-1bb5-4c01-a895-6ef95130e2d9	pg	DataSecurity.SecurityPolicy	DataSecurity.SecurityPolicy	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["model", "uniqueIdentifier", "attributes", "roleBasedDecryptionPolicy"], "x-unique": ["model"], "properties": {"model": {"type": "string"}, "attributes": {"type": "array", "items": {"type": "object", "required": ["name", "jsonPath", "patternId", "defaultVisibility"], "properties": {"name": {"type": "string"}, "jsonPath": {"type": "string"}, "patternId": {"type": ["string", "null"]}, "defaultVisibility": {"type": "string"}}}}, "uniqueIdentifier": {"type": "object", "required": ["name", "jsonPath"], "properties": {"name": {"type": "string"}, "jsonPath": {"type": "string"}}}, "roleBasedDecryptionPolicy": {"type": "array", "items": {"type": "object", "required": ["roles", "attributeAccessList"], "properties": {"roles": {"type": "array", "items": {"type": "string"}}, "attributeAccessList": {"type": "array", "items": {"type": "object", "required": ["attribute", "firstLevelVisibility", "secondLevelVisibility"], "properties": {"attribute": {"type": "string"}, "firstLevelVisibility": {"type": "string"}, "secondLevelVisibility": {"type": "string"}}}}}}}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
workflow-bsm-schema	pg	Workflow.BusinessServiceMasterConfig	Workflow.BusinessServiceMasterConfig	{"type": "object", "title": "Workflow business service state-level config", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["businessService", "isStatelevel", "active"], "x-unique": ["businessService"], "properties": {"active": {"type": "string"}, "isStatelevel": {"type": "string"}, "businessService": {"type": "string"}}}	t	system-mdms-seed	system-mdms-seed	1770614667000	1770614667000
a759d955-8ce8-4191-9a41-7f7352d97642	pg	ACCESSCONTROL-ROLES.roles	ACCESSCONTROL-ROLES.roles	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "name"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "description": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5641188f-b01c-4f3d-9d5d-b68a089d41ee	pg	common-masters.GenderType	  	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "active"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "active": {"type": "boolean"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7c7f7775-130f-4b14-a4a0-dd9b99a33715	pg	common-masters.IdFormat	  	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["format", "idname"], "x-unique": ["idname"], "properties": {"format": {"type": "string"}, "idname": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6f234e53-9093-4d52-9230-5d9363272d93	pg	ACCESSCONTROL-ACTIONS-TEST.actions-test	ACCESSCONTROL-ACTIONS-TEST.actions-test	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["id", "name", "url", "displayName", "orderNumber", "enabled", "serviceCode", "path"], "x-unique": ["id"], "properties": {"id": {"type": "number"}, "url": {"type": "string"}, "code": {"type": "string", "default": "null"}, "name": {"type": "string"}, "path": {"type": "string"}, "enabled": {"type": "boolean", "default": true}, "leftIcon": {"type": "string"}, "rightIcon": {"type": "string"}, "displayName": {"type": "string"}, "orderNumber": {"type": "number", "default": 0}, "serviceCode": {"type": "string", "default": ""}, "parentModule": {"type": "string"}, "navigationURL": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": true}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
7d0afec9-2b73-493c-b31e-d69da0547ed9	pg	ACCESSCONTROL-ROLEACTIONS.roleactions	ACCESSCONTROL-ROLEACTIONS.roleactions	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["rolecode", "actionid", "tenantId"], "x-unique": ["rolecode", "actionid"], "properties": {"actionid": {"type": "number"}, "rolecode": {"type": "string"}, "tenantId": {"type": "string"}, "actioncode": {"type": "string"}}, "x-ref-schema": [{"fieldPath": "rolecode", "schemaCode": "ACCESSCONTROL-ROLES.roles"}, {"fieldPath": "actionid", "schemaCode": "ACCESSCONTROL-ACTIONS-TEST.actions-test"}]}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
e8f92cf4-a4f8-4b07-8934-df99df7aabc3	pg	common-masters.CronJobAPIConfig	  	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["jobName", "active", "method", "url", "payload", "header"], "x-unique": ["jobName", "url"], "properties": {"url": {"type": "string"}, "active": {"type": "string"}, "header": {"type": "object", "required": ["Content-Type"], "properties": {"Content-Type": {"type": "string"}}}, "method": {"type": "string"}, "jobName": {"type": "string"}, "payload": {"type": "object", "required": ["RequestInfo"], "properties": {"RequestInfo": {"type": "string"}}}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
b3706d92-2050-40cc-b485-e1a4a426da96	pg	common-masters.Department	  	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["name", "code", "active"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "active": {"type": "boolean", "default": true}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
4bba95a4-54ef-42f8-858e-d678eae8a2a3	pg	common-masters.Designation	  	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "name", "description", "active"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "active": {"type": "boolean"}, "department": {"type": "array", "items": {"type": "string"}}, "description": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
0233d7a8-f57b-45f1-a0db-b2f97ae4b5f2	pg	common-masters.wfSlaConfig	  	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["slotPercentage", "positiveSlabColor", "negativeSlabColor", "middleSlabColor"], "x-unique": ["slotPercentage"], "properties": {"slotPercentage": {"type": "number"}, "middleSlabColor": {"type": "string"}, "negativeSlabColor": {"type": "string"}, "positiveSlabColor": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
5ecdde1c-62ed-40e6-9944-5efc4298e00a	pg	common-masters.StateInfo	  	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["name", "code"], "x-unique": ["name", "code"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "logoUrl": {"type": "string"}, "bannerUrl": {"type": "string"}, "languages": {"type": "array", "items": {"type": "object"}}, "qrCodeURL": {"type": "string"}, "statelogo": {"type": "string"}, "defaultUrl": {"type": "object"}, "logoUrlWhite": {"type": "string"}, "enableWhatsApp": {"type": "boolean"}, "hasLocalisation": {"type": "boolean"}, "localizationModules": {"type": "array", "items": {"type": "object"}}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
236e18b9-1104-4e5d-b9d1-c1a935724cca	pg	common-masters.uiHomePage	  	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["redirectURL"], "x-unique": ["redirectURL"], "properties": {"redirectURL": {"type": "string"}, "appBannerMobile": {"type": "object", "required": ["code", "name", "bannerUrl", "enabled"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "enabled": {"type": "boolean"}, "bannerUrl": {"type": "string"}}}, "whatsNewSection": {"type": "object", "required": ["code", "name", "enabled", "headerLabel", "sideOption"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "enabled": {"type": "boolean"}, "sideOption": {"type": "object", "required": ["name", "enabled", "navigationUrl"], "properties": {"name": {"type": "string"}, "enabled": {"type": "boolean"}, "navigationUrl": {"type": "string"}}}, "headerLabel": {"type": "string"}}}, "appBannerDesktop": {"type": "object", "required": ["code", "name", "bannerUrl", "enabled"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "enabled": {"type": "boolean"}, "bannerUrl": {"type": "string"}}}, "citizenServicesCard": {"type": "object", "required": ["code", "name", "enabled", "headerLabel", "sideOption", "props"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "props": {"type": "array", "items": {"type": "object", "required": ["code", "name", "label", "enabled", "navigationUrl"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "label": {"type": "string"}, "enabled": {"type": "boolean"}, "navigationUrl": {"type": "string"}}}}, "enabled": {"type": "boolean"}, "sideOption": {"type": "object", "required": ["name", "enabled", "navigationUrl"], "properties": {"name": {"type": "string"}, "enabled": {"type": "boolean"}, "navigationUrl": {"type": "string"}}}, "headerLabel": {"type": "string"}}}, "whatsAppBannerMobile": {"type": "object", "required": ["code", "name", "bannerUrl", "enabled", "navigationUrl"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "enabled": {"type": "boolean"}, "bannerUrl": {"type": "string"}, "navigationUrl": {"type": "string"}}}, "whatsAppBannerDesktop": {"type": "object", "required": ["code", "name", "bannerUrl", "enabled", "navigationUrl"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "enabled": {"type": "boolean"}, "bannerUrl": {"type": "string"}, "navigationUrl": {"type": "string"}}}, "informationAndUpdatesCard": {"type": "object", "required": ["code", "name", "enabled", "headerLabel", "sideOption", "props"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "props": {"type": "array", "items": {"type": "object", "required": ["code", "name", "label", "enabled", "navigationUrl"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "label": {"type": "string"}, "enabled": {"type": "boolean"}, "navigationUrl": {"type": "string"}}}}, "enabled": {"type": "boolean"}, "sideOption": {"type": "object", "required": ["name", "enabled", "navigationUrl"], "properties": {"name": {"type": "string"}, "enabled": {"type": "boolean"}, "navigationUrl": {"type": "string"}}}, "headerLabel": {"type": "string"}}}}}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d42fb05a-7250-4780-a87b-3455e01d061a	pg	egov-hrms.DeactivationReason	egov-hrms.DeactivationReason	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "active"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "active": {"type": "boolean"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
81d8e3d0-6edd-4dd0-b737-5e12e5e396ab	pg	egov-hrms.Degree	egov-hrms.Degree	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "active"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "active": {"type": "boolean"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
503b7082-b0b1-459a-9cf8-07e651ff54f9	pg	egov-hrms.EmployeeStatus	egov-hrms.EmployeeStatus	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "active"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "active": {"type": "boolean"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6b2371b7-f120-4677-9a9c-65e420202d84	pg	egov-hrms.EmployeeType	egov-hrms.EmployeeType	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "active"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "active": {"type": "boolean"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
fc912db2-1ce7-4479-8fb6-6b4429b86ed1	pg	egov-hrms.EmploymentTest	egov-hrms.EmploymentTest	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "active"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "active": {"type": "boolean"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
53a5242c-6116-4eae-add9-59226b16950f	pg	egov-hrms.Specalization	egov-hrms.Specalization	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "active"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "active": {"type": "boolean"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
1523552a-512b-4e18-8a9f-d10c95642711	pg	INBOX.InboxQueryConfiguration	  	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["module", "index"], "x-unique": ["module", "index"], "properties": {"index": {"type": "string"}, "module": {"type": "string"}, "sortBy": {"type": "object", "required": ["path", "defaultOrder"], "properties": {"path": {"type": "string"}, "defaultOrder": {"type": "string"}}}, "sourceFilterPathList": {"type": "array", "items": {"type": "string"}}, "allowedSearchCriteria": {"type": "array", "items": {"type": "object", "required": ["name", "path", "isMandatory", "operator"], "properties": {"name": {"type": "string"}, "path": {"type": "string"}, "operator": {"type": "string"}, "isMandatory": {"type": "boolean"}, "isHashingRequired": {"type": "boolean"}}}}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
22c1101e-c277-44f1-8c2d-4164641b6635	pg	RAINMAKER-PGR.ServiceDefs	RAINMAKER-PGR.ServiceDefs	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["serviceCode", "name", "keywords", "department", "slaHours", "active"], "x-unique": ["serviceCode"], "properties": {"name": {"type": "string"}, "order": {"type": "number"}, "active": {"type": "boolean"}, "keywords": {"type": "string"}, "menuPath": {"type": "string"}, "slaHours": {"type": "number"}, "department": {"type": "string"}, "serviceCode": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
c5f06aac-cb7f-4964-9f10-d0a934f66456	pg	RAINMAKER-PGR.UIConstants	RAINMAKER-PGR.UIConstants	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["REOPENSLA"], "x-unique": ["REOPENSLA"], "properties": {"REOPENSLA": {"type": "number"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
d0163c8f-f303-4f7e-8c2b-b08b7090e968	pg	Workflow.AutoEscalation	Workflow.AutoEscalation	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["businessService", "module", "state", "action", "active", "stateSLA", "businessSLA", "topic"], "x-unique": ["state", "businessService"], "properties": {"state": {"type": "string"}, "topic": {"type": "string"}, "action": {"type": "string"}, "active": {"type": "string"}, "module": {"type": "string"}, "stateSLA": {"type": "number"}, "businessSLA": {"type": "number"}, "businessService": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
6e342785-460d-47ef-bd40-a2a1cfd21a80	pg	Workflow.AutoEscalationStatesToIgnore	Workflow.AutoEscalationStatesToIgnore	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["businessService", "module", "state"], "x-unique": ["businessService"], "properties": {"state": {"type": "array", "items": {"type": "string"}}, "module": {"type": "string"}, "businessService": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
316d40b8-adcd-4169-9ba4-b38e4e88c5c9	pg	Workflow.BusinessService	Workflow.BusinessService	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["tenantId", "uuid", "businessService", "getUri", "postUri", "states"], "x-unique": ["businessService"], "properties": {"uuid": {"type": "string"}, "getUri": {"type": "string"}, "states": {"type": "array", "items": {"type": "object", "required": ["businessServiceId", "state", "applicableNextStates", "applicableActions", "docUploadRequired", "UpdateAllowed", "isTerminateState", "isStartState", "uuid", "tenantId", "actions"], "properties": {"uuid": {"type": "string"}, "state": {"type": "string"}, "actions": {"type": "array", "items": {"type": "object", "required": ["stateId", "action", "nextStateId", "roles", "tenantId", "uuid"], "properties": {"uuid": {"type": "string"}, "roles": {"type": "string"}, "action": {"type": "string"}, "stateId": {"type": "string"}, "tenantId": {"type": "string"}, "nextStateId": {"type": "string"}}}}, "tenantId": {"type": "string"}, "isStartState": {"type": "string"}, "UpdateAllowed": {"type": "string"}, "isTerminateState": {"type": "string"}, "applicableActions": {"type": "string"}, "businessServiceId": {"type": "string"}, "docUploadRequired": {"type": "string"}, "applicableNextStates": {"type": "string"}}}}, "postUri": {"type": "string"}, "tenantId": {"type": "string"}, "businessService": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
a04cc6d7-c3cb-446a-a375-692acec18ed8	pg	Workflow.BusinessServiceConfig	Workflow.BusinessServiceConfig	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "isStateLevel"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "isStateLevel": {"type": "boolean"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1766039437780	1766039437780
theme-config-schema-001	pg	common-masters.ThemeConfig	UI theme colour tokens	{"type": "object", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["code", "name", "version", "colors"], "x-unique": ["code"], "properties": {"code": {"type": "string"}, "name": {"type": "string"}, "colors": {"type": "object"}, "version": {"type": "string"}}, "additionalProperties": true}	t	system-mdms-seed	system-mdms-seed	1770614666000	1770614666000
69453dca-fbd2-4eb9-a832-4de259739b4b	pg	CMS-BOUNDARY.HierarchySchema	Configuration to show boundary hierarchy levels in CMS UI	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["moduleName", "department", "hierarchy", "highestHierarchy", "lowestHierarchy"], "x-unique": ["moduleName", "department"], "properties": {"hierarchy": {"type": "string"}, "department": {"type": "string"}, "moduleName": {"type": "string"}, "lowestHierarchy": {"type": "string"}, "highestHierarchy": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system	system	1781073674409	1781073674409
ad6bdc36-6445-4608-9a06-1786eb300e91	pg	CRS-ADMIN-CONSOLE.adminSchema	CRS Admin Console Schema for boundary management	{"type": "object", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["title", "campaignType"], "x-unique": ["title"], "properties": {"title": {"type": "string", "maxLength": 200, "minLength": 1}, "properties": {"type": "object", "properties": {"numberProperties": {"type": "array"}, "stringProperties": {"type": "array"}}, "additionalProperties": false}, "campaignType": {"type": "string", "maxLength": 100, "minLength": 1}}, "x-ref-schema": [], "additionalProperties": false}	t	system	system	1781073674409	1781073674409
16496067-588a-4d1c-871b-2955cea9e8d8	pg.citya	CMS-BOUNDARY.HierarchySchema	Configuration to show boundary hierarchy levels in CMS UI	{"type": "object", "title": "Generated schema for Root", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["moduleName", "department", "hierarchy", "highestHierarchy", "lowestHierarchy"], "x-unique": ["moduleName", "department"], "properties": {"hierarchy": {"type": "string"}, "department": {"type": "string"}, "moduleName": {"type": "string"}, "lowestHierarchy": {"type": "string"}, "highestHierarchy": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system	system	1781074295688	1781074295688
f9ac4504-91dc-4e53-b8bf-dc25e4460687	pg.citya	CRS-ADMIN-CONSOLE.adminSchema	CRS Admin Console Schema for boundary management	{"type": "object", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["title", "campaignType"], "x-unique": ["title"], "properties": {"title": {"type": "string", "maxLength": 200, "minLength": 1}, "properties": {"type": "object", "properties": {"numberProperties": {"type": "array"}, "stringProperties": {"type": "array"}}, "additionalProperties": false}, "campaignType": {"type": "string", "maxLength": 100, "minLength": 1}}, "x-ref-schema": [], "additionalProperties": false}	t	system	system	1781074295688	1781074295688
dashboard-config-schema-002	pg	dss.DashboardConfig	Dashboard nav/route role gate (allowedRoles)	{"$schema": "http://json-schema.org/draft-07/schema#", "title": "DashboardConfig", "type": "object", "required": ["id", "allowedRoles"], "properties": {"id": {"type": "string", "description": "Config record key; the UI reads the \\"default\\" record (single-record master)"}, "allowedRoles": {"type": "array", "items": {"type": "string", "minLength": 1}, "minItems": 1, "description": "Role codes allowed to see the dashboard home card and open /employee/dashboard. Nav/route gate only — NOT a security boundary: the data plane is enforced server-side by the analytics catalog + scope RBAC. Absent record → the UI falls back to its built-in DASHBOARD_ROLES list."}}, "x-unique": ["id"]}	t	system-mdms-seed	system-mdms-seed	1770614666000	1770614666000
form-validations-schema-001	pg	common-masters.FormValidations	Form field validation patterns (one row per field type, e.g. email, name, postalCode)	{"$schema": "http://json-schema.org/draft-07/schema#", "title": "Form Validations", "type": "object", "required": ["fieldType", "regex"], "x-unique": ["fieldType"], "properties": {"fieldType": {"type": "string", "description": "Which user field this pattern validates, e.g. \\"email\\" or \\"postalCode\\". Frontends fall back to their built-in pattern when a fieldType row is absent. NOTE for postalCode: no row is seeded by default — the per-tenant pattern normally comes from host_vars core_postal_configs (globalConfigs CORE_POSTAL_CONFIGS); an authored postalCode row deliberately outranks it, in DIGIT Studio and the PGR create-complaint flows alike."}, "regex": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1770614666000	1770614666000
common-masters-mobilenumbervalidation-schema	pg	common-masters.MobileNumberValidation	Mobile Number Validation Configuration	{"$schema": "http://json-schema.org/draft-07/schema#", "title": "Mobile Number Validation", "type": "object", "required": ["countryCode", "mobileNumberRegex"], "x-unique": ["countryCode"], "properties": {"countryCode": {"type": "string"}, "mobileNumberRegex": {"type": "string"}, "default": {"type": "boolean", "default": false}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1770614667000	1770614667000
complaint-hierarchy-definition-schema	pg	RAINMAKER-PGR.ComplaintHierarchyDefinition	Declares the ORDERED, CONFIGURABLE levels of a complaint-type hierarchy for a tenant.	{"type": "object", "title": "Complaint Hierarchy Definition", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["hierarchyType", "levels"], "x-unique": ["hierarchyType"], "properties": {"hierarchyType": {"type": "string"}, "active": {"type": "boolean"}, "levels": {"type": "array", "minItems": 1, "items": {"type": "object", "required": ["levelCode", "order"], "properties": {"levelCode": {"type": "string"}, "order": {"type": "number"}, "parentLevel": {"type": ["string", "null"]}, "isFreeText": {"type": "boolean"}, "isLeafServiceCode": {"type": "boolean"}, "label": {"type": "string"}}, "additionalProperties": false}}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1785200000000	1785200000000
complaint-hierarchy-schema	pg	RAINMAKER-PGR.ComplaintHierarchy	Single adjacency-list master for the whole complaint-type tree: interior level nodes and leaf sub-types in one table.	{"type": "object", "title": "Complaint Hierarchy", "$schema": "http://json-schema.org/draft-07/schema#", "required": ["hierarchyType", "levelCode", "code", "name"], "x-unique": ["hierarchyType", "code"], "properties": {"hierarchyType": {"type": "string"}, "levelCode": {"type": "string"}, "code": {"type": "string"}, "parentCode": {"type": ["string", "null"]}, "name": {"type": "string"}, "order": {"type": "number"}, "active": {"type": "boolean"}, "path": {"type": "string"}, "department": {"type": "string"}, "departments": {"type": "array", "items": {"type": "string"}}, "slaHours": {"type": "number"}, "keywords": {"type": "string"}}, "x-ref-schema": [], "additionalProperties": false}	t	system-mdms-seed	system-mdms-seed	1785200000000	1785200000000
\.


--
-- Data for Name: eg_ms_role; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_ms_role (name, code, description, createddate, createdby, lastmodifiedby, lastmodifieddate, version) FROM stdin;
\.


--
-- Data for Name: eg_pgr_address_v2; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_pgr_address_v2 (tenantid, id, parentid, doorno, plotno, buildingname, street, landmark, city, pincode, locality, district, region, state, country, latitude, longitude, createdby, createdtime, lastmodifiedby, lastmodifiedtime, additionaldetails) FROM stdin;
pg.citest	d9a5d6a5-b455-492e-a5f4-b8251df2df15	9a36f8f0-747c-4d56-a0a1-5852a1395e9f	\N	\N	\N	\N	Test Landmark	City A		JLC477	City A	City A	\N	\N	\N	\N	79006ea0-100c-4332-8390-60edff9328c1	1778664552313	79006ea0-100c-4332-8390-60edff9328c1	1778664552834	null
pg.citest	ffc16bde-152f-4c00-8499-caf83f51b8a6	6a63f17f-7c15-4432-98ca-ea625840d56e	\N	\N	\N	\N	Test Landmark	City A		JLC477	City A	City A	\N	\N	\N	\N	79006ea0-100c-4332-8390-60edff9328c1	1778664524734	79006ea0-100c-4332-8390-60edff9328c1	1778664526028	null
\.


--
-- Data for Name: eg_pgr_service_v2; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_pgr_service_v2 (id, tenantid, servicecode, servicerequestid, description, accountid, additionaldetails, applicationstatus, rating, source, createdby, createdtime, lastmodifiedby, lastmodifiedtime, active) FROM stdin;
6a63f17f-7c15-4432-98ca-ea625840d56e	pg.citest	IllegalCuttingOfTrees	PG-PGR-2026-05-13-000185	Illegal Cutting of trees	f1a94c66-a4b5-46da-9492-07b7db54c69f	{"department": "DEPT_5"}	CLOSEDAFTERRESOLUTION	\N	web	79006ea0-100c-4332-8390-60edff9328c1	1778664524734	79006ea0-100c-4332-8390-60edff9328c1	1778664526028	t
9a36f8f0-747c-4d56-a0a1-5852a1395e9f	pg.citest	IllegalCuttingOfTrees	PG-PGR-2026-05-13-000186	Illegal Cutting of trees	f1a94c66-a4b5-46da-9492-07b7db54c69f	{"department": "DEPT_5"}	CLOSEDAFTERRESOLUTION	\N	web	79006ea0-100c-4332-8390-60edff9328c1	1778664552313	79006ea0-100c-4332-8390-60edff9328c1	1778664552834	t
\.


--
-- Data for Name: eg_role; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_role (name, code, description, createddate, createdby, lastmodifiedby, lastmodifieddate, version, tenantid, id) FROM stdin;
\.


--
-- Data for Name: eg_roleaction; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_roleaction (rolecode, actionid, tenantid) FROM stdin;
\.


--
-- Data for Name: eg_token; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_token (id, tenantid, tokennumber, tokenidentity, validated, ttlsecs, createddate, lastmodifieddate, createdby, lastmodifiedby, version, createddatenew) FROM stdin;
\.


--
-- Data for Name: eg_url_shortener; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_url_shortener (id, validform, validto, url) FROM stdin;
\.


--
-- Data for Name: eg_user; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_user (title, salutation, dob, locale, username, password, pwdexpirydate, mobilenumber, altcontactnumber, emailid, createddate, lastmodifieddate, createdby, lastmodifiedby, active, name, gender, pan, aadhaarnumber, type, version, guardian, guardianrelation, signature, accountlocked, bloodgroup, photo, identificationmark, tenantid, id, uuid, accountlockeddate, alternatemobilenumber, countrycode) FROM stdin;
\N	\N	\N	\N	489366|G0/w3vPTuvMVAWkFYIgjXgs97GHSfarXKMKbCd4=	$2a$10$lVGJ27y7QRJ0f46z4d6uDeTml6nt9cMaoc7XpUZ.ZhrEranpNPQ8W	2026-05-10 05:25:11.553	489366|azidopikwoZzbcm1yBn29NfRpKFP6YulQdY=	\N	\N	2026-02-09 05:25:11.563	2026-02-09 05:25:11.563	\N	\N	t	489366|G2/Q/tPzmtNqGVMjQL+zclwglO6ImyjeulzdbteyJ/LZvBbUx2SFWEKY	2	\N	\N	SYSTEM	0	\N		\N	f		\N	\N	pg	3	f80147a7-9711-4a56-9bd3-da4733a59df4	\N	\N	\N
\N	\N	\N	\N	489366|azidopGtwoZzbe5t1+8lCqiXt891ZJ2s2P4=	$2a$10$bpX.KI6M/WMsvI.1GdX3HeuRKI9F6Pc3gsfGyMtmuvJlnILvNkjfS	2026-08-11 09:00:05.401	489366|azidopGtwoZzbe5t1+8lCqiXt891ZJ2s2P4=	\N	\N	2026-05-13 09:00:05.411	2026-05-13 09:00:05.411	1	1	t	489366|FmTK9cju7EANPhIaVBscUvwIL/2nOQ==	0	\N	\N	CITIZEN	0	\N		\N	f		\N	\N	pg	20	f1a94c66-a4b5-46da-9492-07b7db54c69f	\N	\N	\N
\N	\N	\N	\N	489366|E0Xp0u9xguIYIEtxo8vkVboLM/Ku	$2a$10$opgEKfQzL.6wLhDP2B8lRecOXULN4/jbP98BZoqzE1CHncrNTCh8W	2026-08-11 09:13:47.739	489366|azidopikwoZzbcm1yBn29NfRpKFP6YulQdY=	\N	489366|M2XJ8s/dn9YtPU5uXaKnPPlR7p7fWgomRH6FKcUg4g==	2026-05-13 09:13:47.751	2026-05-13 09:13:47.751	\N	\N	t	489366|AXjX78Tw2/4uOVMuW6O0ZU8ikv+3vqdnrPqDLNOqg3BOKBcr	2	\N	\N	EMPLOYEE	0	\N		\N	f		\N	\N	pg	29	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	\N	\N	\N
\N	\N	\N	\N	489366|FVPrc8+W0tEEmddkOwLAZ8SpFw==	$2a$10$chtt2RDmJMpYdUM/e/s4pO9bDWiRnhFb2yVKm0hXTGtia76.iFL62	2026-08-11 09:13:47.87	489366|azmco5mlw4dybCPvBaRbi88jU/qEZG8nzpQ=	\N	489366|NXPL28X0nNY+elUyVWeN//gkQZ3g6/hN99nZqhA=	2026-05-13 09:13:47.879	2026-05-13 09:13:47.879	\N	\N	t	489366|FXPN/tf8ldwvdHUmVLmjclxXMWHIYelOp2vLJmx3Op4M	2	\N	\N	EMPLOYEE	0	\N		\N	f		\N	\N	pg	30	198368f3-d3ac-4e71-969d-6cb63417b312	\N	\N	\N
\N	\N	\N	\N	489366|E0Xp0u9xguIYIEtxo8vkVboLM/Ku	$2a$10$4erG5jF0AYVzhraRcIFD8.ue8yQkzztjpXosWYmxthdPRbURfoPLG	2026-08-11 09:13:47.986	489366|azidopikwoZzbcm1yBn29NfRpKFP6YulQdY=	\N	489366|M2XJ8s/dn9YtPU5uXaKnPPlR7p7fWgomRH6FKcUg4g==	2026-05-13 09:13:47.995	2026-05-13 09:13:47.995	\N	\N	t	489366|AXjX78Tw2/4uOVMuW6O0ZU8ikv+3vqdnrPqDLNOqg3BOKBcr	2	\N	\N	EMPLOYEE	0	\N		\N	f		\N	\N	pg.citya	31	b2632798-952e-42cd-b896-0152c2847479	\N	\N	\N
\N	\N	2000-01-01 00:00:00	\N	489366|EUiJ2uXQsvHEbcRjDh/UcPOGAzQmkeoS	$2a$10$NQAxOXiDx8KjjopRWWYhkOlz1NL.UcN8Z0rtqxsATpWtjwcIKF.hW	2026-08-11 09:27:27	489366|azidopity496ZQFBGUPKUnXL0+x/jdwIkKM=	\N	\N	2026-05-13 09:27:27.572	2026-05-13 09:27:28.041	29	29	t	489366|EUiE2sXwktGCnQMzpcVqpMu1YuSA0hyD	0	\N	\N	EMPLOYEE	0	\N		\N	f		\N	\N	pg.citest	35	79006ea0-100c-4332-8390-60edff9328c1	0	\N	\N
\N	\N	\N	\N	489366|FVPrc8+W0tEEmddkOwLAZ8SpFw==	$2a$10$Xcm1/lgF.QkGzTRU0ojEd.R8fqgyrM65/4Cb3m4MTHuwOqBieQoFO	2026-08-11 09:13:48.129	489366|azmco5mlw4dybCPvBaRbi88jU/qEZG8nzpQ=	\N	489366|NXPL28X0nNY+elUyVWeN//gkQZ3g6/hN99nZqhA=	2026-05-13 09:13:48.138	2026-05-13 09:13:48.138	\N	\N	t	489366|FXPN/tf8ldwvdHUmVLmjclxXMWHIYelOp2vLJmx3Op4M	2	\N	\N	EMPLOYEE	0	\N		\N	f		\N	\N	pg.citya	32	4990dce4-66a4-4752-85a3-7999e81245e5	\N	\N	\N
\N	\N	\N	\N	489366|E0Xp0u9xguIYIEtxo8vkVboLM/Ku	$2a$10$v0Zr0y8aZAnKyhV0lEkpdu4gpK1Ahv8F2ekdJ.wGBtE5N5DTvLbwq	2026-08-11 09:13:48.248	489366|azidopikwoZzbcm1yBn29NfRpKFP6YulQdY=	\N	489366|M2XJ8s/dn9YtPU5uXaKnPPlR7p7fWgomRH6FKcUg4g==	2026-05-13 09:13:48.258	2026-05-13 09:13:48.258	\N	\N	t	489366|AXjX78Tw2/4uOVMuW6O0ZU8ikv+3vqdnrPqDLNOqg3BOKBcr	2	\N	\N	EMPLOYEE	0	\N		\N	f		\N	\N	pg.cityb	33	717d427c-e470-4ffd-86ab-683d6c97e0e2	\N	\N	\N
\N	\N	\N	\N	489366|FVPrc8+W0tEEmddkOwLAZ8SpFw==	$2a$10$gberk1ZRaqm7gb6/mGZcqOyHZ78h.PY2X52MSsSxhbvNCd2Mya3xq	2026-08-11 09:13:48.376	489366|azmco5mlw4dybCPvBaRbi88jU/qEZG8nzpQ=	\N	489366|NXPL28X0nNY+elUyVWeN//gkQZ3g6/hN99nZqhA=	2026-05-13 09:13:48.384	2026-05-13 09:13:48.384	\N	\N	t	489366|FXPN/tf8ldwvdHUmVLmjclxXMWHIYelOp2vLJmx3Op4M	2	\N	\N	EMPLOYEE	0	\N		\N	f		\N	\N	pg.cityb	34	2fca228c-6cc1-4f85-a82f-96d77d4cb61c	\N	\N	\N
\.


--
-- Data for Name: eg_user_address; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_user_address (id, version, createddate, lastmodifieddate, createdby, lastmodifiedby, type, address, city, pincode, userid, tenantid) FROM stdin;
5	0	2026-02-09 05:25:11.574	2026-02-09 05:25:11.574	3	\N	CORRESPONDENCE	\N	\N	\N	3	pg
6	0	2026-02-09 05:25:11.577	2026-02-09 05:25:11.577	3	\N	PERMANENT	\N	\N	\N	3	pg
39	0	2026-05-13 09:00:05.417	2026-05-13 09:00:05.417	20	\N	CORRESPONDENCE	\N	\N	\N	20	pg
40	0	2026-05-13 09:00:05.42	2026-05-13 09:00:05.42	20	\N	PERMANENT	\N	\N	\N	20	pg
57	0	2026-05-13 09:13:47.76	2026-05-13 09:13:47.76	29	\N	CORRESPONDENCE	\N	\N	\N	29	pg
58	0	2026-05-13 09:13:47.764	2026-05-13 09:13:47.764	29	\N	PERMANENT	\N	\N	\N	29	pg
59	0	2026-05-13 09:13:47.885	2026-05-13 09:13:47.885	30	\N	CORRESPONDENCE	\N	\N	\N	30	pg
60	0	2026-05-13 09:13:47.887	2026-05-13 09:13:47.887	30	\N	PERMANENT	\N	\N	\N	30	pg
61	0	2026-05-13 09:13:48.004	2026-05-13 09:13:48.004	31	\N	CORRESPONDENCE	\N	\N	\N	31	pg.citya
62	0	2026-05-13 09:13:48.007	2026-05-13 09:13:48.007	31	\N	PERMANENT	\N	\N	\N	31	pg.citya
63	0	2026-05-13 09:13:48.144	2026-05-13 09:13:48.144	32	\N	CORRESPONDENCE	\N	\N	\N	32	pg.citya
64	0	2026-05-13 09:13:48.146	2026-05-13 09:13:48.146	32	\N	PERMANENT	\N	\N	\N	32	pg.citya
65	0	2026-05-13 09:13:48.267	2026-05-13 09:13:48.267	33	\N	CORRESPONDENCE	\N	\N	\N	33	pg.cityb
66	0	2026-05-13 09:13:48.27	2026-05-13 09:13:48.27	33	\N	PERMANENT	\N	\N	\N	33	pg.cityb
67	0	2026-05-13 09:13:48.391	2026-05-13 09:13:48.391	34	\N	CORRESPONDENCE	\N	\N	\N	34	pg.cityb
68	0	2026-05-13 09:13:48.393	2026-05-13 09:13:48.393	34	\N	PERMANENT	\N	\N	\N	34	pg.cityb
\.


--
-- Data for Name: eg_user_audit_table; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_user_audit_table (id, title, salutation, dob, locale, username, password, pwdexpirydate, mobilenumber, altcontactnumber, emailid, active, name, gender, pan, aadhaarnumber, type, version, guardian, guardianrelation, signature, accountlocked, bloodgroup, photo, identificationmark, tenantid, uuid, auditcreatedby, auditcreatedtime) FROM stdin;
35	\N	\N	2000-01-01 00:00:00	\N	489366|EUiJ2uXQsvHEbcRjDh/UcPOGAzQmkeoS	$2a$10$fp7f7HBQrPe/E5Ku.67wa.7gehydCqRwr2qNbhBOlZ663RakWLeXu	2026-08-11 09:27:27.564	489366|azidopity496ZQFBGUPKUnXL0+x/jdwIkKM=	\N	\N	t	489366|EUiE2sXwktGCnQMzpcVqpMu1YuSA0hyD	0	\N	\N	EMPLOYEE	0	\N		\N	f			\N	pg.citest	79006ea0-100c-4332-8390-60edff9328c1	8155a8e1-86bb-4e5f-9450-f2f7ab2004de	1778664448041
\.


--
-- Data for Name: eg_user_login_failed_attempts; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_user_login_failed_attempts (user_uuid, ip, attempt_date, active) FROM stdin;
2c28d95f-136f-46b6-892f-49e5245ebc59	172.21.0.32	1778655658015	f
2c28d95f-136f-46b6-892f-49e5245ebc59	172.21.0.32	1778659398315	f
2c28d95f-136f-46b6-892f-49e5245ebc59	172.21.0.32	1778662081169	f
2c28d95f-136f-46b6-892f-49e5245ebc59	172.21.0.32	1778662349017	f
2c28d95f-136f-46b6-892f-49e5245ebc59	172.21.0.32	1778662705727	f
\.


--
-- Data for Name: eg_userrole; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_userrole (roleid, roleidtenantid, userid, tenantid, lastmodifieddate) FROM stdin;
\.


--
-- Data for Name: eg_userrole_v1; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_userrole_v1 (role_code, role_tenantid, user_id, user_tenantid, lastmodifieddate) FROM stdin;
INTERNAL_MICROSERVICE_ROLE	pg	3	pg	2026-02-09 05:25:11.571
CITIZEN	pg	20	pg	2026-05-13 09:00:05.415
PGR_VIEWER	pg	29	pg	2026-05-13 09:13:47.758
AUTO_ESCALATE	pg	29	pg	2026-05-13 09:13:47.758
EMPLOYEE	pg	29	pg	2026-05-13 09:13:47.758
GRO	pg	29	pg	2026-05-13 09:13:47.758
SUPERVISOR	pg	29	pg	2026-05-13 09:13:47.758
PGR_LME	pg	29	pg	2026-05-13 09:13:47.758
CSR	pg	29	pg	2026-05-13 09:13:47.758
SUPERUSER	pg	29	pg	2026-05-13 09:13:47.758
CITIZEN	pg	29	pg	2026-05-13 09:13:47.758
DGRO	pg	29	pg	2026-05-13 09:13:47.758
EMPLOYEE	pg	30	pg	2026-05-13 09:13:47.883
GRO	pg	30	pg	2026-05-13 09:13:47.883
DGRO	pg	30	pg	2026-05-13 09:13:47.883
EMPLOYEE	pg.citya	31	pg.citya	2026-05-13 09:13:48.001
DGRO	pg.citya	31	pg.citya	2026-05-13 09:13:48.001
PGR_VIEWER	pg.citya	31	pg.citya	2026-05-13 09:13:48.001
AUTO_ESCALATE	pg.citya	31	pg.citya	2026-05-13 09:13:48.001
SUPERVISOR	pg.citya	31	pg.citya	2026-05-13 09:13:48.001
PGR_LME	pg.citya	31	pg.citya	2026-05-13 09:13:48.001
CSR	pg.citya	31	pg.citya	2026-05-13 09:13:48.001
GRO	pg.citya	31	pg.citya	2026-05-13 09:13:48.001
SUPERUSER	pg.citya	31	pg.citya	2026-05-13 09:13:48.001
CITIZEN	pg.citya	31	pg.citya	2026-05-13 09:13:48.001
EMPLOYEE	pg.citya	32	pg.citya	2026-05-13 09:13:48.142
DGRO	pg.citya	32	pg.citya	2026-05-13 09:13:48.142
GRO	pg.citya	32	pg.citya	2026-05-13 09:13:48.142
PGR_VIEWER	pg.cityb	33	pg.cityb	2026-05-13 09:13:48.264
EMPLOYEE	pg.cityb	33	pg.cityb	2026-05-13 09:13:48.264
DGRO	pg.cityb	33	pg.cityb	2026-05-13 09:13:48.264
AUTO_ESCALATE	pg.cityb	33	pg.cityb	2026-05-13 09:13:48.264
SUPERVISOR	pg.cityb	33	pg.cityb	2026-05-13 09:13:48.264
CSR	pg.cityb	33	pg.cityb	2026-05-13 09:13:48.264
PGR_LME	pg.cityb	33	pg.cityb	2026-05-13 09:13:48.264
GRO	pg.cityb	33	pg.cityb	2026-05-13 09:13:48.264
SUPERUSER	pg.cityb	33	pg.cityb	2026-05-13 09:13:48.264
CITIZEN	pg.cityb	33	pg.cityb	2026-05-13 09:13:48.264
EMPLOYEE	pg.cityb	34	pg.cityb	2026-05-13 09:13:48.389
DGRO	pg.cityb	34	pg.cityb	2026-05-13 09:13:48.389
GRO	pg.cityb	34	pg.cityb	2026-05-13 09:13:48.389
PGR_VIEWER	pg	35	pg.citest	2026-05-13 09:27:27.577
EMPLOYEE	pg	35	pg.citest	2026-05-13 09:27:27.577
GRO	pg	35	pg.citest	2026-05-13 09:27:27.577
PGR_LME	pg	35	pg.citest	2026-05-13 09:27:27.577
CSR	pg	35	pg.citest	2026-05-13 09:27:27.577
CFC	pg	35	pg.citest	2026-05-13 09:27:27.577
SUPERUSER	pg	35	pg.citest	2026-05-13 09:27:27.577
DGRO	pg	35	pg.citest	2026-05-13 09:27:27.577
\.


--
-- Data for Name: eg_wf_action_v2; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_wf_action_v2 (uuid, tenantid, currentstate, action, nextstate, roles, createdby, createdtime, lastmodifiedby, lastmodifiedtime, active) FROM stdin;
ef191941-e2cb-4cc6-bd77-a13ef448904c	pg	eaf4ebb3-9a8e-4671-a82e-04c2fe73ac83	APPLY	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	CITIZEN,CSR	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
7e40dec6-56b9-4698-8a2a-952385dddf47	pg	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	ASSIGNEDBYAUTOESCALATION	9314d274-34ef-46d9-89e1-a337af700e94	AUTO_ESCALATE	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
5faa2d7d-8bcc-430b-8412-2054aebc13eb	pg	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	COMMENT	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	CITIZEN	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
4857d56d-1acf-43a9-af4f-062415d13f10	pg	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	ASSIGN	9314d274-34ef-46d9-89e1-a337af700e94	GRO,PGR_VIEWER	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
e57c2309-ea1c-49c3-b64c-bf99942d8641	pg	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	REJECT	fd16c395-bcaa-4f9c-a452-33e4a3d5acd0	GRO,PGR_VIEWER	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
159dca57-4178-4a65-9046-bcd4bef44a0b	pg	1d486301-4c34-4b19-bf40-da0ebf546bef	COMMENT	1d486301-4c34-4b19-bf40-da0ebf546bef	CITIZEN	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
41668123-c495-4049-b493-25df18307889	pg	1d486301-4c34-4b19-bf40-da0ebf546bef	REJECT	fd16c395-bcaa-4f9c-a452-33e4a3d5acd0	GRO,PGR_VIEWER	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
b249bdef-0265-46c5-b80f-b29c3c95c78d	pg	1d486301-4c34-4b19-bf40-da0ebf546bef	ASSIGN	9314d274-34ef-46d9-89e1-a337af700e94	GRO,PGR_VIEWER	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
9940896a-7b09-4659-8fe4-bd68fd2c5259	pg	9314d274-34ef-46d9-89e1-a337af700e94	REASSIGN	1d486301-4c34-4b19-bf40-da0ebf546bef	PGR_LME,PGR_VIEWER	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
f0c149fe-0de0-40b5-940c-4b0eeb7261fb	pg	9314d274-34ef-46d9-89e1-a337af700e94	COMMENT	9314d274-34ef-46d9-89e1-a337af700e94	CITIZEN	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
5c80da5c-6fde-4656-ab2a-af045bd30832	pg	9314d274-34ef-46d9-89e1-a337af700e94	RESOLVE	f4209bfa-9abe-4da9-b80f-3f43fced607c	PGR_LME,PGR_VIEWER	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
44f0bb87-f682-4392-b86f-0ad16f6622d7	pg	9314d274-34ef-46d9-89e1-a337af700e94	FORWARD	04752227-e267-43e3-bfd8-6e48bdbfd97a	AUTO_ESCALATE	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
882aa517-b5f2-4fb6-bfd2-b079a05c1eb2	pg	fd16c395-bcaa-4f9c-a452-33e4a3d5acd0	COMMENT	fd16c395-bcaa-4f9c-a452-33e4a3d5acd0	CITIZEN	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
d05728de-3da4-4887-ac13-db9fdcf053e4	pg	fd16c395-bcaa-4f9c-a452-33e4a3d5acd0	REOPEN	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	CFC,CITIZEN,CSR,PGR_VIEWER	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
7986cc6b-c15d-4d8c-9991-f6296a6338c9	pg	fd16c395-bcaa-4f9c-a452-33e4a3d5acd0	RATE	3211859d-a96f-49e7-ab8b-6a1f271fe456	CFC,CITIZEN	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
2badb34c-cb6d-489f-8abc-c606c9cd2c07	pg	f4209bfa-9abe-4da9-b80f-3f43fced607c	RATE	4e216e7b-d9cd-4328-ac8d-116c6e30fa3c	CFC,CITIZEN	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
70347fa2-f092-46cb-830c-698eb505d0b4	pg	f4209bfa-9abe-4da9-b80f-3f43fced607c	REOPEN	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	CFC,CITIZEN,CSR,PGR_VIEWER	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
016ba342-ae9c-480b-9364-e2618cb258b1	pg	f4209bfa-9abe-4da9-b80f-3f43fced607c	COMMENT	f4209bfa-9abe-4da9-b80f-3f43fced607c	CITIZEN	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
761ca2aa-dbc6-46cf-b257-3d8c2198e2ea	pg	09c5af9a-052f-4923-ae55-698b992cf7ec	RESOLVEBYSUPERVISOR	e80e3dd6-8336-4586-b84a-c191dcd80c98	SUPERVISOR	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	t
\.


--
-- Data for Name: eg_wf_assignee_v2; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_wf_assignee_v2 (processinstanceid, tenantid, assignee, createdby, lastmodifiedby, createdtime, lastmodifiedtime) FROM stdin;
3b6c9771-ca35-41e3-8a06-27fa0baa18ef	pg.citest	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525350	1778664525350
790ab298-78a5-4e49-aaa9-9b26ec1ce694	pg.citest	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525540	1778664525540
cc6bd1d2-cbc2-40b3-9ea2-c04c9eaf67b2	pg.citest	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525716	1778664525716
e0a56869-1433-4d06-b8e7-04e132ea7279	pg.citest	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525907	1778664525907
2adda6be-758d-4bdf-aaec-fa5cede93ebe	pg.citest	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664552529	1778664552529
8a840e0d-2623-456d-803b-c257500594ce	pg.citest	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664552714	1778664552714
\.


--
-- Data for Name: eg_wf_businessservice_v2; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_wf_businessservice_v2 (businessservice, business, tenantid, uuid, geturi, posturi, createdby, createdtime, lastmodifiedby, lastmodifiedtime, businessservicesla) FROM stdin;
PGR	pgr-services	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	\N	\N	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	432000000
\.


--
-- Data for Name: eg_wf_document_v2; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_wf_document_v2 (id, tenantid, documenttype, documentuid, filestoreid, processinstanceid, active, createdby, lastmodifiedby, createdtime, lastmodifiedtime) FROM stdin;
d3aeb026-1af0-4584-a0f6-0d31838843bb	pg.citest	PHOTO			3b6c9771-ca35-41e3-8a06-27fa0baa18ef	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525350	1778664525350
790713e9-0663-4eeb-a31a-6c8ae14cbd83	pg.citest	PHOTO			790ab298-78a5-4e49-aaa9-9b26ec1ce694	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525540	1778664525540
934efd90-02aa-4462-9e84-5133eeab83b2	pg.citest	PHOTO			cc6bd1d2-cbc2-40b3-9ea2-c04c9eaf67b2	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525716	1778664525716
7798edef-1b4a-4bdb-8e3c-7f345e9e3309	pg.citest	PHOTO			e0a56869-1433-4d06-b8e7-04e132ea7279	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525907	1778664525907
dad7198a-d57a-4bd5-b832-638633b20b77	pg.citest	PHOTO			cb276065-655b-442a-a203-3d9731470804	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664526063	1778664526063
5f1b09b0-f331-43a6-984d-244bdd9c37ec	pg.citest	PHOTO			2adda6be-758d-4bdf-aaec-fa5cede93ebe	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664552529	1778664552529
e6cee572-a7a4-414d-abe3-888ee8679211	pg.citest	PHOTO			8a840e0d-2623-456d-803b-c257500594ce	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664552714	1778664552714
957cb1cf-4ee8-49b8-be7d-8059bd34353f	pg.citest	PHOTO			0291b94b-30a8-4ff4-a5c4-4cd8a299d49a	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664552865	1778664552865
\.


--
-- Data for Name: eg_wf_processinstance_v2; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_wf_processinstance_v2 (id, tenantid, businessservice, businessid, action, status, comment, assigner, assignee, statesla, previousstatus, createdby, lastmodifiedby, createdtime, lastmodifiedtime, modulename, businessservicesla, rating, escalated) FROM stdin;
4ff978f1-e042-4d82-b8aa-cc2311855127	pg.citya	PGR	PG-PGR-2026-05-13-000167	APPLY	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	\N	b2632798-952e-42cd-b896-0152c2847479	\N	\N	\N	b2632798-952e-42cd-b896-0152c2847479	b2632798-952e-42cd-b896-0152c2847479	1778663668117	1778663668117	pgr-services	432000000	\N	f
57946b29-9b60-48e5-a034-64734a341428	pg.citya	PGR	PG-PGR-2026-05-13-000180	APPLY	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	\N	b2632798-952e-42cd-b896-0152c2847479	\N	\N	\N	b2632798-952e-42cd-b896-0152c2847479	b2632798-952e-42cd-b896-0152c2847479	1778664367151	1778664367151	pgr-services	432000000	\N	f
5d38e62b-e6bc-4f0d-9189-60749f9032c3	pg.citest	PGR	PG-PGR-2026-05-13-000182	APPLY	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	\N	79006ea0-100c-4332-8390-60edff9328c1	\N	\N	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664460570	1778664460570	pgr-services	432000000	\N	f
975f5c48-8dd5-4e96-a4bf-f9b2cd22c43f	pg.citest	PGR	PG-PGR-2026-05-13-000185	APPLY	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	\N	79006ea0-100c-4332-8390-60edff9328c1	\N	\N	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664524769	1778664524769	pgr-services	432000000	\N	f
3b6c9771-ca35-41e3-8a06-27fa0baa18ef	pg.citest	PGR	PG-PGR-2026-05-13-000185	REJECT	fd16c395-bcaa-4f9c-a452-33e4a3d5acd0	Test Comment	79006ea0-100c-4332-8390-60edff9328c1	\N	300000	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525350	1778664525350	pgr-services	431999419	\N	f
790ab298-78a5-4e49-aaa9-9b26ec1ce694	pg.citest	PGR	PG-PGR-2026-05-13-000185	REOPEN	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	Test reopen comments	79006ea0-100c-4332-8390-60edff9328c1	\N	\N	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525540	1778664525540	pgr-services	431999229	\N	f
cc6bd1d2-cbc2-40b3-9ea2-c04c9eaf67b2	pg.citest	PGR	PG-PGR-2026-05-13-000185	ASSIGN	9314d274-34ef-46d9-89e1-a337af700e94	Test Comment	79006ea0-100c-4332-8390-60edff9328c1	\N	300000	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525716	1778664525716	pgr-services	431999053	\N	f
e0a56869-1433-4d06-b8e7-04e132ea7279	pg.citest	PGR	PG-PGR-2026-05-13-000185	RESOLVE	f4209bfa-9abe-4da9-b80f-3f43fced607c	Test Comment	79006ea0-100c-4332-8390-60edff9328c1	\N	300000	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664525907	1778664525907	pgr-services	431998862	\N	f
cb276065-655b-442a-a203-3d9731470804	pg.citest	PGR	PG-PGR-2026-05-13-000185	RATE	4e216e7b-d9cd-4328-ac8d-116c6e30fa3c	Test citizen comment for closure	79006ea0-100c-4332-8390-60edff9328c1	\N	\N	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664526063	1778664526063	pgr-services	431998706	\N	f
512c221a-1234-4788-aa38-9a6dc63e2a2b	pg.citest	PGR	PG-PGR-2026-05-13-000186	APPLY	c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	\N	79006ea0-100c-4332-8390-60edff9328c1	\N	\N	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664552347	1778664552347	pgr-services	432000000	\N	f
2adda6be-758d-4bdf-aaec-fa5cede93ebe	pg.citest	PGR	PG-PGR-2026-05-13-000186	ASSIGN	9314d274-34ef-46d9-89e1-a337af700e94	Test Comment	79006ea0-100c-4332-8390-60edff9328c1	\N	300000	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664552529	1778664552529	pgr-services	431999818	\N	f
8a840e0d-2623-456d-803b-c257500594ce	pg.citest	PGR	PG-PGR-2026-05-13-000186	RESOLVE	f4209bfa-9abe-4da9-b80f-3f43fced607c	Test Comment	79006ea0-100c-4332-8390-60edff9328c1	\N	300000	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664552714	1778664552714	pgr-services	431999633	\N	f
0291b94b-30a8-4ff4-a5c4-4cd8a299d49a	pg.citest	PGR	PG-PGR-2026-05-13-000186	RATE	4e216e7b-d9cd-4328-ac8d-116c6e30fa3c	Test citizen comment for closure	79006ea0-100c-4332-8390-60edff9328c1	\N	\N	\N	79006ea0-100c-4332-8390-60edff9328c1	79006ea0-100c-4332-8390-60edff9328c1	1778664552865	1778664552865	pgr-services	431999482	\N	f
\.


--
-- Data for Name: eg_wf_state_v2; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.eg_wf_state_v2 (uuid, tenantid, businessserviceid, state, applicationstatus, sla, docuploadrequired, isstartstate, isterminatestate, createdby, createdtime, lastmodifiedby, lastmodifiedtime, seq, isstateupdatable) FROM stdin;
eaf4ebb3-9a8e-4671-a82e-04c2fe73ac83	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	\N	\N	\N	f	t	f	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	23	t
c72ac8ac-4ed8-454f-9f1b-8e9baa85c7b3	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	PENDINGFORASSIGNMENT	PENDINGFORASSIGNMENT	\N	f	f	f	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	24	f
1d486301-4c34-4b19-bf40-da0ebf546bef	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	PENDINGFORREASSIGNMENT	PENDINGFORREASSIGNMENT	300000	f	f	f	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	25	f
9314d274-34ef-46d9-89e1-a337af700e94	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	PENDINGATLME	PENDINGATLME	300000	f	f	f	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	26	f
fd16c395-bcaa-4f9c-a452-33e4a3d5acd0	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	REJECTED	REJECTED	300000	f	f	t	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	27	f
f4209bfa-9abe-4da9-b80f-3f43fced607c	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	RESOLVED	RESOLVED	300000	f	f	t	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	28	f
3211859d-a96f-49e7-ab8b-6a1f271fe456	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	CLOSEDAFTERREJECTION	CLOSEDAFTERREJECTION	\N	f	f	t	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	29	f
4e216e7b-d9cd-4328-ac8d-116c6e30fa3c	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	CLOSEDAFTERRESOLUTION	CLOSEDAFTERRESOLUTION	\N	f	f	t	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	30	f
09c5af9a-052f-4923-ae55-698b992cf7ec	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	PENDINGATSUPERVISOR	PENDINGATSUPERVISOR	300000	f	f	f	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	31	f
074a5ea3-c571-476e-9683-19fdfff04b56	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	RESOLVEDBYSUPERVISOR	RESOLVEDBYSUPERVISOR	\N	f	f	t	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	32	f
38f17e64-c70b-42cb-8b20-358a829782c8	pg	7b38c57c-ce17-43c5-91a8-1ef737a693b6	CANCELLED	CANCELLED	\N	f	f	t	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	dc71bb18-4bb9-4f26-8746-56f6c68cd48a	1778663385019	33	f
\.


--
-- Data for Name: egov-url-shortening_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public."egov-url-shortening_schema" (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-07-10 10:44:39.758823	0	t
2	20190624185601	eg  ddl	SQL	V20190624185601__eg__ddl.sql	1797967045	egov	2026-07-10 10:44:39.856418	20	t
\.


--
-- Data for Name: egov_enc_service_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.egov_enc_service_schema (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-07-10 10:44:19.355979	0	t
2	20180607185601	eg enc	SQL	V20180607185601__eg_enc.sql	-710801463	egov	2026-07-10 10:44:19.450171	47	t
\.


--
-- Data for Name: egov_filestore_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.egov_filestore_schema (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-07-10 10:44:26.462534	0	t
2	20170420135841	egfilestore tenant ddl	SQL	V20170420135841__egfilestore_tenant_ddl.sql	882190174	egov	2026-07-10 10:44:26.565706	24	t
3	20180319162241	eg filestore alter ddl	SQL	V20180319162241__eg_filestore_alter_ddl.sql	994763967	egov	2026-07-10 10:44:26.690135	2	t
4	20181126143300	egfilestore filename dml	SQL	V20181126143300__egfilestore_filename_dml.sql	-798099361	egov	2026-07-10 10:44:26.704902	4	t
5	20200712143311	egfilestore audit details	SQL	V20200712143311__egfilestore_audit_details.sql	749086971	egov	2026-07-10 10:44:26.723058	4	t
\.


--
-- Data for Name: egov_hrms_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.egov_hrms_schema (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-07-10 10:44:49.131566	0	t
2	20190122152236	create hrms employee table ddl	SQL	V20190122152236__create_hrms_employee_table_ddl.sql	-1554243231	egov	2026-07-10 10:44:49.226602	90	t
3	20190130120650	alter assgnmt add currentassgmt ddl	SQL	V20190130120650__alter_assgnmt_add_currentassgmt_ddl.sql	-1748589821	egov	2026-07-10 10:44:49.412741	1	t
4	20190204154948	create position sequence ddl	SQL	V20190204154948__create_position_sequence_ddl.sql	1748624915	egov	2026-07-10 10:44:49.424562	2	t
5	20190204163735	alter deactivation rename remarks ddl	SQL	V20190204163735__alter_deactivation_rename_remarks_ddl.sql	447036466	egov	2026-07-10 10:44:49.436661	1	t
6	20190204172710	secondary indexes ddl	SQL	V20190204172710__secondary_indexes_ddl.sql	1918652612	egov	2026-07-10 10:44:49.446344	20	t
7	20190215120811	alter uk constraint dml	SQL	V20190215120811__alter_uk_constraint_dml.sql	-83927431	egov	2026-07-10 10:44:49.475572	5	t
8	20190219163221	alter remove phone name clm dml	SQL	V20190219163221__alter_remove_phone_name_clm_dml.sql	541612396	egov	2026-07-10 10:44:49.489169	2	t
9	20190301154105	alter add isactive ddl	SQL	V20190301154105__alter_add_isactive_ddl.sql	1284528784	egov	2026-07-10 10:44:49.501328	2	t
10	20201005230836	eg hrms employee index ddl	SQL	V20201005230836__eg_hrms_employee_index_ddl.sql	508211693	egov	2026-07-10 10:44:49.511624	4	t
11	20201223230836	eg hrms employee reactivation details index ddl	SQL	V20201223230836__eg_hrms_employee_reactivation_details_index_ddl.sql	-839388452	egov	2026-07-10 10:44:49.524387	9	t
12	20201228172710	reactivation indexes ddl	SQL	V20201228172710__reactivation_indexes_ddl.sql	-1000031729	egov	2026-07-10 10:44:49.540489	5	t
\.


--
-- Data for Name: egov_idgen_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.egov_idgen_schema (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-07-10 10:44:04.917181	0	t
2	20170614121459	DDL id generation create ddl	SQL	V20170614121459__DDL_id_generation_create_ddl.sql	-276506180	egov	2026-07-10 10:44:05.011728	16	t
3	20170630130913	create collection seq ddl	SQL	V20170630130913__create_collection_seq_ddl.sql	584536344	egov	2026-07-10 10:44:05.107913	2	t
4	20170713115259	create upicnum seq ddl	SQL	V20170713115259__create_upicnum_seq_ddl.sql	-226250147	egov	2026-07-10 10:44:05.12231	3	t
5	20170731222759	create noticeno seq ddl	SQL	V20170731222759__create_noticeno_seq_ddl.sql	1729453706	egov	2026-07-10 10:44:05.137212	1	t
6	20170816191759	create tl num seq ddl	SQL	V20170816191759__create_tl_num_seq_ddl.sql	-1703806072	egov	2026-07-10 10:44:05.149294	3	t
7	20170817164130	create employee code number seq ddl	SQL	V20170817164130__create_employee_code_number_seq_ddl.sql	-196105635	egov	2026-07-10 10:44:05.16411	2	t
8	20170826133659	create tl application num seq ddl	SQL	V20170826133659__create_tl_application_num_seq_ddl.sql	725879278	egov	2026-07-10 10:44:05.176155	1	t
9	20171020231917	create swm transaction num seq ddl	SQL	V20171020231917__create_swm_transaction_num_seq_ddl.sql	-267295984	egov	2026-07-10 10:44:05.185514	1	t
10	20171030111720	create lcms seq ddl	SQL	V20171030111720__create_lcms_seq_ddl.sql	-1131314050	egov	2026-07-10 10:44:05.195376	4	t
11	20171031140120	create lcms seq voucher ddl	SQL	V20171031140120__create_lcms_seq_voucher_ddl.sql	-898624016	egov	2026-07-10 10:44:05.207811	2	t
12	20171031155035	create lcms seq parawise comments	SQL	V20171031155035__create_lcms_seq_parawise_comments.sql	1312025724	egov	2026-07-10 10:44:05.218269	3	t
13	20171103163310	create swm contract num seq ddl	SQL	V20171103163310__create_swm_contract_num_seq_ddl.sql	200369660	egov	2026-07-10 10:44:05.231684	3	t
14	20171103163443	create swm vendor num seq ddl	SQL	V20171103163443__create_swm_vendor_num_seq_ddl.sql	-762706488	egov	2026-07-10 10:44:05.245037	1	t
15	20171103164912	create swm contractor num seq ddl	SQL	V20171103164912__create_swm_contractor_num_seq_ddl.sql	-631302095	egov	2026-07-10 10:44:05.255582	2	t
16	20171104162601	create swm vendor contract num seq ddl	SQL	V20171104162601__create_swm_vendor_contract_num_seq_ddl.sql	2110220476	egov	2026-07-10 10:44:05.265875	1	t
17	20171108112621	create reference evidence seq ddl	SQL	V20171108112621__create_reference_evidence_seq_ddl.sql	-129584516	egov	2026-07-10 10:44:05.275762	2	t
18	20171109001824	create swm vehicle schedule transaction num seq ddl	SQL	V20171109001824__create_swm_vehicle_schedule_transaction_num_seq_ddl.sql	-2021827066	egov	2026-07-10 10:44:05.289	1	t
19	20171109145848	create swm supplier num seq ddl	SQL	V20171109145848__create_swm_supplier_num_seq_ddl.sql	583388728	egov	2026-07-10 10:44:05.298564	1	t
20	20171110163419	create swm trip num seq ddl	SQL	V20171110163419__create_swm_trip_num_seq_ddl.sql	-1570619200	egov	2026-07-10 10:44:05.308565	1	t
21	20171113174232	create swm vendor paymentdetails seq ddl	SQL	V20171113174232__create_swm_vendor_paymentdetails_seq_ddl.sql	762717103	egov	2026-07-10 10:44:05.316745	2	t
22	20171113175600	create swm sanitationstaff target number seq ddl	SQL	V20171113175600__create_swm_sanitationstaff_target_number_seq_ddl.sql	265986491	egov	2026-07-10 10:44:05.326059	2	t
23	20171113233008	create swm staff transaction number seq ddl	SQL	V20171113233008__create_swm_staff_transaction_number_seq_ddl.sql	2110317753	egov	2026-07-10 10:44:05.336019	2	t
24	20171114104545	create personal details seq	SQL	V20171114104545__create_personal_details_seq.sql	-1866233071	egov	2026-07-10 10:44:05.345818	1	t
25	20171114104620	create agency seq	SQL	V20171114104620__create_agency_seq.sql	-653967466	egov	2026-07-10 10:44:05.35577	2	t
26	20171115210014	create event seq	SQL	V20171115210014__create_event_seq.sql	-1138671054	egov	2026-07-10 10:44:05.366963	1	t
27	20171223074921	create egf bill default number format seq ddl	SQL	V20171223074921__create_egf_bill_default_number_format_seq_ddl.sql	1544476819	egov	2026-07-10 10:44:05.375634	1	t
28	20180206121802	create swm vehicle maintenance repair transaction number ddl	SQL	V20180206121802__create_swm_vehicle_maintenance_repair_transaction_number_ddl.sql	513099893	egov	2026-07-10 10:44:05.384635	1	t
29	20180207123336	create swm shift code ddl	SQL	V20180207123336__create_swm_shift_code_ddl.sql	1730375649	egov	2026-07-10 10:44:05.392305	1	t
30	20180531123523	create propertytax ack ddl	SQL	V20180531123523__create_propertytax_ack_ddl.sql	102790456	egov	2026-07-10 10:44:05.399732	1	t
31	20180607123336	create pg txn id ddl	SQL	V20180607123336__create_pg_txn_id_ddl.sql	936381812	egov	2026-07-10 10:44:05.409013	1	t
32	20180709180520	create propertytax assess ddl	SQL	V20180709180520__create_propertytax_assess_ddl.sql	1893633814	egov	2026-07-10 10:44:05.417675	1	t
33	20180920115635	create tl seq ddl	SQL	V20180920115635__create_tl_seq_ddl.sql	1504691701	egov	2026-07-10 10:44:05.426038	1	t
34	20181030123635	DELETE DUPLICATES AND ALTER PRIMARYKEY ID GEN ddl	SQL	V20181030123635__DELETE_DUPLICATES_AND_ALTER_PRIMARYKEY_ID_GEN_ddl.sql	-2137616238	egov	2026-07-10 10:44:05.435499	8	t
35	20190129174853	create hrms empcode ddl	SQL	V20190129174853__create_hrms_empcode_ddl.sql	-1425111802	egov	2026-07-10 10:44:05.453808	1	t
36	20190520164710	UC SEQ ddl	SQL	V20190520164710__UC_SEQ_ddl.sql	1153445194	egov	2026-07-10 10:44:05.462061	1	t
\.


--
-- Data for Name: egov_localization_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.egov_localization_schema (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-07-10 10:44:12.313328	0	t
2	20170502122717	localization create message	SQL	V20170502122717__localization_create_message.sql	-651873868	egov	2026-07-10 10:44:12.419373	30	t
3	20170614170306	localization message alter add module	SQL	V20170614170306__localization_message_alter_add_module.sql	-1138292234	egov	2026-07-10 10:44:12.505649	7	t
4	20170625193803	add audit columns to message table	SQL	V20170625193803__add_audit_columns_to_message_table.sql	424158717	egov	2026-07-10 10:44:12.527457	3	t
5	20181218164449	alter msg alter id column ddl	SQL	V20181218164449__alter_msg_alter_id_column_ddl.sql	-1867784919	egov	2026-07-10 10:44:12.545569	25	t
\.


--
-- Data for Name: egov_otp_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.egov_otp_schema (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-07-10 10:44:33.064253	0	t
2	20170303153029	otp create token table	SQL	V20170303153029__otp_create_token_table.sql	-1720445245	egov	2026-07-10 10:44:33.163858	25	t
3	20170921000000	otp alter token table	SQL	V20170921000000__otp_alter_token_table.sql	385472944	egov	2026-07-10 10:44:33.266857	3	t
\.


--
-- Data for Name: egov_user_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.egov_user_schema (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-07-10 10:43:55.175837	0	t
2	20170223150524	create eg user table	SQL	V20170223150524__create_eg_user_table.sql	-473117120	egov	2026-07-10 10:43:55.28074	20	t
3	20170223151046	create eg address table	SQL	V20170223151046__create_eg_address_table.sql	-773357059	egov	2026-07-10 10:43:55.369435	19	t
4	20170223151145	create eg role table	SQL	V20170223151145__create_eg_role_table.sql	-1566976242	egov	2026-07-10 10:43:55.401246	14	t
5	20170223151229	create eg user role table	SQL	V20170223151229__create_eg_user_role_table.sql	-1457999063	egov	2026-07-10 10:43:55.432387	3	t
6	20170223151230	eg user drop FK PK recreate	SQL	V20170223151230__eg_user_drop_FK_PK_recreate.sql	-1065901777	egov	2026-07-10 10:43:55.446955	13	t
7	20170404154844	create role sequence	SQL	V20170404154844__create_role_sequence.sql	-674780019	egov	2026-07-10 10:43:55.474404	1	t
8	20170417165545	create unique username tenant constraint	SQL	V20170417165545__create_unique_username_tenant_constraint.sql	-1047782019	egov	2026-07-10 10:43:55.4837	6	t
9	20170417165956	create unique role code tenant constraint	SQL	V20170417165956__create_unique_role_code_tenant_constraint.sql	792682044	egov	2026-07-10 10:43:55.499215	6	t
10	20170423025220	alter table eg user to increase signature length	SQL	V20170423025220__alter_table_eg_user_to_increase_signature_length.sql	725199194	egov	2026-07-10 10:43:55.514392	1	t
11	20170423025221	alter table eg user to reset signature length	SQL	V20170423025221__alter_table_eg_user_to_reset_signature_length.sql	-2104479543	egov	2026-07-10 10:43:55.524523	30	t
12	20170428175632	recreate user address table	SQL	V20170428175632__recreate_user_address_table.sql	408456665	egov	2026-07-10 10:43:55.563917	23	t
13	20170509172805	recreate role and user role table with tenantid	SQL	V20170509172805__recreate_role_and_user_role_table_with_tenantid.sql	1202567563	egov	2026-07-10 10:43:55.595655	17	t
14	20170516145558	alter userrole add lastmodifieddate	SQL	V20170516145558__alter_userrole_add_lastmodifieddate.sql	-30454711	egov	2026-07-10 10:43:55.6233	2	t
15	20170823203553	dropping not null for mobilenumber in eg user	SQL	V20170823203553__dropping_not_null_for_mobilenumber_in_eg_user.sql	1587712007	egov	2026-07-10 10:43:55.634627	1	t
16	20180313150524	added uuid user table	SQL	V20180313150524__added_uuid_user_table.sql	-1031804668	egov	2026-07-10 10:43:55.642766	1	t
17	20180725165212	alter eg role name	SQL	V20180725165212__alter_eg_role_name.sql	682532180	egov	2026-07-10 10:43:55.650837	5	t
18	20180731215512	alter eg role address fk	SQL	V20180731215512__alter_eg_role_address_fk.sql	1212019426	egov	2026-07-10 10:43:55.668514	7	t
19	20181108160312	create indices eg user role	SQL	V20181108160312__create_indices_eg_user_role.sql	93267122	egov	2026-07-10 10:43:55.684368	27	t
20	20190204144112	create eg userrole v1	SQL	V20190204144112__create_eg_userrole_v1.sql	1977171559	egov	2026-07-10 10:43:55.719315	6	t
21	20190222121612	create eg user failed login attempts	SQL	V20190222121612__create_eg_user_failed_login_attempts.sql	-1392078543	egov	2026-07-10 10:43:55.733471	9	t
22	20190313165702	alter eg user address extend	SQL	V20190313165702__alter_eg_user_address_extend.sql	-1928243385	egov	2026-07-10 10:43:55.750647	3	t
23	20190402123143	create indices eg user eg userrole v1 	SQL	V20190402123143__create_indices_eg_user_eg_userrole_v1 .sql	-1249412585	egov	2026-07-10 10:43:55.762299	23	t
24	20210908231720	alter table eg user alternate number	SQL	V20210908231720__alter_table_eg_user_alternate_number.sql	1743363820	egov	2026-07-10 10:43:55.794548	1	t
25	20211029155746	create table user audit	SQL	V20211029155746__create_table_user_audit.sql	-894464608	egov	2026-07-10 10:43:55.801975	5	t
26	20211029171730	modified auditby	SQL	V20211029171730__modified_auditby.sql	-672564999	egov	2026-07-10 10:43:55.815311	6	t
27	20211029175430	modified username audit	SQL	V20211029175430__modified_username_audit.sql	-1616300745	egov	2026-07-10 10:43:55.82878	7	t
\.


--
-- Data for Name: egov_workflow_v2_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.egov_workflow_v2_schema (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-07-10 10:44:42.078089	0	t
2	20181204120036	wf create ddl	SQL	V20181204120036__wf_create_ddl.sql	-943671309	egov	2026-07-10 10:44:42.189763	76	t
3	20181226133033	wf alter table ddl	SQL	V20181226133033__wf_alter_table_ddl.sql	-1846206951	egov	2026-07-10 10:44:42.347753	3	t
4	20190117125333	wf state action alter table ddl	SQL	V20190117125333__wf_state_action_alter_table_ddl.sql	-1913967942	egov	2026-07-10 10:44:42.363411	22	t
5	20190322143035	wf add seq ddl	SQL	V20190322143035__wf_add_seq_ddl.sql	327804453	egov	2026-07-10 10:44:42.40017	2	t
6	20190411170435	wf add isStateUpdatable ddl	SQL	V20190411170435__wf_add_isStateUpdatable_ddl.sql	457550658	egov	2026-07-10 10:44:42.411309	2	t
7	20191211105434	wf modified assignee ddl	SQL	V20191211105434__wf_modified_assignee_ddl.sql	1176859445	egov	2026-07-10 10:44:42.422753	3	t
8	20200925153931	wf missing index ddl	SQL	V20200925153931__wf_missing_index_ddl.sql	1207664085	egov	2026-07-10 10:44:42.435793	5	t
9	20201030131738	wf comment size ddl	SQL	V20201030131738__wf_comment_size_ddl.sql	-1475905560	egov	2026-07-10 10:44:42.448266	5	t
10	20210111134335	wf added assignee idx ddl	SQL	V20210111134335__wf_added_assignee_idx_ddl.sql	-2022994724	egov	2026-07-10 10:44:42.460788	4	t
11	20210203112523	wf alter table ddl	SQL	V20210203112523__wf_alter_table_ddl.sql	366659182	egov	2026-07-10 10:44:42.471744	2	t
12	20210423102936	wf alter table active ddl	SQL	V20210423102936__wf_alter_table_active_ddl.sql	-1560113142	egov	2026-07-10 10:44:42.482939	2	t
13	20210817103463	wf alter table escalated ddl	SQL	V20210817103463__wf_alter_table_escalated_ddl.sql	2103718292	egov	2026-07-10 10:44:42.493279	1	t
\.


--
-- Data for Name: id_generator; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.id_generator (id, idname, tenantid, format, sequencenumber) FROM stdin;
\.


--
-- Data for Name: mdms_v2_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.mdms_v2_schema (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-07-10 10:43:57.958088	0	t
2	20230531114515	schema definition ddl	SQL	V20230531114515__schema_definition_ddl.sql	-2105460030	egov	2026-07-10 10:43:58.061052	14	t
3	20230531144020	mdms data create ddl	SQL	V20230531144020__mdms_data_create_ddl.sql	-1027512135	egov	2026-07-10 10:43:58.164044	13	t
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.message (id, locale, code, message, tenantid, module, createdby, createddate, lastmodifiedby, lastmodifieddate) FROM stdin;
71d56f31-61b0-4cc5-8104-e5d0af1eeb89	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_1002	engineer	pg	rainmaker-common	1	2026-05-13 06:54:26.653	1	2026-05-13 08:00:49.978
c23028f5-8bfc-4bd1-b40f-6eed6a0d35dc	en_IN	SERVICEDEFS_TABBROKEN	tab broken	pg	rainmaker-pgr	1	2026-05-13 06:54:27.142	1	2026-05-13 08:41:42.287
5e42234f-421b-474d-944b-8e3a76a1a391	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_38	CI_SCOPE_DEPT_55272	pg	rainmaker-common	1	2026-05-13 06:54:32.818	\N	\N
6bddf9f1-1349-47f0-b886-7bcd764e8e33	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_1004	CI_SCOPE_DESIG_55272	pg	rainmaker-common	1	2026-05-13 06:54:33.445	\N	\N
00e121cb-74db-426a-838c-4bcec4cdb6c2	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_1003	LME	pg	rainmaker-common	1	2026-05-13 06:54:26.653	1	2026-05-13 08:00:49.978
14287d2a-d4f6-4cf7-8e5d-49c39c9e9e7e	en_IN	SERVICEDEFS_TABBROKEN.DEPT_36	tab broken	pg	rainmaker-pgr	1	2026-05-13 06:54:27.142	1	2026-05-13 08:41:42.287
14f4375c-d73b-4b32-a567-6a064c7bd09b	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_37	ELECTRIC DEPARTMENT	pg	rainmaker-common	1	2026-05-13 06:54:26.132	1	2026-05-13 08:00:49.464
8d4d9543-4af7-4a16-bc33-38d13f763d6e	en_IN	SERVICEDEFS_WATER_NOT_COMING	Water not coming	pg	rainmaker-pgr	1	2026-05-13 06:54:27.142	1	2026-05-13 08:41:42.287
420352b0-563e-461e-ab88-4bb9a932d14c	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_36	WATER DEPARTMENT	pg	rainmaker-common	1	2026-05-13 06:54:26.132	1	2026-05-13 08:00:49.464
03b02807-f7c8-4921-879f-8cb3bc9291cd	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_39	CI_SCOPE_DEPT_59014	pg	rainmaker-common	1	2026-05-13 07:56:54.838	\N	\N
ae5cf5a9-5736-4e61-bcb5-f2903c9680c3	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_1005	CI_SCOPE_DESIG_59014	pg	rainmaker-common	1	2026-05-13 07:56:55.218	\N	\N
180d334d-92f3-4376-8800-272eb058afca	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_40	CI_SCOPE_DEPT_61700	pg	rainmaker-common	1	2026-05-13 08:41:41.466	\N	\N
0e776c3c-015a-449e-98df-6b8ebf0549b4	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_1006	CI_SCOPE_DESIG_61700	pg	rainmaker-common	1	2026-05-13 08:41:41.875	\N	\N
20ddcdbe-f158-4d97-9f6c-d5a0486222a7	en_IN	TENANT_TENANTS_PG_CITEST	CI Test	pg	rainmaker-common	29	2026-05-13 09:27:25.849	\N	\N
b08bd90e-55f0-4948-983e-880daea03553	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_36	WATER DEPARTMENT	pg.citest	rainmaker-common	29	2026-05-13 09:27:26.257	\N	\N
671b2f06-2106-4e46-9784-485c13162483	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_37	ELECTRIC DEPARTMENT	pg.citest	rainmaker-common	29	2026-05-13 09:27:26.257	\N	\N
1e5e7df0-0331-4331-8093-2294fba9aea9	en_IN	COMMON_MASTERS_DESIG_1002	engineer	pg.citest	rainmaker-common	29	2026-05-13 09:27:26.753	\N	\N
5b360c5b-de3b-47e8-85c4-264a278fd06b	en_IN	COMMON_MASTERS_DESIG_1003	LME	pg.citest	rainmaker-common	29	2026-05-13 09:27:26.753	\N	\N
ab210868-6c64-48ce-9788-6b3b4e5506ff	en_IN	SERVICEDFS.WATERNOTCOMING	Water not coming	pg.citest	rainmaker-pgr	29	2026-05-13 09:27:27.163	\N	\N
9747bd00-2eb4-4776-8939-889ec0603737	en_IN	SERVICEDFS.TABBROKEN	tab broken	pg.citest	rainmaker-pgr	29	2026-05-13 09:27:27.163	\N	\N
4a9d154e-a551-402d-833f-65178e5b8f2a	en_IN	TENANT_TENANTS_PG	PG	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1c2c8de9-6a10-40fa-9946-7165e9d01d03	en_IN	ACCESSCONTROL_ROLES_ROLES_PGR_VIEWER	Complaint Viewer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2ead2471-82e3-41c2-86d9-3394e19a3179	en_IN	ACTION_TEST_9HRMS	HRMS	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bd92853c-c021-416d-a202-222a6bbb6b6e	en_IN	ACTION_TEST_COMPLAINTS	Citizen Complaint Resolution System	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6472bb87-be92-46ff-a17d-f9fa182a9fab	en_IN	ACTION_TEST_COMPLAINT_TYPES	Complaint Types	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dfb01257-68e3-4b87-bc44-cdcd1d36e4b7	en_IN	ACTION_TEST_CREATE_COMPLAINT	Create Complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d254e8e0-0e46-4d54-994a-e02c4d9c42e6	en_IN	ACTION_TEST_HOME	Home	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0d97c3c0-ca9e-40f7-ba8a-c13b0690edf6	en_IN	ACTION_TEST_HRMS	HRMS	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fece8362-593d-4c6a-baca-3fb020fd7c08	en_IN	ACTION_TEST_MDMS	Manage Master Data	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a389d80d-b126-40da-9ad9-1664f21151b2	en_IN	ACTION_TEST_PGR	Citizen Complaint Resolution System	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1e5020b7-6c50-4954-91ee-12068323e24c	en_IN	ACTION_TEST_SEARCH	Search	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a49ce74f-e096-4e08-b8ef-6333bbd939c1	en_IN	ACTION_TEST_SEARCH_COMPLAINT	Search Complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
be890a6d-d0b6-4285-bed0-3dbcf720fbe3	en_IN	APPROVED	Approved	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e8fce721-87be-4ce4-89c8-6035f08ead20	en_IN	BUSINESS_SERVICE	Business Service	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bcc5e838-067b-4e26-a34f-2ab7a025924a	en_IN	CALL_CENTER_HELPLINE	Call Center / Helpline	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bc2eb674-acc3-40bf-806a-cb571ee09832	en_IN	CANCELLED	Cancelled	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ac3cb488-90d1-4343-a810-90e8134b91e7	en_IN	CARD	Card	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cfe512df-b957-4818-b7af-600238d06fcc	en_IN	CASH	Cash	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6e8aeb1b-7ef5-4edf-a18d-de4eece33a11	en_IN	CE_DCOUMENT_UPLOADED_ON	Uploaded on	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
21cb7801-52eb-4950-a612-e2dc799b50d8	en_IN	CE_DOCUMENTS_NOT_FOUND	No Documents found	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7a69de86-fa83-45f8-b882-5dc1e7882f0e	en_IN	CE_DOCUMENT_DETAILS	Document Details	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
162f689e-3621-42f0-b46e-7761a41c4e6d	en_IN	CE_DOCUMENT_DOWNLOAD_LINK	Download	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6ee5f142-c604-4520-be2a-2917de73db1a	en_IN	CE_DOCUMENT_OPEN_LINK	Link	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7ce6460e-ab67-4ca4-90ad-d43dbe7e7377	en_IN	CE_DOCUMENT_VIEW_LINK	View	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
26f2204a-c68e-46bd-9e45-810c9ed31e8c	en_IN	CE_SERACH_DOCUMENTS	Search documents	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
31ebf185-4a73-4a12-9f25-983e0261a827	en_IN	CE_TABLE_DOCUMENT_LINK	Attachment/Link	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
39f8d8f0-b3c0-4118-8b2c-ac08471d8766	en_IN	CE_TABLE_DOCUMENT_NAME	Document Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
87445bed-4ec9-446d-9154-da5516c81163	en_IN	CE_TABLE_DOCUMENT_POSTED_BY	Posted By	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a5752993-6688-436a-b0b4-1533d65648d9	en_IN	CHECKBOX_ANSWER_TYPE	Check boxes	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
96520439-d6f0-41bd-ba7a-ac9e64fde4e9	en_IN	CHEQUE	Cheque	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5ca50661-b132-4fb1-9294-bc6c8975085f	en_IN	CITIZEN	Online	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
11fc11b1-9d8e-47b7-ace9-4c9229b4aa7a	en_IN	CITIZEN_FAILURE_COMMON_PAYMENT_MESSAGE	Payment Failed	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b6b5a9d3-049b-4f9d-ba23-93da225c7c2c	en_IN	CITIZEN_FEEDBACK_PENDING	Pending for Citizen Feedback	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9d576276-2854-45c3-bf32-c49c05383a04	en_IN	CITIZEN_SERVICE_CENTER	Citizen Service Center	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
143b1af0-1dac-4e17-9eb4-558d7be8f1fb	en_IN	CMN_NOOPTION	No Options	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c19ac7e0-cdea-4615-93b9-43e63c9f1696	en_IN	COMMON_ALL	All	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2049b598-2d8b-4eea-90a8-1d5c8e75c325	en_IN	COMMON_ARREARS	Arrears	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
858f204d-4349-4ed9-86c0-428b492039bb	en_IN	COMMON_ARREARS_TOTAL	Arrears	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5fa2f901-1d19-4af7-9d22-26e80c84b9cb	en_IN	COMMON_BOTTOM_NAVIGATION_HOME	Home	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e356092a-6007-4447-a035-2774a14678c4	en_IN	COMMON_CERTIFY_ONE	I certify that appropriate amount of work has been completed. Muster roll has been verified against Measurement Book.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c0939f3d-3313-46fd-bc9b-74086a5faa25	en_IN	COMMON_CERTIFY_TWO	: Once approved Payment Advice will be generated and send to JIT-FS for payment processing.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0649da01-05f0-408e-a9b8-d4874cd3188d	en_IN	COMMON_DAY	day	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6f95ddc1-e5b1-4986-b7b9-f885a4970136	en_IN	COMMON_DAYS	days	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
79a60c89-6c9f-4dd9-a7d7-f21e350825da	en_IN	COMMON_DOC_DATA_NOT_FOUND	Document not found!	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bf24e290-8a53-4c7e-9690-dbec7acd3a3d	en_IN	COMMON_DOWNLOAD	Download	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
238aafa5-9c14-4b9b-a181-a82ee7af8e21	en_IN	COMMON_DOWNLOAD_RECEIPT	DOWNLOAD / VIEW RECEIPT	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ef308cd7-a037-4b0d-b745-6f358702850c	en_IN	COMMON_EDIT	Edit	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1beafab2-bb75-4900-880c-c1454030f80d	en_IN	COMMON_GENDER_FEMALE	Female	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
14f79f8e-ece4-4dfd-a2fd-cb10482758cf	en_IN	COMMON_GENDER_MALE	Male	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f65bc114-d0d4-4fd6-b766-f398357d236a	en_IN	COMMON_GENDER_TRANSGENDER	Transgender	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3f4000cd-3772-4d20-b71c-7e96435ff0b0	en_IN	COMMON_INBOX_NO_DATA	No results found !	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7b74e6c0-68ae-406a-b8a9-21281b97ee9c	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_1	Street Lights	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fcdeeebd-c12e-4877-a4bc-0a86f7bdec19	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_2	Building & Roads	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5f31635d-9cb1-412e-b84d-1d646b2f2052	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_3	Health & Sanitation	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2f7fb40b-a9b8-48da-bdb1-9f4b04e0352f	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_4	Operation & Maintenance	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fc1fe97c-312f-46ea-9ceb-8d908edfe2b1	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_5	Hotriculture	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5e7ca518-3017-4dc8-aebd-0b5119ae93eb	en_IN	COMMON_MASTERS_DESIGNATION_AO	Accounts Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
43487ff6-34c6-444f-9fdb-c703cb9a5944	en_IN	COMMON_MASTERS_DESIGNATION_COMM	Commissioner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c24804c7-40dc-4dce-b11c-732013010184	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_100	Computer Opertor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e4c6a8cc-bfab-4e69-a895-1c405f84d22e	en_IN	COMMON_MASTERS_PAYMENTMODE_CASH	Cash	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9982bf66-5e9b-4d72-b746-ff78c3d140b9	en_IN	COMMON_MASTERS_PAYMENTMODE_CHEQUE	Cheque	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
32c27404-73ad-4a3e-88af-416da5971aa9	en_IN	COMMON_MASTERS_PAYMENTMODE_CREDIT/DEBIT CARD	Credit/Debit Card	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
aaeb7059-2e46-4142-a75b-9519c3fb5aa2	en_IN	COMMON_NA	NA	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
00cb5292-9292-40f8-b042-cebf3c18e277	en_IN	COMMON_NO_RESULTS_FOUND	No Results Found	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b254f76d-d211-462d-8ec1-50655042f6c1	en_IN	COMMON_OTHER	Other	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fed419ae-0e4c-4e69-a247-f81dfd693383	en_IN	COMMON_OWNER	Owner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
75d1b9ba-b77e-46e6-a2f9-b964cf85c5bf	en_IN	COMMON_PATTERN_ERR_MSG_MUSTER_ID	Please enter valid Muster Id	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4d2901a8-325f-4f08-8776-bafe6a98df02	en_IN	COMMON_PAYMENT_HEAD	Payment	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d7fd4647-79e2-4b6a-8c7d-2b42eaa22e99	en_IN	COMMON_PAY_SCREEN_HEADER	Payment Information	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bd241366-f4f4-4e8c-b88b-32cdaf536a01	en_IN	COMMON_SELECTED	Selected	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
632f55f5-b537-4db0-a492-5b0850e5f761	en_IN	COMMON_SELECT_WARD	Select Ward	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
513a4636-21e0-4c59-914f-a371e8ed3d2b	en_IN	COMMON_TABLE_NO_RECORD_FOUND	Sorry, no matching records found	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
66d980fe-ee9c-4c24-ad38-ea432c82ea29	en_IN	COMMON_TABLE_SEARCH	Search	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3f04db41-3cc2-49be-b7c9-7d06332881a9	en_IN	COMMON_TABLE_SORT	Sort	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
13e202ff-59b2-40df-8621-58d78d853156	en_IN	COMMON_TOTAL	Total	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
884866bc-5f1c-459a-ba57-a9b1ceb16832	en_IN	COMMON_VALIDITY	Validity	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1347874d-ab78-43b8-96b4-1db3aba91a54	en_IN	COMMON_WARD	Ward	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
610bdce7-0fa8-478b-b71b-4574cae1ff32	en_IN	COMMON_WORKFLOW_STATES	Workflow State	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fe939b53-29f2-4a92-abba-7a633a26ac78	en_IN	COMPLETED	Completed	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
41f32aa8-be4d-41f9-b353-6051688e5a39	en_IN	CONFIRM_DELETE_DOC	Confirm Delete Document	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9ccd8bb8-8549-4336-8e19-b026a58de70f	en_IN	CONFIRM_DELETE_MSG	Please confirm is you want to delete the 	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9971b03e-e58d-441f-afe7-165e66733dc0	en_IN	CORE_COMMON_APPLICANT_ADDRESS_INVALID	Invalid Address	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d88d00b2-1130-482c-a7cc-7ebff9d89eca	en_IN	CORE_COMMON_APPLICANT_MOBILE_NUMBER_INVALID	Invalid Mobile Number	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d62134e7-7721-40fd-8ff1-bcf68bedff8a	en_IN	CORE_COMMON_APPLICANT_NAME_INVALID	Please provide a valid name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
15edbbb4-5f5b-4ac8-afd3-5b7ce16cd137	en_IN	CORE_COMMON_CANCEL	Cancel	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fe8309f3-41e7-42e2-80b6-14f2428a8b90	en_IN	CORE_COMMON_CHANGE_PASSWORD	Change Password	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
84bf8de4-6cd2-4738-958e-9fd6ebc40c77	en_IN	CORE_COMMON_CITY	City	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d2e521a4-b7b1-49a7-b1bf-0413afe35035	en_IN	CORE_COMMON_CONTINUE	Continue	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
43870490-f08e-48e4-b530-6e98e498682c	en_IN	CORE_COMMON_EMAIL	Email	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cc4a79dd-17fc-484c-bf9a-238745504555	en_IN	CORE_COMMON_FORGOT_PASSWORD	Forgot Password?	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
abb6c63c-0762-42b8-b45d-256e78baad9c	en_IN	CORE_COMMON_FORGOT_PASSWORD_LABEL	Forgot Password?	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8045e5db-1fed-4ca8-9cd7-ce0e2e2f007b	en_IN	CORE_COMMON_GENDER	Gender	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d4cccf5d-52f1-497e-bff8-76947fb35266	en_IN	CORE_COMMON_GO_TO_HOME	Go back to home page	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
13899ea5-8ffe-4074-8a1e-acebec3e8d87	en_IN	CORE_COMMON_LOGIN	Login	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
771f68e5-47b1-4124-94e4-241d25c8e2bf	en_IN	CORE_COMMON_LOGOUT	Logout	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c8900842-c9b9-4fc9-af1a-d687ca5a612a	en_IN	CORE_COMMON_MOBILE_ERROR	Please provide a valid mobile number	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e1a11d95-eb15-4856-9eea-12d9db44882d	en_IN	CORE_COMMON_MOBILE_NUMBER	Mobile Number	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c854aaed-9ab3-4d78-bea8-89498cdb369c	en_IN	CORE_COMMON_NAME	Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e42dd852-43f0-4d21-a898-499936c43dcf	en_IN	CORE_COMMON_NAME_VALIDMSG	Please enter a valid Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4a2c4137-c1d9-44cf-b002-aeba117b5afa	en_IN	CORE_COMMON_PHONENO_INVALIDMSG	Invalid Mobile Number	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5a6b0eda-a567-4624-a218-f37964bc49cc	en_IN	CORE_COMMON_PINCODE	Pincode	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bb68aed6-722f-4215-bd55-5954fb88b847	en_IN	CORE_COMMON_PINCODE_INVALID	Please provide a valid pincode	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0d30b178-d6cf-4384-93db-1158daac4a32	en_IN	CORE_COMMON_PROFILE_CITY	City	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
93eb657c-647c-41b6-b8e2-76c299e1dba2	en_IN	CORE_COMMON_PROFILE_CONFIRM_PASSWORD	Confirm New Password:	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fe039b69-98c4-4cb8-b1c0-b2268620b7ca	en_IN	CORE_COMMON_PROFILE_CURRENT_PASSWORD	Current Password:	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a6b37048-ef2b-4093-b0ff-6c4862e877e5	en_IN	CORE_COMMON_PROFILE_EMAIL	Email	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bdb49516-2ab9-4ed6-b543-8349a7164287	en_IN	CORE_COMMON_PROFILE_EMAIL_INVALID	Invalid Email	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2bb55831-d0f9-4f95-b219-b380339f01e0	en_IN	CORE_COMMON_PROFILE_ERROR_PASSWORD_NOT_MATCH	Passwords dont match	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e764a94f-2dbe-4191-ab9f-1dee124432a0	en_IN	CORE_COMMON_PROFILE_FILE_UPLOAD_ERROR	An error occurred while uploading the file	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c32bdaf7-664c-4f75-9b70-ad68040acabc	en_IN	CORE_COMMON_PROFILE_GENDER	Gender	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
de5385a2-7655-40ef-864c-02d5c2284952	en_IN	CORE_COMMON_PROFILE_INVALID_FILE_INPUT	Please upload a valid file to upload	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
205866a0-b6f0-48ad-8853-8117fbefbc9c	en_IN	CORE_COMMON_PROFILE_MAXIMUM_UPLOAD_SIZE_EXCEEDED	Please upload a file less than 1 MB	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cd025b7a-3120-4942-8766-0fae2300d11a	en_IN	CORE_COMMON_PROFILE_MOBILE_NUMBER	Mobile no.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6cf7c141-063b-4520-8d30-0bb003d39a12	en_IN	CORE_COMMON_PROFILE_MOBILE_NUMBER_INVALID	Please enter a valid mobile number	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c2afc9a5-2484-4766-8945-7be33da41939	en_IN	CORE_COMMON_PROFILE_NAME	Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4bcabdca-0f68-49a1-8d20-3e21a284f8fa	en_IN	CORE_COMMON_PROFILE_NAME_INVALID	Please enter a valid name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bfa5a6df-d662-4d56-9814-2dc4e2d27a32	en_IN	CORE_COMMON_PROFILE_NEW_PASSWORD	New Password:	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
143bbdf0-8903-44b1-80e5-4cae17b4585e	en_IN	CORE_COMMON_PROFILE_PASSWORD_INVALID	Invalid password	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c9786559-cb9a-4c65-9bab-bc508f5a9474	en_IN	CORE_COMMON_PROFILE_PASSWORD_MISMATCH	Passwords don't match	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d6163758-184e-4d05-9cd9-4a774099dbc3	en_IN	CORE_COMMON_PROFILE_UPDATE_ERROR_WITH_PASSWORD	Password must be 8 to 15 characters long and can include alphanumeric characters (a-z, A-Z, 0-9) along with the special characters @, #, $, and %.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b89ff5c5-01e1-4cfb-8d7f-3d92098e1723	en_IN	CORE_COMMON_PROFILE_UPDATE_SUCCESS	Profile updated successfully	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
27760335-574a-497a-84da-3587301b4e78	en_IN	CORE_COMMON_PROFILE_UPDATE_SUCCESS_WITH_PASSWORD	Profile and password updated successfully	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ee1ed028-e1b2-4f55-b633-789055aa91f5	en_IN	CORE_COMMON_REQUIRED_ERRMSG	Required	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3f723d7e-20b0-4a94-8095-595543701de6	en_IN	CORE_COMMON_RESET_PASSWORD_LABEL	Reset Password	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
51b5a44f-dd77-455b-a6d0-eb48109eb60b	en_IN	CORE_COMMON_SAVE	Save	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
576ee6bb-a77a-4669-853d-e18c3fe52590	en_IN	CORE_COMMON_SKIP_CONTINUE	Skip And Continue	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
353495c4-f748-4e94-ae25-ae7e754703a0	en_IN	CORE_COMMON_SUBMIT	Submit	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
20b19925-bc97-47e1-9380-9ee3863b0e51	en_IN	CORE_EMPLOYEE_OTP_CHECK_MESSAGE	Please check your messages for the OTP & then set a new password.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
316982f0-2163-4744-80b8-c42524660c69	en_IN	CORE_LOGIN_CONFIRM_NEW_PASSWORD	Confirm New Password 	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
11818b62-421b-40c0-a2ed-859bebc8266b	en_IN	CORE_LOGIN_NEW_PASSWORD	New Password 	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9430983a-983b-40ef-955e-a9e6b38c3e84	en_IN	CORE_LOGIN_PASSWORD	Password	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
47738c57-1686-4f1e-952d-49564ad05e81	en_IN	CORE_LOGIN_USERNAME	User Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4b15628c-7d52-4710-8c0f-6faf91397d40	en_IN	CORE_LOGOUTPOPUP_CANCEL	CANCEL	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5d8d30ae-bbef-470b-a886-ee0997476610	en_IN	CORE_LOGOUT_CANCEL	Cancel	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
070542ca-06f6-417b-be40-b384ff452192	en_IN	CORE_LOGOUT_MESSAGE	Logout	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
915175cf-9d9e-4a65-9adb-f19d97ba24f6	en_IN	CORE_LOGOUT_WEB_CONFIRMATION_MESSAGE	Are you sure you want to	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
803bd2fc-8e37-4a83-8eee-ea931d23dc87	en_IN	CORE_LOGOUT_WEB_HEADER	Logout	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
55bfa06e-4af3-4d8c-9485-ab042a6db636	en_IN	CORE_LOGOUT_WEB_YES	Yes, Logout	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a4d932f6-16dd-412a-86e3-c4489f2c29a8	en_IN	CORE_OTP_OTP	OTP	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0ccc8c46-9312-4de8-add1-7afcb048024b	en_IN	CORE_OTP_RESEND	RESEND	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fab21624-5781-4b4e-97cb-6840f4810ada	en_IN	CORE_OTP_SENT_MESSAGE	An OTP has been sent to :	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
016a6ff1-ee3f-4d3b-b5d8-546be350f539	en_IN	CORE_SOMETHING_WENT_WRONG	Something went wrong	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
da16080d-d39b-432e-9718-4ce4d957f561	en_IN	CORE_UNDER_MAINTENANCE	Under Maintenance!	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ec30a8c2-b8c3-4582-9689-b7f71c86e6f3	en_IN	CREATED	Application Created	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c49dfd1b-a96d-475b-9a11-4206649ec26e	en_IN	CREATED_FROM_DATE	Created from Date	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a32499ab-38ce-46f4-a48d-ef04ed017f36	en_IN	CREATED_TO_DATE	Created to Date	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ccdf7768-2795-449d-b07a-4e2ddb6348d7	en_IN	CS_ACTION_FILEUPLOADED	File Uploaded	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
85cc383a-c0cd-434d-9535-ca5ed9bccd87	en_IN	CS_ACTION_NO_FILEUPLOADED	No File Uploaded	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
331cd516-91a3-48b7-943d-30795c8db5c3	en_IN	CS_ADDCOMPLAINT_COMPLAINT_LOCATION	Complaint's Location	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f2e0bebd-5ddd-4ad2-a948-f1ff1bf307d2	en_IN	CS_ADDCOMPLAINT_SELECT_GEOLOCATION_HEADER	Pin Property Location	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
51c9b3f4-a996-4af4-a50b-88ac76ddf989	en_IN	CS_ARREARS_DETAILS	Arrear Details	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1781af2d-9db5-41ea-b249-05c6ea0fbbc4	en_IN	CS_BILL_DUEDATE	Due Date	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c458288c-6f87-4919-ac61-c15480b26083	en_IN	CS_BILL_NO	Bill No	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9a750c4c-c727-4a79-a39f-985c7cb38e9c	en_IN	CS_BILL_NOT_FOUND	Bill Not Found	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
012e4423-fd57-45f5-826f-320513663001	en_IN	CS_BILL_PERIOD	Billing Period	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1755933c-7445-4ea6-aabb-8c2bc6c51865	en_IN	CS_COMMONS_NEXT	Next	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
03dcfccf-ca73-44c2-a4ff-69fbf4eb64bb	en_IN	CS_COMMON_ACTION	Action	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
36e74ae1-0ec6-4d91-bdd6-b4581aa96034	en_IN	CS_COMMON_ASSIGN	Assign	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b6510c1b-6218-4635-91d5-d0fb8ff24289	en_IN	CS_COMMON_ATTACHMENTS	Documents	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
10febf9c-b660-4600-862f-ea67b765d132	en_IN	CS_COMMON_BACK	Back	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
403ab381-591d-48d6-807b-6d2c5e9774bf	en_IN	CS_COMMON_CANCEL	Cancel	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
60f5a527-237c-4241-af0c-aecb1740c5e8	en_IN	CS_COMMON_CHOOSE_FILE	Choose File	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2397b9f6-c741-4584-a6e3-66fea503ee17	en_IN	CS_COMMON_CHOOSE_LANGUAGE	Choose your language	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
28687c03-8e03-45c5-9aa3-6b53bf7eb533	en_IN	CS_COMMON_CHOOSE_LOCATION	Choose your location	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
25ea30a4-cfe2-43d4-9d39-b71f72c39789	en_IN	CS_COMMON_CLEAR_SEARCH	Clear search	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
93d869e7-b26e-456a-a327-21a02d889179	en_IN	CS_COMMON_COMPLAINT_RESOLVED	Resolved	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e73751a0-f9e4-4570-ab22-e7ca42fe5de2	en_IN	CS_COMMON_DASHBOARD_INFO_UPDATES	Information and Updates	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8e7e42cb-d212-4332-8763-ad7c97708e58	en_IN	CS_COMMON_DOCUMENTS	Documents	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3645e148-ebf5-4e7a-866e-af70e61cadad	en_IN	CS_COMMON_DOWNLOAD	Download	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a3d05afd-399b-458e-9a36-8634457b97f7	en_IN	CS_COMMON_FILE_A_COMPLAINT	File a Complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7988151f-6954-4368-b440-daa030102145	en_IN	CS_COMMON_GET_DIRECTIONS	Get Directions	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dd3c13ac-eb5d-4627-afc8-c0c5364a6451	en_IN	CS_COMMON_HELP	Help	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
97ba009b-030e-4358-ada3-b0d810c7490c	en_IN	CS_COMMON_HELPLINE	HELPLINE	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0cae908e-c88a-45f4-a0a7-0b72739b778e	en_IN	CS_COMMON_HOME_COMPLAINTS	Citizen Complaint Resolution System	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
32d51bd3-c08d-4780-b1cd-b9005073c80e	en_IN	CS_COMMON_INFO	Info	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5851d8d0-5082-4176-b1c0-5efdbbfae873	en_IN	CS_COMMON_LOCATION_SELECTION_ERROR	Please select your Location	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
abc6dba5-7d4e-4988-b035-9fd35271aca9	en_IN	CS_COMMON_NEW_SURVEY	Add New Survey	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c75308aa-33a7-4a6f-a015-1d27c4a5efe6	en_IN	CS_COMMON_NEXT	Next	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
30de0d6b-fecd-4fce-8599-bbdbdc1790c3	en_IN	CS_COMMON_OR	OR	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2a666a13-170f-4782-a775-c79eeaceae81	en_IN	CS_COMMON_PAYMENT_AMOUNT	Payment Amount	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3cf411bf-aba0-471a-9c97-1ee04fd0516b	en_IN	CS_COMMON_PAYMENT_COMPLETE	Payment Complete	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
77c15ebb-3974-48dc-937b-fe9e1a8355ad	en_IN	CS_COMMON_PRINT_CERTIFICATE	Print Certificate	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3ef8c74b-2b5d-42fa-bbeb-e87f39b53ed6	en_IN	CS_COMMON_PRINT_RECEIPT	Print Receipt	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a1bd18d3-c0fd-4a05-a529-9d8b5ba34887	en_IN	CS_COMMON_PROCEED_TO_PAY	Proceed To Pay	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7c3f13c7-8379-4873-bc59-d32cb9ac7975	en_IN	CS_COMMON_RECIEPT_NO	Reciept No.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
32c83299-c64d-4538-a44c-cca14fa6bc69	en_IN	CS_COMMON_REOPEN	Re-open	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bcbe820d-fdeb-4589-8223-c4d45bbf99f6	en_IN	CS_COMMON_REQUIRED	Required	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
24676d64-16b7-4d8f-b36b-6efd83ef8747	en_IN	CS_COMMON_RETRY	Retry	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
444357c4-18ed-4d45-9e34-cd25e4301a37	en_IN	CS_COMMON_ROWS_PER_PAGE	Rows per page	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
56e4838d-aca6-42fd-94a1-073ae9573223	en_IN	CS_COMMON_SEARCH_PLACEHOLDER	Search here	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
28d0b66f-be1f-40b6-94b4-b16b0e40623d	en_IN	CS_COMMON_SKIP	Skip and Continue	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bde6a411-20eb-49ed-b2c1-8020b28886a2	en_IN	CS_COMMON_SUBMIT	Submit	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1401ff3b-18fb-49d7-b3a6-aa7bd58df7b8	en_IN	CS_COMMON_SURVEYS	Surveys	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a7107dc2-7fba-45d1-a887-7cf8466b8013	en_IN	CS_COMMON_THANK_YOU	Thank You	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
10e5b60b-3c84-4811-9066-2448abb9267b	en_IN	CS_COMMON_VIEW	View	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8e8004de-436c-4737-8b42-ca52ac96a407	en_IN	CS_DOWNLOAD_RECEIPT	Download Receipt	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9439b22b-e090-4433-9dfd-efa3042a1d8d	en_IN	CS_FILE_APPLICATION_INFO_LABEL	Info	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e95d4563-8f5a-4376-95fd-5f71b1b62fab	en_IN	CS_FILE_APPLICATION_PINCODE_LABEL	Do you know the pincode ?	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8fac2203-91eb-4f82-9670-47f33c46c162	en_IN	CS_FILE_APPLICATION_PROPERTY_LOCATION_PROVIDE_LANDMARK_TITLE	Provide Landmark	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
05a75114-0776-4656-bc57-0c8a9acf8e5a	en_IN	CS_FILE_UPLOAD_ERROR	Invalid File	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bbd3d642-f5cc-4743-aa50-4d571b65dec2	en_IN	CS_HEADER_MYCITY	My City	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c0fb30ad-3161-4088-b3d7-c1749e0cf95b	en_IN	CS_HEADER_NOTIFICATIONS	Notifications	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7f810291-5c96-4e78-98e2-fd5e9ee691cb	en_IN	CS_HEADER_WHATSNEW	What’s New	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
61be9e4a-7f46-45ed-bfbd-733885a34089	en_IN	CS_HIDE_CARD	Hide Details	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
96c0b68c-64f2-4b68-9e50-6f32be2e0f80	en_IN	CS_HOME_MY_COMPLAINTS	My Complaints	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
adedf07c-800e-463b-85ea-49c4adab96b6	en_IN	CS_INBOX_STATUS_FILTER	Status	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b4b64a91-97f3-42aa-af25-f997aecf5749	en_IN	CS_INFO_DELETE	Delete	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b6f3506b-be5d-483f-88a9-d65ff9e7d91a	en_IN	CS_INVALID_OTP	Invalid OTP	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
55c43b36-b678-4572-9c43-c9fdc9285da4	en_IN	CS_LINK_DSO_DASHBOARD	DSO Login/ Dashboard	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
075359c0-a438-4130-a6eb-4f0044f1674b	en_IN	CS_LINK_LOGIN_DSO	DSO Login	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4860874c-b6b1-4684-aec7-f82cdd048233	en_IN	CS_LOGIN_NAME_TEXT	Provide the name of the person to make your experience more personalised	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1249decc-3cab-4350-9b40-fa8ac64236a0	en_IN	CS_LOGIN_OTP	OTP Verification	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c8255eef-c443-4f4d-b4fe-23cbf82eeda7	en_IN	CS_LOGIN_OTP_TEXT	Enter the OTP sent to	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8a8dab6c-218c-4d9d-8d86-8a6cab498d01	en_IN	CS_LOGIN_PROVIDE_MOBILE_NUMBER	Provide your mobile number	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
df594cb6-1db0-4cec-b46f-e9334c56b754	en_IN	CS_LOGIN_PROVIDE_NAME	Provide your Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
08ac5e12-d49b-4d0c-8f12-3edd3fbf38d4	en_IN	CS_LOGIN_TEXT	All the communications regarding the application will be sent to this mobile number.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
10f65ea9-0981-4464-8563-30313d80147e	en_IN	CS_MAXIMUM_UPLOAD_SIZE_EXCEEDED	Upload file size less than 5MB	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
10fe9680-6082-4973-bcdf-0fb3a036c860	en_IN	CS_MYAPPLICATIONS_NO_APPLICATION	No Applications found	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c0c403f5-a765-49d9-8301-86b8286d1cff	en_IN	CS_NA	NA	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ab29c993-9c4a-4e99-8c41-cd853b228ab0	en_IN	CS_PROFILE_EMAIL_ERRORMSG	Invalid Email Id	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0c0e4a9e-8d17-4920-ac57-1a55dd7fe077	en_IN	CS_RESEND_ANOTHER_OTP	Resend another OTP	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3a19cd81-934e-4120-9f6d-037d298414b4	en_IN	CS_RESEND_OTP	Resend OTP	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7a392077-4fd0-4530-9e28-88b514c8e21a	en_IN	CS_RESEND_SECONDS	secs	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d255c696-c824-4dee-b325-3c82c6afc970	en_IN	CS_REVIEW_AND_FEEDBACK	Rate us	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c425e3d0-39f9-4739-ace3-34c146775807	en_IN	CS_SEARCH	search	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a8e4f949-23c2-4366-a12b-9b297cbaaeb0	en_IN	CS_SELECTED_TEXT	ULB	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
42ba87af-230b-4e81-afdf-96571365648c	en_IN	CS_SHOW_CARD	View Details	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6ed14009-7bae-443d-ad7c-5bc521738d67	en_IN	CS_SKIP_CONTINUE	Skip and Continue	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
145b9d95-d409-4679-82fb-031c14cd6580	en_IN	CS_SLA_DAY	days ago	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0f7396ac-7421-4f6d-997d-a20f46054439	en_IN	CS_SLA_NOW	Now	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1b27c31a-f969-498f-8f27-037208c95a9b	en_IN	CS_SURVEY_RESPONDED	Already Responded	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
06094e00-37ef-46b2-aa27-d8a89787356d	en_IN	CS_SURVEY_RESULTS	Survey results	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9c1254e0-9745-4410-b544-6e2b083e316e	en_IN	CS_TITLE_MY_BILLS	My Bills	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
690ba136-8272-4dc2-bfd1-5a35a0c12526	en_IN	CS_TO	to	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f44e4fd7-671d-43f7-a691-19367ce0ce78	en_IN	Code	code	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ceafceb6-98e7-41f3-be4e-e2fde48d7085	en_IN	DASHBOARD_CITIZEN_SERVICES_LABEL	Citizen Services	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ffa68f4b-66ef-4944-b431-33da31e7d8aa	en_IN	DASHBOARD_VIEW_ALL_LABEL	VIEW ALL	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4449f461-7b92-4c34-9c79-e8dc6b16a77e	en_IN	DASHBOARD_WHATS_NEW_LABEL	What’s New	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
050131ad-b7e4-4fed-ad1d-25e780574121	en_IN	DATE_ANSWER_TYPE	Date	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
67ce7517-8b73-4f31-8cbe-830d1e2bd657	en_IN	DATE_VALIDATION_MSG	To date should be greater then from date	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
79e9e194-c80a-4470-a195-04967328c85f	en_IN	DCOUMENT_DESCRIPTION	Document Description	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3f536d63-741b-4570-8f30-6279f76de9f4	en_IN	DESIGNATION	Designation	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
08050a5b-d2e3-4477-9d65-35769e8790a7	en_IN	DIGIT_I_ACCEPT	I accept	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
271bdc8a-2c8e-45b0-8ef1-55df9c1025dc	en_IN	DIGIT_I_DO_NOT_ACCEPT	I do not accept	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a0a24445-ee80-4dd9-84ee-081daa651b64	en_IN	DIGIT_TABLE_OF_CONTENTS	Privacy Policy	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
30391a39-3034-4395-a4dd-29de0cd2b948	en_IN	DISABLED	Disabled	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
420ee0b2-b8a3-487a-9275-9acd777d906a	en_IN	DISPOSAL_IN_PROGRESS	Disposal in Progress	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
10ff5935-84f5-40bc-9a4b-8c54a4ff26aa	en_IN	DOCUMENTS_ATTACH_RESTRICTIONS_SIZE	Only jpg, png, doc and pdf files. 5MB max file size.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6586c107-22b7-4ed7-9a9e-ae757c613a20	en_IN	DOCUMENTS_CATEGORY_CARD_LABEL	Document Category	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5d6c88e5-3e15-404d-bc34-9b7642d20080	en_IN	DOCUMENTS_DOCUMENT_HEADER	Documents	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b14bb66e-46ec-4b05-9227-2803e560ca39	en_IN	DOCUMENTS_EDIT_HEADER	Edit	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
48f41dd0-9e65-44c8-bdb5-1d6f5ac13017	en_IN	DOCUMENT_CATEGORY	Document Category	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c473721e-a675-46cd-a58a-b908d14fc43c	en_IN	DOCUMENT_NAME	Document Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6ce3bbeb-8321-47f2-877f-217b106f5219	en_IN	EDIT_NEW_PUBLIC_MESSAGE	Edit Public Message	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
24c5cbc4-e29a-44fb-b942-3ae6cbb76d57	en_IN	EDIT_PROFILE	Edit Profile	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7ba6f288-6245-4909-8f0c-48472dbe99db	en_IN	ES_BY_CLICKING	I agree to the DIGIT's	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dc571dfc-181c-400c-94b2-8c1701441612	en_IN	NEW_DOCUMENT	Document	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f9cdef43-1331-43f1-aae9-054af8876d09	en_IN	PGR	Citizen Complaint Resolution System	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a314d7f2-7e5b-4531-b8e8-e49b57645021	en_IN	PGR_CREATE_ANOTHER_COMPLAIN	Create Another Complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3c093610-3a47-4d0c-a5dc-143edd35f4d6	en_IN	PGR_INBOX	Inbox	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4bdc0b37-4b21-4392-af49-29f5587a3fa2	en_IN	PGR_SEARCH_RESULTS_HEADING	Search Citizen Complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
88d0543a-196c-4da1-8e56-94eeaac0f91a	en_IN	PLUMBER	Plumber	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
aa2d3ee7-aea9-4942-be2f-9555444a0838	en_IN	PRIVACY_AUDIT_REPORT	Privacy Audit Report	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0a9cd433-8491-48a1-b762-bfae33e23587	en_IN	PROFILE_UPDATED	Profile updated successfully	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fec52faa-05dd-4c38-bde1-47dcdcfaa116	en_IN	SERVICE_TYPE	Service Type	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
21c749c1-4c10-4b3a-86bb-ea049038b922	en_IN	SORT_BY	Sort By	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d1887cce-efbe-4b95-aea8-75eca1b187cc	en_IN	STATUS	Status	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9fc7070a-8d1e-4305-8612-54ecc04539f2	en_IN	SUBMITTED	Submitted	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
aa0e2408-1729-47eb-a30c-ee82c41e2e3b	en_IN	SURVEY_INFO_HEADER	Note	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1dda28bf-3a9b-4755-94a9-8f43c8cccd96	en_IN	SURVEY_INFO_LABEL	For Active surveys only end date/time and survey description can be edited.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f5e9ecd3-0b19-4ed1-88cc-84167a4e23b1	en_IN	SURVEY_QUESTIONS	Questions	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c238b933-5150-4929-a237-e6cbad00fa8d	en_IN	SURVEY_REPORT	Report	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
20a70ef0-90df-4085-a8ad-40d05990645e	en_IN	SURVEY_STATUS_TOOLTIP	Active Status represents that survey is actively collecting responses. Inactive status fall pre and post active collection dates	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
04568cd4-96ec-41cb-9187-20e25f6358f2	en_IN	TOTAL_CHALLANS	Total Challans	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
967f66b1-6285-4d8e-b775-34e6fdcd1f53	en_IN	TOTAL_CHALLANS 	Total Challans	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
46bb3eca-bf52-465c-87a0-50e52dcc4e1a	en_IN	TOTAL_DOCUMENTS	Documents	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7bb2ab7e-5598-41ee-afb4-45e9c14ab109	en_IN	TOTAL_EMPLOYEES	Total Employees	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6cde63aa-3966-4cd7-8a4f-19b5350b969d	en_IN	TOTAL_EVENTS	Events	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3179b73f-5ee9-4cb1-b4a7-9f6ce3470cd0	en_IN	TOTAL_MESSAGES	Messages	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
66d8fa68-a82b-4af2-bfb0-872714338b4b	en_IN	TOTAL_NEARING_SLA	Nearing SLA	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7f356f2e-3e1b-426c-a00b-36e662e0e391	en_IN	TOTAL_PGR	Total	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8b13ec3b-c54d-4f05-992e-ddd134f32edf	en_IN	TRANSGENDER	Transgender	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
83942f96-3ff9-4016-a6a2-d3c3455756f1	en_IN	UNKNOWN_ERROR	Unknown error	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e221a957-3af3-4cf7-b661-768d15883e18	en_IN	VERIFIED	Verified	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3a3abe81-c683-4d5e-9936-e1ac04ad5afa	en_IN	VIEW_ON_MAP	View on Map	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fa4d526c-cf43-4849-a2e9-642ecd21d25a	en_IN	WF_ACTION_CANCELLED	Action has been cancelled	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d83ea32a-e82a-46fd-ab9d-934efec48277	en_IN	WF_APPROVAL_UPLOAD_HEAD	Supporting Documents	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9c7c9c3d-f12d-4d09-bc93-9774999d0f56	en_IN	WF_ASSIGNEE_NAME_LABEL	Assignee Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bb3fe605-c1f4-40d8-bf4d-d42d4b5e01bd	en_IN	WF_ASSIGNEE_NAME_PLACEHOLDER	Select assignee Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f1234e97-5df7-469a-b5e3-e6b53daf859d	en_IN	WF_INBOX_HEADER_CURRENT_OWNER	Current Owner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8618ab56-ffc0-4878-a5b6-16fc98e0e975	en_IN	WF_INBOX_HEADER_LOCALITY	Locality	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
10df6470-59cb-4f74-a1f3-29cfb98479fc	en_IN	WF_INBOX_HEADER_SLA_DAYS_REMAINING	SLA (Days Remaining)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5d72e4dc-93ed-4346-ae0e-619d129332f6	en_IN	WF_MODAL_APPROVER	Assignee Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
502be6b4-07b9-4b22-af17-6ea5b476fb30	en_IN	WF_MODAL_CANCEL	Cancel	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
05eda1a9-cbf1-4a72-a49b-15355ceb0474	en_IN	WF_MODAL_COMMENTS	Comments	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a55ae6ff-9a35-45d8-9c56-80ef8dce4289	en_IN	WF_TAKE_ACTION	TAKE ACTION	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a19f789f-8f51-4a1e-9651-7fba51d74ce2	en_IN	ERR_INVALID_MOBILE_NUMBER	Please enter a valid mobile number	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
138140ba-3a3e-4b94-b94a-5de41ba157b4	en_IN	MOBILE_VALIDATION_DIGITS	digits	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1ec39e08-04a5-4796-80d0-9441d6f8efac	en_IN	MOBILE_VALIDATION_AT_LEAST	at least	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
007e97aa-fa16-4b8e-bf06-2a2f34992eb8	en_IN	MOBILE_VALIDATION_STARTING_WITH	starting with	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b55839af-a59f-4a5c-98c4-2fa8f2115386	en_IN	MOBILE_VALIDATION_OR	or	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
20386a02-99e3-4e82-ae6a-b2d475f5552b	en_IN	EVENTS_DATERANGE_LABEL	Date Range	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a5c5d81d-155c-432f-9f22-78bb33b78146	en_IN	ES_CLEAR_ALL	Clear All	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
86548d97-bb2e-4fb9-94ab-62472c409b79	en_IN	ES_COMMON_APPLY	Apply	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
927241f1-e779-447b-8003-46319d3fcae5	en_IN	ES_COMMON_CONTACT_DETAILS	Contact Details	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d9157e0b-49d3-43f8-a786-1d7c9a2f00c5	en_IN	ES_COMMON_HOME	Home	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c0a150ff-af8d-4c84-b4c4-9705ea6de1fe	en_IN	ES_PRIVACY_POLICY	Privacy Policy	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7d41f57f-5c4b-4f52-8762-18cdd4974961	en_IN	ES_FORGOT_PASSWORD_DESC	Please enter your user name to reset password.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6863c108-e38f-4c5b-a0ed-0af3db6e428a	en_IN	TL_APPROVAL_UPLOAD_HEAD	Supporting Documents	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c1bd92dd-6141-44af-8847-402b6115f776	en_IN	HR_COMMON_CREATE_EMPLOYEE_HEADER	Create Employee	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1ab6cab3-ef1d-4749-8a46-524d77aa6427	en_IN	HR_HOME_SEARCH_RESULTS_HEADING	Search Employee	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a62a6fcd-f707-479c-8420-567cf5cdb5d4	en_IN	ACTIVE_EMPLOYEES	Active Employees	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e61211d8-0782-4637-b26a-52bc312ee5fa	en_IN	ACTION_TEST_WORKBENCH	Workbench	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0e573c5a-1f86-4194-809f-65c7eac21700	en_IN	ACTION_TEST_LOCALISATION	Manage Localisation	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9bc364b6-5b8b-41ae-8ec8-d002f9b98f1d	en_IN	ADMIN_BLOCK	Block	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fa3f550d-6b55-451b-b7b1-587b3649b5bb	en_IN	ADMIN_LOCALITY	Locality	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e60f0160-98e4-48d3-97f5-33b439758886	en_IN	ADMIN_ZONE	Zone	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2740db48-63bc-4ff7-b3a2-4c853bed9cee	en_IN	ADMIN_CITY	City	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
003ae49f-1407-4e8f-b33b-a38a88dab843	en_IN	ES_PGR_INBOX	Inbox	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6b58ffa1-ed61-4270-baed-79a7117f3c03	en_IN	ES_PGR_HEADER_COMPLAINT	Citizen Complaint Resolution System	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
11f4311f-caf2-47ac-9ef8-a1492020ba54	en_IN	ES_PGR_NEW_COMPLAINT	New Complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3da09269-3dd3-4aa4-863c-7b63c68e46b5	en_IN	ES_INBOX_LOCALITY	Locality	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4658fedc-6cfe-475d-ad55-4950d0b42537	en_IN	ES_INBOX_STATUS	Status	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2fbd8706-f230-4dff-ad74-66057159c782	en_IN	ES_COMMON_INBOX	Inbox	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
439b2742-73e9-49eb-ae85-ac84407c248e	en_IN	ES_TITLE_INBOX	Inbox	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
802c4f1a-a411-4edc-a3b5-122213159a9d	en_IN	EV_SLA_DAY_ONE	day ago	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
abdf09f7-d928-4a3a-a1e1-c5b67dae942e	en_IN	EV_SLA_MINUTE	Minutes ago	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4b301cd5-c1a9-489a-b4f8-33af93dd255f	en_IN	EV_SLA_MINUTE_ONE	minute ago	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6a5e5fa4-2baa-41f6-811b-fd67e29db541	en_IN	EV_SLA_MONTH	Months ago	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0d75e349-92c7-44a6-9b67-87daf6a4b989	en_IN	EV_SLA_MONTH_ONE	month ago 	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
97123c99-081e-4cef-a7d7-9d4670c4e747	en_IN	EV_SLA_TIME	hrs ago	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
850b5689-f0da-4622-91c1-8547bd0e071d	en_IN	EV_SLA_TIME_ONE	hr ago	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
905168e7-c839-44d0-ac6e-318f2e6bdf52	en_IN	EV_SLA_WEEK	Weeks ago	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
daa22343-6386-4ce4-b753-a8bb30c72a05	en_IN	EV_SLA_WEEK_ONE	Week ago	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a13dfd3b-3bd7-4793-8fb1-9c22c4737a1e	en_IN	ES_COMMON_PLEASE_ENTER_ALL_MANDATORY_FIELDS	Please enter all mandatory fields	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2856198f-82c3-4447-a92c-9aae9ae1c634	en_IN	ES_COMMON_NO_DATA	No Data Found	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
49480b88-7aea-4ff6-95f5-ccc82a92e08c	en_IN	ES_COMMON_SEARCH	Search	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
335fa503-1f92-4da8-89a2-95df003c09ee	en_IN	ES_COMMON_FILTER	Filter	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bebc56d5-8aff-4431-9d0b-85552b086ffa	en_IN	ES_COMMON_FILTER_BY	FILTER BY	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
243b40e1-72b7-4760-8004-be41edd4aee3	en_IN	ES_COMMON_CLEAR_ALL	CLEAR ALL	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8479cd94-a933-463e-90eb-8192d6973b3a	en_IN	ES_COMMON_CLEAR_SEARCH	CLEAR SEARCH	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
85d6b535-70c4-468e-a8d7-064ba6f17d25	en_IN	ES_COMMON_TAKE_ACTION	Take action	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
05cd0ea7-be75-4d79-bd2d-a91ef597a2b7	en_IN	ES_COMMON_VIEW_DETAILS	View Details	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3a71b209-f6fa-4d61-a4f5-14a65ac04216	en_IN	ES_COMMON_HIDE_DETAILS	Hide Details	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
11b60434-7d44-4869-b77e-c7019198e868	en_IN	ES_COMMON_UPDATE	Update	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dd72effc-9fbd-4f7c-9035-96db35e40840	en_IN	ES_COMMON_NA	NA	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9232cce3-03f0-41d4-8e23-3f6f3667f3e5	en_IN	ES_COMMON_ULB	ULB	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f2a4dfb3-4bae-4bc3-9140-eb563f334eac	en_IN	ES_COMMON_NOTE	Note	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ecb6a35e-187f-4850-9231-aa4f9dfe60b5	en_IN	ES_COMMON_SEARCH_BY	Search By	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bff01e5b-9d85-40e2-b9aa-dcaab6651e16	en_IN	ES_COMMON_APPLICATION_SUBMIT	Submit	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ddabb111-2117-4441-9e26-7ccaadd25ead	en_IN	ES_COMMON_MIN_SEARCH_CRITERIA_MSG	Please enter minimum 1 search criteria	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
331f2ba8-202e-4f43-9ba6-30269fe7a502	en_IN	ES_COMMON_ENTER_DATE_RANGE	Enter valid date range	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c066f47d-df9a-48a9-8116-9b4bf72aeee8	en_IN	ES_COMMON_Y_DEL	Yes, Delete	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a0b1dcfb-b2a7-40ae-a93a-872a202fb7b6	en_IN	ES_COMMON_USER_ULBS	User Ulb(s)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e17212ca-cbd9-4a03-bd42-6744af3bbb65	en_IN	ES_COMMON_INFO	Info	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a2aefd78-6350-434d-bb5f-3efd704f8cd5	en_IN	ES_COMMON_DOC_CATEGORY	Document Category	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
28116d9b-6f2d-49ab-89f3-464994af48b8	en_IN	ES_COMMON_DOC_DESCRIPTION	Document Description	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3c41950f-2561-4b55-b560-6bee57c3373f	en_IN	ES_COMMON_DOC_DOCUMENT	Document	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
57de038c-2915-4c39-afd7-0f0ccbd094a9	en_IN	ES_COMMON_DOC_FILENAME	File Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
91a256be-2f23-43e6-9892-1cc798954f31	en_IN	ES_COMMON_DOC_NAME	Document Name	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9776e8b5-24ae-455a-811b-69c0400bde22	en_IN	ERR_DEFAULT_INPUT_FIELD_MSG	Invalid Input	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
915dfc90-510d-44bf-9a02-11fcab807207	en_IN	ERR_HRMS_INVALID_MOB_NO	Invalid mobile number	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
38101986-fa10-45c7-887c-33771cf94e49	en_IN	ERR_HRMS_INVALID_CITY	Invalid City	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
31c2b732-4396-4b66-b066-04a8c4294be5	en_IN	ERR_PASSWORD_DO_NOT_MATCH	Password do not match	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d150f4e5-2ee5-4374-b09a-c0c42f863970	en_IN	ES_SEARCH_APPLICATION_MOBILE_INVALID	Please provide a valid mobile number	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7f79c2a0-ed32-4b40-8e01-ccaf6a9893dd	en_IN	WF_COMMON_COMMENTS	Comments	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
480af594-858f-4d77-b9f2-31967ea3590a	en_IN	ACCESSCONTROL_ROLES_ROLES_PGR_VIEWER	Complaints Viewer	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4dd53499-2f45-40f8-b6c7-0258adfeb783	en_IN	ADMIN	Admin	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4228b0e1-478e-4cb4-81d6-df7a4f9ebd31	en_IN	CONTRACT	Contract	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
516e40cd-c9fe-4076-b985-f3b9d50d0601	en_IN	CS_COMPLAINT_DETAILS_SUB_COMPLAINT_TYPE	Complaint Sub-Type	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
de2f7d4a-fee9-404f-a1ea-af4b5785c6ee	en_IN	DAILYWAGES	Dailywages	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
05066444-ea4d-4b19-ac8c-155e561d8be4	en_IN	DEPUTATION	Deputation	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
091989b8-f51d-4e38-b969-886d05d2e181	en_IN	ERR_ALL_MANDATORY_FIELDS	Enter data in all mandatory fields	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c2cdf480-f477-400c-bdf7-53b5df537dbd	en_IN	ERR_BASE_TENANT_MANDATORY	Atleast one Jurisdiction should be selected in Parent city	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3bfd69bd-ca0e-4f12-9152-07f88ad457b3	en_IN	ERR_HRMS_INVALID_DATE_OF_APPOINTMENT	Invalid employee date of appointment entered by the user.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a4f4b629-b2de-47c1-970a-f84980f59cb6	en_IN	ERR_HRMS_INVALID_DEACT_REASON	Employee deactivation reason is invalid.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1baed27b-6fd2-4342-9654-d2fece0f404e	en_IN	ERR_HRMS_INVALID_DEPT	Invalid department of employee entered.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bbd7cd14-9db3-4cb2-bcbf-b20a18ae1e0b	en_IN	ERR_HRMS_INVALID_MOB_NO	Invalid mobile number entered.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
31213c9d-ffb1-44e4-8803-a95a0b132ad4	en_IN	ERR_HRMS_INVALID_ROLE	Invalid role assigned to the employee.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0026babf-dfc4-4c11-b71c-55df8d572bab	en_IN	ERR_HRMS_USER_CREATION_FAILED	User creation failed at the user service.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ff3b3d63-d4e3-4120-b56c-e88b1b634536	en_IN	ERR_HRMS_USER_EXIST_MOB	User already exists for the entered mobile number. Use a different mobile number to proceed.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
25896515-dab2-4c18-a511-577cda76e73b	en_IN	ERR_HRMS_USER_EXIST_USERNAME	User already exists for the entered user name.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3480b562-972f-4664-8136-fd5ca1822baa	en_IN	ES_COMMON_SEARCH_BY	SEARCH BY:	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
50fadc50-5972-468f-9e22-8c2bb8f9b5d0	en_IN	ES_SEARCH_APPLICATION_MOBILE_INVALID	Please provide a valid mobile number	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6a33d6e3-9a2f-4231-961d-7fdbaa4748a9	en_IN	HRMS_CREATE_EMPLOYEE_INFO	The login credentials have been shared with the employee via SMS on the registered mobile number.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
99fcc928-c429-4f9d-90d0-14d5bbccc0b1	en_IN	HRMS_CREATE_EMPLOYEE_RESPONSE_MESSAGE	Employee Created Successfully	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b59c4ac2-af11-48b7-8d8e-50b3e4618c0a	en_IN	HRMS_UPDATE_EMPLOYEE_RESPONSE_MESSAGE	SUCCESS	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3fc30c6b-f14b-4914-ab69-67e97fb2cbed	en_IN	HR_ACTION_NO_FILEUPLOADED	No File Selected	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c3a7fcb2-f057-4446-bc69-8e2ace14a1b7	en_IN	HR_ACTIVATE_EMPLOYEE_HEAD	Activate Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f08445c0-3c74-469d-b772-9860c28c5591	en_IN	HR_ACTIVATE_HEAD	Active	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
24d89835-737c-4ac6-adf9-1174ee0ddbf8	en_IN	HR_ACTIVATION_REASON	Reason for Re-activation	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b8c3c8b4-23ae-4fe8-a8e8-9af11e6e8c9e	en_IN	HR_ADD_ASSIGNMENT	ADD ASSIGNMENT	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
50d2a7dd-9a05-4279-94d9-9e48bbf20757	en_IN	HR_ADD_JURISDICTION	ADD JURISDICTION	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c3cc3d57-83d8-4c5c-8d0e-5110d5b4141a	en_IN	HR_APPOINTMENT_DATE_LABEL	Date of Appointment	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1018c245-f152-442f-baa4-0452936f99ff	en_IN	HR_APPROVAL_UPLOAD_HEAD	Supporting Documents	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4e8b31e6-7d47-49c3-ac69-cb9b9f8418b0	en_IN	HR_ASMT_FROM_DATE_LABEL	Assigned From Date	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c4950d40-ad86-422a-8f71-538d3e13f172	en_IN	HR_ASMT_TO_DATE_LABEL	Assigned To Date	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ae57e0a2-3370-4b6c-b081-6814a72629f6	en_IN	HR_ASSIGNMENT	Assignment	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5256962d-876d-42e7-8006-2615213baddd	en_IN	HR_ASSIGN_DET_HEADER	Assignment Details	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8a4ded71-b67c-4c05-99e3-be3223db1daf	en_IN	HR_ASSIGN_DET_SUB_HEADER	Verify entered details before submission. Assignment details cannot be edited once submitted.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ae950a69-a442-4264-b051-2633d92bd1df	en_IN	HR_BIRTH_DATE_LABEL	Date of Birth	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5e05e0d4-a36a-428d-b1d2-b32865c77f01	en_IN	HR_BOUNDARY_LABEL	Boundary	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cef45b2f-bbd0-4a30-b761-4130294d37fe	en_IN	HR_BOUNDARY_TYPE_LABEL	Boundary Type	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4b7c3dac-f70b-4b89-b1c9-e05f125a3941	en_IN	HR_COMMON_APPLY	Apply	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7623b8ea-9639-4c13-83e4-7ece53286d46	en_IN	HR_COMMON_BUTTON_HOME	Home	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
87c713d0-01f2-4817-b42c-e356796d4fa7	en_IN	HR_COMMON_BUTTON_SUBMIT	Submit	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ee731ef2-82bc-4720-876c-13223fa3d12e	en_IN	HR_COMMON_CLEAR_SEARCH	Clear Search	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
49c2831a-5996-4aee-bc72-964c84cbbb21	en_IN	HR_COMMON_CREATE_EMPLOYEE_HEADER	Create Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3b0539bc-2e05-41af-8268-ce555fef8b27	en_IN	HR_COMMON_EDIT_EMPLOYEE_HEADER	Edit Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f5aa6bc-4b28-444c-936c-223f5c31e584	en_IN	HR_COMMON_FILTER	Filter By	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ac278836-7101-48aa-8b8d-10a3ad18a60d	en_IN	HR_COMMON_HEADER	Employee Management	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ec9003c8-fc01-46b5-a1f1-cd1b56dccb67	en_IN	HR_COMMON_SEARCH	Apply	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d1900d09-f1c4-4990-9296-92b2e88ecbe6	en_IN	HR_COMMON_TABLE_COL_DEPT	Department	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fa3d5ff9-2740-4fd0-89d2-f2b5f5189cc9	en_IN	HR_COMMON_TABLE_COL_ROLE	Role	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
167fbde4-37ac-42b8-8216-9f6de0d5b6f1	en_IN	HR_COMMON_TAKE_ACTION	Take Action	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
61d9e293-bbcc-4830-acdf-baceee3cc950	en_IN	HR_CORRESPONDENCE_ADDRESS_LABEL	Correspondence Address	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
974aca48-b3e1-4166-ae4f-5a3916ef15bf	en_IN	HR_CURRENTLY_ASSIGNED_HERE_SWITCH_LABEL	Currently Assigned Here	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
daf6afa3-c607-4763-ba1c-1d67ee849471	en_IN	HR_DEACTIVATE_EMPLOYEE_HEAD	Deactivate Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
36c1a0d2-988e-4c9a-af73-d2ac1d52da57	en_IN	HR_DEACTIVATE_HEAD	Inactive	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0d1e1ef4-e99c-4e7d-9fc9-7da2914a8da5	en_IN	HR_DEACTIVATION_REASON	Reason for Deactivation	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c22dde92-f0c7-4cc3-926a-ff925bd25dfd	en_IN	HR_DEPT_LABEL	Department	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
441ab595-a5fd-4a38-b4c9-02fd5a2551eb	en_IN	HR_DESG_LABEL	Designation	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2e26eded-483d-44cb-af80-e98bb79a13f7	en_IN	HR_EFFECTIVE_DATE	Effective Date	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
189f943f-3fa7-4ac6-984d-d20d45fdb303	en_IN	HR_EMAIL_LABEL	Email	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4e4eaa2b-33e6-43c9-892b-c05c07e46d6e	en_IN	HR_EMPLOYEE_ID_LABEL	Employee ID	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f039d3e4-a316-4956-af82-011af3954bbc	en_IN	HR_EMPLOYMENT_TYPE_LABEL	Employement Type	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bb3e0422-4074-4978-94d8-f452af144a1a	en_IN	HR_EMP_ID_LABEL	Employee ID	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
16a2da97-367c-44e9-9e71-00a830c640d2	en_IN	HR_EMP_ID_MESSAGE	ID assigned to employee by the municipality. Incase there is no ID assigned, leave the column blank for the system to generate the Employee ID.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
38a76ea9-cb9f-45f9-b0b8-1736b95d5584	en_IN	HR_EMP_NAME_LABEL	Employee Name	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f2f13cb3-1d02-49f7-a12e-64b201093429	en_IN	HR_EMP_STATUS_LABEL	Employment Status	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4a1f27c0-a652-4194-8e97-abfb7164a3fc	en_IN	HR_GENDER_LABEL	Gender	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7bad2463-2c95-4e23-898b-6ea0c274874a	en_IN	HR_HIERARCHY_LABEL	Hierarchy	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a0b3ca5f-de05-4abc-bcfd-a8ed21eb4803	en_IN	HR_HOME_SEARCH_RESULTS_HEADING	Search Employe	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
68cac256-af0e-4776-8f3d-71b0448ebb14	en_IN	HR_JURISDICTION	Jurisdiction	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7a946914-9e66-4d82-9524-bacf4a8bfe5d	en_IN	HR_JURISDICTION_DETAILS_HEADER	Jurisdiction Details	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
88ad38df-f1f3-499c-9f8c-03beada764b1	en_IN	HR_JURIS_DET_HEADER	Jurisdiction Details	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b5fb8ce5-bb1d-44a2-bab8-2e6030bd8197	en_IN	HR_MOB_NO_LABEL	Mobile Number	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c5ec3a2d-824e-48a5-af63-762fb64d3d7f	en_IN	HR_NAME_LABEL	Employee Name	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bc70fd9c-f88d-46d4-93ef-33ab6f2d7f67	en_IN	HR_NEW_EMPLOYEE_FORM_HEADER	Employee Details	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9ba5e5f9-efb4-44e6-afb3-52636ce351cc	en_IN	HR_ORDER_NO	Order No.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a8104d60-bec5-480f-80b0-0fcde0aa0d23	en_IN	HR_PERSONAL_DETAILS_FORM_HEADER	Personal Details	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f20fe31a-2eae-49da-8987-80a29e9a1103	en_IN	HR_REMARKS	Remarks	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
afea9464-0967-4025-bdf9-3827263e5d97	en_IN	HR_ROLE_LABEL	Role	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6d3c0975-32f1-49c8-a4a1-fcc0091e9def	en_IN	HR_ROLE_NO_LABEL	No of Roles	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
abacf41d-7e17-4456-952a-b0a3e3cd3d69	en_IN	HR_STATUS_LABEL	Status	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8fda0c2d-891e-4f2a-afbc-728034b26e1e	en_IN	HR_ULB_LABEL	Locality	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ba6175a1-e063-4e26-9728-40c5a9571fa3	en_IN	PERMANENT	Permanent	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
473c9f4a-9165-42ea-a523-5fa8628d7969	en_IN	REVENUE	Revenue	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
93850109-fc20-4c9c-bb38-9c66db29a11a	en_IN	TEMPORARY	Temporary	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a05850ff-8c91-4872-9732-9bc79c8634a7	en_IN	ANOTHER_USER	Another User	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8dcc2f1a-53f4-4906-9be9-d0e8f0f8e286	en_IN	ASSIGN	Assign	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
16367460-a4c1-4309-ac42-bd2311edcfc7	en_IN	ASSIGNED_TO_ALL	Assigned to All	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8d502787-08ac-4f19-af79-703aa4ed7071	en_IN	ASSIGNED_TO_ME	Assigned to Me	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ecfaee34-1402-4345-a4d6-b260e9b694ef	en_IN	ASSIGN_SUCCESSFULLY	Assigned Successfully	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2a275073-a67c-4a0d-aca2-ef314b50e38f	en_IN	COMPLAINTS_COMPLAINANT_CONTACT_NUMBER	Complainant Phone No.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ddceaec9-41e3-4cef-a133-b41b53e37b39	en_IN	COMPLAINTS_COMPLAINANT_NAME	Complainant Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
125350af-c857-443d-b204-d18605183f2f	en_IN	CORE_COMMON_CLOSE	CLOSE	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7f9f1496-2e84-4c82-8327-d33191c4770d	en_IN	CORE_COMMON_NAME_VALIDMSG	Please enter a valid Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
77456774-0cd1-4d4e-a014-1245169d0caf	en_IN	CORE_COMMON_PHONENO_INVALIDMSG	Invalid Mobile Number	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
613b24e7-655b-4c61-b7a1-007439fd396c	en_IN	CORE_COMMON_PINCODE	Pincode	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2c2cd228-6e06-40f2-bc7b-709413e23318	en_IN	CORE_COMMON_PINCODE_INVALID	Provide Valid Pin code	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a87afe87-d06e-4272-9675-3a86b918cfe0	en_IN	CORE_COMMON_REQUIRED_ERRMSG	Required	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1e18ed15-50b0-4f8b-bbab-88090844d273	en_IN	CORE_COMMON_SKIP_CONTINUE	Skip and continue	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
29d74cb3-2ba5-4009-adb9-2f4774de6100	en_IN	CORE_EMPLOYEE_OTP_CHECK_MESSAGE	Please check your messages for the OTP & then set a new password.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fbd9ca73-7843-4461-94a3-7207cf0acc7b	en_IN	CORE_LOGIN_CONFIRM_NEW_PASSWORD	Confirm New Password 	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
72d19aa3-095a-40eb-b9f1-390a2d70d064	en_IN	CORE_LOGIN_NEW_PASSWORD	New Password 	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e7d7ebc3-60f0-4108-a48f-36397659de20	en_IN	CORE_LOGIN_PASSWORD	Password	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fcc918ac-86d2-4b8f-a312-834bdf302416	en_IN	CORE_LOGIN_USERNAME	User Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fde233ea-b981-4a30-930e-f032d15d4b59	en_IN	CORE_LOGOUTPOPUP_CANCEL	CANCEL	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
680d49c4-ce88-41b4-8dfa-6c1dc67df248	en_IN	CORE_OTP_OTP	OTP	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b23ec6f1-ff52-40c6-bf8c-86be07fcdfe3	en_IN	CORE_OTP_RESEND	RESEND	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
03987d6e-2a89-4cb6-8e12-4323a58749be	en_IN	CORE_OTP_SENT_MESSAGE	An OTP has been sent to :	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9fbbc899-766a-47e0-8528-b7139ac7d444	en_IN	CS_ACTION_ASSIGN	Assign Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
02aa7a24-cb8c-41b3-b241-245b1af7e206	en_IN	CS_ACTION_FILEUPLOADED	File Uploaded	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fb00b4d6-cbf9-4c02-95ca-ffb222f1a2fe	en_IN	CS_ACTION_NO_FILEUPLOADED	No file uploaded	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
204aca20-90c1-4a31-916e-79f05f2aec89	en_IN	CS_ACTION_REASSIGN	Re-assign Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ec262fef-daea-4ea4-9fec-59bfde61d24c	en_IN	CS_ACTION_REJECT	Reject Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c002cdfd-d69f-4c6b-adc2-0cfce7e2f65b	en_IN	CS_ACTION_REOPEN	Re-open	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
13673f98-989a-41d0-8028-f0f9903736a4	en_IN	CS_ACTION_SUPPORTING_DOCUMENTS	Supporting Documents	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
16b37fef-ff94-46fa-9532-220df88c7bdd	en_IN	CS_ADDCOMPLAINT_ADDITIONAL_DETAILS	Additional Address Information	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b8246b34-9b6b-471e-971d-f9f02e8b683b	en_IN	CS_ADDCOMPLAINT_ADDITIONAL_DETAILS_SUBMIT_COMPLAINT	Submit Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
64b00a29-e61f-4ac0-80a5-275da50ef954	en_IN	CS_ADDCOMPLAINT_ADDITIONAL_DETAILS_TEXT	If you think apart from information provided till now additional details are required to resolve complaint, provide it below:	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2ea7053d-02d8-4c11-aa17-ad30aa697fde	en_IN	CS_ADDCOMPLAINT_CHANGE_PINCODE_TEXT	If you know the pincode of the complaint address, provide below. It will help us identify complaint location easily or you can skip and continue	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
657ef361-a3b7-4625-b7c2-19eae4080272	en_IN	CS_ADDCOMPLAINT_CITY_MOHALLA_TEXT	Choose the locality of the complaint from the list given below.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
89b2c160-621d-4810-b5de-d19fa176064d	en_IN	CS_ADDCOMPLAINT_COMPLAINT_LOCATION	Complaint's Location	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5261bd32-c51f-4911-837b-edb8830535ec	en_IN	CS_ADDCOMPLAINT_COMPLAINT_SUBTYPE_PLACEHOLDER	Choose Complaint Sub-Type	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6863dc87-16eb-46f4-b035-64e31d8f3793	en_IN	CS_ADDCOMPLAINT_COMPLAINT_SUB_TYPE	Complaint Sub-Type	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
babc9a19-8856-42f8-a21a-df26584987ed	en_IN	CS_ADDCOMPLAINT_COMPLAINT_TYPE	Complaint Type	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
48bfb650-8189-4138-853f-1db98af958e5	en_IN	CS_ADDCOMPLAINT_COMPLAINT_TYPE_PLACEHOLDER	Select complaint type	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b841cb3f-8105-4f6a-8124-c8c2d304fb72	en_IN	CS_ADDCOMPLAINT_LANDMARK	Landmark	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2af06477-1dbc-4db5-810a-47e0c286f333	en_IN	CS_ADDCOMPLAINT_LOCATION	Complaint Location	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
030bda3a-1f21-477d-ba20-a996dd09d2bf	en_IN	CS_ADDCOMPLAINT_PROVIDE_ADDITIONAL_DETAILS	Provide Additional Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
59865149-818c-4d57-8d67-89e41b696033	en_IN	CS_ADDCOMPLAINT_PROVIDE_COMPLAINT_ADDRESS	Provide Complaint address	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9672edaf-13cb-49bc-a190-4cc40cbc1704	en_IN	CS_ADDCOMPLAINT_SELECT_GEOLOCATION_HEADER	Pin Complaint Location	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e5554963-c1a4-4bfc-84b7-6bcaa3a1a0f4	en_IN	CS_ADDCOMPLAINT_SELECT_GEOLOCATION_TEXT	Click and hold to drop the pin to complaint location. If you are not able to pin the location you can skip the continue for next step.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0bcdaff5-96b1-46f6-a440-c83588c1f83f	en_IN	CS_ADDCOMPLAINT_UPLOAD_PHOTO	Upload complaint photos	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e21c69e6-d830-4e9b-8ecb-d1fec27d32f7	en_IN	CS_ADDCOMPLAINT_UPLOAD_PHOTO_TEXT	Click on the icon below to upload the complaint photos as evidence. You can capture photos directly through your camera or upload from your Gallery. If you do not have complaint photo, you can skip the continue for next step.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
09c63f10-5ac6-4af8-9333-d262ff548c54	en_IN	CS_ADDCOMPLAINT_YOU_RATED	You Rated 	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
03bb8d50-da06-4285-ac53-06e577844f89	en_IN	CS_COMMON_ASSIGN	Assign	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
54c9faa0-fb1c-4025-830f-671c1e0ed417	en_IN	CS_COMMON_ATTACHMENTS	Attachments	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
aba67ff0-d5e5-477f-936a-45d685cb26d9	en_IN	CS_COMMON_BACK	Back	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
82514138-90c2-42a3-b6b5-faef7a952321	en_IN	CS_COMMON_CANCEL	Cancel	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
11adf9a8-0b58-4cc2-a04f-ed997e93b376	en_IN	CS_COMMON_CHOOSE_FILE	Choose File	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bd7d870f-f58d-4317-a4d9-fc6fd7a35b89	en_IN	CS_COMMON_CLEAR_SEARCH	CLEAR SEARCH	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c7caf0d1-d5d8-4496-ba70-51b70ae0daf1	en_IN	CS_COMMON_CLOSED	Closed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4640e245-6695-4130-b589-f0f9b963393b	en_IN	CS_COMMON_COMMENTS	Comments	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e1bae7da-ad00-4fe7-99fc-cc59364ca12c	en_IN	CS_COMMON_COMPLAINT	Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
11686459-a58f-4253-a844-c76d86e73c05	en_IN	CS_COMMON_COMPLAINT_FILED	Complaint filed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
96b5cbb2-a3e8-447d-81f5-7326a127b636	en_IN	CS_COMMON_COMPLAINT_NO	Complaint No	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e2c5ce17-8ee2-4b5d-bca5-fcdcf1ae1273	en_IN	CS_COMMON_COMPLAINT_REJECTED	Rejected	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e73f15ae-751d-4ec8-853e-ac6bc878249f	en_IN	CS_COMMON_COMPLAINT_REOPENED	Complaint Re-opened	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bc606169-a6db-4d8c-8691-34da23e96a28	en_IN	CS_COMMON_COMPLAINT_RESOLVED	Complaint resolved	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f60e963c-c680-4547-8192-6cbd033e007f	en_IN	CS_COMMON_COMPLAINT_SUBMITTED	Complaint Submitted	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
46555072-0d53-4058-b727-bb3a7103cb71	en_IN	CS_COMMON_DAY	day	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
39b0454a-e13a-4a9d-ab38-134f16eaa1fe	en_IN	CS_COMMON_DAYS	days	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
aca700c0-e125-4c63-8eb2-64b55f64e5da	en_IN	CS_COMMON_EMPLOYEE_COMMENTS	Comments	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e3f9aa69-cb2e-4f93-957a-49831126e3c3	en_IN	CS_COMMON_EMPLOYEE_NAME	Employee Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7e6867d3-5780-4f13-a32c-783ff3604ee0	en_IN	CS_COMMON_ERROR_LOADING_RESULTS	Error while loading results	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4197fa79-8db9-4b28-8e5a-a28fc70c90f4	en_IN	CS_COMMON_FILE_A_COMPLAINT	File a Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
49c22e12-09cd-487b-be55-bbe3b089b95d	en_IN	CS_COMMON_FILTER	Filter	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
39a2cbd7-e626-4758-a1e7-2abb2ba980c8	en_IN	CS_COMMON_HOME	Home	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ae49ac75-96a7-46e4-ab74-c26ab9d894ce	en_IN	CS_COMMON_INBOX	Inbox	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
430f0ecd-1fac-40e3-a9d5-27f9c82774dd	en_IN	CS_COMMON_MOBILE_NO	Mobile No	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5437079a-3313-48a6-bdda-b3e57b82bff6	en_IN	CS_COMMON_NEXT	Next	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1668de73-9861-4693-a15e-50a1da1885ed	en_IN	CS_COMMON_OPEN	Open	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b5337311-de30-4178-8f05-b370e4202e09	en_IN	CS_COMMON_PENDINGATLME	Pending at LME	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
587ab442-cca1-4dcc-ae0b-633a8403e550	en_IN	CS_COMMON_PENDINGFORASSIGNMENT	Pending for assignment	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5fadce20-585c-4ec2-aad3-522e79704566	en_IN	CS_COMMON_PINCODE_NOT_SERVICABLE	Sorry we are not providing service in this city	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
179cd06f-fd3c-42cd-87eb-bcc16c8f61fb	en_IN	CS_COMMON_RATING_SUBMIT_TEXT	By making your voice heard, you help us improve mSeva.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e74a7355-4f52-4db9-82e3-4f7e8d5edb6d	en_IN	CS_COMMON_REJECT	Reject	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
023a7e3f-7101-4f9e-b1b5-a73555952cb6	en_IN	CS_COMMON_REQUIRED_FIELDS_MISSING	Required fields missing	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b23b70dc-5425-47da-b52f-8d23f3ee6117	en_IN	CS_COMMON_RESOLVE	Resolve	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
93629ebe-92e0-4181-bffd-7f525876725f	en_IN	CS_COMMON_SEARCH_BY	SEARCH BY	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f257e790-d35c-458f-84b8-f8114a84a2f4	en_IN	CS_COMMON_SELECT_EMPLOYEE	Select Employee	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8b730fdc-5ce7-4e49-8d7a-c5d320c271b9	en_IN	CS_COMMON_SKIP	Skip and Continue	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d1acd420-b871-417c-89d4-6784b5d2cabe	en_IN	CS_COMMON_SUBMIT	SUBMIT	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6d48c642-5daa-4a90-836c-9435c97dc3d4	en_IN	CS_COMMON_THANK_YOU	Thank You	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a003f5fd-d64d-4cab-a48c-6ba0fa44e42c	en_IN	CS_COMMON_TRACK_COMPLAINT_TEXT	The notification along with complaint number is sent to your registered mobile number. You can track the complaint status using mobile or web app.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
88f27275-f1a8-4f47-9af7-2a866d8a92a9	en_IN	CS_COMPLAINT_ADDTIONAL_DETAILS	Additional Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
454db6d5-7cdf-4128-acaa-9de195f56b3c	en_IN	CS_COMPLAINT_COMMENT_SUCCESS	Comment Successful	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0cbd0a8b-9371-4614-8c3e-4a5240968b38	en_IN	CS_COMPLAINT_DETAILS_ADDITIONAL_DETAILS	Additional Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f776c78e-b694-4232-adb8-676481622900	en_IN	CS_COMPLAINT_DETAILS_ADDITIONAL_DETAILS_DESCRIPTION	Description	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3c51989d-0e49-4161-9606-525aaaaedf32	en_IN	CS_COMPLAINT_DETAILS_ADDRESS_1_DETAILS	Address	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
20989aab-09d0-4752-a642-7800295cd3f7	en_IN	CS_COMPLAINT_DETAILS_ADDRESS_2_DETAILS	Address Line 1	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
da85b46f-f5c2-4e76-84f8-750d3849ea0a	en_IN	CS_COMPLAINT_DETAILS_APPLICATION_STATUS	Application Status	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cf0cd63f-4f66-42eb-9294-452262fbdd45	en_IN	CS_COMPLAINT_DETAILS_AREA	Locality	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
91dd21f7-138f-4385-9f84-0eca143369c1	en_IN	CS_COMPLAINT_DETAILS_CITY	City	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
612041c6-b0c7-41ca-8ac3-729854924024	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_DATE	Complaint Date	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5acf8182-8283-411f-a1ef-cee9141e7f65	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_DESCRIPTION	Complaint Description	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9d1224fe-8b08-4a08-ab30-741002fe7a5a	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_DETAILS	Complaint Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
acedd701-32d3-4fb9-8ee3-3df0da8d488a	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_NO	Complaint No.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ca9f636e-ac1c-4400-8d13-1cebd4e46787	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_SUBTYPE	Complaint Subtype	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1ac38a2f-582a-4378-8ec3-7f944f5988bd	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_TIMELINE	Complaint Timeline	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6a5bad8b-2e8f-4ecf-a608-025a8c7f7fdf	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_TYPE	Complaint Type	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
31931f2a-415b-470b-b20d-915b0ab36835	en_IN	CS_COMPLAINT_DETAILS_CURRENT_STATUS	Current Status	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
80576ddb-4cbc-4dc8-8386-84f6334b11d1	en_IN	CS_COMPLAINT_DETAILS_GEOLOCATION	Geolocation	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ae3e8e4f-11cc-437e-9266-5fac0cedb506	en_IN	CS_COMPLAINT_DETAILS_LANDMARK	Landmark	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f806d8c2-837e-4a15-95df-be7e40d688b1	en_IN	CS_COMPLAINT_DETAILS_LOCALITY	Locality	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1e383f1c-6c08-47e9-9e8a-a864dff67f3f	en_IN	CS_COMPLAINT_DETAILS_SUB_COMPLAINT_TYPE	Complaint Sub-Type	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
01e00820-fc63-4580-82bd-5c938b4708cf	en_IN	CS_COMPLAINT_FILED_DATE	Filed Date	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
edcdbf19-3b12-4510-8138-41d55663ef6e	en_IN	CS_COMPLAINT_LANDMARK__DETAILS	Landmark	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
79ced362-7d9e-404f-929b-6577d6200ca2	en_IN	CS_COMPLAINT_LOCATION_DETAILS	Location Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
440d4a6a-8f39-49c6-aab4-5060fb85db47	en_IN	CS_COMPLAINT_LOCATION	Complaint's Location	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
537b637c-9e83-4aa4-8274-f122355de478	en_IN	CS_NAVIGATE	Open in Maps	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
84d58a2a-7e07-4422-8589-588420d350b6	en_IN	CS_COMPLAINT_POSTALCODE__DETAILS	Postal Code	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
829c59b7-763e-47d6-8650-d804bc5ce0a3	en_IN	CS_COMPLAINT_RATE_HELP_TEXT	How would you rate your experience with us?	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
da81e265-36b0-4d35-bda4-408af10339db	en_IN	CS_COMPLAINT_RATE_TEXT	How would you rate your experience with us?	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
711af4fc-f215-4f53-beb9-dcd03a2e5393	en_IN	CS_COMPLAINT_SUBTYPE_TEXT	The complaint type you have chosen has following complaint sub-types. Select the option of your choice from the list given below.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
452ae8b2-f5a2-4dcb-9bb8-e365092dba91	en_IN	CS_COMPLAINT_TYPE_OTHERS	Others	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
938da9bc-c44d-4684-b867-8bba0381ce35	en_IN	CS_COMPLAINT_TYPE_TEXT	Select the option related to your complaint from the list given below. If the complaint type you are looking for is not listed select others.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1ab1af2f-b5b3-47ef-9120-4994498d1ec3	en_IN	CS_CREATECOMPLAINT_MOHALLA	Locality	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e19e0e48-a576-4dec-a911-487b801babd9	en_IN	CS_FEEDBACK_ENTER_RATING_ERROR	Please rate your experience between 1-5 stars	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1c100909-a139-4fc3-9dc9-2ac9e2f5f0f6	en_IN	CS_FEEDBACK_OTHERS	Others	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
316ef44d-f71c-4c0c-85f9-30e61df0fb69	en_IN	CS_FEEDBACK_QUALITY_OF_WORK	Quality of Work	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8e40c596-2ccd-499f-8eb9-3be06f09e0b8	en_IN	CS_FEEDBACK_RESOLUTION_TIME	Resolution Time	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ee22cd63-cb5e-4044-82cb-3d4fe88ab853	en_IN	CS_FEEDBACK_SERVICES	Services	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2c486a55-4b7a-44c7-94e9-6f7cd499d311	en_IN	CS_FEEDBACK_WHAT_WAS_GOOD	What was good ?	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
46d36640-7925-4c23-82bd-b64722db1c7b	en_IN	CS_FILE_APPLICATION_PROPERTY_LOCATION_PROVIDE_LANDMARK_TITLE_TEXT	Provide the landmark to help us reach the complaint location easily.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3cf6453e-9e87-468d-b4fd-01295094be79	en_IN	CS_HEADER_COMPLAINT_SUMMARY	Complaint Summary	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
32eadc0f-f419-4dac-ad82-0b16df886e52	en_IN	CS_HOME_MY_COMPLAINTS	My Complaints	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c4bf1894-ac17-40b6-bd07-c876c4eac2a7	en_IN	CS_MANDATORY_COMMENTS	Comments are mandatory	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6d7ca3b4-007b-48c3-8585-02987518f4d5	en_IN	CS_MYCOMPLAINTS_NO_COMPLAINTS	You haven't logged any complaints yet. \nStart with one, make a change.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
516e6974-5923-40f7-bcf9-66f7a67acd0b	en_IN	CS_MYCOMPLAINTS_NO_COMPLAINTS_EMPLOYEE	No Records Found	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1491f474-a09f-4db1-819b-6bfb96cd1bee	en_IN	CS_PGR_COMPLAINT_DETAILS	Complaint Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ebbbdcd2-0ba4-4b58-b87f-4151ffe18c02	en_IN	CS_PGR_COMPLAINT_NUMBER	Complaint No.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7f5b6af3-9037-40e9-b27d-e23bc57fd89e	en_IN	CS_PGR_CREATE_COMPLAINT	Create Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
64727848-7a6d-4076-8cf1-c6fc685e3526	en_IN	CS_PGR_LOCALITY	Locality	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1395873f-dd0e-4d31-bd16-729f3bf85f67	en_IN	CS_PGR_RESPONSE	Response	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a861a9ba-55ac-4d0f-86ab-3e2a0144c631	en_IN	CS_PGR_SEND_COMMENT	Send	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
116a58c5-fae1-4535-a905-2d9743b030d9	en_IN	CS_PROFILE_EMAIL_ERRORMSG	Invalid Email Id	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f14f2de8-330c-46ec-acc3-eb82bb64d036	en_IN	CS_REJECT_COMPLAINT	Employee Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fc73a3d3-185f-4cfa-b189-0e1167b5d246	en_IN	CS_REOPEN_COMPLAINT	Choose Reason to Re-open the Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5edbb7e6-f877-4816-9876-163bfdbf60f5	en_IN	CS_REOPEN_OPTION_FOUR	No permanent solution	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
705d5d74-c02d-4471-8188-21797a98faf4	en_IN	CS_REOPEN_OPTION_ONE	No work was done	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e6437e1b-982d-46f0-885e-11f13a724517	en_IN	CS_REOPEN_OPTION_THREE	Employee did not turn up	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d6baafeb-4269-4937-a8f9-ae0d6b5fb338	en_IN	CS_REOPEN_OPTION_TWO	Only partial work was done	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9df2a6b9-40a1-470e-b7d1-7c6375fee828	en_IN	CS_UPLOAD_RESTRICTIONS	**Upload restrictions	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c11c2786-93b4-4c24-9c23-d1db7b709140	en_IN	DASHBOARD_CITIZEN_SERVICES_LABEL	Citizen Services	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f4907bf7-82fe-4ddf-bffc-2f9a7915d740	en_IN	DASHBOARD_WHATS_NEW_LABEL	Whats New	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bd6f70e9-01bd-4bab-be9c-a3cefcf0c2b0	en_IN	DEPT_1	Street Lights	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1d638dbd-2a87-4f33-bdd5-34404fc1372a	en_IN	DEPT_3	Garbage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4348ecf0-ccda-4208-a324-d50da8028503	en_IN	ES_COMMON_CLEAR_SEARCH	Clear Search	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a487fa8b-e40a-4d9e-a23c-3b8d98e0a48f	en_IN	ES_COMMON_FILTER	Filter By	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
39100ba5-e92f-4588-a15f-bc673fd9ec13	en_IN	ES_COMMON_FILTER_BY	Filter By	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cb880326-d240-4a3b-b238-fb3c6f97aa86	en_IN	ES_COMMON_INBOX	Inbox	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e9ec5595-50db-4649-958c-c15e6264a706	en_IN	ES_COMMON_SEARCH	Search	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b76009dd-e8fe-4c85-b584-5d5ded96a21b	en_IN	ES_COMMON_TRACK_COMPLAINT_TEXT	The notification along with complaint number is sent to your applicant’s mobile number. Applicant can track the complaint status using mobile or web app.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
432ae227-f9b8-4e87-9341-8ec2b0c3f5cb	en_IN	ES_CREATECOMPLAINT_ADDRESS	Address	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4b57d42b-1fd5-440a-86c1-edc79e539845	en_IN	ES_CREATECOMPLAINT_COMPLAINT_NAME	Citizen Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4c76b5cf-29c6-4228-acd4-23cc77c374c0	en_IN	ES_CREATECOMPLAINT_FOR	Complaint For	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2181b069-61b6-43d3-99cf-e13cbd283068	en_IN	ES_CREATECOMPLAINT_MOBILE_NUMBER	Citizen Mobile No.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5f6620ea-5860-483b-821b-c6f2fd627216	en_IN	ES_CREATECOMPLAINT_NEW_COMPLAINT	New Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
74e83e00-b5f6-41d3-93c8-3ceaef583972	en_IN	ES_CREATECOMPLAINT_PROVIDE_COMPLAINANT_DETAILS	Complainant Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
073fd281-48dc-44a7-806c-935f14961607	en_IN	ES_PGR_FILTER_STATUS	Status	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
984f3829-11ef-4e61-b4a7-5ed356306bb9	en_IN	ES_PGR_HEADER_COMPLAINT	Citizen Complaint Resolution System	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4d4b411e-c84c-47cb-8fb5-46c411551c8a	en_IN	ES_PGR_INBOX	Inbox	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
03426a1f-d751-4945-8ecf-dd2bdaae4a84	en_IN	ES_PGR_NEW_COMPLAINT	New Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
79fbb8fe-05f9-45c1-9a28-9be90cfc2561	en_IN	ES_SEARCH_BOTTON	SEARCH	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d08ca0d8-996b-4df4-82a5-41a205aa3b73	en_IN	FAILED_TO_UPDATE_COMPLAINT	Failed to update the complaint, please try again later.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
865d11b2-1a74-4fd7-83ba-555b1575d424	en_IN	HR_COMMON_TABLE_COL_DEPT	Department	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
232a767a-1394-4c88-ab2c-feb035e09bda	en_IN	MYSELF	Myself	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
34ee904f-8b5e-4b58-8b86-50f1d82e5652	en_IN	NO_RESULTS_FOUND	No Results Found	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f840a21e-505a-407c-8e4e-b2e6acf94ddb	en_IN	PGR_ACTION_REJECT	Reject Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
02c554c8-58e9-41c5-9e6a-10e0ed9f0da9	en_IN	PGR_ACTION_RESOLVE	Resolve Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b2e34bb6-aeea-4f07-a123-a21c4a0bee8b	en_IN	PGR_CITIZEN_APPLY_PENDINGFORASSIGNMENT_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} has been submitted with ID {id} on {date}. You can track your complaint status on the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
50dbd1a9-d440-4a7b-a7f6-22b4ad6974be	en_IN	PGR_CITIZEN_ASSIGN_PENDINGATLME_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been assigned to {emp_name}, {emp_designation}, {emp_department}. You can track your complaint status and connect with our officials on the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0a16b42b-3a91-43d2-bfd5-2d7a167ba66d	en_IN	PGR_CITIZEN_REASSIGN_PENDINGFORREASSIGNMENT_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been re-assigned to {emp_name}, {emp_designation}, {emp_department}. You can track your complaint status and connect with our officials on the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ffb70904-e336-45d5-9421-30290b1c6fec	en_IN	PGR_CITIZEN_REJECT_REJECTED_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been rejected. Reason for Rejection: {additional_comments} If you wish to re-open the complaint, you can visit the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ea1b165f-bcc7-480e-b128-704eb22fdb5b	en_IN	PGR_CITIZEN_REOPEN_PENDINGFORASSIGNMENT_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been Re-opened as per your request. You can track your complaint status and connect with our officials on the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6b9d1e1c-622a-4496-ae3d-6127fd17bbe1	en_IN	PGR_CITIZEN_RESOLVE_RESOLVED_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been resolved by {emp_name}. If you are not satisfied with service you can RE-OPEN complaint through web portal or by calling your nearest municipal office.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
07606a4e-5713-4779-8971-7556d7ac1829	en_IN	PGR_EMPLOYEE_ASSIGN_PENDINGATLME_SMS_MESSAGE	Shri {emp_name}, Complaint for '{complaint_type}' with ID {id} has been assigned to you. Please take appropriate action. {ao_designation} - {ulb}.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1862e8b4-02fb-41c3-8643-77f1c2e0fe58	en_IN	PGR_EMPLOYEE_RATE_CLOSEDAFTERREJECTION_SMS_MESSAGE	Shri {emp_name}, Complaint for {complaint_type} with ID {id} has received {rating}/5 feedback from the citizen. Thank you for your service.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
87783dec-81a4-4f11-b09f-c9efa90bf81b	en_IN	PGR_EMPLOYEE_RATE_CLOSEDAFTERRESOLUTION_SMS_MESSAGE	Shri {emp_name}, Complaint for {complaint_type} with ID {id} has received {rating}/5 feedback from the citizen. Thank you for your service.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bbd47790-5f63-4d05-aa42-cd7add5b3b6f	en_IN	PGR_EMPLOYEE_REASSIGN_PENDINGFORREASSIGNMENT_SMS_MESSAGE	Shri {emp_name}, Complaint for {complaint_type} with ID {id} has been re-assigned as per your request. {ao_designation} - {ulb}.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2f09d4e1-671f-4871-b267-83197925e811	en_IN	PGR_EMPLOYEE_REOPEN_PENDINGFORASSIGNMENT_SMS_MESSAGE	Shri {emp_name}, Complaint for {complaint_type} with ID {id} has been Re-opened by the citizen. It is being reviewed by Assigning officer - {ulb}.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
35b0ed70-51e9-4fd6-8745-8084b664d975	en_IN	PROFILE_UPDATED	Profile is successfully updated	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
311d9eb7-5e0d-4949-a899-8f51aec1b47a	en_IN	REASSIGN	Re-assign	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7eebaa38-7526-4747-a415-19dea9f6a419	en_IN	REASSIGN_SUCCESSFULLY	Re-assigned Successfully	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3a3be1dc-17a2-48d3-8219-dd6bdbb82f33	en_IN	REJECT	Reject	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
35671cc3-6ad0-4209-a2cf-2b19a59fbb63	en_IN	REJECT_SUCCESSFULLY	Rejected Successfully	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e141393b-abc8-4b31-9215-0c779261a9ae	en_IN	REOPEN	Re-Open	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
930149a2-70bd-4b9c-9729-8a69175f2cb1	en_IN	REOPEN_SUCCESSFULLY	Reopened Successfully	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e3b369ca-6c93-4758-9b38-8b11cc1eab45	en_IN	RESOLVE	Resolve	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c40a4635-5175-4126-a458-549bb842798d	en_IN	RESOLVE_SUCCESSFULLY	Resolved Successfully	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8b636f9f-3890-4520-8c55-b99fb8e4956f	en_IN	CS_COMPLAINT_DETAILS_PIN_LOCATION	Pin Location	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
69339a66-c165-4a99-9749-f1054745f9a3	en_IN	PGR_INBOX_TAB_MY	My Complaints	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
21640cd8-974f-4acd-b89d-39a3b0a587db	en_IN	PGR_INBOX_TAB_ALL	All Complaints	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
010db89a-459f-4ee6-9fe1-224a45cfa9c5	en_IN	CS_CANNOT_REOPEN_COMPLAINT_PAST_DEADLINE	The window for reopening this complaint has closed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
767980b1-5a6a-4310-be1a-71ddc67539a7	en_IN	ACTION_TEST_LOCALISATION	Manage Localisation	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7d63b1af-17a6-4cc9-8f9a-0fe02130cfe6	en_IN	ACTION_TEST_MDMS	Manage Master Data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ad95b7d4-1ea3-4f72-813c-776b6b90f817	en_IN	ACTION_TEST_UPLOAD_BOUNDARY	Manage Boundary Data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
30f8657c-bc3a-4b32-8c06-b0737c012f84	en_IN	ACTION_TEST_WORKBENCH	Workbench	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5ad48912-bc42-4ffd-909a-be1fc6ff3e24	en_IN	ADD_NEW_ROW	Add Row	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
58d87053-c765-4e9b-96e5-4388e50f720d	en_IN	CLEAR_LOC_TABLE	Clear	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dfdffe40-33c3-4be1-9d4c-acd287bf0e0f	en_IN	COMMON_CORE_COLLAPSE	Collapse	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2103070a-6d38-48ab-94c2-545a0dc40705	en_IN	COMMON_CORE_EXPAND	Expand	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
32f4390e-c1c9-463b-bd35-6ba78def3421	en_IN	CORE_COMMON_SAVE	Save	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cd7da0cb-275c-4f09-9bc7-bacb0138c48e	en_IN	CS_COMMON_ACTION	Action	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c616e8e8-dbcb-46b1-b6b2-40a986393016	en_IN	DUPLICATE_RECORD	Duplicate Record	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9ef716ba-7eb3-4e56-ad4b-1dd4d5df11a9	en_IN	ES_COMMON_CLEAR_SEARCH	Clear Search	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7e4d2e2b-2396-4384-99c3-73f80df75e9e	en_IN	ES_COMMON_ENTER_DATE_RANGE	Enter date range	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ae869e64-7a79-4436-9481-af9c1bacdef0	en_IN	ES_COMMON_NA	NA	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bac03644-feca-4372-8b6f-8492e6fdbd1d	en_IN	ES_COMMON_SEARCH	Search	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2e85ae0d-df39-4154-b472-f1a839b2a837	en_IN	LOCALISATION_SEARCH	Manage Localisation	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bc7aca9b-7026-497f-8183-e9a709cdb650	en_IN	MDMS_VIEW	View Master Data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1eff1dbb-97ce-4780-8164-8f8f97c0328a	en_IN	UNIQUE_IDENTIFIER_EMPTY_ERR	Unique fields cannot be empty.	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0c29be37-969d-489f-bc42-d3f01b066a29	en_IN	WBH_ADD	Add	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
33e4d79c-5e15-4ea6-9f3a-13b3963d592d	en_IN	WBH_ADD_LOCALISATION	Add New	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
26a35ade-df8e-4241-81ad-de299b4c0d6e	en_IN	WBH_ADD_MDMS	Add Master data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7c79e82f-4f7e-408c-9b71-7bac14ebb2a8	en_IN	WBH_ADD_MDMS_ADD_ACTION	Add data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
697ce72c-2347-4e50-b8c8-eb630e3f889a	en_IN	WBH_ADD_MDMS_UPDATE_ACTION	Update	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4761fd10-9c6c-4a15-9b71-1435afe86ae9	en_IN	WBH_BOOLEAN_VALUE_FALSE	FALSE	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9936ae84-58d0-4206-8442-9959f483014a	en_IN	WBH_BOOLEAN_VALUE_TRUE	TRUE	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a94bbf07-6cd1-4977-9dda-ddedf364e205	en_IN	WBH_BULK_BROWSE_FILES	bulk upload files	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
86b76c38-ab24-4521-9fb2-d49b633ac40c	en_IN	WBH_BULK_UPLOAD	Upload	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
344c159b-c64a-4455-8678-d7a4fa1659db	en_IN	WBH_BULK_UPLOAD_HEADER	Bulk Upload	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
89677165-13ac-462b-adea-ad82a17dd34a	en_IN	WBH_BULK_UPLOAD_SUBMIT	Submit	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
15e319df-72a3-42cb-a1b7-3547cb56eef2	en_IN	WBH_CANCEL	Cancel	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ecd223c3-47f3-44e0-9301-748f4c65a82f	en_IN	WBH_COMMON_ALL	All	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a6877583-f7b8-413f-ab7c-8ca48ff62408	en_IN	WBH_COMMON_NO	No	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
05cb8513-8c2e-42f6-920a-1bbb896f3023	en_IN	WBH_COMMON_YES	Yes	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0723e0d8-a147-42cc-9d27-7454dfcbd66b	en_IN	WBH_CONFIRM	Confirm	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4118585f-8855-4880-b949-ce9d8a2dcb11	en_IN	WBH_DELETE_ACTION	Delete	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0ba59393-be92-448f-b8de-9fb99906e08e	en_IN	WBH_DOWLOAD_TEMPLATE	Download Template	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c515a05f-4494-427b-ab68-74f602a44626	en_IN	WBH_DOWNLOAD_TEMPLATE	Download Template	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3ce8df1f-122a-4574-82cc-2fec6cbed61c	en_IN	WBH_DRAG_DROP	Drag & drop	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9075b3a8-ebc0-4e83-ad11-0f9e662926a3	en_IN	WBH_EDIT_MDMS	Edit Master Data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ae2feece-f5b7-40c3-9293-3dd5d066ce94	en_IN	WBH_ERROR_MDMS_DATA	Error : Error	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fbebe2d3-f7fb-45c7-8024-75a834d01b72	en_IN	WBH_FIELD	Field	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
18dffb38-7bcf-408a-ab61-2174b97b24b5	en_IN	WBH_FIELD_VALUE	Value	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3698933f-b46a-4067-980d-94bedce97faa	en_IN	WBH_INFO	Info	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2ca425f0-c5ca-4b21-8ba9-76f4ed4e2a1e	en_IN	WBH_INFO_MESSAGE	Below is the list of localizations data. Please add or modify as needed.	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
072dc87d-e9ea-4f8e-9878-b90868743ff4	en_IN	WBH_ISACTIVE	Active (Yes/No)	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9df19243-36a5-4952-a267-093cfd9e0ff3	en_IN	WBH_LOCALISATION_SEARCH_HEADER	Localisation Data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9cb58929-9b77-4499-a291-8bcf6a320583	en_IN	WBH_LOC_ADD	Add Localisation	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d10f9f38-3a38-4ac3-9bda-b9f172a8e7c1	en_IN	WBH_LOC_BULK_UPLOAD_XLS	Bulk Upload	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b8622e0c-3fbc-4059-9765-8ff41d3d0a6d	en_IN	WBH_LOC_CODE	Keycode	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
89919227-76af-45c6-8d7e-22cef4e0a4d6	en_IN	WBH_LOC_DEFAULT_INFO_MESSAGE	Messages will also be upserted into default locale	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cffd2a1a-a4d3-40c9-9e8e-74cee6b9b190	en_IN	WBH_LOC_EDIT_LOCALISATION	Update Localisation	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bb800c20-1ee8-47fb-b59a-6b5fa0e498c0	en_IN	WBH_LOC_EDIT_MODAL_CANCEL	Cancel	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
07e9dcdd-8244-4ec7-8912-87f72845e54b	en_IN	WBH_LOC_EDIT_MODAL_SUBMIT	Submit	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
88387de5-bc08-4c2c-93b2-b3402bdc87f9	en_IN	WBH_LOC_EMPTY_KEY_VALUE_VALIDATION_ERR	Keycode/Text should not be empty	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c8dd4e8d-0c73-4180-a421-3fd0be289a5f	en_IN	WBH_LOC_ENTER_VALID_MESSAGE	Please Enter Valid Text	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c3523420-8e86-4b70-8f76-68d553dc62b0	en_IN	WBH_LOC_HEADER_CODE	Keycode	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
73e9421b-f7f7-4ac9-9ff0-7ecc05f51b67	en_IN	WBH_LOC_HEADER_DEFAULT	Default Value	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1f208fb5-8ddc-46ad-b472-6a964732978d	en_IN	WBH_LOC_HEADER_MESSAGE	Text	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e72b32e5-f5d7-4ecf-96d5-7629b91f44e8	en_IN	WBH_LOC_HEADER_MODULENAME	Module Name	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c8b66d59-acfd-4301-85ba-aeb156d33b4d	en_IN	WBH_LOC_KEYCODE	Keycode	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b26e3522-cbcb-489d-b9dc-b203aa0ec30d	en_IN	WBH_LOC_LANG	Language	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cce55224-493b-4dbd-84af-1cda6bfec45b	en_IN	WBH_LOC_LOCALE	Locale	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
24287298-80e8-4671-ad15-53398ee504e4	en_IN	WBH_LOC_MESSAGE	Text	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5bc42566-b6f7-465e-8fd1-fe7ee84bbff6	en_IN	WBH_LOC_MESSAGE_VALUE	Text	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
11f0923d-2b74-4a9a-9845-463ba07f6ad6	en_IN	WBH_LOC_MODULE	Module	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b66762b3-773e-4e36-a810-83606c3ee72d	en_IN	WBH_LOC_SELECT_LANG	Select Language	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a1447398-de20-484a-b8f1-72c3fc2474d2	en_IN	WBH_LOC_SELECT_MODULE	Select Module	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
02f5c7e9-a325-4c86-aae5-bb0eef84e9ef	en_IN	WBH_LOC_UPDATE_FAIL	Localisation Update Failed	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7687f117-4d15-4364-a1a3-05c9b4d18127	en_IN	WBH_LOC_UPDATE_SUCCESS	Successfully updated	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f86706c9-8d51-4ea0-8550-b79fe538961c	en_IN	WBH_LOC_UPSERT_FAIL	Localisation Upsertion Failed	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b90e1634-e528-4b5a-8656-7969f0136249	en_IN	WBH_LOC_UPSERT_SUCCESS	Localisation Upserted Succesfully	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
90d414c3-b2a0-4995-af83-616aba98bf9f	en_IN	WBH_LOC_WARNING_LOCALE_MUST_BE_PRESENT	Language must be present	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
27f8df1c-8ae0-4675-bc8e-92dd28b2442b	en_IN	WBH_MANAGE_MASTER_DATA	Manage Master data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4b33281d-a9fb-4c69-a290-8f5be32aa3ad	en_IN	WBH_MDMS_MASTER_ACCESSCONTROL_ACTIONS_TEST	ACCESSCONTROL-ACTIONS-TEST	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
12cd35c8-9c1c-403a-9361-198ca1add1a0	en_IN	WBH_MDMS_SEARCH_VALIDATION_FIELD_VALUE_PAIR	Please enter both field and value	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2889de39-5782-4e63-831c-0bafdf282bbd	en_IN	WBH_SEARCH_MDMS	Manage Master data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2b3951f9-da93-4477-9f49-fee34c4807a5	en_IN	WBH_SHOW_JSON	Show JSON	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0a467568-501d-41c6-af87-f6c935aa7684	en_IN	WBH_SUCCESS_MDMS_MSG	Success : Data added Successfully with Id	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
00707d88-7705-4ea6-b933-4f08b7dc4878	en_IN	WBH_SUCCESS_UPD_MDMS_MSG	Data updated successfully with id	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bc927826-3aaa-464f-a911-140d47969cd6	en_IN	WBH_UNIQUE_IDENTIFIER	Unique Identifier	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
44ba3bb4-8b35-4703-89c7-eb56c6f0f1fb	en_IN	WBH_VIEW_MDMS	View Master Data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8feb9ea2-9f74-441a-9c33-54eeb790f498	en_IN	WORKBENCH_ACTIONS	Actions	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
54589392-000c-41f3-94d0-3cb4ad853a82	en_IN	WORKBENCH_HOME	Workbench	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4a4b6d04-36c4-47e2-847a-11b4c178d3a9	en_IN	WORKBENCH_LABEL_SELECT	Select	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2cd8459d-6ddb-4d18-a0ee-a08f8d0decd2	en_IN	WORKBENCH_LABEL_VIEW_MORE	View more	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7b4a32fd-3ecc-4b24-89a9-e78524febe45	en_IN	ACTION_TEST_0HOME	Home	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
21e96fc3-0df5-4057-8eb6-e5341c957ee9	en_IN	ACTION_TEST_9MASTERDATA	Master Data	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
12e60d4e-07b9-49ba-909b-5e5a20fc3122	en_IN	ACTION_TEST_9MDMS	Manage Master Data	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
49bb163b-aacc-437b-9a8c-69e7cbac66cc	en_IN	ACTION_TEST_9TEST	TEST	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
95f0596e-ea8b-4c67-905a-30fa0bd87089	en_IN	ACTION_TEST_ADMINISTRATION	Administration	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
27bfa534-50d1-4481-81ee-eb326ca282be	en_IN	ACTION_TEST_ALL_COMPLAINTS	All Complaints	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
202a9df7-bf16-4389-b9e2-e3aa8a94ae6e	en_IN	ACTION_TEST_APPLICATION	Application	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f1a6b0d5-3516-4bbb-bd7a-2d68254c7bc6	en_IN	ACTION_TEST_APPLICATION_STATUS	Application Status	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8fc60dc1-3e7b-4cda-adac-05ff4a39c904	en_IN	ACTION_TEST_APPLICATION_STATUS_REPORT	Appliction status report	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9813ce07-8de8-4069-9be0-df78df89b39f	en_IN	ACTION_TEST_APPLY	Apply	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7cb28424-63ad-43ae-8dde-2d79760aba4c	en_IN	ACTION_TEST_COMMONMASTERDEPARTMENT	Department	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bc57b30a-9dcc-482c-9114-69d1ef707355	en_IN	ACTION_TEST_COMPLAINTS_TYPE	Complaint Types	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
80a0fb65-b5b1-4ce9-95c1-058181a8ca1d	en_IN	ACTION_TEST_CREATE_EMPLOYEE	Create Employee	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8a9424a7-9758-4993-99d5-dd33c8331a7f	en_IN	ACTION_TEST_DEPARTMENT	Department	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
68b5a704-f0a2-40ee-9888-663d7b9aa89a	en_IN	ACTION_TEST_DEPARTMENTS	Departments	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
39dffa33-2514-468a-8315-45334093000e	en_IN	ACTION_TEST_EMPLOYEE	Employee	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c9dbd420-2393-4686-ab3d-50d79af9e8ba	en_IN	ACTION_TEST_EMPLOYEEDIRECTORY	Employee Directory	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1d82ddb2-d35b-4b13-9626-4b8e17b8936f	en_IN	ACTION_TEST_EMPLOYEEINBOX	Employee Inbox	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4945486d-6186-4d7b-b15a-d7986a6cd8d1	en_IN	ACTION_TEST_EMPLOYEE_REPORT	Employee Report	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a8016067-c3f6-459e-8895-cb3f0731bb1a	en_IN	ACTION_TEST_EVENTS	Events	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b9bf3627-3663-43da-a977-5b75e04fe613	en_IN	ACTION_TEST_FAQS	FAQs	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5f17f1d3-e33e-46dc-a109-05c5b7cf1366	en_IN	ACTION_TEST_FILE_COMPLAINT	File Complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2b350bf4-9fc9-4d0b-80b8-b6b6280eb122	en_IN	ACTION_TEST_GRO_PERFORMANCE_REPORT	GRO Performance Report	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9247c481-2ae9-447e-92c8-2e08b1462d62	en_IN	ACTION_TEST_IFRAME	iFrame	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a672348a-0154-4bf7-a89b-e218ea6b5600	en_IN	ACTION_TEST_LANGUAGE	Language	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fc97db46-c28d-4965-b7e8-987fa48cb050	en_IN	ACTION_TEST_LANGUAGES	Language Selection	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9efba4e5-3790-4a83-b976-720c7e925e77	en_IN	ACTION_TEST_LME_PERFORMANCE_REPORT	LME Performance Report	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4aedcbde-04a5-47de-8c4c-dc723aebe099	en_IN	ACTION_TEST_LOCALIZATION	Localization	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
77faf4ab-526d-46c3-be69-00ed97a7a5c9	en_IN	ACTION_TEST_MANAGE_DEPARTMENT_MASTER	Department Master	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e0903a03-5755-4e1f-955f-34e2431a8b78	en_IN	ACTION_TEST_MANAGE_EMPLOYEETYPE_MASTER	Employee Master	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
38accd84-a3e6-452f-9b2c-1eb80b29fb79	en_IN	ACTION_TEST_MANAGE_PGR_SERVICE_DEF_MASTER	CCRS Service Def Master	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
10608cfd-e8fe-452e-9662-b6a312af30f4	en_IN	ACTION_TEST_MANAGE_UOM_MASTER	UOM Master	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
448d950c-042c-4aa0-93fa-4382dee8a39b	en_IN	ACTION_TEST_MYCOMPLAINTS	My Complaints	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
478c88d5-9929-4d10-9176-251468478fff	en_IN	ACTION_TEST_OPEN_COMPLAINTS	Open Complaints	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ad4c0a0a-23f0-424f-a8cc-42b06184ef36	en_IN	ACTION_TEST_OVERVIEW	Overview	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0781fda4-3d01-413b-b394-95e0d45d2e68	en_IN	ACTION_TEST_PGRSERVICEDEFS	Citizen Complaint Resolution System Services	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e451b26a-5db4-4e09-b324-e810760386f9	en_IN	ACTION_TEST_PGR_DASHBOARD	Citizen Complaint Resolution System Dashboard	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c5aba959-3c8f-4ef1-be2a-16f67968e351	en_IN	ACTION_TEST_PGR_REPORTS	Citizen Complaint Resolution System Reports	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3671dba6-7ba2-49ec-bd83-2d5a66989213	en_IN	ACTION_TEST_PGR_ULB_DASHBOARD	Citizen Complaint Resolution System ULB Dashboard	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5cb9aeff-464b-433e-b8fc-73a2968c8cc3	en_IN	ACTION_TEST_ROLEACTIONS	Role Action	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
62006222-502d-4bc9-b82a-3005c539f989	en_IN	ACTION_TEST_ROLES	Roles	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
68cda8ef-0734-4cb7-8529-ca092e45ab18	en_IN	ACTION_TEST_SEARCHAPPLICATION	Search Application	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
40de3277-06cc-4c75-b46c-f3003ffcde89	en_IN	ACTION_TEST_SEARCH_COMPLAINTS	Search Complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
11a4b4e4-2755-4b28-8acd-6d0efcd849db	en_IN	ACTION_TEST_SEARCH_EMPLOYEE	Search Employee	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cf34dbfb-56ab-4e47-bdc8-39b6fe09de4b	en_IN	ACTION_TEST_TENANT	Tenant	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2d99e4b2-1044-41a1-9910-8193dc3e233b	en_IN	ACTION_TEST_UPDATE_DEPARTMENT_MASTER	Department Master	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c02807df-db16-4b03-b641-818ddd6e55c2	en_IN	ACTION_TEST_UPDATE_EMPLOYEETYPE_MASTER	Employee Type Master	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
56d06724-3e52-4bc8-9215-0701cf2c5457	en_IN	ACTION_TEST_UPLOADER	Uploader	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c7046f8c-318d-483d-a707-63aa7cfbb131	en_IN	ACTION_TEST_UPLOAD_BUDGET	Upload Budget	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
30200ce3-33a0-44dd-9a02-356e80f49c74	en_IN	ACTION_TEST_CLOSED_COMPLAINTS	Closed Complaints	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
22c068c3-a64f-4fac-a39a-3d716a7e886e	en_IN	ACTION_TEST_NATIONAL_PGR	Citizen Complaint Resolution System	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
991e6196-dcd6-45b2-8dcb-e712cc6fc7de	en_IN	ACTION_TEST_MANAGE_DEPARTMENT_MASTER	Manange Department Master	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
15cc5f87-0391-42c8-9602-47b76f3fac6c	en_IN	ACTION_TEST_MANAGE_EMPLOYEETYPE_MASTER	Manage Employee Master	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
974bde89-95fe-4578-b66e-fa24a6850c2f	en_IN	hrms.employee.create.notification	Hi $employeename, Welcome to mSeva. Your profile has been successfully set-up : Username - $username Password - $password, Thank you.	pg	egov-hrms	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1f779d78-8dcb-4030-9665-9f608c3e9c94	en_IN	hrms.employee.reactivation.notification	Dear <Employee Name>,\nYour profile with employee Username <Username>has been activated on <date>.	pg	egov-hrms	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c7895377-72a1-4d3f-b696-7a5a9ffd241c	en_IN	ACCESSCONTROL_ROLES_ROLES_CEMP	Counter Employee	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
84f8fcdf-7781-416f-a116-c09c19677484	en_IN	ACCESSCONTROL_ROLES_ROLES_EMPLOYEE	Employee	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6eda3f93-cfdf-442c-9653-c3c01312951b	en_IN	ACCESSCONTROL_ROLES_ROLES_EMPLOYEE_ADMIN	EMPLOYEE ADMINr	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a4776c0c-56a8-4199-82dc-981678be7ce3	en_IN	ACCESSCONTROL_ROLES_ROLES_GO	Grievance Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
740e55ab-e5c6-4d90-9b9b-324edd1f70ff	en_IN	ACCESSCONTROL_ROLES_ROLES_GRO	Grievance Routing Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6fb86ec2-0d44-44af-b5b4-134e1fa2a03a	en_IN	ACCESSCONTROL_ROLES_ROLES_HRMS_ADMIN	HRMS ADMIN	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
23a5043c-3e09-49fc-894f-7cef6480c7df	en_IN	ACCESSCONTROL_ROLES_ROLES_PGR-ADMIN	PGR Administrator	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
58f98493-a7f3-4f4e-b9d7-7426f31d6183	en_IN	ACCESSCONTROL_ROLES_ROLES_PGR_ADMIN	CCRS Administrator	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fe997f1c-9268-420c-8eea-afd115fd11f9	en_IN	ACCESSCONTROL_ROLES_ROLES_PGR_LME	CCRS Last Mile Employee	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9afdc1ae-fb19-43a4-80ff-1b2a736b0908	en_IN	CATEGORIES_OF_COMPLAINT_TYPES_CAN_BE_SUBMITTED_ON_GRIEVANCE_PORTAL	categories of complaint types can be submitted on grievance portal. 	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9d83ed1b-d646-4f36-bd54-ef75b29fd3f5	en_IN	CCF_COLLECT_THIS_DATA_INFO_LABEL	We collect data directly from you (when you use our services) as and when you register and login into the app/website. We may also collect data from Union, State, and Local governments, including their agents/employees, as well as receive data that is available openly for public use.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
234baa93-5b02-4a35-a0c6-1563611bbc0f	en_IN	CCF_PP_DO_WE_COLLECT_THIS_DATA_INFO_LABEL	We collect data directly from you (when you use our services) as and when you register and login into the app/website. We may also collect data from Union, State, and Local governments, including their agents/employees, as well as receive data that is available openly for public use.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
effb8c94-7c91-4b62-b57c-d2ecc46c1d54	en_IN	CCF_PP_GRIEVANCES_INFO_LABEL	In case of any grievances, you may send your complaints for redressal over Grievance Portal available at 	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4a8fa841-ad33-4556-9592-b8995ec885bf	en_IN	CCF_PP_GRIEVANCES_INFO_LINK_LABEL	Link	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5f31fcea-4f8b-417f-b787-7947248604b5	en_IN	CCF_PP_GRIEVANCES_LABEL	GRIEVANCES	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3051f789-05fa-4ca0-9ec2-b9a4e15e1e20	en_IN	CCF_PP_HOW_DO_WE_PROCESS_INFO_1_LABEL	We use this data to serve you with the best civic experience, such as providing digital grievance redressal systems, efficient service delivery, creating dashboards of ULB activities, etc. Data is only processed on the basis of a legal mandate and for a legitimate and necessary purpose (to deliver to you the services you are requesting, and to make improvements in service delivery and administration, as well as any other purposes specified by law).	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3d840cff-7bd2-44fd-b91a-a0ffcfd60809	en_IN	CCF_PP_HOW_DO_WE_PROCESS_INFO_4_LABEL	We may disclose or share this data to/with employees and/or contractors of the urban local body, state government, or other government agencies, service providers, whose role requires them to view or use this information in order to perform their official duties, including providing you the service(s) you are requesting.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4462926c-6a2a-4797-854d-85023c1d3366	en_IN	CCF_PP_REFERS_LABEL	Through PROGRAM NAME, you can access and avail services offered by STATE OR ULB NAME Government departments, Central Government department, Local bodies & their agencies and corporate/private bodies (utility services) (Service Providers). You can use PROGRAM NAME website / application / services in different ways such as, service discovery, availing services, registering grievances, and so on.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ded0df3d-891d-4a78-ad40-1473ef3d4b32	en_IN	CCF_PROCESS_DISCLOSE_SHARE_EMPLOYEES_LABEL	We may disclose or share this data to/with employees and/or contractors of the urban local body, state government, or other government agencies, service providers, whose role requires them to view or use this information in order to perform their official duties, including providing you the service(s) you are requesting. 	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2cc048fc-374d-469c-8d7a-d7dfd95afc3b	en_IN	CCF_PROCESS_DISCLOSE_SHARE_INFO_LABEL	We use this data to serve you with the best civic experience, such as providing digital grievance redressal systems, efficient service delivery, creating dashboards of ULB activities, etc. Data is only processed on the basis of a legal mandate and for a legitimate and necessary purpose (to deliver to you the services you are requesting, and to make improvements in service delivery and administration, as well as any other purposes specified by law).	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
49bf29ae-e4e2-47ad-b92f-2c2ef0308c7c	en_IN	CITIZEN_CONSENT_FORM_PP_ACCESS_AVAIL_LABEL	Through PROGRAM NAME, you can access and avail services offered by STATE OR ULB NAME Government departments, Central Government department, Local bodies & their agencies and corporate/private bodies (utility services) (Service Providers). You can use PROGRAM NAME website / application / services in different ways such as, service discovery, availing services, registering grievances, and so on.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0d0d1dba-0e55-4013-a0a1-808add10a53b	en_IN	COMMON_ASSIGNEE	Assignee	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1941bf31-06c1-4dec-b142-5007c5c56b8c	en_IN	COMMON_DESGN_OF_OFFICER_IN_CHARGE	Designation of officer In-charge	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
671acedc-3e80-449b-9004-a35494fb238b	en_IN	COMMON_INBOX_ASSIGNED_TO_ALL	Assigned to all	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4d15d023-8bfb-4e5b-a426-45f40608b638	en_IN	COMMON_INBOX_ASSIGNED_TO_ME	Assigned to me	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7b736510-459f-4429-9ef4-33b12d547da2	en_IN	COMMON_INBOX_TAB_ASSIGNED_TO_ME	Assigned to me	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
089a9021-b01b-453a-aa57-b80a1cd2b713	en_IN	COMMON_MASTERS_DEPARTMENT_ACC01	ACCOUNTS	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a374d9c4-9df1-40bc-a361-98b3b2dabd5d	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_10	Help Desk	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fc7933c9-3383-495e-a3ef-844c5d93b7cd	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_11	Housing and Urban Development	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7e44fd1c-8cfb-4415-a22d-4f5f8b9a112c	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_12	Birth and Death Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
51a7451d-45a8-4119-9bfe-36cd95e8e698	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_13	Tax Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
36573aa3-a024-49d0-bca2-2a5c502460b4	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_14	Civil	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d2851c8f-0876-49d0-91da-6c8ae74903e2	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_15	Engineering Branch (O&M - W&S)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9b5e28b2-471f-492a-a49f-5738ddddddfa	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_16	Health Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a64b3084-eedb-4a5b-8d6c-0601e7f097e9	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_17	Tehbezari branch (Encroachments)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
565120fe-dd8f-475c-beed-f7db17548ec1	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_18	Engineering Branch (Electrical)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9d5c1985-21d1-4cca-9616-b9b28bc573c4	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_19	Advertisment Tax Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
72d3941b-f47f-4837-82cb-dc9abce237fb	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_20	Complaint Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d7e64b3f-17f5-4faf-8046-54c0f6bcda9d	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_21	Sanitation Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
529ff5d0-a038-4ff4-b429-4b44bab5e8c5	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_22	Engineering Branch (Mechanical)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7ee74b40-a0a1-47fa-9d64-9febc2605f7d	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_23	Tehbazari	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4da8ac1c-5790-4163-b55c-9ba50becdd9b	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_24	Fire Brigade	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
020557b1-5d09-43fd-b17f-f61d2f67b17d	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_25	Accounts Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e508b89c-5f4a-46af-be7b-36857d597010	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_26	Rent	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
54775a01-0f9b-459a-ab6f-706e2aaed0be	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_27	License Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
053aa9f8-1f41-41ea-8407-5bdc888769b8	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_28	Property Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6afc83a8-8007-4206-9602-bf514b3ea1c9	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_29	Receipt and Dispatch Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2b771d1c-65d4-4225-a7f0-9b9fb6101d63	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_30	Tehbazari and Property Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7ddde181-e3d2-41f0-a171-d0eb45953d5b	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_31	Pension and HFA etc	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ce7e5546-fc3a-40ed-860a-2a2ace482804	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_32	Land Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e9bec0e9-48d3-4a04-ad5f-2e2caaa1f62b	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_33	Property Tax Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ebb4624b-56e4-4e91-8a7c-a7475e7a2f40	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_34	Establishment Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ebc7a2e9-b9b7-4877-8c35-9f49322b9874	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_35	Works Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
573480ee-4d7b-4fb0-8ec2-1a21e3bbbfc9	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_41	Water Supply and Sewerage	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1451d94e-c217-4082-a041-d7ea6fc3a8f2	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_42	Executive Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
62647478-469c-4796-9e10-7d18d7883423	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_43	Property and House Tax	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5c9b9bef-f08f-49b7-a174-99430575f2e5	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_44	Purchaser Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8d3c13f5-54b3-4120-a8cd-11534db6ae96	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_45	Engineering Branch (Civil - B&R	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6568a023-3c18-4f73-a0e5-f65501933d07	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_47	Property Tax & Rent & Tehbazari	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6acba763-307a-4f31-9bc2-b6fc5efc0e53	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_49	BPL	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
588de9ed-d028-450b-aa8e-8bb692473349	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_51	Executive Agency	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0ffa5e73-a87d-4b32-97f7-c0fbb0d2bcb1	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_52	Library	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
84a0fb7a-b143-4e1d-ba20-17f0e6ae48b2	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_6	Building Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
005d01ac-8e29-4ffc-b6ca-c0bcb7a8ac45	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_7	Citizen service desk	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8fed69d3-30a5-4111-b6fb-560d716d6e02	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_8	Complaint Cell	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
be3db2af-0cac-4a53-a9fe-e39ca2608c64	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_9	Secretary/General Administration Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c6f0353c-7fa9-4719-a732-929b5aa95eec	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_LG	Legal Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
73764673-703f-4261-aafd-2a04d9a1d86e	en_IN	COMMON_MASTERS_DEPARTMENT_DEPT_TP	Town Planning	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
593a9701-b81a-4080-a1ab-185293c7027d	en_IN	COMMON_MASTERS_DEPARTMENT_ENG	Accounts Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
87a54293-9a60-4baa-be37-3a8d1115afe9	en_IN	COMMON_MASTERS_DEPARTMENT_PHS01	PUBLIC HEALTH AND SANITATION	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a7415d54-cc12-4784-9dbb-272bbaad7d5b	en_IN	COMMON_MASTERS_DEPARTMENT_PWSSB	PWSSB	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5a877c11-605a-43c0-89a4-49bf9b249544	en_IN	COMMON_MASTERS_DEPARTMENT_REV01	REVENUE	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b8fa5247-dc93-4f91-ae4c-1a4edfbec4fd	en_IN	COMMON_MASTERS_DEPARTMENT_TP01	TOWN PLANNING	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5c8c5f99-5e06-4f4c-88db-5e3180e0e4ee	en_IN	COMMON_MASTERS_DESIGNATION_ACC_AO	Accounts Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4e23f8ce-fc8d-46b9-8ec8-e75b8e7bbd03	en_IN	COMMON_MASTERS_DESIGNATION_ACC_JAO	Junior Accounts Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
17d9e0ef-8fbe-405b-8d1d-6ccdbecab51a	en_IN	COMMON_MASTERS_DESIGNATION_ADM_ADMC	Additional Commissioner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bc6b5554-c672-44a8-9211-b4d3cd9baef5	en_IN	COMMON_MASTERS_DESIGNATION_ADM_AEO	Assistant Executive Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1d2334a9-9a89-4f01-babc-3ea921631fee	en_IN	COMMON_MASTERS_DESIGNATION_ADM_AMC	Assistant Commissioner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6d1c06cf-886e-45b2-9887-ab9cbd0ce11d	en_IN	COMMON_MASTERS_DESIGNATION_ADM_DMC	Deputy Commissioner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bb9a5a16-a650-4a69-ab76-bc62823c8a88	en_IN	COMMON_MASTERS_DESIGNATION_ADM_EO	Executive Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
afb87014-13fb-4b1d-8043-fb63f9731b36	en_IN	COMMON_MASTERS_DESIGNATION_ADM_MC	Commissioner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a2e599c5-0ff4-4b33-bf8d-8c4f7489de35	en_IN	COMMON_MASTERS_DESIGNATION_ADP01	Assistant Director, Planning	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dc784286-69fa-468a-ac75-4262bccb4dd1	en_IN	COMMON_MASTERS_DESIGNATION_AE01	Assistant Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f5149bff-6f74-4362-91f4-d7e23ea08ede	en_IN	COMMON_MASTERS_DESIGNATION_AHDO01	Assistant Horticulture Development Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9cca74dd-4c03-4850-9025-ba4cce0cd4ae	en_IN	COMMON_MASTERS_DESIGNATION_AHO01	Assistant Health Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bf6f5176-8c2d-4f3b-9316-8791668e1cb0	en_IN	COMMON_MASTERS_DESIGNATION_AHO02	Animal Husbandry Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5678c8e8-27e4-4b91-adfa-adf56ead062a	en_IN	COMMON_MASTERS_DESIGNATION_AME01	Amen	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ed221f57-bca8-4d76-ab78-b0a2a3585625	en_IN	COMMON_MASTERS_DESIGNATION_AO01	Accounts Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ab9298cf-c109-4728-92bb-00cca85ece7f	en_IN	COMMON_MASTERS_DESIGNATION_AVEO01	Assistant Vigilance and Enforcement Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c7b1e53c-4f62-4754-b53c-6cf1a4d2ee75	en_IN	COMMON_MASTERS_DESIGNATION_CCI01	Chief Cleanliness Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2a091960-17ba-4067-a593-faca538ca2ec	en_IN	COMMON_MASTERS_DESIGNATION_CE	Chief Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
71bd9b37-1fc3-4f22-976b-fd75a9751796	en_IN	COMMON_MASTERS_DESIGNATION_CI01	Cleanliness Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
72bbb4a4-aaa1-4571-9182-5b5b3ef86f19	en_IN	COMMON_MASTERS_DESIGNATION_CLERK	Clerk	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
da6f9808-cf01-4efc-9a82-3d8c33c5e73d	en_IN	COMMON_MASTERS_DESIGNATION_CMFA01	Chief Municipal Finance and Accounts Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9cfff39b-3556-4cbb-ad93-df2ed010175c	en_IN	COMMON_MASTERS_DESIGNATION_DDPA01	Deputy Director, Planning and Architecture	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7ca7ff46-119b-4f08-8d09-49919223fcdb	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_01	Superintending Engineer ( B&R)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fa8a4478-fc36-4524-bc59-d63e9bdd083e	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_02	Corporation Engineer (B&R)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
eee8b2b0-bd46-4f07-b687-721c1be4f3a6	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_03	Asst. Engineer ( B&R)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
315820fb-21e3-4264-98da-7d53f2c15f08	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_04	Junior Engineer ( B&R)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f5a120a5-b5f1-42c2-b808-301bf1860372	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_05	Land Scape Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
594b230b-0d56-491c-aac5-0fc776066f60	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_06	Superintending Engineer ( O&M)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
97d6cd9c-781d-444d-8193-71708a7d83e3	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_07	Corporation Engineer (O&M)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f54df226-1c2b-45e8-895a-48afa4bbed7e	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_08	Asst. Engineer ( O&M)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
63ac5802-a923-42e5-a629-72303f5bcefc	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_09	Junior Engineer ( O&M)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
48f32cc6-3000-4cf1-89b1-18a1826dac4b	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_10	Superintending Engineer ( Light)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1413882b-7636-458e-8d04-7c835b573ebd	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_1001	Deputy Controller Finance and Accounts	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6e2ffeed-7916-437c-a8b5-c4aaeeb0a28a	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_101	Steno	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5cc18113-c63b-46d1-a32f-06d157793731	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_102	Plumber	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
baae92c7-bf42-49e2-9915-92d13a82a456	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_103	Pump Operator	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d66e65a3-6db0-4e78-aa41-2108d3dc48a2	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_104	Court Clerk	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
961d547c-dcc9-4df1-833d-db537b3765fc	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_105	Fitter Coolie	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9e21146e-d939-485a-8c53-bc6c96aacf88	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_106	Sub Divisional Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5542187f-0d09-490d-a9c4-ed5cccf04204	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_107	Sub Fire Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
66e346ef-306a-4e13-b16f-ad6fd65b360a	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_108	Restorar	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2007fa90-83a0-42c8-b5d2-0c9072fae764	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_109	Senior Scale Stenographer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
aa237b83-e02c-47e6-bb54-dfe7e2d652d5	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_11	Corporation Engineer (Light)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d2aed353-e520-4e3f-8441-d5674dbb78c1	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_110	Mali-Cum-Chounkidar	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3bf3b449-40c7-4813-b69e-6cb5ece1a3fb	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_111	Mali	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3ddbca80-2c95-4994-8815-6f0bb903b015	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_112	Beldar	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
76d562ee-93ab-4e63-b839-b165a8506fa6	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_113	Sanitory Supervisor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
97b0cd15-8a97-4355-b62e-3d21ae1e5738	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_114	Fiter Cooli	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8dd674ce-4f70-4e3a-9a0b-cec6ff87e2e5	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_115	Junior Technician	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d289f9e9-87f9-4366-8069-b14786d8987c	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_116	Sewerman	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f531168-deb7-4442-9565-8f2f669f4f07	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_117	Steno/Personal Assistant	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
df85eb49-b38c-4abe-a2d1-e9e551baa8fe	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_118	Architect	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4b046b34-89fc-45ff-97af-9fb2ef7685da	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_119	Site Engineer/Contractor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
57262be2-620f-40f9-bf00-12cc5399f747	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_12	Junior Engineer ( Light)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bcf2518f-6be5-44c9-b282-8a459bd70ec1	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_120	Tractor Driver	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6baa8ae1-9d99-463a-8fdc-f1823403b9ba	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_121	Trolley Man	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ae529290-3836-4767-b0c9-e94cad3053c5	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_123	peon	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
97009898-9525-40d7-8d4a-3348807e3142	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_124	Bill Distributor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
58d9923a-c5d1-4aed-8d7f-32e635239cd3	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_125	Sewadar	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
813fdfd5-a162-4abf-ba4c-e1bc0779053e	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_13	Health Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bfdee657-b884-4b14-b978-6ef5855a9d6a	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_14	Medical Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
24bf947d-0696-40af-a68d-544c7eaa1d70	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_15	Chief Sanitary Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fb554fb3-e3df-4132-8e50-fcbb54a40a6c	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_16	Sanitary Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
67b3d7f7-4143-4d30-8c16-5a7fb8431098	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_17	Sanitary Supervisor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bdbc632a-e605-4822-9e99-0bf10bf4c177	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_18	Senior Town Planner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8f7802a6-1db4-48ae-8c2b-90e26b520f02	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_19	Municipal Town Planner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
96d0bb23-e11a-40ce-8c18-522281fda65e	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_20	Asst. Town Planner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c48721b6-b8ee-4494-ad02-439168dffb65	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_21	Building Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cce79b4f-3f7e-4d7e-86fb-f3bca745cc96	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_22	Junior Enginer ( Horticulutre)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
875484a3-246a-438b-bd6c-1ca4e00d188a	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_23	Citizen service representative	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
042dbd7c-aa00-4302-ac44-73d1e67dd7c1	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_24	Assistant Commissioner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fb7715f5-ea5e-42fd-bd1c-7c012cc99bd5	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_25	Assistant Engineer (Light)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
af5be5a3-d8a4-46ae-aac9-1cc74798b64e	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_26	Secretary	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
68a717fe-b9f4-4552-97ab-1cc2fe2f3110	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_27	Computer Operator	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a32b6e96-605b-48ad-92f6-f580d92433b5	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_28	In Charge/DBA	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e3eddb52-7026-44de-8887-3688f4df47a1	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_33	Baildar	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9b2c37f6-b945-414a-8201-3a70ad23d132	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_34	Junior Assistant	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
13c217fc-ec37-4653-88ba-13509aa38994	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_35	Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
50c52a49-6fea-4497-8c5a-1c2491d971d8	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_36	Assistant Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a43e0366-fab9-418f-874f-8f4ee5764aa0	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_37	Surveyor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c28241bd-9ac6-4a28-a083-f24c397e7cb2	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_38	Assistant Corporation Engg.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e1d0bdd0-578a-4051-9a12-750d0e765be5	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_39	Head Draftsman	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1739558c-6d49-47ff-aefc-ea205cc198b2	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_40	General Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4d1b8209-d46e-4094-adce-7f0614a054db	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_41	Draftsman	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
588f507f-105c-49b6-a12e-171ef4330b04	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_42	Superintending Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e49d0bf0-fc61-47b5-9bfa-829726727a7c	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_43	Superitendent	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7434d273-c282-4e29-9d7c-9487374b937e	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_44	Junior Draftsman	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
73f5979b-86df-4512-9766-ab8b7dcef69a	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_45	Assistant Town Planner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9a9e0b9c-afdf-4b28-b2e4-e1cee5bb3c03	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_46	Building inspector(Technical)/Draftsman	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dd506d43-e2b3-4d16-b919-21c379b96c9e	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_47	Superintendent	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
271b8e1d-7d68-42c0-8d0d-1cdb88a4e655	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_48	Data entry operator	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
eb1edd13-bbfb-4396-9b7d-0859977d9b1e	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_49	Assistant Municipal Engineering	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d5f8f64a-08c7-4efd-b7b6-31f4b77cec71	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_50	Sanitary Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3702319d-2bac-4d21-b760-c6caa86e1319	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_51	Commissioner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7776af17-22f9-4833-8d24-8f3b633d6ec4	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_52	Municipal Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d4897e98-73f5-46a4-9aa5-402cd475a236	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_53	Executive Engineer/Municipal Engineer/Corporation Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
94e79426-7ed1-4e3f-9b27-d608bdd2a10a	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_54	Junior.Assistant	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e35ac7d5-f58d-4ee2-9c8a-56ed63f89943	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_55	Fireman	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b16d0a0d-9e1d-468a-90b7-4c5b17839b26	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_56	Deputy Controller (Finance & Accounts)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
036a1b67-7093-4dfc-b4ee-fb98e74268f8	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_57	Corporation Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f1ae075-21ff-4458-aa58-b9b9f354cad1	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_58	Accountant	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ff93d900-5882-44dc-a7d7-0afa059e92a1	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_59	Sanitary Supervisor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f7f542d6-1a68-4f45-aebe-b6484cdbd7b3	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_60	Draftman	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2f879724-6379-470b-960b-d4cb9435d205	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_61	Data Entry Operator	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
52f2b969-c376-48de-8210-4ab134ead15d	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_62	Inspector/Senior Assistant	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d361fe93-c967-417a-9350-6dbd6b3fcbc4	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_63	Fire Station Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
62734f4e-37b4-47a3-9bc6-bf0f192efe79	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_64	INSPECTOR	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
893fa114-30ff-4bc3-a260-ba5fb444ef5d	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_65	Assistant Corporation Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8999521f-ccdc-4a67-af72-dbab4c18818c	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_66	Computer Programmer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
85cbd413-dfdb-4938-9a67-8c4118f4b4bc	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_67	Corporation Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6755b9ff-6e1a-4a7c-8d79-7121a7b87146	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_68	Asistant Commisstioner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a3885977-2d68-46e8-b7a2-b587c94f90b4	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_69	Executive officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fa9fb208-a0ae-48b2-8890-06526b0cc6f9	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_70	ALM (Assistant Line Man)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7b3e65ef-b200-4306-a42e-ccab50a76ec1	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_71	Sub-Divisional Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
10d34b4f-e8d0-48c7-a9a6-273644e52efd	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_72	Supervisor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
27b762b2-2024-4800-8a77-ceec2519b26d	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_73	GIS EXPERT	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c8e300f5-dd21-47d8-aef3-9d8be0459b8b	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_74	Local Registrar	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
44f6f2a0-1704-451f-8112-61b2bbc112f8	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_75	Tax Collector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8fdd7345-d533-4fff-ad77-776f9945315d	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_76	Building Superintendent	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5acf9fb9-9adb-4645-8889-590a86800209	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_77	Sanitory Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3280b9f1-c340-492e-8ef1-257a2bd253b7	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_78	Additional Local Registrar	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
125c103d-3eca-4f3b-ac19-d48cac09fd6e	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_79	Superintendent Engineer (Councils)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2cfa8f41-6b4d-4e61-9fa4-c2e025818c03	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_80	Senior Assistant	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a976adf6-a758-4b01-a97a-a45ce380dccf	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_81	Chief Sanitory Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4143c980-e5ea-4430-b2d9-02c0437a66c5	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_82	Sub Registrar	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1a761030-0e33-465e-9b64-0775a0160fe1	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_83	Legal Assistant	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
85d2382a-ed16-4c05-bf51-cdde3258515b	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_84	Electrician	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e07e45b7-dc64-4cd0-b9c6-06511958a90f	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_85	Assistant Municipal Engineer ( Civil )	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
89f265c3-7561-475e-aa17-ee794cf2c24b	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_86	Junior Engineer (Building)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
88ee3f68-b376-4ca0-956b-572398424bf0	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_87	Computer in Birth and Death Branch	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
25aa7881-75ac-4527-92d0-81489cbcf0e4	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_88	Junior Engineer (Electrical)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a6ded2d1-d84d-4465-be7c-895ba3fff8c8	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_89	Executive Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f3401d2d-5d30-4958-a1d7-86790df3c0c7	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_90	Peon	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0044f772-5a49-4a77-ad3f-a86ef75f20f6	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_91	Municipal Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
aa5790a3-eb2f-43ed-b18b-084df0437111	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_92	Driver	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2ddad354-774b-4ee0-87c7-0b5e5a9e673e	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_93	Sectional Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
db215fcf-257c-40f3-9206-216b6aa08293	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_94	Sweeper	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ac4a5a95-9a51-4045-8aad-2103e5e9a191	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_95	Watchman	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6f636184-5905-4f67-a44e-5c1fab3f0cb8	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_96	Pump Opertor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0f9ff504-d1bf-4dc4-908f-23d468fed5e9	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_97	Clerk-cum- computer opertor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
49faf763-83f1-4155-b9a8-bf0fd79b3b8f	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_98	Assistant Municipal Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e3cb1126-d083-4501-bc76-85899b0c3ea2	en_IN	COMMON_MASTERS_DESIGNATION_DESIG_99	Assistant Pump Operator	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9c9ae88d-0fcb-46ae-a60e-c2a83209c7b8	en_IN	COMMON_MASTERS_DESIGNATION_DPA01	Director, Planning and Architecture	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e33346c6-0fec-49de-8083-26c663222ce7	en_IN	COMMON_MASTERS_DESIGNATION_DRAFT01	Draftsman	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
346a4b90-2db8-4699-97df-66e9961ef4cc	en_IN	COMMON_MASTERS_DESIGNATION_EO01	Enforcement Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
43cf81e3-049b-436e-bfcf-48ffefbc83f4	en_IN	COMMON_MASTERS_DESIGNATION_EO02	Executive Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
28c6be64-46d1-45d3-824c-1704a7c04412	en_IN	COMMON_MASTERS_DESIGNATION_FO01	Finance Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bde39719-0d14-4a45-8898-7fda6bda61e9	en_IN	COMMON_MASTERS_DESIGNATION_HC01	Head Clerk	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
851b6968-d4ba-4496-ae08-1430fc1871ad	en_IN	COMMON_MASTERS_DESIGNATION_JE01	Junior Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c0f63acf-0250-4818-8fdb-ec5adc644ad6	en_IN	COMMON_MASTERS_DESIGNATION_JE_PWSSB	Junior Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9e1d3c3f-4a7b-4a90-9a1d-43ec6cb981f0	en_IN	COMMON_MASTERS_DESIGNATION_JMC01	Joint Municipal Commissioner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
84ff6936-7c78-4303-9940-a7214f7c191a	en_IN	COMMON_MASTERS_DESIGNATION_LDC01	Lower Division Clerk	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5bc1237c-1914-4787-a46c-be4315c56496	en_IN	COMMON_MASTERS_DESIGNATION_MA01	Municipal Administrator	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
839cc2e3-094c-4238-bd17-a7c238c651f7	en_IN	COMMON_MASTERS_DESIGNATION_MCS01	Municipal corporation Secretary	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
62c3a8ba-1ff5-4362-a5b3-c044fd8762ef	en_IN	COMMON_MASTERS_DESIGNATION_MS01	Municipal Secretary	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3dc542e9-cc34-4d3c-84ee-6200db1dd91e	en_IN	COMMON_MASTERS_DESIGNATION_OS01	Offices Superintendent	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6bc7a078-338b-46f2-9c09-12b01d043db5	en_IN	COMMON_MASTERS_DESIGNATION_RI01	Revenue Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
403c2d5c-e5e1-4983-821b-2c46a55445e0	en_IN	COMMON_MASTERS_DESIGNATION_RO01	Revenue Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
05c09247-3657-4619-bac9-6480cd328e32	en_IN	COMMON_MASTERS_DESIGNATION_SAMC01	Senior Additional Municipal Commissioner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
de792049-9699-42d0-9d7f-8dfdddcbe29c	en_IN	COMMON_MASTERS_DESIGNATION_SDO_PWSSB	Sub Division Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5805f30d-07a9-4bc4-8d83-6968b109e517	en_IN	COMMON_MASTERS_DESIGNATION_SK01	Store Keeper	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
73ec5914-be83-4aca-a6bb-ca495df3051b	en_IN	COMMON_MASTERS_DESIGNATION_SUR01	Surveyor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
012bc3a9-3e79-4087-ad30-9ba89517c8aa	en_IN	COMMON_MASTERS_DESIGNATION_TA01	Town Architect	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ccd597df-6541-462f-84a8-a2e027b0115a	en_IN	COMMON_MASTERS_DESIGNATION_Tax	Ward Officer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a7892e6d-7292-4663-ba91-25963f9ea941	en_IN	COMMON_MASTERS_DESIGNATION_UDC01	Upper Division Clerk	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
019823e0-3cee-40d5-85a3-fcfc5ff7abe5	en_IN	COMMON_MASTERS_DESIGNATION_WIR	WIR	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
db686521-27ee-48c0-a8b4-374b4aab6a55	en_IN	COMMON_MASTERS_DESIGNATION_WRK_ACCE	Account Expert (MUKTA)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1d4f2fe9-7d89-401e-8a40-7e53e26a47f5	en_IN	COMMON_MASTERS_DESIGNATION_WRK_AE	Assistant Enginner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f228978b-4390-49a0-ab8f-0bcd2a387ed4	en_IN	COMMON_MASTERS_DESIGNATION_WRK_AEE	Assistant Executive Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9b89b2c6-ae4f-4750-86a8-904ffb342b3b	en_IN	COMMON_MASTERS_DESIGNATION_WRK_AM	Ameen	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5b29005b-a343-4006-9942-b43437d5b138	en_IN	COMMON_MASTERS_DESIGNATION_WRK_CE	City Enginner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5ee6766a-4f25-463f-b1bf-f20687296bba	en_IN	COMMON_MASTERS_DESIGNATION_WRK_DA	Dealing Assistant	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
caedc114-8352-499e-a480-b23736e9a7dd	en_IN	COMMON_MASTERS_DESIGNATION_WRK_DEE	Deputy Executive Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a5f9e3d2-bd7d-419e-86c2-76fd367fc1ad	en_IN	COMMON_MASTERS_DESIGNATION_WRK_EE	Executive Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d87169c5-5c18-443e-82c9-fb424b5d66db	en_IN	COMMON_MASTERS_DESIGNATION_WRK_IE	Implementation Expert (MUKTA)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f2725845-a127-44b3-a44b-1e61adcf602c	en_IN	COMMON_MASTERS_DESIGNATION_WRK_JE	Junior Enginner	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
30d5aa64-92bb-4ca2-a014-da0950550c3a	en_IN	COMMON_MASTERS_DESIGNATION_WRK_ME	Municipal Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1ac2b002-3768-4f37-b0c4-5dae83af86ba	en_IN	COMMON_MASTERS_DESIGNATION_WRK_PC	Program Coordinator (MUKTA)	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a3a812a7-49ee-4f4d-a459-b0ebb85347cb	en_IN	COMMON_MASTERS_DESIGNATION_WRK_RI	Revenue Inspector	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
775d1eac-78cb-48f6-b97d-115e62441ed1	en_IN	COMMON_MASTERS_DESIGNATION_XEN_PWSSB	Executive Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
30c62cb1-5e73-4ec9-b3cc-e7bdfe2ca61f	en_IN	COMMON_MASTERS_OWNERSHIPCATEGORY_INSTITUTIONALSOCIETY_SELFHELPGROUP	Self Help Group	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f17116da-cc74-48e9-a1ef-1172dc9fcaba	en_IN	COMMON_MASTERS_OWNERSHIPCATEGORY_SOCIETY_SELFHELPGROUP	Self Help Group	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
59f8bb77-f197-4bdf-adc4-39144d91bb90	en_IN	COMMON_MASTER_DESIGNATION_WRK_EE	Executive Engineer	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0fd972a2-3aac-434d-bcb7-7c8b71eb5bfe	en_IN	COMPLAINTS_RESOLVED_IN_LAST_30_DAYS	 complaints resolved in the last 30 days	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7a3d42a1-5500-4461-88bc-4fc0567c6828	en_IN	CORE_COMMON_SEARCH_COMPLAINT	Search Complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
be8fa8d5-ddef-4bf4-b843-6ebb78d3fbc0	en_IN	CORE_LOGIN_USERNAME_PLACEHOLDER	Enter your Employee ID	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ddb54d9f-47df-4849-b0ef-e729b0fcf800	en_IN	CS_ACTION_ASSIGNEDBYAUTOESCALATION	Assigned by auto escalation	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
30abbe36-9a0d-4fc6-abdc-f69bc5d942f4	en_IN	CS_ACTION_CLOSERESOLVEDCOMPLAIN	Close resolved complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
75b46c48-6de6-4a59-8da5-8f36650c6951	en_IN	CS_COMMON_EMPLOYEEOTP_CHANGED_PASSWORD_SUCCESS	Password changed successfully!	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3ffe0f22-ab1b-443a-9dd5-2dfc161ef63a	en_IN	CS_COMMON_INBOX_PGR	Citizen Complaint Resolution System	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
85abe39b-8ac0-4af3-b9b3-84dfcf5b46bf	en_IN	CS_HEADER_MDMS_COMMON	MDMS	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bf8d11cc-28e8-4d13-bca6-d06130e7329c	en_IN	CS_HOME_FILE_COMPLAINT	File Complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2493061a-9f06-415b-816b-785df8cb0c1d	en_IN	CS_HOME_HEADER_LOCALIZATION	Localization	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c4937cfe-f40e-411f-9bcc-a85bebebbf0d	en_IN	CS_INBOX_MDMS_FETCH_ERROR	Session Expired Login Again	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a66ba7e8-c936-4273-9f78-7ec1cba32c14	en_IN	CS_LANDING_PAGE_COMPLAINTS_DESCRIPTION	DIGIT Complaints offers an easy to use interface which enables you to lodge civic works related complaints. It also lets you track the status of your complaint and facilitates direct interaction with your municipality till its resolution.	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ae16b02f-93ea-42c9-8347-3803cd45ab0e	en_IN	CS_MYCOMPLAINTS_TRACK	TRACK	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a3af63df-bc55-4cbd-af5a-e3680724fbdc	en_IN	DEPT_REG_NO	Department Registration number	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2655c15b-2c57-4fcf-965a-324a7b33c10b	en_IN	EGOV_LOCATION_BOUNDARYTYPE_BLOCK	BLOCK	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
66469999-a8ba-4319-9c7f-86eb1e04e6f8	en_IN	EGOV_LOCATION_BOUNDARYTYPE_CITY	CITY	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e5e74ca1-a3dc-4ceb-a85e-5ce1acb08767	en_IN	EGOV_LOCATION_BOUNDARYTYPE_LOCALITY	LOCALITY	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
80d1c019-f5b5-4ffc-8e4f-8646018806ba	en_IN	EGOV_LOCATION_BOUNDARYTYPE_ZONE	ZONE	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
121ca446-1d8f-410b-b5dd-ab3f9748f812	en_IN	EGOV_LOCATION_TENANTBOUNDARY_ADMIN	ADMIN	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e78b1317-3c33-457a-90cc-49b7d6e4f6ba	en_IN	EGOV_LOCATION_TENANTBOUNDARY_BLOCK	BLOCK	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e6b421fa-aab1-4439-ae19-41031db8cbb7	en_IN	EGOV_LOCATION_TENANTBOUNDARY_CITY	CITY	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d51370b3-5e9c-4ace-94f1-353c1ce5deb9	en_IN	EGOV_LOCATION_TENANTBOUNDARY_LOCALITY	LOCALITY	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f8cc5914-98c9-4e7c-9331-4217e8813256	en_IN	EGOV_LOCATION_TENANTBOUNDARY_REVENUE	REVENUE	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
18d8f5ad-e75e-454e-8f55-1bb5e7a043ad	en_IN	EGOV_LOCATION_TENANTBOUNDARY_ZONE	ZONE	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
87d8e03f-05ce-4718-af55-30dcaa4e3af8	en_IN	WF_INBOX_HEADER_ASSIGNED_BY	Assigned By	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d3122c58-237a-4da4-ab6c-669b65564007	en_IN	WF_INBOX_HEADER_ASSIGNED_TO	Assigned To	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cb2bd3bb-17d3-4d37-a4ba-435ebf47e71e	en_IN	WF_PGR_CLOSEDAFTERRESOLUTION	Close After Resolution	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5abc0791-32c0-405d-bada-8002ec84658d	en_IN	WF_PGR_PENDINGATLME	Pending at LME	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4c49610a-1976-413a-b2e6-2f90b79dc253	en_IN	WF_PGR_PENDINGATSUPERVISOR	Pending at Supervisor	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6fcc7c9e-9753-4c02-8ae2-1d53fdccf036	en_IN	WF_PGR_PENDINGFORASSIGNMENT	Pending for Assignement	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c9a928d3-fc20-4027-95ec-afa008a5518c	en_IN	WF_PGR_PENDINGFORREASSIGNMENT	Pending for Reassignment	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
01160c84-6f8c-49e7-88d2-21ab12afb907	en_IN	WF_PGR_REJECTED	Rejected	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
52477a5d-5917-4a25-bd45-01ee8aec7208	en_IN	WF_PGR_RESOLVED	Resolved	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4353215f-02af-44d6-82bb-ece6f8cb0cf4	en_IN	WHATSAPP_SCAN_QR_CODE	Scan the QR code to file/track complaints	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
18c2a68b-ab9e-49b7-bef0-a7588dbbe70e	en_IN	ES_INBOX_ASSIGNED_TO_ALL	Assigned to All	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f889b2f8-895e-4a92-a532-e1450d578706	en_IN	ES_INBOX_ASSIGNED_TO_ME	Assigned to Me	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
992edf9d-f52e-4ae7-92b4-f15aed8cc693	en_IN	ES_COMPLAINT_RESOLVED_SUCCESS_MESSAGE	You have marked the complaint as	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6fc99489-1c8a-4574-99b1-e0ce8552aa25	en_IN	ERR_COMPLAINT_NUMBER_SEARCH	Complaint No. should be at least 6 digits	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f75b3193-9234-43a5-b21e-c9cf37de78e5	en_IN	CS_PGR_REPORTS_HEADER	Reports	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
737efe1e-310f-4218-bfd6-a89119e51a87	en_IN	MODULE_PGR	Citizen Complaint Resolution System	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
74337d59-0c2e-491f-88f7-e07c3345f05a	en_IN	reports.pgr.datefrom	From Date	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fd98832c-5c23-4cd7-8f1c-d0f967bbb401	en_IN	reports.pgr.dateto	To Date	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
302b9eb2-0af6-4c75-80f0-ca56df7a82f9	en_IN	reports.pgr.dept.name	Department	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
45496d31-7a85-45c7-aa27-fc9c37bc91ca	en_IN	reports.pgr.status	Nature of complaint	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2b2945e5-2b8c-4274-a64b-66b6f261d60b	en_IN	IS_AVG_COMPLAINT_RESOLUTION_TIME	is the average complaint resolution time	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
797bd0ee-44b6-478c-bd06-058cb017b3ce	en_IN	ERR_NO_ADMIN_BOUNDARY_FOR_TENANT	There is no admin boundary data available for this tenant	pg	rainmaker-common	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6b65c621-58b6-48d2-ac09-f54326626be7	en_IN	ACCESSCONTROL_ROLES_ROLES_LOC_ADMIN	Localization Admin	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7d815a75-c9d4-4ca3-949d-eadd83b94081	en_IN	ACCESSCONTROL_ROLES_ROLES_MDMS_ADMIN	Workbench MDMS Admin	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
01dd7d12-e345-425e-9169-8b88a4b59aa5	en_IN	ACCESSCONTROL_ROLES_ROLES_PT_CEMP	Property Tax Counter Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
95c82a59-2549-4501-9f7c-8d332e24c5bf	en_IN	ACCESSCONTROL_ROLES_ROLES_SW_CEMP	SW Counter Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f4a81747-dca8-4620-9299-66e0b4d2afd2	en_IN	ACCESSCONTROL_ROLES_ROLES_WS_CEMP	WS Counter Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
313fa475-fcde-4952-8ec6-8fb1c66bbb2f	en_IN	ACTIVATE EMPLOYEE	Activate Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f251567-7e5b-43f8-b2bb-82374e938d21	en_IN	COMMON_MASTERS_DEPARTMENT_ACC	Accounts	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
009a9a68-a14d-4f66-b538-e1d8620b9a08	en_IN	COMMON_MASTERS_DEPARTMENT_ADM	Administration	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5076cc33-efb6-41d3-b9cb-39c72343c546	en_IN	COMMON_MASTERS_DEPARTMENT_NULM	National Urban Livelihood Mission	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d43b3bff-8385-4306-8527-7dde1dea2a83	en_IN	COMMON_MASTERS_DEPARTMENT_PHS	Public Health and Sanitation	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
da1b3888-8a6b-407b-a531-dd5a9921f8b6	en_IN	COMMON_MASTERS_DEPARTMENT_PR	Public Relations	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c5284c0f-4b7a-4b15-89d0-42daaba70b1e	en_IN	COMMON_MASTERS_DEPARTMENT_REV	Tax	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0bb0d9c1-7f1a-4386-beb1-1347df2d6671	en_IN	COMMON_MASTERS_DEPARTMENT_TWP	Town Planning	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0f0be52d-099d-453d-a2a0-0a60b2f2059f	en_IN	COMMON_MASTERS_DEPARTMENT_WRK	Works	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1ae0640e-c33a-4419-bb6e-eadfd2a3ad6d	en_IN	CS_COMPLAINT_LOCALITY	Locality	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4ac9b1d8-3587-46a9-86c8-4f3ffdf8953d	en_IN	CS_COMPLAINT_SELECT_CITY	City	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a2e40d78-3b11-446d-94ea-6ffa4b8fcee6	en_IN	EGOV_HRMS_DEACTIVATIONREASON_ORDERBYCOMMISSIONER	Order by Commissioner	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7e6ccc21-7f27-4cc9-a705-0d9a1aac2727	en_IN	EGOV_HRMS_DEACTIVATIONREASON_OTHERS	Others	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
20e88b9b-43f4-46d3-9d18-1f84097d115b	en_IN	EGOV_HRMS_DEGREE_10+2_EQUIVALENTDIPLOMA	10+2/EQUIVALENTDIPLOMA	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e035ba74-415d-46b4-b492-f3bf0e71c876	en_IN	EGOV_HRMS_DEGREE_B_A_B_SC__B_COM_BBA	B.A/B.SC./B.COM/BBA	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
71033606-7299-4fd8-b973-fbbfb726746a	en_IN	EGOV_HRMS_DEGREE_B_E_B_TECH_	B.E/B.TECH.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
826c8983-89f9-43b8-835e-1101a469ecbb	en_IN	EGOV_HRMS_DEGREE_DOCTORATE	DOCTORATE	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5f5c8c2d-69e8-4d94-8dc4-0c8c970aa787	en_IN	EGOV_HRMS_DEGREE_LLB_LLM	LLB/LLM	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
afca732e-bf5c-4fa2-8d10-130cbafa064f	en_IN	EGOV_HRMS_DEGREE_MATRICULATION	MATRICULATION	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
544a8d0c-923e-4f22-8102-fe2f4a86872b	en_IN	EGOV_HRMS_DEGREE_MBA_PGDM	MBA/PGDM	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
14a49418-d6bd-4e94-87cb-91307feef02b	en_IN	EGOV_HRMS_DEGREE_M_A_M_COM__M_SC_	M.A/M.COM./M.SC.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e1880600-e5b1-4cbd-879f-ce0828782eba	en_IN	EGOV_HRMS_DEGREE_M_E_M_TECH_	M.E/M.TECH.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0b8bdf26-5d43-41d0-912d-26e0e87be3d3	en_IN	EGOV_HRMS_DEGREE_OTHER	OTHER	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
63394d12-c89f-4c77-b3e9-7559cea84d66	en_IN	EGOV_HRMS_EMPLOYEESTATUS_DECEASED	DECEASED	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
22248857-24ba-4017-ab7a-17be141d6395	en_IN	EGOV_HRMS_EMPLOYEESTATUS_EMPLOYED	EMPLOYED	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
517668dd-643f-436d-8069-77676a1e14c1	en_IN	EGOV_HRMS_EMPLOYEESTATUS_RESIGNED	RESIGNED	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3b765d81-d7aa-4123-9b3a-73c3478d3b54	en_IN	EGOV_HRMS_EMPLOYEESTATUS_RETIRED	RETIRED	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a0505ef7-0cf6-4f61-9e9e-415bd55882bc	en_IN	EGOV_HRMS_EMPLOYEESTATUS_SUSPENDED	SUSPENDED	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f1d20172-06c9-4a8a-827d-2c9cb4ecef23	en_IN	EGOV_HRMS_EMPLOYEESTATUS_TERMINATED	TERMINATED	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7892b30e-0f65-44bc-9364-f14951339a68	en_IN	EGOV_HRMS_EMPLOYEESTATUS_TRANSFERRED	TRANSFERRED	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a3aca1be-a527-4099-9ac2-25a7e68879d9	en_IN	EGOV_HRMS_EMPLOYEETYPE_CONTRACT	CONTRACT	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
001f2f88-439d-4f47-81f6-e196c3a02e8d	en_IN	EGOV_HRMS_EMPLOYEETYPE_DAILYWAGES	DAILYWAGES	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d8880c50-520d-49fd-9c01-12e7de72d664	en_IN	EGOV_HRMS_EMPLOYEETYPE_DEPUTATION	DEPUTATION	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
58562bd2-3cd1-427a-a3b4-db250e293b78	en_IN	EGOV_HRMS_EMPLOYEETYPE_PERMANENT	PERMANENT	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
329077ce-01ff-4f83-8524-c4ebe8604579	en_IN	EGOV_HRMS_EMPLOYEETYPE_TEMPORARY	TEMPORARY	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7a210e30-d879-4f5d-b815-77feac226aa9	en_IN	EGOV_HRMS_EMPLOYMENTTEST_APTITUDETEST	APTITUDE TEST	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cda45409-e7bf-43ac-9820-bbf4d72426e8	en_IN	EGOV_HRMS_EMPLOYMENTTEST_MAINS	MAINS	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a7039d0e-82be-47f5-b125-514b2bddcb11	en_IN	EGOV_HRMS_EMPLOYMENTTEST_PRELIMS	PRELIMS	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8f8a06ee-8bd7-4e4f-9c2e-1e873a684a42	en_IN	EGOV_HRMS_SPECALIZATION_ARTS	Arts	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9e2c4b52-eda0-492b-8c60-a0ab5020d762	en_IN	EGOV_HRMS_SPECALIZATION_SCIENCE	Science	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0d35ce27-dcc4-4eda-b31e-4f94353b6b80	en_IN	EMPLOYEE_RESPONSE_ACTIVATION_ACTION	Employee Reactivated Successfully	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f259af8c-8178-458b-b7c1-dc1c0abc05b0	en_IN	EMPLOYEE_RESPONSE_CREATE_ACTION	Employee Created Successfully	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
748d3128-7d85-4f19-a873-c1b3a50b4a0a	en_IN	EMPLOYEE_RESPONSE_CREATE_ACTION_ERROR	Employee Creation Failed	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2426b664-9b7e-41b3-a15c-f082d7da4f3b	en_IN	EMPLOYEE_RESPONSE_CREATE_LABEL	Employee ID	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
28c0f8fe-573a-4198-8b56-d1e41ea289e5	en_IN	EMPLOYEE_RESPONSE_DEACTIVATION_ACTION	Employee Deactivated Successfully	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
db1d77f2-ec9e-492b-91b2-b87133cbb0e2	en_IN	EMPLOYEE_RESPONSE_DEACTIVATION_ACTION_ERROR	Employee Deactivation Failed	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4a9dc5b3-83a1-4496-bfb0-995113df351f	en_IN	EMPLOYEE_RESPONSE_UPDATE_ACTION	Employee Details Updated Successfully	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f8cb1d31-59b6-4931-8a17-edbee677dbcb	en_IN	EMPLOYEE_RESPONSE_UPDATE_ACTION_ERROR	Employee Details Update Failed	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bfc4f45c-ae66-4cc5-933e-6bf796e2ed6e	en_IN	ERR_HRMS_BULK_CREATE_DUPLICATE_EMPCODE	Bulk request has duplicate employee code	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ffdab525-bb91-4329-8693-7a18e6730735	en_IN	ERR_HRMS_BULK_CREATE_DUPLICATE_MOBILE	Bulk request has duplicate mobile number	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9c98c5c9-d000-4829-8756-19438a0bbe13	en_IN	ERR_HRMS_GENERATE_ID_ERROR	Unable to create ids	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a6138fb9-4a1f-438b-8486-90797aca9d61	en_IN	ERR_HRMS_INVALID_ASSIGNMENT_CURRENT_TO_DATE	To Date field should be blank for current assignment of the employee.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8cda8663-3f37-4f5f-b868-f41558db7e72	en_IN	ERR_HRMS_INVALID_ASSIGNMENT_DATES	Employee period of assignment (From Date or To date) can not be before date of birth.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8cd0c7bc-e765-460b-8556-6324499be949	en_IN	ERR_HRMS_INVALID_ASSIGNMENT_DATES_APPOINTMENT	Employee period of assignment (From Date or To date) can not be before date of appointment.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ef14d8dc-7e38-45ff-863d-3dc2b1a1dbcf	en_IN	ERR_HRMS_INVALID_ASSIGNMENT_NOT_CURRENT_TO_DATE	To date field should not be blank for non current assignment of the employee.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e312ed16-8733-4757-9a15-e3b0401964f5	en_IN	ERR_HRMS_INVALID_ASSIGNMENT_PERIOD	Invalid period of assignment (From date - To date).	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1d1e496e-869b-4a6b-93c9-5cf3c825a31f	en_IN	ERR_HRMS_INVALID_BOUNDARY_TYPE_HEIRARCHY	Jurisiction boundary type value is invalid.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
51265c17-9b70-4873-a210-fa0a516ebad9	en_IN	ERR_HRMS_INVALID_CURRENT_ASSGN	There should be exactly one current assignment for the employee.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
13ac622b-c45a-452c-b770-7b14733f41e6	en_IN	ERR_HRMS_INVALID_DATE_OF_APPOINTMENT_DOB	Employee date of appointment can not be before date of birth.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4abdf901-2a10-4e25-a84a-0853c7a327e4	en_IN	ERR_HRMS_INVALID_DEACT_REQUEST	Employee active flag should be set as false during deactivation.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0b10fa4b-dcf3-4277-ac3d-7595770d05a8	en_IN	ERR_HRMS_INVALID_DEPARTMENTAL_TEST	Departmental evaluation test of the employee is invalid.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d2d48a47-3f22-4a2e-93d3-66e42b0700c8	en_IN	ERR_HRMS_INVALID_DEPARTMENTAL_TEST_PASSING_YEAR	Departmental evaluation test passing year of the employee can not be before date of birth.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8ba0e5de-c301-4a77-828c-d96f06b63523	en_IN	ERR_HRMS_INVALID_DESG	Invalid designation of employee.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f3cee8a0-87ad-46cf-9e09-7881833f092d	en_IN	ERR_HRMS_INVALID_DOB	Invalid date of birth entered.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bfaa5a8b-020b-4372-aaba-7dd7b8d2c583	en_IN	ERR_HRMS_INVALID_EDUCATIONAL_PASSING_YEAR	Education year of passing of the employee can not be before date of birth.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8d890146-98d4-41ec-987b-2587785ff080	en_IN	ERR_HRMS_INVALID_EDUCATIONAL_STREAM	Education stream of the employee is invalid.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
095fac6f-62a5-4af0-95d1-09c60b138ff7	en_IN	ERR_HRMS_INVALID_EMP_STATUS_ROLE	Invalid employment status entered.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8ac60a31-7a40-4632-9987-d376b4bdb333	en_IN	ERR_HRMS_INVALID_EMP_TYPE	Invalid employee type entered.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bef12aed-fb80-4206-98f5-5ffe47955e23	en_IN	ERR_HRMS_INVALID_JURISDICTION_ACTIIEV_NULL	Jurisiction should have atleast 1 active data	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
770d6844-2507-4c3c-beac-914647fbb473	en_IN	ERR_HRMS_INVALID_JURISDICTION_BOUNDARY	Jurisiction boundary value is invalid.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cb8e151a-a3b3-49ca-8184-cf08d24fa3fe	en_IN	ERR_HRMS_INVALID_JURISDICTION_HEIRARCHY	Jurisiction hierarchy value is invalid.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b26bc25b-ccf1-45af-87c7-bf67e4b2a4ff	en_IN	ERR_HRMS_INVALID_QUALIFICATION	Qualification of the employee is invalid.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d184838c-8ab4-443d-82a6-df5dd502c6e2	en_IN	ERR_HRMS_INVALID_SEARCH_AOD	Along with as on date, atleast one department and designation need to be passed as search criteria.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fe541a26-2d32-4f78-8b50-b9e3e10fd9bd	en_IN	ERR_HRMS_INVALID_SEARCH_REQ	Open search is disabled for this user.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
59302f7e-6242-4a35-b20d-4ae9ee01e0e0	en_IN	ERR_HRMS_INVALID_SEARCH_ROLES	For search based on roles, passing of tenant id is mandatory.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
24aa03ff-6894-4965-86fe-96e782d5e8dc	en_IN	ERR_HRMS_INVALID_SEARCH_USER	For search based on phone number and name, passing of tenant id is mandatory.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
01d265e9-4664-48ef-90bb-0f1a87052bf4	en_IN	ERR_HRMS_INVALID_SERVICE_ASSGN	There should be maximum one currently working service for the employee.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2a4b4634-c4b8-4873-9565-f61b8b6fc456	en_IN	ERR_HRMS_INVALID_SERVICE_CURRENT_TO_DATE	To Date of service period should be blank for currently working employees.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e458b6d2-3c24-46ae-b6cd-1ecf9f466b7f	en_IN	ERR_HRMS_INVALID_SERVICE_DATES	Employee service period (From date or To date) can not be before date of birth.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
af84692c-6c0e-41ae-8c5c-6748603dfa2f	en_IN	ERR_HRMS_INVALID_SERVICE_NOT_CURRENT_TO_DATE	To Date of service period should not be blank for currently non working employees.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7c6636ba-8c14-4d8c-95c8-269645aaa79e	en_IN	ERR_HRMS_INVALID_SERVICE_PERIOD	Service period (From date or To date) of employee is invalid.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e4a943f1-2a6a-4398-93c8-c6531308bfa3	en_IN	ERR_HRMS_INVALID_SERVICE_STATUS	Service stataus of employee is invalid.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ab1ebf26-cb23-431d-9254-fe5481f009ac	en_IN	ERR_HRMS_MISSING_ROLES	Invalid mobile number entered.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e8be7d74-0869-4e65-be17-9dbd0f7141f0	en_IN	ERR_HRMS_OVERLAPPING_ASSGN	There should not be overlapping period of assignments for the employee.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a71cc616-d3c1-46e3-a720-306c096dd6de	en_IN	ERR_HRMS_OVERLAPPING_ASSGN_CURRENT	Period of assignements of employee should not be after current assignment.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
02f56889-51b3-4c6c-9ad3-86aaacd0f11d	en_IN	ERR_HRMS_OVERLAPPING_SERVICEHISTORY_CURRENT	Period of service details of employee should not be after current assignment!	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1495fdde-ae3f-408c-8423-90eafe252010	en_IN	ERR_HRMS_UPDATE_ASSIGNEMENT_INCOSISTENT	Assignment data in an update request should contain all previously entered data.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cb9d7cda-0cd7-4d1f-9048-9b1140442f7f	en_IN	ERR_HRMS_UPDATE_DEACT_DETAILS_INCORRECT_EFFECTIVEFROM	Employee deactivation effective date should not be future date.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
39a54e97-3886-47d2-a0ad-add5a7efcf3a	en_IN	ERR_HRMS_UPDATE_DEACT_DETAILS_INCOSISTENT	Employee deactivation data in an update request should contain all previously entered data.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2e1d762f-b1ee-4e11-9946-59c1fb2a7205	en_IN	ERR_HRMS_UPDATE_DOCUMENT_INCOSISTENT	Employee document data in an update request should contain all previously entered data.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c9c600d7-27cc-4b52-a748-efa6a221120a	en_IN	ERR_HRMS_UPDATE_EDUCATION_INCOSISTENT	Education data in an update request should contain all previously entered data.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0b87e932-35a4-46ca-8f7f-54a3078e0dbd	en_IN	ERR_HRMS_UPDATE_EMPLOYEE_CODE_CHANGE	Employee code can not be changed in an update request.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ce681678-5015-4ff9-87d2-c5bbfa90042e	en_IN	ERR_HRMS_UPDATE_EMPLOYEE_NOT_EXIST_CODE	No employee found for given UUID.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8dfdbebd-14bd-4bca-90aa-d430b9345a25	en_IN	ERR_HRMS_UPDATE_EXISTING_MOBNO	User exist for given mobile no	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a456f8fd-e5b5-4179-bba6-169c02987fbe	en_IN	ERR_HRMS_UPDATE_JURISDICTION_INCOSISTENT	Jurisdiction data in an update request should contain all previously entered data.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
06d27873-391e-4f46-ac67-7f4ef31898f6	en_IN	ERR_HRMS_UPDATE_NULL	Employee Code in an update request should not be null.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
630f9bc2-d4ca-4b6a-b9ed-4ecdcf6c4347	en_IN	ERR_HRMS_UPDATE_NULL_ID	Employee ID in an update request should not be null.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c47893ba-252f-47d2-9866-ff1a9a044d7d	en_IN	ERR_HRMS_UPDATE_NULL_UUID	Employee UUID in an update request should not be null.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
92060933-4c2e-433e-af8d-630f13744376	en_IN	ERR_HRMS_UPDATE_SERVICE_HISTORY_INCOSISTENT	Service history data in an update request should contain all previously entered data.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2f24228b-c173-43a9-aee5-44eee52c1165	en_IN	ERR_HRMS_UPDATE_TESTS_INCOSISTENT	Employee evaluation test data in an update request should contain all previously entered data.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
af7e290b-d356-4b70-9112-d10c93cc077b	en_IN	ERR_HRMS_USER_UPDATION_FAILED	User updation failed at the user service.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1d0120f7-0b1f-422b-a4ea-7e2a20701ca6	en_IN	HE_NEW_EMPLOYEE_CITY_LABEL	New Employee Locality	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ca11d442-b784-4e00-9c81-373a55920b56	en_IN	HE_NEW_EMPLOYEE_CITY_LABEL 	New Employee Locality	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
529db979-3793-4b50-a046-866a969485b9	en_IN	HRMS_SEARCH_RESET_BUTTON	Reset	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9279cee2-c017-4a0c-8e9c-330baac7998c	en_IN	HR_ACTIVATE_EMPLOYEE_LABEL	Activate Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
61aed9f2-e69f-46f1-8065-ec419f9f03eb	en_IN	HR_ADD_NEW_EMPLOYEE_BUTTON	Add Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d57d9854-f4e2-443f-8901-9d641a5b404c	en_IN	HR_ASMT_FROM_DATE_PLACEHOLDER	Assigned From Date	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ba2bf527-4a28-41ee-96ff-e5b50340eaaa	en_IN	HR_ASMT_TO_DATE_LABEL_PLACEHOLDER	Assigned To Date	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3445ef44-922b-43d6-98da-83182290c385	en_IN	HR_ASMT_TO_DATE_PLACEHOLDER	Assigned To Date	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c12df103-c292-4cd9-a9bd-17af862fef13	en_IN	HR_BOUNDARY_PLACEHOLDER	Select Boundary	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
68efc2fb-650a-4fca-9fea-cde9ccf744c6	en_IN	HR_BOUNDARY_TYPE_PLACEHOLDER	Select Boundary Type	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b2a83544-2737-4e19-9355-84dc19ac3def	en_IN	HR_COMMON_APPL_NEW_HEADER	Create New Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5a6ce207-46d5-4acc-895e-b87daee281c0	en_IN	HR_COMMON_DEACTIVATED_EMPLOYEE_HEADER	Deactivate Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
991d2c30-7471-40dc-9b18-f2d0c7424c5b	en_IN	HR_COMMON_REACTIVATED_EMPLOYEE_HEADER	Reactivate Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5a27b969-326d-45e1-936d-a2abcb27ecb3	en_IN	HR_COMMON_TABLE_COL_DESG	Designation	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c21e5dfe-1364-4f98-b5de-7d7df978b8b3	en_IN	HR_COMMON_TABLE_COL_EMP_ID	Employee ID	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
919bf463-c32d-4543-928b-7baebc292e90	en_IN	HR_COMMON_UPDATE_EMPLOYEE_HEADER	Employee Update	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5e143e8d-5f9e-4200-adb6-982a058a60f6	en_IN	HR_CREATE_SUCCESS_MESSAGE	Employee Created Successfully	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9e18af82-d3d1-45e0-bf65-29bdeb21c3fe	en_IN	HR_CREATE_SUCCESS_SUBHEADER	A notification has been sent to the created Employee at registered Mobile No.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5bac8c5a-16c4-4845-9f45-f3850b5cb1d8	en_IN	HR_CURR_ASSIGN_LABEL	Currently Assigned Here	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4b175819-12c6-466c-9c83-1ed7ffed1a63	en_IN	HR_DEACTIVATE_EMPLOYEE_BUTTON_TEXT	Deactivate Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3e69a861-b8a1-4b7f-8b4a-a0e5079e6d84	en_IN	HR_DEACTIVATE_EMPLOYEE_LABEL	DEACTIVATE EMPLOYEE	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
492eb77c-aeeb-414c-b129-4f5f394690e2	en_IN	HR_DEACTIVATE_SUCCESS_MESSAGE	Employee Deactivated Successfully	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ea92460a-650f-4d2f-871c-e21b6a55c704	en_IN	HR_DEPARTMENT_PLACEHOLDER	Select Department	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
01138f9f-c1f0-459e-891d-36894190f677	en_IN	HR_DEPT_PLACEHOLDER	Select Department	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1aafba6e-88b5-49b6-9523-a9eda86ba2c9	en_IN	HR_DEPT_TEST_HEADER	Department Test Details	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f7dd96f5-c847-42f3-9ee6-1f4186bcc9b4	en_IN	HR_DESIGNATION_PLACEHOLDER	Select Designation	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
35cd7264-c260-411b-a459-2eda4f08e079	en_IN	HR_DESIG_PLACEHOLDER	Select Designation	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
58c9282d-ff42-4b8e-ab9b-11664c26c027	en_IN	HR_EMPLOYEE_ID_PLACEHOLDER	Enter Employee ID	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1bf8b49c-1a97-4c02-b0be-c5bdfd45acd8	en_IN	HR_EMP_ID_ERR_MSG	Invalid Employee ID	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
59c4c5cb-1c36-4018-9a9c-9719ffe9c479	en_IN	HR_EMP_ID_PLACEHOLDER	Enter Employee ID	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a8387dbc-ed48-4f27-a821-f589c1b1e423	en_IN	HR_EMP_MOBILE_LABEL	Employee Mobile No.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e98413c8-101d-4177-818f-d6df7a9524e8	en_IN	HR_EMP_MOBILE_PLACEHOLDER	Enter Employee Mobile No.	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
83e6785e-5e8e-43c9-bc7e-aa51ed94d015	en_IN	HR_EMP_NAME_PLACEHOLDER	Enter Employee Name	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8d7cc7bb-ce91-481f-931c-f9fb673a1442	en_IN	HR_EMP_TYPE_LABEL	Employee Type	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3d40a802-821a-4f8f-8eb7-8c5eea75900b	en_IN	HR_EMP_TYPE_PLACEHOLDER	Select Employee Type	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2fec5917-c724-42ee-a503-b043bf0f5d88	en_IN	HR_FATHER_HUSBAND_NAME_PLACEHOLDER	Enter Employee Name	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
398a4fd6-04b8-41f6-a7ff-05870a320974	en_IN	HR_HOD_LABEL	Head of Department	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
901a72ed-db2c-4511-9488-39bd9168b03d	en_IN	HR_HOD_SWITCH_LABEL	Head Of Department	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ef853b80-4dff-4c2e-aa7c-39c3dc22d8cf	en_IN	HR_HOME_SEARCH_RESULTS_DESC	Provide at least one parameter to search for an employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
99ff2f54-0416-4e0e-b7cd-c41602bd70df	en_IN	HR_HOME_SEARCH_RESULTS_TABLE_HEADING	Search Results for Employee	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bed372f6-ab3e-41b5-bee3-161a9c81a072	en_IN	HR_NAME_PLACEHOLDER	Enter Employee Name	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
033cb3b7-0fe6-4dcf-be0b-287256bc060d	en_IN	HR_NEW_EMP_NAME_PLACEHOLDER	Enter Employee Name	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
672778d3-53c4-4c65-92f2-55b64fe8e245	en_IN	HR_PROFESSIONAL_DETAILS_FORM_HEADER	Employee Details	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dabf8ca7-ca28-45d5-ad19-824002e9ec6c	en_IN	HR_RACTIVATE_SUCCESS_MESSAGE	Employee Reactivated Successfully	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d41a6fec-5207-4b0f-9e61-a04de149feb3	en_IN	HR_SUMMARY_HEADER	Create New Employee - Summary	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b25e4814-5b8e-40ac-b738-6bfcd1ab6cb7	en_IN	HR_UPDATE_SUCCESS_MESSAGE	Employee Updated Successfully	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e3e4512a-dce9-46cf-a6ac-0559359128fd	en_IN	HR_VIEW_HEADER	View Employee Information	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
757e47d9-8791-47c5-9537-f7f7c3184442	en_IN	TL_ADD_ASSIGNMENT	ADD ASSIGNMENT	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9dd5e47a-4073-484c-8907-421008d64574	en_IN	TL_ADD_JURISDICTION	ADD JURISDICTION	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b369838b-5649-40bb-82cd-15293518a228	en_IN	reports.hrms.department	Employee Department	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c07094ce-1c88-4149-9bb1-486bae3502e3	en_IN	reports.hrms.designation	Employee Designation	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
583b3026-ddc6-426f-80cc-7ea5b5876990	en_IN	reports.hrms.id	Employee Id	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d4f54d65-4555-4058-952c-965c923583fd	en_IN	reports.hrms.name	Employee Name	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
edd795de-3c06-47e0-8dd9-411771b96f4d	en_IN	reports.hrms.role	Employee Roles	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
57f3dacc-bc09-4c49-a80a-c91dd5c2dc09	en_IN	reports.hrms.status	Employee Status	pg	rainmaker-hr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4deabb9b-caa6-4343-85bf-30a6a1db4067	en_IN	COMMON_BOTTOM_NAVIGATION_COMPLAINTS	Citizen Complaint Resolution System	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8755f241-ba99-40f8-baa2-df4fd5614031	en_IN	COMMON_MASTERS_DESIGNATION_AC01	Additional Commissioner	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bac3f959-1f13-4943-8f43-461479f815ac	en_IN	COMMON_MASTERS_DESIGNATION_AMO01	Asst. Medical Officer	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
40125c6c-155a-442b-bccc-a771aa5144ce	en_IN	COMMON_MASTERS_DESIGNATION_CM01	City manager	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ede39eed-3dbe-478d-bb2e-112824fe85cc	en_IN	COMMON_MASTERS_DESIGNATION_CME01	Chief Municipal Engineer	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fd34c8b4-cdfc-4dbc-a54f-ad23b5f7c243	en_IN	COMMON_MASTERS_DESIGNATION_DC01	Deputy Commissioner	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
72ffd4b1-6359-423b-b0f7-06bb9ad51970	en_IN	COMMON_MASTERS_DESIGNATION_HDC01	Higher Division Clerk	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f1ddfe61-5c47-4f2f-a04c-ddda483a2173	en_IN	COMMON_MASTERS_DESIGNATION_HSI01	Head Sanitary Inspector	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e02d4cc9-cea0-4af0-badd-c3ad27160f25	en_IN	COMMON_MASTERS_DESIGNATION_MC01	Municipal Commissioner	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bc130df9-ebaf-4298-8ddb-4ee3968e0558	en_IN	COMMON_MASTERS_DESIGNATION_SS01	Sanitory Supervisor	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
94bb3282-d416-4f7e-a080-afa371cbfbfb	en_IN	COMMON_MASTERS_DESIGNATION_TC01	Tax Collector	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
81e196be-2c79-4bee-8d15-c786e62c84f1	en_IN	COMMON_MASTERS_DESIGNATION_TI01	Tax Inspector	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
91a236a7-1438-425a-8f4b-d1a004b0c721	en_IN	COMPLAINTS_SUPERVISOR_CONTACT_NUMBER	Supervisor Contact No.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f6018119-5686-430f-989b-b229676d22c8	en_IN	COMPLAINTS_SUPERVISOR_NAME	Supervisor Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e96bbca3-6361-455e-8344-4fa7815db8e7	en_IN	CORE_COMMON_SEARCH_COMPLAINT	Search Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a8cdf46f-b2dd-4031-b2f8-b61a9cf6868b	en_IN	CORE_LOGIN_USERNAME_PLACEHOLDER	Enter your Employee ID	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
04060c23-3e45-4ce4-b31c-581a35fe3937	en_IN	CS_ACTION_ASSIGN_TEXT	Complaint Assigned Successfully	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
745f2cf1-9e69-4180-a07a-4d3f53630e6a	en_IN	CS_ACTION_REASSIGN_TEXT	Complaint Reassigned Succesfully	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fb6713a6-f3c7-4d6d-a980-7165005afd6d	en_IN	CS_ACTION_REJECT_TEXT	Complaint Rejected Succesfully	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
912d311e-86bb-4161-a3a6-078f74c824b5	en_IN	CS_ACTION_REOPEN_TEXT	Complaint Reopened Successfully	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b35a28dd-1415-4b7e-8f04-4b2b88c6777a	en_IN	CS_ACTION_RESOLVE_TEXT	Complaint Resolved Successfully	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1562fbff-49ab-46ac-8541-a824fd9c7eac	en_IN	CS_ADDCOMPLAINT_ADDITIONAL_DETAILS_PLACEHOLDER	Enter WARD and address	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6cd8dd8a-df5d-4d41-9fd5-b0dd4fd48354	en_IN	CS_ADDCOMPLAINT_ADDRESSINFO	Address Info:	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
95f2397e-42ce-4745-be32-08556be094cd	en_IN	CS_ADDCOMPLAINT_COMPLAINT_DETAILS	Complaint Additional Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
13b5c4d2-1561-464a-aa64-68eddb777754	en_IN	CS_ADDCOMPLAINT_COMPLAINT_DETAILS_PLACEHOLDER	Enter Complaint additional details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fc13ec61-7f60-4d56-a2fe-c9f24624f548	en_IN	CS_ADDCOMPLAINT_COMPLAINT_SUBTYPE	Complaint Sub-Type 	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
76a83475-7734-4cf2-bc2c-b977bccba4c0	en_IN	CS_ADDCOMPLAINT_ERROR_COMPLAINT_SUBTYPE	Select the complaint sub-type	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
222cf1b3-49e4-4136-a198-a48056915160	en_IN	CS_ADDCOMPLAINT_ERROR_COMPLAINT_TYPE	Select the complaint type	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4d31d35b-2c79-403b-9346-5f499bf4c07d	en_IN	CS_ADDCOMPLAINT_ERROR_FAILURE	Sorry, there is a problem with the service. Try again later.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6edbfe74-83af-432c-a8e3-acd49547bd0a	en_IN	CS_ADDCOMPLAINT_ERROR_MESSAGE	Complaint Not Submitted	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1cfb686b-8985-458c-b1c7-9edb0c0cd4d2	en_IN	CS_ADDCOMPLAINT_ERROR_REOPEN_REASON	Select reason to re-open complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
af790e5c-8eca-46fa-9fb8-92a65d30d087	en_IN	CS_ADDCOMPLAINT_HOUSE_NO	House No. and Street Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4a351fb6-4e6a-41f7-a9a0-3160c4949549	en_IN	CS_ADDCOMPLAINT_HOUSE_NO_PLACEHOLDER	Enter House No. and Street Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
062a16b3-c610-4804-8301-b2a46546ef9f	en_IN	CS_ADDCOMPLAINT_LANDMARK_ERROR	Enter Landmark	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
afb55faa-42c6-4d4a-b4e2-5ca93aaa679e	en_IN	CS_ADDCOMPLAINT_LANDMARK_PLACEHOLDER	Enter landmark	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4e2c8e66-3552-48f3-8bff-a3f419801ed2	en_IN	CS_ADDCOMPLAINT_LOCATION_ERROR	Select City and Locality	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9022faf1-4a65-468a-9317-3537371e1e9a	en_IN	CS_ADDCOMPLAINT_LOCATION_ERRORMSG	Address doesn’t exist	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
321f45a3-6dff-45a5-aa29-ff42840b8b9c	en_IN	CS_ADDCOMPLAINT_PINCODE	Do you know the pincode ?	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
660f1f38-c1f3-43ec-b798-440051a89814	en_IN	CS_ADDCOMPLAINT_PIN_LOCATION	Pin Complaint location	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8d503285-2a85-4f1e-be9c-c41ceb23af67	en_IN	CS_ADDCOMPLAINT_PIN_LOCATION_TEXT	If you know the pincode of the complaint address, provide below. It will help us identify complaint location easily or you can skip and continue.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ea2d2b9b-efaf-4f21-8083-a3b73a238793	en_IN	CS_ADDCOMPLAINT_PROVIDE_LANDMARK	Provide Landmark	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
096d5244-c74e-4c3c-a83f-a4792cc8dca7	en_IN	CS_ADDCOMPLAINT_PROVIDE_LANDMARK_TEXT	Provide the landmark to help us reach the complaint location easily.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
791b03d2-4a43-4395-9e79-8b526afca145	en_IN	CS_ADDCOMPLAINT_UPLOAD_ERROR_MESSAGE	Upload Image	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6132d878-6759-468e-8c8a-546ff41a3fce	en_IN	CS_ADD_COMPLAINT_COMPLAINT_SUBMISSION	Complaint Submission	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
60308555-e51a-4895-83d0-d5747ac6c8e3	en_IN	CS_COMMON_ASSIGNED	Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4d6e8ae3-118b-48ef-88e5-c59ca56c8ebe	en_IN	CS_COMMON_ASSIGNED_TO	Assigned to 	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
40c2c780-7fed-46cc-9d8c-2acba88f7a07	en_IN	CS_COMMON_CITIZEN_REQUEST_REASSIGN	Being Re-assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7cdca4fa-add1-4500-8d88-d3cf2212be02	en_IN	CS_COMMON_COMPLAINT_ASSIGNED_TO	Complaint assigned to	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b4a95927-f085-4d14-aea5-7bdaa50dfb1f	en_IN	CS_COMMON_COMPLAINT_DATE	ComplaintDate	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0163c136-eab2-45f6-adba-c7412ccc39cf	en_IN	CS_COMMON_COMPLAINT_PENDINGFORASSINMENT	Pending for Assignment	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1d31a4d9-32ae-41a6-8aeb-0c943fa082e0	en_IN	CS_COMMON_COMPLAINT_STATUS	Complaint status	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b7e2f383-4072-4760-9338-4d99ce828fda	en_IN	CS_COMMON_PENDINGFORREASSIGNMENT	Pending for reassignment	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6cf2bbac-2c01-4c7b-9e42-ec42b90b462a	en_IN	CS_COMMON_PGR_STATE_CLOSEDAFTERREJECTION	Closed after rejection	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b826fe49-b2ec-4975-bde2-9fc6da5312f9	en_IN	CS_COMMON_PGR_STATE_CLOSEDAFTERRESOLUTION	Closed after resolution	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
23326425-8f99-497c-b7de-289e13b30896	en_IN	CS_COMMON_PGR_STATE_PENDINGATLME	Pending at last mile employee	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
41ce6041-de74-47bd-90ec-f91c2bc2fcf9	en_IN	CS_COMMON_PGR_STATE_PENDINGFORASSIGNMENT	Pending for assignment	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
54838c55-4267-46e8-9c62-cf75e783a4c0	en_IN	CS_COMMON_PGR_STATE_PENDINGFORREASSIGNMENT	Pending for re-assignment	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
14b5b418-970d-4d65-b165-776af69f0dfb	en_IN	CS_COMMON_PGR_STATE_REJECTED	Rejected	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d0665fda-48c3-4040-9e68-6834a7a0a23b	en_IN	CS_COMMON_PGR_STATE_RESOLVED	Resolved	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f8ee935b-7968-420d-90ce-a2c6fda0dd9d	en_IN	CS_COMMON_RE-ASSIGN REQUESTED	Re-assign Requested	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
36da5b1d-569e-49a7-8f75-4a8f2605d2a1	en_IN	CS_COMMON_REASSIGNED	Re-assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3989bb9a-1670-4a67-b6dd-5e7547555d75	en_IN	CS_COMMON_REASSIGNED_TO	Re-Assigned to 	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
00369a12-9a8e-4d83-a7ff-918350426da5	en_IN	CS_COMMON_RE_ASSIGNED	Re-Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b6da806e-8215-4e35-bcdb-4ec08c039876	en_IN	CS_COMMON_STATUS_ASSIGNED	Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e6527f71-deb1-4f5a-ba26-8bfa33c90c7c	en_IN	CS_COMMON_STATUS_BEING_REASSIGNED	Complaint is being Re-Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6ec8e8e8-fe6a-4112-9f14-f28b25d60c29	en_IN	CS_COMMON_STATUS_CLOSED	Your Complaint has been Closed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b2d1343e-eaf4-411f-9517-d1f274f0dcc2	en_IN	CS_COMMON_STATUS_REASSIGNED	Your Complaint has been Re-assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
029d7201-6e99-4d64-bcea-2150b19b0d55	en_IN	CS_COMMON_STATUS_REASSIGN_REQUESTED	Your Complaint is being Re-Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fbfb68d7-4e08-4411-a897-f8155a205234	en_IN	CS_COMMON_STATUS_REJECTED	Your Complaint has been Rejected	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
67249869-0aa6-49ed-822d-eccf2e632a19	en_IN	CS_COMMON_STATUS_REOPENED	Your Complaint has been Re-opened	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1d74fe89-983c-473f-8c88-58c6acdff2d8	en_IN	CS_COMMON_STATUS_RESOLVED	Your Complaint has been Resolved	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d09c4057-2111-41c1-80f1-2216a2fc3c49	en_IN	CS_COMMON_STATUS_SUBMITTED	Your Complaint has been Filed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3b90862c-093d-4b1e-a9e6-073a14db41e4	en_IN	CS_COMMON_STATUS_UNASSIGNED	Unassigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
64254557-f3a8-4083-83ea-333bdd8bc48e	en_IN	CS_COMPLAINTDETAILS_HOUSE	House/Street No	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
46e1c997-e2cf-424d-af14-2032f60f6e36	en_IN	CS_COMPLAINTDETAILS_LANDMARK	Landmark	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a7a4ecad-deea-4100-a179-a5ba568a4f0b	en_IN	CS_COMPLAINTDETAILS_MOHALLA	Mohalla/City	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0a6633f7-81ca-4275-8b14-0e729776cf2d	en_IN	CS_COMPLAINT_COMPLAINT_ADDTIONAL_DETAILS	Additional Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7b386d76-d76b-4ae7-bff1-d48fde522a48	en_IN	CS_COMPLAINT_DETAILS_ACCUMULATION_LITTER	Accumulation of Litter	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5325cc7a-907d-4dd8-918b-383267152d0f	en_IN	CS_COMPLAINT_DETAILS_ADDRESS_DETAILS	Address Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
17deed4d-67f2-4e08-bcff-265fbb1a6e65	en_IN	CS_COMPLAINT_DETAILS_ASSIGN	Assign	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
193717b3-7051-4214-8a2f-3fd18c26101e	en_IN	CS_COMPLAINT_DETAILS_ASSIGNED	Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4928b41b-d9ec-4a36-a6bc-ccf04907feae	en_IN	CS_COMPLAINT_DETAILS_ASSIGNED_TO	Assigned to 	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ee046b98-679b-4623-ba04-c32db4c032e7	en_IN	CS_COMPLAINT_DETAILS_ATTACHMENTS	Attachments	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0f79d47b-6f8f-4f36-8710-1b4572ce6709	en_IN	CS_COMPLAINT_DETAILS_BACK	Back	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a74c60f5-aaef-4f8c-a38c-cf7ee5197bbb	en_IN	CS_COMPLAINT_DETAILS_BEING_REASSIGNED	Complaint is being re-assigned by	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e8f4fb14-4162-43e1-a540-10caa3236fc1	en_IN	CS_COMPLAINT_DETAILS_BLOCKAGE_OF_DRAINS	Blockage Of Drains	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3a5127ba-ed76-49c4-b363-92c9f73e7f4a	en_IN	CS_COMPLAINT_DETAILS_BROKEN_FOOTPATHS	Broken Footpaths	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dab18d50-2cf5-460f-a48b-aecc98d09ef5	en_IN	CS_COMPLAINT_DETAILS_BUILDING_NAME	Build Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
009091c0-2e83-4d51-8ae4-950f49072c97	en_IN	CS_COMPLAINT_DETAILS_CALL_BUTTON	CALL	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e1e7e4fe-06ec-42d8-b534-5e4336f66cbe	en_IN	CS_COMPLAINT_DETAILS_CANCEL	Cancel	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
db831fea-de02-4ae4-868b-87e6e312eaf2	en_IN	CS_COMPLAINT_DETAILS_CANCELLED	Cancelled	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
046cfbce-dd88-48c5-aa88-5c4cf8f488c1	en_IN	CS_COMPLAINT_DETAILS_CHOOSE_FILE	Choose File	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
804892f4-27de-4ac5-93eb-2e9eb77e6c99	en_IN	CS_COMPLAINT_DETAILS_CITIZEN_FEEDBACK	Citizen Feedback	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
735604d5-a00c-4455-a783-96eae02bcd79	en_IN	CS_COMPLAINT_DETAILS_CITIZEN_REQUEST_REASSIGN	Being Re-assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dfc5761a-e485-465f-810e-5dba65e1bb53	en_IN	CS_COMPLAINT_DETAILS_CLEAR_ALL	CLEAR ALL	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0928725f-848c-4079-b16a-ff192651ef17	en_IN	CS_COMPLAINT_DETAILS_CLEAR_SEARCH	CLEAR SEARCH	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
333b3530-171c-4be6-91c7-2c33d91453a7	en_IN	CS_COMPLAINT_DETAILS_CLOSED	Closed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e3622da1-080c-4faa-b484-a4ca369fbd34	en_IN	CS_COMPLAINT_DETAILS_CLOSEDAFTERREJECTION	Closed after rejection	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
166c46da-ea58-47e0-869e-2c402c42ecc2	en_IN	CS_COMPLAINT_DETAILS_CLOSEDAFTERRESOLUTION	Closed after resolution	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c8e7edf9-bd39-4106-b225-e9f2d039641b	en_IN	CS_COMPLAINT_DETAILS_CLOSED_UCASE	CLOSED	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e0b00a89-4050-4737-8b7e-a85bfe5d4e8d	en_IN	CS_COMPLAINT_DETAILS_COMMENTS	Too much garbage lying on the road, its very dificult to cross the area.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1a60acfc-ceff-4ed0-ab4e-52dbe3c2d5fd	en_IN	CS_COMPLAINT_DETAILS_COMMENTS_PLACEHOLDER	Type your comments	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0570aba8-198e-4330-838e-da082d9e5673	en_IN	CS_COMPLAINT_DETAILS_COMMENTS_PLACEHOLDER2	Write your comments...	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f915c9e-f835-4b79-bfb7-6d92bbcb5f24	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT	Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
77bca363-8ae5-405a-9496-7ac0cdf185f0	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_ASSIGNED_TO	Complaint assigned to	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f426459a-bf75-4f44-bfe1-b09b2a7e4dc4	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_FILED	Complaint Filed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c9ff3bb9-c9a5-4a73-b1ea-f0f2f3418ca4	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_PENDINGFORASSINMENT	Pending for Assignment	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d01c833f-4a4b-4454-aad6-1d6334049519	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_REJECTED	Rejected	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0459eb66-bb61-44df-9fbd-5218c3562654	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_REOPENED	Complaint Re-opened	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e81f2e84-c8e6-4eb5-be1f-33fc5758f24f	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_RESOLVED	Complaint Resolved	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c2399f83-5ff2-4444-ad0a-438bf4fe86ce	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_STATUS	Complaint status	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8b8d3aad-34f0-4eca-b52e-3d14bcda71d5	en_IN	CS_COMPLAINT_DETAILS_COMPLAINT_SUBMITTED	Complaint Submitted	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d33726d9-67ff-472d-b554-df026db98050	en_IN	CS_COMPLAINT_DETAILS_DAY	day	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1f9251e0-198a-4747-9803-962d82afa191	en_IN	CS_COMPLAINT_DETAILS_DAYS	days	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5c493c88-89cf-40a2-8f53-d2ab4ba1bbbc	en_IN	CS_COMPLAINT_DETAILS_DAYS_LEFT	days left	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a868dc37-e5fb-4667-9038-74ef7ca802ff	en_IN	CS_COMPLAINT_DETAILS_DAY_LEFT	day left	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2c393cc0-24ec-41c5-ba25-664bd212bf44	en_IN	CS_COMPLAINT_DETAILS_DOOR	Door	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5c127213-74ed-41e9-9ec6-99c46dd9ab23	en_IN	CS_COMPLAINT_DETAILS_EMPLOYEE_COMMENTS	Comments	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1de6047d-76d4-44c6-9dd0-932b55b5b8e6	en_IN	CS_COMPLAINT_DETAILS_EMPLOYEE_NAME	Employee Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6e81a7aa-c345-4beb-af4d-ed59c37a6df7	en_IN	CS_COMPLAINT_DETAILS_ERROR_LOADING_RESULTS	Error while loading results	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
90991f00-8006-4f4b-9e4a-279d289b3b33	en_IN	CS_COMPLAINT_DETAILS_ERROR_SCREEN_MESSAGE	The page you are looking for cannot be found	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
10f23c92-d2bd-446a-844a-bd377d623bb0	en_IN	CS_COMPLAINT_DETAILS_FILE_A_COMPLAINT	File a Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cd7abba1-32cf-4f04-9d0c-b6d9482d18e2	en_IN	CS_COMPLAINT_DETAILS_FILTER	Filter	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ab008330-8eed-4b61-86b9-b50991bdd544	en_IN	CS_COMPLAINT_DETAILS_GARBAGE_BIN_ABSENT	Garbage Bin Absent	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
20ed5366-77de-4dc3-8dee-7e1b0c2a31e3	en_IN	CS_COMPLAINT_DETAILS_HOME	Home	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
47d2b053-bd39-47f7-bc8e-70a8544ef38d	en_IN	CS_COMPLAINT_DETAILS_INBOX	Inbox	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
46fd8db6-f28b-46fa-acd6-e9a1b8311e1c	en_IN	CS_COMPLAINT_DETAILS_LOCATION	Enter Complaint Location	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
703ed9e0-8609-4f8e-abfd-092bf73edcee	en_IN	CS_COMPLAINT_DETAILS_LOGOUT	Logout	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
be3d724e-3b3e-4391-977a-92399bb2ce07	en_IN	CS_COMPLAINT_DETAILS_MOBILE_NO	Mobile No	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8d801548-f394-49c7-bb8c-6021615645ae	en_IN	CS_COMPLAINT_DETAILS_MOBILE_NO.	Mobile No	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
13302fc8-54d2-418c-9133-fe2a501fd29b	en_IN	CS_COMPLAINT_DETAILS_NEXT	Next	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b79a55a3-6040-4605-b72d-e54a0f795e36	en_IN	CS_COMPLAINT_DETAILS_OPEN	Open	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a94dd236-fdcf-4538-b721-ef5b34cb69c5	en_IN	CS_COMPLAINT_DETAILS_OPENED	Opened	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6c73081c-c209-441b-80c4-bb71286df2fd	en_IN	CS_COMPLAINT_DETAILS_OPEN_UCASE	OPEN	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f8cf1b78-78b9-4aeb-92a0-a52f05eb44bd	en_IN	CS_COMPLAINT_DETAILS_OVERDUE_BY	Overdue by	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
33fc1e7e-c064-4db3-8638-9cc39274aec8	en_IN	CS_COMPLAINT_DETAILS_OVERFLOWING_BINS	Overflowing Garbage Bins	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ecb40850-8231-44cc-bd66-69132a01a646	en_IN	CS_COMPLAINT_DETAILS_PATHOLES	Patholes	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9eb86492-a4ff-4075-a4d4-8855331423df	en_IN	CS_COMPLAINT_DETAILS_PENDINGATLME	Pending at LME	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3c164143-e466-4582-ad62-37a77d0089ad	en_IN	CS_COMPLAINT_DETAILS_PENDINGATSUPERVISOR	Pending At Supervisor	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a974a014-d507-4af4-9bce-eac4d318c72b	en_IN	CS_COMPLAINT_DETAILS_PENDINGFORASSIGNMENT	Pending for assignment	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
db08874d-c8b5-4697-a210-e3699ddc6e9a	en_IN	CS_COMPLAINT_DETAILS_PENDINGFORREASSIGNMENT	Pending for reassignment	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8eb58479-17e7-4d17-89d6-f6f771907613	en_IN	CS_COMPLAINT_DETAILS_PENDING_STATUS	Complaint pending at GRO	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f66f1393-a3d4-4dd4-be54-24a78da3d50e	en_IN	CS_COMPLAINT_DETAILS_PINCODE_NOT_SERVICABLE	Sorry we are not providing service in this city	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0131b265-5f10-4980-b75f-6df0a07a7c50	en_IN	CS_COMPLAINT_DETAILS_PLOT_NO	Plot No.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1bd72a91-763f-4cb5-8462-f7e70d4c52ac	en_IN	CS_COMPLAINT_DETAILS_RATE	RATE	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
06386a58-72b6-459e-a10a-2fb825029c12	en_IN	CS_COMPLAINT_DETAILS_RATING_SUBMIT_TEXT	By making your voice heard, you help us improve mSeva.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8e19ad9c-8d08-4eb0-9aa2-7a777c987e88	en_IN	CS_COMPLAINT_DETAILS_RE-ASSIGN REQUESTED	Re-assign Requested	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c128477c-0fe7-4544-b88f-c4eef3316c1c	en_IN	CS_COMPLAINT_DETAILS_REASSIGNED	Re-assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ee426680-c694-49ea-9fbb-18d2c03987f6	en_IN	CS_COMPLAINT_DETAILS_REASSIGNED_TO	Re-Assigned to 	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
41ae40ef-94bf-4994-b360-217a35dc343d	en_IN	CS_COMPLAINT_DETAILS_REASSIGN_REQUESTED	Re-Assign requested	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d40436cf-df81-41bf-ac57-8718aef4a04a	en_IN	CS_COMPLAINT_DETAILS_REJECT	Reject	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1e272123-3418-451b-96c3-1f3889b80dae	en_IN	CS_COMPLAINT_DETAILS_REJECTED	Rejected	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8967f92a-05c1-4686-adcf-7d02225ff1c3	en_IN	CS_COMPLAINT_DETAILS_REJECTED_UCASE	REJECTED	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
780fd220-acfe-4529-9212-609c7b2d11cf	en_IN	CS_COMPLAINT_DETAILS_REOPEN	RE-OPEN	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d3c19363-d637-4c42-b839-e94ca8ae516a	en_IN	CS_COMPLAINT_DETAILS_REOPENED	Re-opened	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a83f15f5-e81a-49a8-a6a6-46ebb80a7f00	en_IN	CS_COMPLAINT_DETAILS_RESOLUTION_EVIDENCE	Resolution Evidence	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b5347b13-af73-4788-be0d-af89d713f085	en_IN	CS_COMPLAINT_DETAILS_RESOLVE	Resolve	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1ac2aea0-ea84-470a-8f44-87bc0d3dc60a	en_IN	CS_COMPLAINT_DETAILS_RESOLVED	Resolved	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
588fd8f2-c0d8-4995-87d7-16ce2c03bd23	en_IN	CS_COMPLAINT_DETAILS_RESOLVEDBYSUPERVISOR	Resolved By Supervisor	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9fda76e5-7cc7-48cf-b83a-1fed7cc41803	en_IN	CS_COMPLAINT_DETAILS_RESOLVED_UCASE	RESOLVED	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5afaa981-8d39-428f-b991-56c29b0e5ae6	en_IN	CS_COMPLAINT_DETAILS_RE_ASSIGNED	Re-Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fc5f807f-6748-4a92-b837-48dc2eff2fb8	en_IN	CS_COMPLAINT_DETAILS_SEARCH_BY	SEARCH BY	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9511adc1-533c-4c28-846b-30a44f144315	en_IN	CS_COMPLAINT_DETAILS_SKIP	Skip and Continue	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
544833c1-0253-4735-a55e-85fbb7cd254b	en_IN	CS_COMPLAINT_DETAILS_STATUS_ASSIGNED	Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3fe97152-8c21-408a-8127-7065c2f8a61b	en_IN	CS_COMPLAINT_DETAILS_STATUS_BEING_REASSIGNED	Complaint is being Re-Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1488a8ad-70a7-49dc-ac07-71acfd293caf	en_IN	CS_COMPLAINT_DETAILS_STATUS_CLOSED	Your Complaint has been Closed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1f5340e5-2635-43b9-ba63-6c0447d0bc4c	en_IN	CS_COMPLAINT_DETAILS_STATUS_REASSIGNED	Your Complaint has been Re-assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5a0612f2-80e6-4dff-99d8-9b3c033aaa44	en_IN	CS_COMPLAINT_DETAILS_STATUS_REASSIGN_REQUESTED	Your Complaint is being Re-Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9df4b1aa-75dd-4410-b7d8-c18ab6c63bc1	en_IN	CS_COMPLAINT_DETAILS_STATUS_REJECTED	Your Complaint has been Rejected	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
67df9575-376c-4f38-a741-900c557d3a11	en_IN	CS_COMPLAINT_DETAILS_STATUS_REOPENED	Your Complaint has been Re-opened	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f6321481-c5dd-4d2b-a5d4-dc1d8c28612e	en_IN	CS_COMPLAINT_DETAILS_STATUS_RESOLVED	Your Complaint has been Resolved	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
df02e985-d4af-46db-b28b-133e15d28924	en_IN	CS_COMPLAINT_DETAILS_STATUS_SUBMITTED	Your Complaint has been Filed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e19ae419-9ad8-4758-9ae9-813a7bdc0e5a	en_IN	CS_COMPLAINT_DETAILS_STATUS_UNASSIGNED	Unassigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
40931cf1-e679-42c4-90b4-108df74c28dc	en_IN	CS_COMPLAINT_DETAILS_STREET	Street	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1d5f0b47-26d2-4132-9d5b-12f8e52fd5f8	en_IN	CS_COMPLAINT_DETAILS_SUBMISSION_DATE	Filed Date	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e2fa359c-6a78-4333-a114-569df8a183e7	en_IN	CS_COMPLAINT_DETAILS_SUBMIT	SUBMIT	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1ad8b58c-043f-463d-94b0-3ef013bf0cc4	en_IN	CS_COMPLAINT_DETAILS_SUBMITTED	Filed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7a6ef640-49c3-471f-9182-e1faf2847cbe	en_IN	CS_COMPLAINT_DETAILS_SWEEPERS_ABSENT	Absenteeism of Sweepers	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
69e89b5c-c597-4e64-a568-22c70fbf3b17	en_IN	CS_COMPLAINT_DETAILS_THANK_YOU	Thank You	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f7e6f3c3-0b53-4aef-a19d-6cb8842cc793	en_IN	CS_COMPLAINT_DETAILS_TRACK_COMPLAINT_TEXT	The notification along with complaint number is sent to your registered mobile number. You can track the complaint status using mobile or web app.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3f79e23f-7e87-4964-9d7d-ea39736b4306	en_IN	CS_COMPLAINT_DETAILS_UPLOAD_PHOTOS	UPLOAD PHOTOS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a15d28df-6837-4fed-abb1-017fd2b17399	en_IN	CS_COMPLAINT_LOCALITY	Locality	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
90421a64-c5a9-44bf-8585-6352d31a147f	en_IN	CS_COMPLAINT_NO_ERROR_TEXT	Complaint No should be minimum 6 digits	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
11567adf-23e5-4af0-8e52-d535bfbabbf8	en_IN	CS_COMPLAINT_PIN_COMPLAINT_LOCATION_TEXT	Click and hold to drop the pin to complaint location. If you are not able to pin the location you can skip the continue for next step.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3a935385-0e37-4a96-9857-12e1815a6beb	en_IN	CS_COMPLAINT_SELECT_CITY	City	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d3dbadb3-84ee-444c-9f3a-82839c6b232b	en_IN	CS_COMPLAINT_SUBMITTED_COMPLAINT_NO	Complaint No.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c2e31a54-d188-4e8e-925f-5b8a75fa0ff8	en_IN	CS_COMPLAINT_SUBMITTED_LABEL1	Complaint Registered Successfully	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a05f99b8-ec22-4232-845a-baaffb379fae	en_IN	CS_COMPLAINT_SUBMITTED_LABEL2	You can track the status of your complaint on this app anytime!	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4ad185e9-fa9b-47c1-a4fc-207ed48ebf5e	en_IN	CS_COMPLAINT_SUBMITTED_THANKYOU	Thank You!	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
56463515-86de-40ee-80d1-ad514ee3e89c	en_IN	CS_COMPLAINT_TYPE_DRAINS	Drains	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e84615ca-fc67-48e1-b030-af62f16fe2d3	en_IN	CS_COMPLAINT_TYPE_GARBAGE	Garbage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
90e41d64-3052-4c6f-bf4a-bdb62949cfdc	en_IN	CS_COMPLAINT_TYPE_PUBLIC_HEALTH_HYGIENE	Public Health & Hygiene	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fb283766-4fa8-4ef2-a98d-46c4e8d7740c	en_IN	CS_COMPLAINT_TYPE_PUBLIC_LAND_PROPERTY	Public Land & Property	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cc7deda0-beb9-42bb-9291-30ed581a112b	en_IN	CS_COMPLAINT_TYPE_SEARCH_PLACEHOLDER	Search	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
38e63a5b-dcdd-4ab2-88e0-f897bcf7f5cc	en_IN	CS_COMPLAINT_TYPE_STREET_LIGHTS	Street Lights	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ae912244-0ecd-4ed2-bdd8-80f4608c268e	en_IN	CS_COMPLAINT_TYPE_WATER	Water	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ca32217e-50d8-4ca7-866f-27b76053c03d	en_IN	CS_CREATECOMPLAINT_MOHALLA_PLACEHOLDER	Choose Locality	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
451cc071-91ca-4094-bd60-e9a535c13a93	en_IN	CS_HEADER_ADD_COMPLAINT	Add Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d446ec40-2d57-4c88-814e-00c899860442	en_IN	CS_HEADER_ALL_COMPLAINTS	All Complaints	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4c0284c1-03dd-4552-8f3a-8a2de61b9e30	en_IN	CS_HEADER_ASSIGN_COMPLAINT	Assign Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d834b511-418b-489c-ba45-53ee7539aa75	en_IN	CS_HEADER_COMPLAINT_SUBMITTED	Complaint Filed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2bc60f5f-5a81-40ea-84ed-ea6fb2a11ccc	en_IN	CS_HEADER_REASSIGN_COMPLAINT	Re-Assign Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b8c1790f-84c2-4401-a6f9-bf547f058e07	en_IN	CS_HEADER_REOPEN_COMPLAINT	Reopen Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a6603871-73c4-450e-b97a-8ab916c0fd94	en_IN	CS_HEADER_REQUEST_REASSIGN	Request Re-Assign	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
78b57f7a-7d79-4da2-8b59-4b61c3287144	en_IN	CS_HOME_FILE_COMPLAINT	File Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b657c409-7781-41ed-969f-755c48550952	en_IN	CS_HOME_MY_COMPLAINTS_CARD_LABEL	My Complaints	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
df2ec3d2-78e4-4037-8788-dbac367057e3	en_IN	CS_HOME_STATUS_PREFIX	Your complaint has been	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
140b9452-9bce-47c7-a3d5-373cfbf9d56e	en_IN	CS_HOME_STATUS_REASSIGN_PREFIX	Your complaint is	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
95d7988b-d259-4555-963f-d3c913e962a7	en_IN	CS_HOME_UPDATES	Filed Complaints	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1343f024-17b3-4061-b7b7-c5723e62da01	en_IN	CS_HOWITWORKS_DESCRIPTION	We have made connecting with us easier than ever before. Once you raise the complaint, we will assign it to the responsible officer. You can track the status of your complaint on our web-site under “ My Complaints “ till your complaint is resolved.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f7a27a72-7a60-445a-8279-8f262aafe7da	en_IN	CS_HOWITWORKS_RAISE_COMPLAINT	Raise a Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3356f1e6-f0e0-4c3d-bbdd-b7fb1feeaebb	en_IN	CS_LANDING_PAGE_COMPLAINTS_DESCRIPTION	mSeva Complaints offers an easy to use interface which enables you to lodge civic works related complaints. It also lets you track the status of your complaint and facilitates direct interaction with your municipality till its resolution.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a665de91-5502-44c9-9fe6-3a9dc7c2851d	en_IN	CS_MYCOMPLAINTS_CLOSED	Complaint Resolved. Please rate	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
90506be1-9c7f-4ac7-a391-3a17c3b59d0b	en_IN	CS_MYCOMPLAINTS_COMPLAINT_HEADER	ComplaintHeader	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ab52a686-d077-4214-99b9-aaa49f08364e	en_IN	CS_MYCOMPLAINTS_COMPLAINT_PREFIX	Complaint has been	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c30f6bdc-48f4-4790-92c1-9bec812a4746	en_IN	CS_MYCOMPLAINTS_ESCALATED_TO	Escalated To:	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
85781c59-c981-4ea4-86fb-194ed243df8d	en_IN	CS_MYCOMPLAINTS_RATE	. Please rate	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
18346148-ebd1-40b0-aed2-54db5e440101	en_IN	CS_MYCOMPLAINTS_REASSIGN_MESSAGE1	requested for re-assign	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dd421646-ac87-4b52-8f6f-63bdfbaf2898	en_IN	CS_MYCOMPLAINTS_REASSIGN_MESSAGE2	You have	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
914c8d3c-8a11-48e9-9eb1-1a5746b1c59c	en_IN	CS_MYCOMPLAINTS_REJECTED	Complaint has been Rejected	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c7d50826-3414-4154-a62a-7794f603347c	en_IN	CS_MYCOMPLAINTS_RE_ASSIGNED	Complaint Re-assigned to	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b12efb4e-201b-4881-a249-e04a2636f173	en_IN	CS_MYCOMPLAINTS_TO	to	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d3830f71-67b5-4fa0-a57b-e90bf2dcac58	en_IN	CS_MYCOMPLAINTS_TRACK	TRACK	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5e2dedd6-67c4-48c7-aa80-569b2d148bcb	en_IN	CS_PGR_REPORTS_HEADER	Citizen Complaint Resolution System Reports	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2fd4e0ea-3b6c-4d2e-95c9-f436c814e05b	en_IN	CS_REOPEN_COMPLAINT_WHY	Why do you want to Re-Open your Complaint?	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9a5ada42-348d-4c97-a89b-ceaab4ef4f13	en_IN	CS_REOPEN_SUCCESS_MESSAGE	Your complaint has been Re-opened	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c49a9fd0-7ff9-4bf7-b22a-5dfb47c5e13e	en_IN	CS_SORT_OPTION_ONE	Complaint Date - Old to New	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d7ea3f72-ad28-42ca-952f-52738db8fab6	en_IN	CS_SORT_OPTION_TWO	Complaint Date - New to old	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fdadd117-1150-4991-b2fb-a18a2dd10522	en_IN	DASHBOARD_TITLE_PGR	Dashboard	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cdf14490-3941-4fd3-953c-fc52f6c315eb	en_IN	DEPARTMENT_DEPT_1	Street Lights	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
89923eb2-fd7e-43df-9285-90fbde409e89	en_IN	DEPARTMENT_DEPT_3	Garbage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f2d49b2f-d6f8-43c2-8aec-42a9c9ec23d4	en_IN	EMPLOYEE.ASSIGNMENT.TITLE	ASSIGNMENT DETAILS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d9c920df-db24-4c3a-a7a8-6396562a01c1	en_IN	EMPLOYEE.EMPLOYEE.TITLE	EMPLOYEE DETAILS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a2aa8f16-4837-433c-a70a-82087bf829d0	en_IN	EMPLOYEE.JURISDICTION.TITLE	JURISDICTION LIST	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c5699077-ddec-4e1d-8638-9b8d7a39582a	en_IN	EMPLOYEE.OTHER.TITLE	OTHER DETAILS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2fa7782a-a467-4a12-84d3-bd161c835022	en_IN	EMPLOYEE.SERVICE.TITLE	SERVICE SECTION	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cc1405d9-cade-4249-98b5-056033d23dc3	en_IN	ERR_COMPLAINT_NUMBER_SEARCH	Enter at least last 6 digit of complaint No	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ca681f21-c206-4761-9aaa-101176181b46	en_IN	ES_ALL_COMPLAINTS_ASSIGNED_TAB_LABEL	ASSIGNED	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a0ab8334-691c-480a-8dca-5cfa0a92d9f1	en_IN	ES_ALL_COMPLAINTS_ASSIGNED_TO	Assigned to:	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fc77fcc0-aa53-4daf-ae38-8660e94ec2bc	en_IN	ES_ALL_COMPLAINTS_HEADER	All Complaints	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
68b3bd68-bcfb-4b92-af42-f4bbdb3cefe2	en_IN	ES_ALL_COMPLAINTS_SUBMITTED_BY	Submitted By :	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8fc56f40-d803-4f22-a7be-4d610c54fd0d	en_IN	ES_ALL_COMPLAINTS_UNASSIGNED_TAB_LABEL	UNASSIGNED	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0462d3fb-fb5f-4046-96c2-6679746e5e39	en_IN	ES_ASSIGN_STATUS_ASSIGN	Choose Employee to assign complaint to from the list	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
14c0fbe5-1940-4fd8-b128-340c542ec7b5	en_IN	ES_ASSIGN_STATUS_REASSIGN	Choose Employee to Re-assign complaint to from the list	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
772a4845-fc13-4fd5-90f7-119e92298126	en_IN	ES_ASSIGN_TO_EMPLOYEE_HEADER	Assign to Employee	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
011bd56e-47f5-48b6-81fa-409d2a68aef7	en_IN	ES_CLOSED_COMPLAINTS_HEADER	Closed Complaints	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5e29a0dd-f2ce-41ad-89cf-0f7a5f78acc4	en_IN	ES_COMMON_ASSIGN	ASSIGN	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a26daf58-afb2-4e67-ab63-af67bff5d67e	en_IN	ES_COMMON_REASSIGN	RE-ASSIGN	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9e60f961-7b5a-4483-bed7-3e5c38da5b73	en_IN	ES_COMMON_SEARCH_COMPLAINT	Search Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
866c8901-4c6a-4021-a7f5-677018739d3b	en_IN	ES_COMMON_SEARCH_EMPLOYEE	Search Employee	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f3cda1f9-050c-4f87-a656-bb0c4f8b6b61	en_IN	ES_COMPLAINTS_COUNT_RATIO_LABEL	Showing {0} of {1} complaints	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8aa1eeac-128f-4c76-b01a-d0b492b0f50d	en_IN	ES_COMPLAINT_ASSIGNED_HEADER	Complaint Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
09bb15d0-9dc5-47ac-b78a-61681378aec8	en_IN	ES_COMPLAINT_DETAILS_ASSIGNED_BY	Assigned By	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9461d551-4bbd-4aa2-9725-e0bad3c225df	en_IN	ES_COMPLAINT_DETAILS_REASSIGNED_BY	Re-Assigned By	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
594e97a3-5cb6-4aa5-85b3-00dad5afc7d2	en_IN	ES_COMPLAINT_FILED_BY_CSR	Complaint Filed at Citizen Service Desk	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f9567f9-5980-46b5-98f5-cc0e8dc83640	en_IN	ES_COMPLAINT_REASSIGNED_HEADER	Complaint Re-Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4212227f-c556-407f-aad5-97fbacede5f8	en_IN	ES_COMPLAINT_REJECTED_HEADER	Complaint Rejected	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
87737efc-a4cc-4f14-9f5e-2cffad01d263	en_IN	ES_COMPLAINT_REJECT_SUCCESS_MESSAGE	You have Rejected this complaint.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e51af9f2-a8d9-40f8-b141-ceb18e82be32	en_IN	ES_COMPLAINT_RESOLVED_SUCCESS_MESSAGE	You have marked the complaint as	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fe7e15b0-52f6-4f45-9f90-eac13c373b24	en_IN	ES_COMPLAINT_SUCCESS_LASTLABEL	Please share the complaint no. with the citizen	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5bac63d6-0ebe-4dc6-908b-779d71b3f605	en_IN	ES_COMPLAINT_SUMMARY_MAP	MAP	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e516d324-7397-43ab-8da7-47eb6a4663fc	en_IN	ES_CREATECOMPLAINT_ADDITIONAL_DETAILS	Additional Complaint Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e5e488b4-3236-4ace-add3-d6a0e0d7079a	en_IN	ES_CREATECOMPLAINT_ADDITIONAL_DETAILS_PLACEHOLDER	Add complaint description	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
70c97b96-0939-4292-a5dd-f0bf34d4173d	en_IN	ES_CREATECOMPLAINT_ADDRESS_PLACEHOLDER	Enter complaint address	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c4ba0d2b-7725-4392-ae33-0c4170434b7e	en_IN	ES_CREATECOMPLAINT_COMPLAINT_NAME_PLACEHOLDER	Enter citizen name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
beaea68a-81f5-48cd-9863-f7e850039f44	en_IN	ES_CREATECOMPLAINT_MOBILE_NUMBER_PLACEHOLDER	Enter citizen mobile no.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
43b660d7-dd43-4a0e-9bad-cfaae3720a69	en_IN	ES_CREATECOMPLAINT_MOHALLA	Mohalla	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7a96e17f-f5d5-4060-a8d2-c33396aa34df	en_IN	ES_CREATECOMPLAINT_MOHALLA_PLACEHOLDER	Select your Mohalla	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1794880f-472b-4d3e-9267-3427684310b6	en_IN	ES_CREATECOMPLAINT_SELECT_PLACEHOLDER	Select	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a5f0a889-3444-4142-bc35-6fe2d1c4eb4b	en_IN	ES_CREATE_COMPLAINT	Create Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2e68c815-552b-4c3f-8167-e69ba25ed51d	en_IN	ES_EMPLOYEE_DIRECTORY_HEADER	Employee Directory	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
74c80c88-d533-47fc-bc33-d64c9fb4aa45	en_IN	ES_MYCOMPLAINTS_CLEAR_SEARCH_BUTTON	CLEAR SEARCH	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
da2f0b85-b134-4657-a14b-32adddbcb791	en_IN	ES_MYCOMPLAINTS_COMPLAINT_NO	Enter last 6 digits of Complaint No	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
347bd398-9dc0-46a9-8d77-612bbcece21a	en_IN	ES_MYCOMPLAINTS_NO_ASSIGNED_COMPLAINTS	No assigned complaints	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
db8ad7ed-e530-450e-981d-2c58d0337105	en_IN	ES_MYCOMPLAINTS_NO_COMPLAINTS_ASSIGNED	No complaints to show	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2dad4316-dfcc-48ad-b5dc-31fbc718f573	en_IN	ES_MYCOMPLAINTS_NO_COMPLAINTS_TO_ASSIGN	No complaints to Assign	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4989b0f8-67eb-419b-88a7-7aac7b6b643e	en_IN	ES_MYCOMPLAINTS_SEARCH_BUTTON	SEARCH	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
77f66a95-2be5-472a-bd4f-6f0c5e7e57e3	en_IN	ES_OPEN_COMPLAINTS_HEADER	Open Complaints	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
33b7d111-042e-4a6c-a8a3-955f6f068dd3	en_IN	ES_REASSIGN_OPTION_FOUR	Other	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5049bf15-379f-4cb7-85e1-ee5b1a746844	en_IN	ES_REASSIGN_OPTION_ONE	Not a valid complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e557bb90-4b52-46ac-bff2-4416d883b08d	en_IN	ES_REASSIGN_OPTION_THREE	Absent or on leave	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ee381b7a-4195-4b74-9dd7-1dc33374ab11	en_IN	ES_REASSIGN_OPTION_TWO	Not my responsibility	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0542d8fb-d47b-4d8f-a796-745fc6199630	en_IN	ES_REASSIGN_REQUEST_QUESTION	Why do you want this complaint to be Re-Assigned?	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
42cd4386-b72a-468d-93bc-787a0bec9474	en_IN	ES_REASSIGN_REQUEST_SUCCESS_MESSAGE	Your Re-Assign request has been sent.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
734e9163-d723-43e0-b7a1-6d46457ff08a	en_IN	ES_REASSIGN_TO_EMPLOYEE_HEADER	Re-Assign to Employee	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
42d7c3d2-df83-4d16-bcf6-62b5f0fa0030	en_IN	ES_REJECT_COMPLAINT_QUESTION	Why do you want to Reject this Complaint?	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3b5c0ac2-d6b5-49e1-81a0-dc42d1ce2cc8	en_IN	ES_REQUEST_REQUEST_RE_ASSIGN	REQUEST RE-ASSIGN	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
32efafbc-0f13-4dd3-b596-65ed39aaa94a	en_IN	HR_SUMMARY_DEPT_TEST_DEATILS_SUBHEADER	Department Test Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
68b6291d-33a9-4093-8ff8-e204412133f4	en_IN	PGR_ACTION_ASSIGN	Assign Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3a892cb0-ccfc-4c39-a6f9-5a279224114e	en_IN	PGR_ACTION_REASSIGN	Re-Assign Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cf095e8b-badf-4872-8e88-c2a998369c4a	en_IN	PGR_ACTION_REOPEN	Reopen Complaint	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8838254e-4f28-4deb-af2e-6bc6598f1e64	en_IN	PGR_APPLY_PENDINGFORASSIGNMENT_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} has been submitted with ID {id} on {date}. You can track your complaint status on the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4c3caeba-0958-468a-b720-4cde7b0aa09e	en_IN	PGR_ASSIGN_CITIZEN_PENDINGATLME_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been assigned to {emp_name}, {emp_designation}, {emp_department}. You can track your complaint status and connect with our officials on the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ee62eec6-aabc-4270-9400-225820d413b0	en_IN	PGR_ASSIGN_EMPLOYEE_PENDINGATLME_SMS_MESSAGE	Shri {emp_name}, Complaint for {complaint_type} with ID {id} has been assigned to you. Please take appropriate action. {ao_designation} - {ulb}.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c87335c0-60ac-4921-9767-c9a57f5ff63a	en_IN	PGR_CITIZEN_REASSIGN_PENDINGATLME_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been re-assigned to {emp_name}, {emp_designation}, {emp_department}. You can track your complaint status and connect with our officials on the web portal. \n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
04ed4081-aec5-4984-a010-2f78d766c777	en_IN	PGR_CLOSE_EMPLOYEE_CLOSEDAFTERRESOLUTION_SMS_MESSAGE	Shri {emp_name}, Complaint for {complaint_type} with ID {id} has received {rating}/5 feedback from the citizen. Thank you for your service.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
340d9f10-1a16-4611-a21f-0e9c62b2555f	en_IN	PGR_DEFAULT_CITIZEN_SMS_MESSAGE	Your current complaint status is {status}. You can track your complaint status on the mSeva app or your local government web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a4ed719a-01ab-468d-8406-6dcabad1e0d8	en_IN	PGR_DEFAULT_SMS_MESSAGE	Your complaint has been {status}. You can track your complaint status on the mSeva app or your local government web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
91526ce9-3f9e-45f2-b23e-f069acfe88dd	en_IN	PGR_EMPLOYEE_REASSIGN_PENDINGATLME_SMS_MESSAGE	Shri {emp_name}, Complaint for '{complaint_type}' with ID {id} has been re-assigned as per your request. {ao_designation} - {ulb} \n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4951b89d-7d0c-44fb-a58e-1f84141a3b7b	en_IN	PGR_REASSIGN_CITIZEN_PENDINGATLME_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been re-assigned to {emp_name}, {emp_designation}, {emp_department}. You can track your complaint status and connect with our officials on the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2b5521af-e3bb-4251-a2a4-a2eb2351cb47	en_IN	PGR_REASSIGN_EMPLOYEE_PENDINGATLME_SMS_MESSAGE	Shri {emp_name}, Complaint for {complaint_type} with ID {id} has been re-assigned as per your request. {ao_designation} - {ulb}.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2a408799-fa5d-419e-ba46-7d8e02782465	en_IN	PGR_REASSIGN_PENDINGATLME_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been re-assigned to {reassign_emp_name}, {emp_designation}, {emp_department}. You can track your complaint status and connect with our officials on the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bd6f9b73-ebad-43b6-9407-4a8866aa22a1	en_IN	PGR_REJECT_CITIZEN_REJECTED_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been rejected. Reason for Rejection: {reason}, Additional Comments: {additional_comments} If you wish to re-open the complaint, you can visit the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2200903c-9ea9-4094-97af-e563b390e830	en_IN	PGR_REJECT_REJECTED_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been rejected. Reason for Rejection: {reason}, Additional Comments: {additional_comments} If you wish to re-open the complaint, you can visit the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
636e7750-6119-487a-94f3-c6a8d22bed2c	en_IN	PGR_REOPEN_CITIZEN_PENDINGFORASSIGNMENT_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been RE-OPEN as per your request. You can track your complaint status and connect with our officials on the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3de83070-49a5-4cad-b343-bdeb167323c7	en_IN	PGR_REOPEN_EMPLOYEE_PENDINGFORASSIGNMENT_SMS_MESSAGE	Shri {emp_name}, Complaint for {complaint_type} with ID {id} has been re-opened by the citizen. It is being reviewed by Assigning officer - {ulb}.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9e902283-fd0b-46ec-9429-bcf1b3cfd26a	en_IN	PGR_REOPEN_PENDINGFORASSIGNMENT_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been RE-OPEN as per your request. You can track your complaint status and connect with our officials on the web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d344da5c-ab96-4ffc-8076-16073bdfa73d	en_IN	PGR_RESOLVE_CITIZEN_RESOLVED_SMS_MESSAGE	Dear Citizen, Your complaint for {complaint_type} with ID {id} submitted on {date} has been resolved by {emp_name}. If you are not satisfied with service you can RE-OPEN complaint through web portal or by calling your nearest municipal office\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1061270e-8fc5-4bd1-9c24-67294c359ca0	en_IN	PGR_RESOLVE_RESOLVED_SMS_MESSAGE	Dear Citizen,\n Your complaint for <complaint_type> with ID <id> submitted on <date> has been resolved by <emp_name>. If you are not satisfied with service you can REOPEN complaint through web portal or by calling our CSR.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
68893ca3-6f7b-4171-b557-a8402bf68d8c	en_IN	SERVICEDEFS_BOUNDARYSTRUCTUREIDENTITY	Boundary, Structure & Identity	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bffceb9a-8d76-4051-9077-9eb6910d8056	en_IN	WF_PGR_APPLY	Applied	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5da26a44-88fa-4a55-b72f-3e95b52e6491	en_IN	WF_PGR_ASSIGN	Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6487f7f5-a523-4597-be3a-449ee11683eb	en_IN	WF_PGR_RATE	Closed after rating	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f974f68a-d798-4dd1-aba3-0e3fffca7a14	en_IN	WF_PGR_REASSIGN	Re-Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9b2dc19c-6b02-42dc-b8e8-48c5646e6bf6	en_IN	WF_PGR_REJECT	Rejected	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
242734f8-ebb2-4db0-a08c-1b0ff1fd3532	en_IN	WF_PGR_REOPEN	Reopened	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dc9bc32e-66cf-445d-a6bd-e17829e82fc7	en_IN	WF_PGR_RESOLVE	Resolved	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b91d590e-8209-4daf-892b-017fbf3271cd	en_IN	chatbot.pgr.assigned	Assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8741cd80-b31e-4385-abc4-86309987d559	en_IN	chatbot.pgr.closed	Closed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3aeb498e-b6c5-4bac-9766-e2ced480fd43	en_IN	chatbot.pgr.open	Filed	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a8194671-4558-4425-9411-98209bcf68f8	en_IN	chatbot.pgr.reassignrequested	Being Re-assigned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e77b1832-4142-404f-8356-dfcb26ba9d31	en_IN	chatbot.pgr.rejected	Rejected	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3b4b4814-9260-4b7a-9417-24dd22854b83	en_IN	chatbot.pgr.resolved	Resolved	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6321e301-da57-4a22-90cb-805ab7321339	en_IN	employee.Assignment.fields.department	Department	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ffb53ef4-4d7a-4f39-8406-c90cd625d751	en_IN	employee.Assignment.fields.designation	Designation	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
10f0d987-a213-4a27-af5d-7c5209cccd6c	en_IN	employee.Assignment.fields.documents	Documents	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
88849954-855b-43da-828a-07644f88cda2	en_IN	employee.Assignment.fields.fromDate	From Date	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8e8ef7b5-4a29-43a9-97a4-f3c6ad5547eb	en_IN	employee.Assignment.fields.function	Function	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ecfdd58c-1df5-4dea-abcf-1c417990f4fb	en_IN	employee.Assignment.fields.functionary	Functionary	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bc8b014c-798d-4c00-a733-bfca0def998f	en_IN	employee.Assignment.fields.fund	Fund	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1453bcdc-6391-40ca-8c2b-d1833d8f98f2	en_IN	employee.Assignment.fields.govtOrderNumber	Govt Order Number	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
98214202-2535-4770-aa6a-18dd272f1a96	en_IN	employee.Assignment.fields.grade	Grade	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
24f5a76c-a047-43e7-81b6-b8da11702a39	en_IN	employee.Assignment.fields.hod	If Hod	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f68a59c-102f-4037-a5a5-786d1f22075e	en_IN	employee.Assignment.fields.position	Position	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
36e4756b-89c3-4e6a-b0e0-5eaac1399751	en_IN	employee.Assignment.fields.primary	Is Primary	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a877dccf-8890-4878-903e-471083d522d0	en_IN	employee.Assignment.fields.toDate	To Date	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8ccc75bd-c58a-4e0e-99dd-ae6911dbad31	en_IN	employee.Assignment.title	ASSIGNMENT DETAILS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3ece9c17-532d-4488-80f9-c5ad9dcbd13d	en_IN	employee.DepartmentalTest.fields.test	Test	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cc2fc20b-816f-4f92-89d9-8ea1b0a86d84	en_IN	employee.DepartmentalTest.title	Departmental Test Details	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
845e9b68-4acb-4291-bbd5-2920709dc8d1	en_IN	employee.EducationalQualification.fields.documents	Doc Documents	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2f0f2235-b275-4e69-bee5-533d150f63a9	en_IN	employee.EducationalQualification.fields.majorSubject	Major Subject	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
11374af2-2a17-4317-b346-360b1a61ca63	en_IN	employee.EducationalQualification.fields.qualification	Qualification	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1ad1228a-1fe0-40d3-b305-c6d930de0a1f	en_IN	employee.EducationalQualification.fields.university	University/Board	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
435ac3c0-2ab7-4232-9e5f-dddb4b5ffeef	en_IN	employee.EducationalQualification.title	Educational Qualification	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
df71acdf-1ba2-412b-8b61-ad210f4ebdc7	en_IN	employee.Employee.fields.EmployeePhoto	Employee Photo	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
348cc2a1-9ed1-4ee5-9d5b-d1070310ab73	en_IN	employee.Employee.fields.EmployeeSignature	Employee Signature	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
74a6d23d-47a6-4091-b73a-4d97416427eb	en_IN	employee.Employee.fields.OtherAttachments	Other Attachment	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4305a7c3-fd85-433d-b8d6-083531e299c1	en_IN	employee.Employee.fields.User.aadhaarNumber	Aadhaar Number	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7fc17495-7003-4177-85b6-6a123dbd05bc	en_IN	employee.Employee.fields.User.birth	Native/Birth Place	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
644a2305-a1a4-4e12-99a5-41cf34a50781	en_IN	employee.Employee.fields.User.bloodGroup	Blood Group	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
87204670-a3f1-429f-ab32-db33e0418cf7	en_IN	employee.Employee.fields.User.gender	Gender	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
09b6270c-7ba7-43f4-908e-f5ee3066fc4c	en_IN	employee.Employee.fields.User.mobileNumber	Phone Number	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a183efeb-b71c-48b1-890f-46ea3ada1f6c	en_IN	employee.Employee.fields.User.name	Employee Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dee6c62e-605b-4879-bad1-09f3dcfffb44	en_IN	employee.Employee.fields.User.userName	User Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
52448471-1997-4137-b929-7905f65e47dd	en_IN	employee.Employee.fields.bank	Bank	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e110f33b-ad85-43fb-9b78-e3929f0e8c12	en_IN	employee.Employee.fields.bankAccount	Account Number	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
630e5a62-c60a-4cd6-8ddd-a21bffcb3bf1	en_IN	employee.Employee.fields.bankBranch	Bank Branch	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3f6f8fb4-4db9-4f3c-b994-8ad5cfff5754	en_IN	employee.Employee.fields.category	Category	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9d3877c9-cf93-4276-86d4-7f53e542acae	en_IN	employee.Employee.fields.city	City	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ede58672-9847-4609-aaa3-7346f1804703	en_IN	employee.Employee.fields.code	Code	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e58b59fd-86d5-45a3-9b15-6bdbee24589e	en_IN	employee.Employee.fields.community	Community	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
15270931-e7c3-4582-8ebb-8b1c44b9a812	en_IN	employee.Employee.fields.correspondenceAddress	Correspondence Address	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6212d59a-e9ef-4571-b93e-f4c6e6191aab	en_IN	employee.Employee.fields.correspondencePinNumber	Correspondence Pin Number	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0d2a0434-7287-4ead-a061-b3f50e7fc024	en_IN	employee.Employee.fields.dateOfAppointment	Date of Appointment	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cbe610fb-a5e6-41dc-8dfc-d47942e2c401	en_IN	employee.Employee.fields.dateOfBirth	Date of Birth	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
116d0fc7-9d45-411c-abf9-f2ac305bca43	en_IN	employee.Employee.fields.dateOfJoining	Date of Joining/Deputation	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
db03f77b-44a8-456e-b133-0e58e9252062	en_IN	employee.Employee.fields.dateOfResignation	Date of Resignation	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0d36b407-ae97-4313-b1a4-1ae590d6adff	en_IN	employee.Employee.fields.dateOfRetirement	Date of Retirement	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f2700ce5-4821-4586-abc4-5b1f82bf58f9	en_IN	employee.Employee.fields.dateOfTermination	Date of Termination	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ecae9d49-1a2e-4201-86f0-2142553a64d5	en_IN	employee.Employee.fields.email	Email Id	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
109ab398-2158-4888-94a7-e191741fa4ff	en_IN	employee.Employee.fields.employeeStatus	Employee Status	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6b7be269-34f6-4312-855a-2ff7a12c638b	en_IN	employee.Employee.fields.employeeType	Employee Type	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a56c74d2-c759-4ec9-b4bb-3e07f6b1a389	en_IN	employee.Employee.fields.fatherSpouseName	Father's/Spouse Name	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8c09c644-0ae1-4897-a10b-43fe25cdb643	en_IN	employee.Employee.fields.gpfNo	Gpf No/CPS Number	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d753773b-0cb6-485f-a0d5-ddddb2c6c855	en_IN	employee.Employee.fields.group	Employee Group	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4245eb61-059f-4e0d-9f04-cdc740809486	en_IN	employee.Employee.fields.identification	Identification Mark	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f52185d-9ff2-4887-875d-7c2f0e4e2a03	en_IN	employee.Employee.fields.languagesKnown	Languages Known	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a669c91f-2269-4370-a0d5-e8aca3a492eb	en_IN	employee.Employee.fields.maritalStatus	Marital Status	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f1d406d-7848-4124-b6b9-30be7b1c1f55	en_IN	employee.Employee.fields.medicalReportProduced	Medical Report Produced?	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
16551dc3-1dcd-4cae-8322-7b5298bec74a	en_IN	employee.Employee.fields.motherTongue	Mother Tongue	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8034f6c3-c463-4ac4-963b-c3d5390ae52b	en_IN	employee.Employee.fields.pan	PAN	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f6ef548-ed0c-4326-a0e3-2e84cc030ec3	en_IN	employee.Employee.fields.parmanentPinNumber	Permanent Pin Number	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
da3ea9e4-e99d-4742-bc35-4805c36d9406	en_IN	employee.Employee.fields.passportNo	Passport No	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
44cda11a-4b46-4b41-b8d3-c788264a0c95	en_IN	employee.Employee.fields.permanentAddress	Permanent Address	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3f449c54-33ab-4293-9306-daa3f6335ebb	en_IN	employee.Employee.fields.physicallyDisabled	Is Physically Disabled?	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
45921ab8-b9ea-4814-b26f-1d50934956a5	en_IN	employee.Employee.fields.recruitmentMode	Recruitment Mode	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
230e1ae6-654d-4463-b9b6-c2032b050195	en_IN	employee.Employee.fields.recruitmentQuota	Recruitment Quota	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
838b4aaf-4fb3-470c-8f61-7ee80475ae9d	en_IN	employee.Employee.fields.recruitmentType	Recruitment Type/Service Type	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b39b0d05-b83a-4f7d-9669-0f127949e574	en_IN	employee.Employee.fields.religion	Religion	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
141782ff-0098-4b67-8447-1df32edac31c	en_IN	employee.Employee.fields.retirementAge	Retirement Age	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a4320345-5c16-47a9-8848-bcbcc3e5aea5	en_IN	employee.Employee.title	EMPLOYEE DETAILS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5426e93c-31b4-477b-ac11-b45119f14be1	en_IN	employee.Jurisdictions.title	JURISDICTION LIST	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f5c30328-0e2d-41be-a20e-218c8074103f	en_IN	employee.Probation.fields.declaredOn	Declared On	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
783dba3b-fdaa-4de8-b086-1123f0962d22	en_IN	employee.Probation.fields.documents	Documents	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1e5ac2b5-b31b-470f-9925-dcf8cd35b470	en_IN	employee.Probation.fields.orderDate	Order Date	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
975fe26e-17e7-48a2-9be6-d7a4a144a755	en_IN	employee.Probation.fields.orderNo	Order No	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
21279e54-720c-4fb0-923b-00f165b150fe	en_IN	employee.Probation.fields.remarks	Remarks	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
64c3e658-8a06-4f59-81d2-798879323dbb	en_IN	employee.Probation.title	Probation	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5445f9e9-fc9d-4e3a-b0c9-f6f46705d942	en_IN	employee.Regularisation.fields.declaredOn	Declared On Date	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
39984785-916f-4edd-9b72-f4170737590f	en_IN	employee.Regularisation.title	Regularisation	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
04e4c7fb-7e10-4606-8f8e-27eb00455c5c	en_IN	employee.ServiceHistory.fields.ServiceEntryDescription	Service Entry Description	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6b3fc32a-ce1a-4c50-b883-8882af5bf30e	en_IN	employee.ServiceHistory.fields.date	Date	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9b5440ea-a577-4ea9-8931-e73dce155f8c	en_IN	employee.ServiceHistory.fields.documents	Documents	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
134f458e-bb5c-40aa-b588-9e6e63c6de81	en_IN	employee.ServiceHistory.fields.orderNo	Order No	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6b8a7fab-3a9f-4133-b460-59cb7296b6a4	en_IN	employee.ServiceHistory.fields.remarks	Remarks/Comments	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e23caf18-7c76-413b-96b7-80801d29163e	en_IN	employee.ServiceHistory.title	Service History	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c122f087-60f7-4f06-8c7b-6c757e5c683a	en_IN	employee.TechnicalQualification.fields.grade	Grade	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d282d74a-9322-4a4a-b267-20852ae8ceb7	en_IN	employee.TechnicalQualification.fields.remarks	Remarks	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
85f33011-498d-4899-aeef-bc9ac8e31abe	en_IN	employee.TechnicalQualification.fields.skill	Skills	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ed2db58c-ef86-4a47-ad6e-92f6489ac96a	en_IN	employee.TechnicalQualification.fields.yearOfPassing	Year Of Completion	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bacd907f-caa7-4e9b-9dcc-d130c8fa382c	en_IN	employee.TechnicalQualification.title	Technical Qualification	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a1416a64-1de2-4612-a005-847fc4186a75	en_IN	employee.createPosition.groups.fields.outsourcepost.value1	Yes	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ab2ad5da-8d9c-4d73-927f-a44d759a5afb	en_IN	employee.createPosition.groups.fields.outsourcepost.value2	No	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e34202f0-7be0-44ef-9006-fad2668412d0	en_IN	employee.fields.isUserActive	Is User Active?	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
023430e9-f390-42a3-9130-6c708b6440d6	en_IN	employee.jurisdiction.fields.boundary	Boundary	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e0f47540-8e96-44f3-8c27-23a1aae17a86	en_IN	employee.jurisdiction.fields.boundaryType	Boundary Type	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e8f477d0-7a2f-4688-af76-0efc4a97179b	en_IN	employee.other.title	OTHER DETAILS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e950b510-e234-40ff-af4d-4ed5d4b29c89	en_IN	employee.service.title	SERVICE SECTION	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
50c92f71-7bac-4741-b7b7-20b146fe760c	en_IN	pgr.complaint.category.ANIMALS	Animals	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a497d6af-3756-4ad7-a71e-543327185b0d	en_IN	pgr.complaint.category.BADSTREETLIGHT	Bad Streetlight	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0d118a05-eac4-47da-b44b-c623a0edd1ec	en_IN	pgr.complaint.category.BADSUPPLY	Bad Supply	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a8e96d44-ff65-4abd-91f8-875fcef7f9a7	en_IN	pgr.complaint.category.BADTRAFFICLIGHT	Bad Traffic Light	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f28b6b22-29ec-42ba-9180-886630ef1f75	en_IN	pgr.complaint.category.BINNOTEMPTY	Bin Not Empty	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d9516459-c9ad-4382-b722-bb0859a0768e	en_IN	pgr.complaint.category.BINS	Bins	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4f3f1ec8-48f5-4415-9005-bff88c3340df	en_IN	pgr.complaint.category.BLOCK/OVERFLOWINGSEWAGE	Block / Overflowing sewage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
80c9ca61-4d2e-4418-b335-cbb984cb0bb6	en_IN	pgr.complaint.category.BLOCKED	Blocked	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
db6841fe-6a16-41e7-aeec-00423ce94794	en_IN	pgr.complaint.category.BLOCKEDDRAIN	Blocked Drain	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
73caddd1-b8c0-48bf-b992-a09b9034cab4	en_IN	pgr.complaint.category.BLOCKOROVERFLOWINGSEWAGE	Block/Overflowing sewage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1904094d-0f60-4170-93db-10cdde64c390	en_IN	pgr.complaint.category.BLOCKOVERFLOWINGSEWAGE	Block/Overflowing sewage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
84f2075d-339f-4f6e-803e-2a91b5d3ec13	en_IN	pgr.complaint.category.BOUNDARYSTRUCTUREIDENTITY	Boundary, Structure & Identity	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
19eda849-f0ef-4a14-b803-f64e37c07f98	en_IN	pgr.complaint.category.BROKEN	Broken	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
28f71876-c052-4fdc-bc1e-8111e4453e7b	en_IN	pgr.complaint.category.BROKENBIN	Broken Bin	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
274486b0-bc45-408f-840e-e4169f30a1bb	en_IN	pgr.complaint.category.BROKENGARBAGEBIN	Broken Garbage Bin	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
65f20e1f-a551-433e-baca-86ac5edea77b	en_IN	pgr.complaint.category.BROKENGUARD	Broken Guard	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1e316a7e-77e3-4b80-8ec7-a67512c20f9f	en_IN	pgr.complaint.category.BROKENHANDPUMP	Broken Handpump	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
723876c1-e3c0-42a9-b8fb-4290a626dc15	en_IN	pgr.complaint.category.BROKENORDAMAGEDPIPE	Broken Or Damaged Pipe	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
01cda4c9-b6fd-4dca-93a5-7646f7b41976	en_IN	pgr.complaint.category.BROKENORLEAKINGSEWAGEPIPE	Borken or Leaking Sewage pipe	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
95040b80-2509-405d-90da-9634f479238b	en_IN	pgr.complaint.category.BROKENPIPEORTAP	Broken Pipe Or Tap	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b8f73b35-de97-4da9-b325-66ac205b6211	en_IN	pgr.complaint.category.BROKENWATERPIPEORLEAKAGE	Broken water pipe / Leakage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1eae17a9-abbc-4838-8723-3a96b31d847f	en_IN	pgr.complaint.category.BROKENWATERPIPEORTAP	Broken Water Pipe or Tap	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4219a3dd-4e9e-4295-9226-8f08e38b173b	en_IN	pgr.complaint.category.BURNING	Burning	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1326ba00-8f7e-40af-9c0f-4b5bf8a15cb6	en_IN	pgr.complaint.category.BURNINGOFGARBAGE	Burning of garbage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d7a68efa-0822-411e-83dd-3a6b23027e01	en_IN	pgr.complaint.category.BlockOrOverflowingSewage	Block/Overflowing sewage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9e3b0b5b-82ab-474d-9570-667a5a5cc052	en_IN	pgr.complaint.category.BoundaryStructureIdentity	Boundary, Structure & Identity	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9e4c1cca-6ce5-4a7c-9e4d-502ed6c318f3	en_IN	pgr.complaint.category.BrokenWaterPipeOrLeakage	Broken water pipe / Leakage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a1b3be11-0f52-4657-8fd3-b0491d4fa4ce	en_IN	pgr.complaint.category.BurningOfGarbage	Burning of garbage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e1da4880-228b-4987-9ade-ab50b49457bb	en_IN	pgr.complaint.category.COMPENSATION	Compensation(Redevelopment & Damaged Property)	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5c9571f1-afe3-4657-92ca-2b3809335b12	en_IN	pgr.complaint.category.CONSTRUCTIONMATERIALLYINGONTHEROAD	Construction material lying on the road	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bb9783d2-1aaf-43c5-a9bb-877c27307824	en_IN	pgr.complaint.category.CUSTOMS	Customs Duty	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
48443262-8807-452d-9da6-b4f377fbadde	en_IN	pgr.complaint.category.CUSTOMSDUTY	Customs Duty	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
88c581d5-b0e4-41b6-b713-5ed9b4f5a8f1	en_IN	pgr.complaint.category.CUTTINGORTRIMMINGOFTREEREQUIRED	Cutting/trimming of tree required	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e120db62-6b15-45ea-878a-17510f41deaa	en_IN	pgr.complaint.category.Compensation	Compensation(Redevelopment & Damaged Property)	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8aead2f1-5082-4198-a744-4a7ad47cb675	en_IN	pgr.complaint.category.ConstructionMaterialLyingOntheRoad	Construction material lying on the road	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d96c79cf-40d7-4761-bf96-311226d009f2	en_IN	pgr.complaint.category.CustomsDuty	Customs Duty	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
eff376eb-bd25-4707-bd90-622bfb3d5f80	en_IN	pgr.complaint.category.CuttingOrTrimmingOfTreeRequired	Cutting/trimming of tree required	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3c6341fe-bc0f-48f6-8641-eb46ebc39e14	en_IN	pgr.complaint.category.DAMAGED	Damaged	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c4b85e39-43eb-4fff-992f-d93f88431fcc	en_IN	pgr.complaint.category.DAMAGED/BLOCKEDFOOTPATH	Damaged/blocked footpath	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e6ad5620-937c-4fcb-acb0-6c7fac6a0d77	en_IN	pgr.complaint.category.DAMAGEDBLOCKEDFOOTPATH	Damaged/blocked footpath	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b8989978-d412-4534-b466-4d3df6d08c56	en_IN	pgr.complaint.category.DAMAGEDDRAIN	Damaged Drain	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7aa5d0ea-bb2d-4629-8bf8-4a70a7939829	en_IN	pgr.complaint.category.DAMAGEDFOOTPATH	Damaged Footpath	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9cb81a4e-5c0e-43bb-a410-9bec217bddc2	en_IN	pgr.complaint.category.DAMAGEDGARBAGEBIN	Damaged garbage bin	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
752a2eaf-a33f-40f3-bf57-4ebad89ed628	en_IN	pgr.complaint.category.DAMAGEDORBLOCKEDFOOTPATH	Damaged/blocked footpath	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
56f45277-93c8-4df6-ae6a-7989419ffe15	en_IN	pgr.complaint.category.DAMAGEDROAD	Damaged road	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
137a7992-df22-4848-813e-f95f733298ae	en_IN	pgr.complaint.category.DAMAGEDSTREETLIGHT	Damaged Streetlights	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
66dfe7ed-5f1b-4722-9c53-311c9444634c	en_IN	pgr.complaint.category.DEADANIMALS	Dead animals	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
817d7b62-cdc2-48f2-a15f-4aef84ebbae4	en_IN	pgr.complaint.category.DEADBODY	Dead Body	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
939275e9-f3fe-4fb2-9f59-6f53f29b15b5	en_IN	pgr.complaint.category.DEBRISORSILT	Debris Or Silt	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a5731c16-b721-496a-99d1-0bd8292f7634	en_IN	pgr.complaint.category.DIRTYORSMELLY	Dirty Or Smelly	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b21bbd20-3146-4993-bcb8-6f4305eedf89	en_IN	pgr.complaint.category.DIRTYORSMELLYPUBLICTOILETS	Dirty/smelly public toilet	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
da0934a9-3e66-44bf-af36-e31aaba856c9	en_IN	pgr.complaint.category.DIRTYWATERSUPPLY	Dirty water supply	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fd6a9ac2-226d-4414-b519-8c59ef3c65ef	en_IN	pgr.complaint.category.DISPLACEMENT	Displacement (Insecurity)	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6c51bd09-3c84-487e-be89-739dabb09920	en_IN	pgr.complaint.category.DRAINS	Drains	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9ef42030-fe5e-4750-a7ed-6069f3812b76	en_IN	pgr.complaint.category.DUMPING	Dumping	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5b33b094-9062-44a0-991e-987b7b09b16b	en_IN	pgr.complaint.category.DamagedGarbageBin	Damaged garbage bin	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b2f054c1-5131-46f7-aa10-b239a8f33a11	en_IN	pgr.complaint.category.DamagedOrBlockedFootpath	Damaged/blocked footpath	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2e4f58a4-6d06-43b7-a0f4-74ad2540cab6	en_IN	pgr.complaint.category.DamagedRoad	Damaged road	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a429b7c8-b363-4f4b-8e2a-f969341db744	en_IN	pgr.complaint.category.DeadAnimals	Dead animals	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cd62e019-9ef5-4c1a-873c-eeddbbc3c462	en_IN	pgr.complaint.category.DirtyOrSmellyPublicToilets	Dirty/smelly public toilet	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0207990e-d702-4544-82e1-90c3cd75086d	en_IN	pgr.complaint.category.DirtyWaterSupply	Dirty water supply	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8666e721-df33-4561-a378-51d13d4101fc	en_IN	pgr.complaint.category.Displacement	Displacement (Insecurity)	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e3f63362-2e5c-4ca6-ac21-e9e05d63ef7f	en_IN	pgr.complaint.category.EMPLOYEEABSENT	Employee Absent	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b6bc3c4e-8d51-4dbb-8aa4-49332b68e9da	en_IN	pgr.complaint.category.ENCROACHMENT	Encroachment	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e60d2acd-a222-4f44-9e40-4bc5d453c024	en_IN	pgr.complaint.category.ENCROACHMENTONPUBLICPROPERTY	Enroachment on Public Property	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2c1ab83e-8a16-472a-b24d-75566bc154b0	en_IN	pgr.complaint.category.FINANCE	Tax Rate	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
af841135-2b58-4318-a710-3b580f44a17f	en_IN	pgr.complaint.category.FOOTPATHS	Footpaths	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3147fe6f-ea6e-46b6-8f64-ef10fcefe14e	en_IN	pgr.complaint.category.GARBAGE	Garbage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4d0db9a4-4439-4639-b629-11c94bdf48d3	en_IN	pgr.complaint.category.GARBAGEBINNOTEMPTY	Garbage Bin not empty	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b6f08327-b0b1-4260-888e-c948c47ca3a4	en_IN	pgr.complaint.category.GARBAGEBINNOTTHERE	Garbage Bin not there	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e4a17d1a-7814-43c4-813f-c9f62c950837	en_IN	pgr.complaint.category.GARBAGENEEDSTOBECLEANED	Garbage needs to be cleaned	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
45dc2003-92c0-476c-bc1c-7e630a96474a	en_IN	pgr.complaint.category.GARBAGENEEDSTOBECLEARED	Garbage needs to be cleared	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0f3e368d-0435-49ed-9a9a-014f6124be0e	en_IN	pgr.complaint.category.GOODGOVERNANCE	Good Governance	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dc192ae0-3b5b-45a0-ab2f-96528e4e041d	en_IN	pgr.complaint.category.GOVERNANCE	Good Governance	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
63eb9d49-3337-49be-b145-5b1b4f696434	en_IN	pgr.complaint.category.GarbageNeedsTobeCleared	Garbage needs to be cleared	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9382e3be-3a90-4ff3-b837-931d4263ccbc	en_IN	pgr.complaint.category.GoodGovernance	Good Governance	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c90ac5ac-e3f9-4853-bf92-9b172755eefc	en_IN	pgr.complaint.category.HOUSEDEBATE	House Debate (Kebele House & Proclamation 47/67)	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6a1b26df-ff46-4e98-82fd-e4d2163a19cc	en_IN	pgr.complaint.category.HOUSING	House Debate (Kebele House & Proclamation 47/67)	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
60384841-df66-45d2-8806-a8ee20b3f9f1	en_IN	pgr.complaint.category.HouseDebate	House Debate (Kebele House & Proclamation 47/67)	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
53ec9b5e-62ed-405a-bc62-c626f4abf9f3	en_IN	pgr.complaint.category.ILLEGALCONSTRUCTION	Illegal Construction	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fa70d700-5de4-481c-a213-aacdd4bee208	en_IN	pgr.complaint.category.ILLEGALCONSTRUCTIONS	Illegal constructions	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a43f0e8a-01d4-413c-b6db-6270caedfbea	en_IN	pgr.complaint.category.ILLEGALCUTTING	Illegal Cutting	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e2333556-b392-47eb-b8bf-d96d3c9d9a3b	en_IN	pgr.complaint.category.ILLEGALCUTTINGOFTREES	Illegal Cutting of trees	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0e82fdd3-85e6-4b3c-a2e4-2533f048914e	en_IN	pgr.complaint.category.ILLEGALDISCHARGE	Illegal discharge of sewage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
53647dee-8abc-4451-b999-e5be1dcadfd6	en_IN	pgr.complaint.category.ILLEGALDISCHARGEOFSEWAGE	Ilegal Discharge of Sewage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
42fade68-4f73-4fcb-91cf-b7f6c81852a7	en_IN	pgr.complaint.category.ILLEGALFOOTPATHSHOP	Illegal Footpath Shop	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1fb28c56-b892-49bd-9da6-15b051f4f49a	en_IN	pgr.complaint.category.ILLEGALHOARDING	Illegal Hoarding	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2e80a99e-83a8-45a1-8d4b-68f34932f17e	en_IN	pgr.complaint.category.ILLEGALPARKING	Illegal parking	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e1a894cb-e89b-4b3d-b857-e2478eb844c4	en_IN	pgr.complaint.category.ILLEGALSHOPS	Illegal Shops	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9a9ac06e-f248-46d3-bc5f-e394ac12b60d	en_IN	pgr.complaint.category.ILLEGALSHOPSONFOOTPATH	Illegal shops on footpath	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d02e8499-83d9-41f3-bbc0-630cbc0896f5	en_IN	pgr.complaint.category.ILLEGALSHOPSONTHEFOOTPATH	Illegal Shops on the Footpath	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
48c3a606-c260-4df6-a01b-10cca0f71a02	en_IN	pgr.complaint.category.INFRASTRUCTURE	Boundary, Structure & Identity	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c5474a75-b43e-47ee-9b4d-fdc4a23e647e	en_IN	pgr.complaint.category.IllegalConstructions	Illegal constructions	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d09e663f-86e0-4c77-be56-ef7f1ba80170	en_IN	pgr.complaint.category.IllegalCuttingOfTrees	Illegal Cutting of trees	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ab80cf7f-759e-4081-81c5-acec02db796c	en_IN	pgr.complaint.category.IllegalParking	Illegal parking	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
308a6028-7395-4702-9986-c93c365e5e95	en_IN	pgr.complaint.category.IllegalShopsOnFootPath	Illegal shops on footpath	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2379ee3d-c65f-4c16-967b-10a69e3cfa32	en_IN	pgr.complaint.category.JUSTICE	Justice	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a17fb8a5-fef3-4962-b206-32a8504dfc9f	en_IN	pgr.complaint.category.Justice	Justice	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ad3879f7-16a2-4940-b2f2-5d52b075305e	en_IN	pgr.complaint.category.LABOR	Labor Dispute	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a3557841-9151-405e-9653-603bb5d225fd	en_IN	pgr.complaint.category.LABORDISPUTE	Labor Dispute	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2b96b2a3-430d-4da9-9fd6-b213e2a91d3d	en_IN	pgr.complaint.category.LANDVIOLATION	Land Violation	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
351d17df-7473-4022-acb3-fc1d6f8a5c6d	en_IN	pgr.complaint.category.LANDVIOLATIONS	Land Violations	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
330d60f6-d039-4690-be46-4bb9218b3b2c	en_IN	pgr.complaint.category.LEGAL	Justice	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9102d89f-f377-4930-9454-c0bdf22abda0	en_IN	pgr.complaint.category.LIGHTS	Lights	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5b18aefc-6707-4371-8dd2-c825d6925489	en_IN	pgr.complaint.category.LaborDispute	Labor Dispute	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1cc64410-514d-4763-8acf-27b42f1bb19b	en_IN	pgr.complaint.category.MANHOLECOVERMISSINGORDAMAGED	Manhole cover is missing/damaged	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6442464f-a57d-440f-8062-cf9eeeed61a9	en_IN	pgr.complaint.category.MANHOLEISSUE	Manhole Issue	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8999cbf0-172e-4bf5-894b-aef983f78d08	en_IN	pgr.complaint.category.MISUSE	Misuse	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
de9e6c10-47cd-423d-8644-8843036af09b	en_IN	pgr.complaint.category.MOSQUITOES	Mosquitoes	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c9ff5bc0-ded7-4432-912a-212a7f61ca08	en_IN	pgr.complaint.category.MOSQUITOS	Mosquitoes	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
099377e5-3c04-42af-883c-3bac382b7e81	en_IN	pgr.complaint.category.ManholeCoverMissingOrDamaged	Manhole cover is missing/damaged	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1e4981f3-b8b6-4e76-ac1a-cde6abc0db43	en_IN	pgr.complaint.category.NONSWEEPINGOFROAD	Non sweeping of road	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6f236bac-5fc0-4ea0-a181-e07e2b422c97	en_IN	pgr.complaint.category.NOSTREETLIGHT	No streetlight	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3d30e0f3-9fbb-4cf3-ac7a-52803dbf8fb6	en_IN	pgr.complaint.category.NOTFUNCTIONAL	Not Functional	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b5e601dc-2526-498f-abdc-1514dc6423a7	en_IN	pgr.complaint.category.NOTWATERSUPPLY	Not Water Supply	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5d20a851-ed67-4ffe-befd-c2193016ddd0	en_IN	pgr.complaint.category.NOWATERORELECTRICITY	No Water Or Electricity	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
439720ee-4165-4a5a-9758-c36a2bfe3a9d	en_IN	pgr.complaint.category.NOWATERORELECTRICITYINPUBLICTOILET	No water/electricity in public toilet	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
57c45b1f-5a17-4be3-85b7-5c95d10a9cdd	en_IN	pgr.complaint.category.NOWATERSUPPLY	No Water Supply	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4b0ca10d-ca58-4756-9c5e-294df8dd4ad8	en_IN	pgr.complaint.category.NoStreetlight	No streetlight	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
297cca30-3247-4fe6-86b1-ae047072a4d5	en_IN	pgr.complaint.category.NoWaterOrElectricityinPublicToilet	No water/electricity in public toilet	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7858595b-00aa-4ffa-9019-4234d3ff1c36	en_IN	pgr.complaint.category.NoWaterSupply	No Water Supply	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
71b70d5f-ec64-42f0-a3a2-1d0710cf8f6f	en_IN	pgr.complaint.category.NonSweepingOfRoad	Non Sweeping Of Road	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
964e4437-8679-49f8-9957-63a251a12fe0	en_IN	pgr.complaint.category.OPENDEFACATION	Open Defecation	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5ca532d6-ca8b-419e-b4b3-fefafa9579e2	en_IN	pgr.complaint.category.OPENDEFECATION	Open Defecation	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
550f6458-6efd-448e-a688-3232c6ec1ba9	en_IN	pgr.complaint.category.OPENLAND	Open Land	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9e0e03a5-4de3-4987-9086-9ab9e43d28c6	en_IN	pgr.complaint.category.OTHERS	Others	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4cd54bee-bc2b-492f-a724-26d9d5dcd24f	en_IN	pgr.complaint.category.OVERFLOWING	Overflowing	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0ec8e34a-ea8e-4351-817b-df561a91aeec	en_IN	pgr.complaint.category.OVERFLOWING/BLOCKEDDRAIN	Overflowing/Blocked drain	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e65ca2d3-e687-48db-bf0f-8c6e3cd3e0d6	en_IN	pgr.complaint.category.OVERFLOWINGBLOCKEDDRAIN	Overflowing/Blocked drain	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b14d13dc-37c4-4529-b8f4-677914aadf19	en_IN	pgr.complaint.category.OVERFLOWINGDRAIN	Owerflowing Drain	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dbbc5baf-d682-4698-8a19-53d2a541e282	en_IN	pgr.complaint.category.OVERFLOWINGORBLOCKEDDRAIN	Overflowing/Blocked drain	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7f9bdf3b-b8ba-4a79-87b9-e6a3cc377c8e	en_IN	pgr.complaint.category.OVERFLOWINGSEWAGE	Overflowing Sewage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8e3cbfc5-349e-4639-a1e1-63a391485bd6	en_IN	pgr.complaint.category.OpenDefecation	Open Defecation	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a8c24f07-1c3c-4b9d-ad38-bd5addb9dfa7	en_IN	pgr.complaint.category.Others	Others	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3d65e418-27e1-46e3-b8d8-fed5eaa0e49f	en_IN	pgr.complaint.category.OverflowingOrBlockedDrain	Overflowing/Blocked drain	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9faf56dc-9c55-40dd-a406-7eb937bdb87f	en_IN	pgr.complaint.category.POLEORLIGHTDAMAGE	Pole Or Light Damage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2b286f6b-e8f1-4019-8c69-f5e06283bc5d	en_IN	pgr.complaint.category.POORSWEEPING	Poor Sweeping	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ced43dbe-1063-4b25-98d8-3d186f25198a	en_IN	pgr.complaint.category.POSSESSIONDISPUTE	Possession Dispute	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2f926f7e-45ab-4e79-90e8-280ddccb84fa	en_IN	pgr.complaint.category.POTHOLES	Potholes	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5a127208-e9af-48f6-ad8f-29d0822db383	en_IN	pgr.complaint.category.POTHOLESONTHEROAD	Potholes on the Road	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d7b4536e-10fc-4a6f-8e48-6bbe7c2934cb	en_IN	pgr.complaint.category.PROPERTY	Possession Dispute	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c789c5e6-5730-490d-9828-910f7e07bdfb	en_IN	pgr.complaint.category.PROPOSAL	Proposal	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f1fca3a9-09ee-4754-b0c7-d71d51854301	en_IN	pgr.complaint.category.PROPOSALS	Proposal	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a1db5eb0-0777-42c8-afef-2ae6e973f658	en_IN	pgr.complaint.category.PUBLICTOILETISDAMAGED	Public toilet damaged	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
91127e79-2be7-4845-89e3-cd9b71a8aa40	en_IN	pgr.complaint.category.PUBLICTOILETISNOTWORKINGPROPERLY	Public Toilet is not working properly	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
99157614-e366-43e6-b4d7-6e5236e81bb9	en_IN	pgr.complaint.category.PUBLICTOILETS	Public Toilets	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
993b4df4-c93c-43ca-a4bd-5c5bdd105c38	en_IN	pgr.complaint.category.ParkRequiresMaintenance	Park requires maintenance	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
05264e56-712f-44c2-b9f2-5a337765b477	en_IN	pgr.complaint.category.Parks	Park requires maintenance	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
856e4891-97d3-47d1-aa9d-22f65f50524c	en_IN	pgr.complaint.category.PossessionDispute	Possession Dispute	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fc5937e4-5ba1-4d77-b3a7-bcc7b51bcd75	en_IN	pgr.complaint.category.Proposal	Proposal	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6f236af1-7f9d-42fe-b615-e70b4c5d0b96	en_IN	pgr.complaint.category.PublicToiletIsDamaged	Public toilet damaged	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e41df8a5-057d-4345-ab74-86ca2d7d1312	en_IN	pgr.complaint.category.REMOVEGARBAGEORWATER	Remove Garbage Or Water	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4ec2f7a1-3823-487c-96f5-11b20205376e	en_IN	pgr.complaint.category.REPLACE/PROVIDEGARBAGEBIN	Replace/provide garbage bin	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cfb36e49-c4a1-4d0b-a07a-634e919ee579	en_IN	pgr.complaint.category.REPLACEORPROVIDEGARBAGEBIN	Replace/provide garbage bin	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2b9e5081-47a6-45d5-9f5a-cfc1819b0972	en_IN	pgr.complaint.category.REPLACEPROVIDEGARBAGEBIN	Replace/provide garbage bin	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4dec6fe4-41c6-49e5-a9fe-8682e159afbb	en_IN	pgr.complaint.category.REQUESTNEW	Request New	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e6f84f61-4f91-4c45-889d-d1cf5ffd7f5c	en_IN	pgr.complaint.category.REQUESTSMOKEOP	Request Smoke Op	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c91561e4-569d-408c-b420-80c2ec2002d2	en_IN	pgr.complaint.category.REQUESTSPRAYINGORFOGGINGOPERATION	Request spraying/ fogging operations	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b6101c16-cae0-4f10-9fda-4e3a104b6d0b	en_IN	pgr.complaint.category.REQUESTSPRAYOP	Request Spray Op	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1f479180-26df-4119-b3ab-95dffd809027	en_IN	pgr.complaint.category.REQUESTTANKER	Request Tanker	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f253e468-129c-4562-b775-f3a423fa57f6	en_IN	pgr.complaint.category.REQUESTTRIMMING	Request Trimming	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e6ef5914-772e-4ca4-9178-cb19a111fabe	en_IN	pgr.complaint.category.RETIREMENT	Retirement	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
07955c93-f6ce-4f83-b8fd-99089031dbb7	en_IN	pgr.complaint.category.ROADORFOOTPATH	Road Or Footpath	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e90156a7-a583-4b1a-88a5-6e11c464294d	en_IN	pgr.complaint.category.ROADS	Roads	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4cb15e56-26ad-4148-81a5-05bb3b88a047	en_IN	pgr.complaint.category.ROADSANDFOOTPATHS	Roads & footpaths	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
33859263-41b5-418f-8714-399c14646d8d	en_IN	pgr.complaint.category.ROADSCODEE	Roads codee	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0ee19e7a-7cfb-4668-9fa7-bf66441f1f44	en_IN	pgr.complaint.category.ReplaceOrProvideGarbageBin	Replace or provide garbage bin 	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f6f5af8-cef5-4b45-8678-59731366e9e2	en_IN	pgr.complaint.category.RequestSprayingOrFoggingOperation	Request spraying/ fogging operations	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4e95ac59-3dca-4303-8312-11d609abd4fc	en_IN	pgr.complaint.category.Retirement	Retirement	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
32c5e81f-b881-4ee5-9b7b-a415de3f84ee	en_IN	pgr.complaint.category.SERVICE	Service	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
666fb8fe-333d-45da-964d-6f006dfa5cf1	en_IN	pgr.complaint.category.SERVICENAME.FEVERS_DENGUE_MALARIA	Fevers - Dengue	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1f9b3a6f-6a1e-4de3-92a5-2cf7bd12b3aa	en_IN	pgr.complaint.category.SERVICENAME.NON_RECEIPT_OF_PENSIONS_DISABLED_ELDERLY_ETC	Non-Receipt of Pensions - Disabled	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
053a834a-286d-4409-a21d-8c86c824e08f	en_IN	pgr.complaint.category.SERVICENAME.REPAIRS_TO_FLYOVERS_BRIDGES_CULVERTS	Repairs to Flyovers	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
71318457-259b-4480-8388-59b773d4a9c6	en_IN	pgr.complaint.category.SERVICENAME.UNHYGIENIC_IMPROPER_TRANSFER_OF_MEAT_LIVESTOCK	Unhygienic	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1ca4f598-f099-4e20-85e6-d3d002359399	en_IN	pgr.complaint.category.SEWAGE	Sewage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d940b3ae-a3af-4b8a-a6c9-b5dcd3278cff	en_IN	pgr.complaint.category.SEWAGEEFFLUENTS	Sewage Effluents	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c3de05db-b9d8-4a27-ab6d-d84244da3c3b	en_IN	pgr.complaint.category.SHORTAGEOFWATER	Shortage of water	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
df575151-4111-4467-a1bc-9abf0aa9d9bb	en_IN	pgr.complaint.category.SHORTSUPPLY	Short Supply	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
03cb2df6-bf26-4aa7-bac7-1726c317040b	en_IN	pgr.complaint.category.SLOWPROGRESS	Slow Progress	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
386c4083-bdab-44ce-acdd-ef4f924529cc	en_IN	pgr.complaint.category.STAGNANTWATER	Stagnant Water	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
37efd390-4312-4482-b38f-9b7b213f2b7d	en_IN	pgr.complaint.category.STORMWATERDRAIN	Storm Water Drain	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
15fcb786-f672-45c9-990b-78ff26dc895d	en_IN	pgr.complaint.category.STRAYANIMALS	Stray animals	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9851dc5c-56df-4742-86b3-f5bfaaecdbeb	en_IN	pgr.complaint.category.STRAYCATTLE	Stray Cattle	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e192a535-5f70-4ee6-adef-928c5f118c2e	en_IN	pgr.complaint.category.STRAYDOGS	Stray Dogs	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d5d33a01-e064-4401-8d0f-2df992968fbf	en_IN	pgr.complaint.category.STRAYPIGS	Stray Pigs	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cd13cc5a-2cbd-4086-96f6-93f005f7068e	en_IN	pgr.complaint.category.STREETLIGHTNOTWORKING	Streetlight not working	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1f294e5d-5a81-4be3-a935-b9f77e05107c	en_IN	pgr.complaint.category.STREETLIGHTS	Streetlights	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f28e157d-6e82-4b3c-a8d7-e5d190130438	en_IN	pgr.complaint.category.SUGGESTION	Suggestion	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0ffec705-fcc7-4828-8a2a-eb1eae33d45d	en_IN	pgr.complaint.category.SUGGESTIONS	Suggestion	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
15eb7714-98f5-4335-bcba-f2a48c57c16f	en_IN	pgr.complaint.category.SUPPORT	Support / Help	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dc3cff40-b0db-4a60-b292-218554cd59f3	en_IN	pgr.complaint.category.SUPPORTHELP	Support / Help	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2de0fa38-fd1e-4698-90fa-6bfc77f6103f	en_IN	pgr.complaint.category.ShortageOfWater	Shortage of water	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
db6fe5d9-d06b-4858-883a-fc2efe740b0c	en_IN	pgr.complaint.category.StrayAnimals	Stray animals	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
121c4188-37f4-418a-a61d-f93d768c5481	en_IN	pgr.complaint.category.StreetLightNotWorking	Streetlight not working	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d221a88f-2230-4cb1-9645-76ca6b47eb19	en_IN	pgr.complaint.category.Suggestion	Suggestion	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1f750d5d-4a00-4e7a-88c7-75f9708a07ce	en_IN	pgr.complaint.category.SupportHelp	Support / Help	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5704a022-fdbd-4295-94a7-49ba7dca9184	en_IN	pgr.complaint.category.TAXRATE	Tax Rate	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ec1110b6-a289-4d2d-a609-0d6c059e0960	en_IN	pgr.complaint.category.TOILETS	Toilets	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1c0f5d26-5abd-4e10-9d40-9ac6f387e288	en_IN	pgr.complaint.category.TREES	Trees	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e630c573-bbb1-4455-87b1-199a0a094165	en_IN	pgr.complaint.category.TRUCKSPILLAGE	Truck Spillage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f97841eb-62e9-4fe2-9fff-0311fcf43fad	en_IN	pgr.complaint.category.TaxRate	Tax Rate	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c904c611-84e0-41ed-91de-7556b12e7f65	en_IN	pgr.complaint.category.VACANTLAND	Vacant Land	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1fac575f-0d46-407a-81c2-1716dfac7667	en_IN	pgr.complaint.category.WATER	Water	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3e958c9e-d625-4d69-8aa8-384aed73ce91	en_IN	pgr.complaint.category.WATERANDSEWAGE	Water & Sewage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b28f40af-cd93-4d2e-a8ea-27b579facda7	en_IN	pgr.complaint.category.WATERBODY	Water Body	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5967048d-6883-4eb3-8851-d747190fa158	en_IN	pgr.complaint.category.WATERLOGGED	Water Logged	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7806ebc0-32af-442a-8c1d-9532d60f78f1	en_IN	pgr.complaint.category.WATERLOGGEDROAD	Water logged road	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c0c2e2e4-68ec-45ab-a24a-f0be1a52cad9	en_IN	pgr.complaint.category.WATERPRESSUREISVERYLESS	Water pressure is very less	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5d4f2cf3-0b3d-481f-ad3a-e7d815f11845	en_IN	pgr.complaint.category.WaterLoggedRoad	Water logged road	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4788a6e5-329b-4cdc-a04a-7a5e3480ec82	en_IN	pgr.complaint.category.WaterPressureisVeryLess	Water pressure is very less	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2d7a8f09-8828-49c4-9085-5fcc96f3fb1b	en_IN	pgr.complaint.category.illegalDischargeOfSewage	Ilegal Discharge of Sewage	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a9c1c198-9282-4bcc-bd0b-1d0719e98401	en_IN	pgr.sms.notification.assign	Your complaint for {complaint_type} has been assigned to {emp_name}, {emp_designation}, {emp_department}\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9cc1c2c4-5fd4-406a-896a-a6848ad39ae2	en_IN	pgr.sms.notification.assign.citizen	Dear Citizen, Your complaint for <complaint_type> with ID <id> submitted on <date> has been assigned to <emp_name>, <emp_designation>, <emp_department>. You can track your complaint status and connect with our officials on the on the web portal.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bc3a437e-ffaa-43f9-886c-bee6c2a16f06	en_IN	pgr.sms.notification.assign.employee	Shri <emp_name>, Complaint for '<complaint_type>' with ID <id> has been assigned to you. Please take appropriate action. <ao_designation> - <ulb>	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8ba59ae3-4e37-48e3-9f0e-6ccd0b048c59	en_IN	pgr.sms.notification.close.employee	Shri <emp_name>, Complaint for <complaint_type> with ID <id> has received <rating>/5 feedback from the citizen. Thank you for your service.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c80fa0d5-bb95-4f41-9c58-a5258b102b67	en_IN	pgr.sms.notification.comment	<emp_name> has commented on your complaint for <complaint_type> with complaint ID <id>. Comment - <comment>.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
73ae83a7-2790-4cc1-8e52-1031b0f471be	en_IN	pgr.sms.notification.comment.default	You have received a comment on your complaint. You can track your complaint status on the mSeva app or your local government web portal.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
80b42441-fad0-488e-87dc-fe0ec6fea1e4	en_IN	pgr.sms.notification.default	Your complaint has been <status>. You can track your complaint status on the mSeva app or your local government web portal	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
989325dd-f276-4de6-807c-664a35bd007c	en_IN	pgr.sms.notification.reassign	Your complaint for {complaint_type} has been re-assigned to {emp_name}, {emp_designation}, {emp_department}.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ba24007a-5e83-4d5f-9029-a1084e5b8e94	en_IN	pgr.sms.notification.reassign.citizen	Dear Citizen, Your complaint for <complaint_type> with ID <id> submitted on <date> has been re-assigned to <emp_name>, <emp_designation>, <emp_department>. You can track your complaint status and connect with our officials on the on the web portal.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4fcbbea1-3b4d-40fd-98b9-468bb158c29c	en_IN	pgr.sms.notification.reassign.employee	Shri <emp_name>, Complaint for '<complaint_type>' with ID <id> has been re-assigned as per your request. <ao_designation> - <ulb>	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b17a7dd9-9551-49af-9ae2-57f1e0bf9b64	en_IN	pgr.sms.notification.reject	Your complaint for {complaint_type} has been rejected on {date}. Reason for Rejection: {reason} Additional Comments: {additional_comments}.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2d42c8b1-9faf-4fbc-ae0f-912c025e8117	en_IN	pgr.sms.notification.reject.citizen	Dear Citizen, Your complaint for <complaint_type> with ID <id> submitted on <date> has been rejected. Reason for Rejection: <reason>, Additional Comments: <additional_comments> If you wish to re-open the complaint, you can visit the web portal.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
29546dc7-8d23-4c48-a243-1dddb4e17d6e	en_IN	pgr.sms.notification.reopen	Your complaint for {complaint_type} has been re-opened on {date}.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
635864f5-d9c3-46a9-936a-c100bd29704d	en_IN	pgr.sms.notification.reopen.citizen	Dear Citizen, Your complaint for <complaint_type> with ID <id> submitted on <date> has been RE-OPEN as per your request. You can track your complaint status and connect with our officials on the web portal.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3ea05e43-6c23-4d16-a1b9-173138d28612	en_IN	pgr.sms.notification.reopen.employee	Shri <emp_name>, Complaint for <complaint_type> with ID <id> has been re-opened by the citizen. It is being reviewed by Assigning officer - <ulb>.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ccea2b7b-b27c-4acc-a6db-4bccb266f844	en_IN	pgr.sms.notification.resolve	Your complaint for {complaint_type} has been resolved on {date}. Please give us your feedback on the mSeva app, your local government web portal or at this link {app_link}.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ebd4b22c-7347-4133-a2c5-b2a73b660025	en_IN	pgr.sms.notification.resolve.citizen	Dear Citizen, Your complaint for <complaint_type> with ID <id> submitted on <date> has been resolved by <emp_name>. If you are not satisfied with service you can RE-OPEN complaint through web portal or by calling our CSR.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fee73b10-b1df-4c5f-b0e2-8a85613f9994	en_IN	pgr.sms.notification.submit	Your complaint for {complaint_type} has been submitted with ID {id} on {date}. You can track your complaint status on the mSeva app or your local government web portal.\n\nEGOVS	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ebae8669-607d-4bcf-9b19-57f0982206fb	en_IN	pgr.sms.notification.submit.citizen	Dear Citizen, Your complaint for <complaint_type> has been submitted with ID <id> on <date>. You can track your complaint status on the web portal.	pg	rainmaker-pgr	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a4d7d4d1-2ac3-432d-8fae-84ff3e3216f5	en_IN	COMMON_MASTERS_COMMON_MASTERS_LOCALIZATIONMODULES	Localizationmodules	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e94cf3d6-0c5c-4f54-90bc-d7290a3d8653	en_IN	COMMON_MASTERS_DEPARTMENT_ACTIVE	Active	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
52c7b1e5-a130-459a-a85d-0dd1e1ec08f2	en_IN	COMMON_MASTERS_DEPARTMENT_CODE	Code	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5f49c9bb-11b1-4b59-9573-d0ad01c40fc3	en_IN	COMMON_MASTERS_DEPARTMENT_NAME	Name	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a8d658a2-a687-4a3c-959d-ce8a17fcb659	en_IN	COMMON_MASTERS_DESIGNATION_ACTIVE	Active	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f40ff32f-4c02-4098-bd00-cc701c384726	en_IN	COMMON_MASTERS_DESIGNATION_CODE	Code	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
066c1b0b-3d58-45d6-a33e-7a7fb69392c4	en_IN	COMMON_MASTERS_DESIGNATION_DESCRIPTION	Description	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5ab58497-8071-4e23-bb0d-7b8062df9793	en_IN	COMMON_MASTERS_DESIGNATION_NAME	Name	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4a2ad8a9-799f-4a39-9b3a-de2acbb66e48	en_IN	COMMON_MASTERS_STATEINFO_EMPLOYEE	Employee	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b946e7f0-0ef1-48ac-800f-7ccfe647cd75	en_IN	COMMON_MASTERS_STATEINFO_HASLOCALISATION	Haslocalisation	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
39ca831a-4554-4124-948d-09a547c4cedb	en_IN	COMMON_MASTERS_STATEINFO_LOCALIZATIONMODULES	Localizationmodules	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f4ce25d8-4552-4131-a9fa-4e3f822c8627	en_IN	COMMON_MASTERS_UICOMMONPAY_EMPLOYEEURL	Employeeurl	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
686610b2-659a-43f4-9f8b-d3f49f54af9d	en_IN	EGOV_HRMS_DEACTIVATIONREASON_ACTIVE	active	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
af01b936-7a6a-475a-a998-d8bd13988328	en_IN	EGOV_HRMS_DEACTIVATIONREASON_CODE	code	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
070c9c02-c85c-4f16-b511-458da5b72a75	en_IN	EGOV_HRMS_DEGREE_ACTIVE	active	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9d952ea2-201d-4104-8213-48084dfd25f9	en_IN	EGOV_HRMS_DEGREE_CODE	code	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
790de38d-3218-48bf-96e9-46d99b325bf0	en_IN	EGOV_HRMS_EMPLOYEESTATUS_ACTIVE	active	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bde413a8-60a7-45f2-9401-51684a6b969f	en_IN	EGOV_HRMS_EMPLOYEESTATUS_CODE	code	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
203e271b-dc33-4097-b0f4-1a02e33f4244	en_IN	EGOV_HRMS_EMPLOYEETYPE_ACTIVE	active	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cb9f4c2c-8806-4d14-b71b-cd3fd3b7904f	en_IN	EGOV_HRMS_EMPLOYEETYPE_CODE	code	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b8e27e0d-53e3-479e-8897-1b028e65769b	en_IN	EGOV_HRMS_EMPLOYMENTTEST_ACTIVE	active	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8ebcf8da-856e-4821-b63a-9f15da8d8bd1	en_IN	EGOV_HRMS_EMPLOYMENTTEST_CODE	code	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
631515d3-e7c6-4cbe-9f77-9d8ee75a102a	en_IN	EGOV_HRMS_SPECALIZATION_ACTIVE	active	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
19a601f4-c20e-4562-a086-4d85ff0e0118	en_IN	EGOV_HRMS_SPECALIZATION_CODE	code	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
90e78eed-d762-4745-9624-f55799b0f2c7	en_IN	LOCALISATION_ADD	Add Localisation	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
77148b45-21a6-4217-83ea-d28629edf2fc	en_IN	MDMS_ADD_V2	Add Master Data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
490283ef-9712-41cc-9f6f-06c58d748590	en_IN	MDMS_EDIT	Edit Master Data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f8818502-aad4-4c64-bad2-5e2db9176b96	en_IN	MDMS_SEARCH_V2	Search Master Data	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
88b2c49d-61ee-496c-8672-cfcc336be130	en_IN	RAINMAKER_PGR_COMPLAINCLOSINGTIME_COMPLAINMAXIDLETIME	Complainmaxidletime	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cfc4b79a-f1d6-4dc7-aaec-b879e8289807	en_IN	RAINMAKER_PGR_PRIORITYLEVEL_ACTIVE	Active	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0ce49227-6753-46e3-934b-0635459e7e44	en_IN	RAINMAKER_PGR_PRIORITYLEVEL_CODE	Code	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cd57bf32-c87a-43d0-a995-27f7969d3d8b	en_IN	RAINMAKER_PGR_PRIORITYLEVEL_NAME	Name	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
751b9d53-032d-4038-b11c-0b0d47a4317b	en_IN	RAINMAKER_PGR_SERVICEDEFS_ACTIVE	Active	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9581e28f-8a75-478a-87eb-200356b80517	en_IN	RAINMAKER_PGR_SERVICEDEFS_DEPARTMENT	Department	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
60365f72-1ddd-4afc-b950-be842c480a7a	en_IN	RAINMAKER_PGR_SERVICEDEFS_KEYWORDS	Keywords	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6a7249fb-4ee2-4bfc-8a7e-ff27283c6c44	en_IN	RAINMAKER_PGR_SERVICEDEFS_MENUPATH	Menupath	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2a69255e-1667-47a8-9b7a-8e333d50b4b0	en_IN	RAINMAKER_PGR_SERVICEDEFS_MENUPATHNAME	Menu Path Name	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
bcaec567-6102-4702-81ed-ef55a14f02e7	en_IN	RAINMAKER_PGR_SERVICEDEFS_NAME	Name	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b5109cb0-8362-488d-ae1e-bbefc8b4d56e	en_IN	RAINMAKER_PGR_SERVICEDEFS_ORDER	Order	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1d572691-f97f-4e05-8ea5-14e039ea1200	en_IN	RAINMAKER_PGR_SERVICEDEFS_SERVICECODE	Servicecode	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
77086db0-0c3f-4d8d-a81d-eb4c5a66985d	en_IN	RAINMAKER_PGR_SERVICEDEFS_SLAHOURS	Slahours	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
95408f4e-aab4-458e-8b55-276ccb6f0a49	en_IN	RAINMAKER_PGR_UICONSTANTS_REOPENSLA	Reopensla	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7a0a9459-c59f-4ee0-9218-55b1ac8b6cf7	en_IN	SCHEMA_COMMON_MASTERS_DEPARTMENT	Department	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
fd266395-7b06-48b4-b74d-a1eacc6cf87c	en_IN	SCHEMA_COMMON_MASTERS_DESIGNATION	Designation	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
931ee18f-f1d2-4d60-a66e-32c0ae57c0e4	en_IN	SCHEMA_EGOV_HRMS_DEACTIVATIONREASON	DeactivationReason	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ae9b1d85-4b6c-4413-97d1-2bd9c510b457	en_IN	SCHEMA_EGOV_HRMS_DEGREE	Degree	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cca9ffac-469a-424b-80d1-4b3e95c62f8b	en_IN	SCHEMA_EGOV_HRMS_EMPLOYEESTATUS	EmployeeStatus	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5600b39d-aae7-42b5-9e97-04f8ee9e32ca	en_IN	SCHEMA_EGOV_HRMS_EMPLOYEETYPE	EmployeeType	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
18e7bf86-40c7-476a-bf4d-e481a0ab52e8	en_IN	SCHEMA_EGOV_HRMS_EMPLOYMENTTEST	EmploymentTest	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4bbf902a-248d-4a0d-b545-55d3f21deacc	en_IN	SCHEMA_EGOV_HRMS_SPECALIZATION	Specalization	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
87821f0d-ee18-4922-92e4-e3d1a062aaea	en_IN	SCHEMA_EGOV_HRM_EGOV_HRMS	Egov-hrms	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ac040e47-6dac-4899-9a72-6e7d6f6ed2fc	en_IN	SCHEMA_RAINMAKER_PGR_COMPLAINCLOSINGTIME	Complainclosingtime	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
70e1052a-bb2d-46fe-8178-bcf2656936e8	en_IN	SCHEMA_RAINMAKER_PGR_PRIORITYLEVEL	Prioritylevel	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
041646f1-b015-43b2-a456-f8c2df2ff272	en_IN	SCHEMA_RAINMAKER_PGR_SERVICEDEFS	Servicedefs	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
64e3ae82-3a84-4a3f-9be3-564685623c30	en_IN	SCHEMA_RAINMAKER_PGR_UICONSTANTS	Uiconstants	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
25545fcf-e642-4639-8ef1-00d875008783	en_IN	WBH_ERROR_MDMS_DATA DUPLICATE_RECORD	Duplicate Record	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cc68e150-5143-4fab-ab83-3d49a236e334	en_IN	WBH_MDMS_ACCESSCONTROL_ACTIONS_TEST_ACTIONS_TEST	actions-test	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6daeee1a-7d1f-4c03-b3d6-b27098419ef5	en_IN	WBH_MDMS_ACCESSCONTROL_ROLEACTIONS_ROLEACTIONS	roleactions	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
14031661-2ebd-4bda-95f1-198b4b1efb32	en_IN	WBH_MDMS_ACCESSCONTROL_ROLEACTION_ACCESSCONTROL_ROLEACTIONS	Accesscontrol-roleactions	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a7aaef74-48a1-4707-bc36-28620aea3e55	en_IN	WBH_MDMS_ACCESSCONTROL_ROLES_ROLES	roles	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b4638c66-3ae8-4a31-ab09-4c6cdfdc5d39	en_IN	WBH_MDMS_BILLINGSERVICE_BUSINESSSERVICE	BusinessService	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e99103f7-ccc6-45ca-9db8-7e7a55e6b76c	en_IN	WBH_MDMS_BILLINGSERVICE_PAYMENTSERVICE	PaymentService	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9f6ae66e-dee3-4a8d-8438-72ff192674dd	en_IN	WBH_MDMS_BILLINGSERVICE_TAXHEADMASTER	TaxHeadMaster	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
2a34b3f2-1148-4870-9740-a03fd3ecad7e	en_IN	WBH_MDMS_BILLINGSERVICE_TAXPERIOD	TaxPeriod	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1c6bb66d-ad02-4626-bfcb-accdc921eea7	en_IN	WBH_MDMS_COMMON-MASTERS_GENDERTYPE	GenderType	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f804c3db-4d9b-4085-9388-44c49494254e	en_IN	WBH_MDMS_COMMON_MASTERS_BDTEMPLATE	Bdtemplate	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f572fe88-b40b-4e45-ad38-af20260a0e3d	en_IN	WBH_MDMS_COMMON_MASTERS_CANCELCURRENTBILLREASONS	Cancelcurrentbillreasons	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b4b5bc3d-2e8c-4406-af81-ee052a52bb82	en_IN	WBH_MDMS_COMMON_MASTERS_CANCELRECEIPTREASON	Cancelreceiptreason	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dd42363c-5082-4a89-bf88-4fab245dd7e6	en_IN	WBH_MDMS_COMMON_MASTERS_CENSUSYEAR	Censusyear	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9eafde89-c279-4a56-bd0a-1400c58ef95a	en_IN	WBH_MDMS_COMMON_MASTERS_CITIZENCONSENTFORM	Citizenconsentform	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
54e9f3e4-d810-413e-93b2-50d71d4cfed4	en_IN	WBH_MDMS_COMMON_MASTERS_COMMONINBOXCONFIG	Commoninboxconfig	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
dc20db87-08d0-4dc4-9c1c-2fe1f85b07f8	en_IN	WBH_MDMS_COMMON_MASTERS_CRONJOBAPICONFIG	Cronjobapiconfig	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8b249f6c-d830-434c-bb5e-1cce16a3a2dc	en_IN	WBH_MDMS_COMMON_MASTERS_DEPARTMENT	Department	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ea874558-8a8a-496f-a975-9dc4c7a0fc34	en_IN	WBH_MDMS_COMMON_MASTERS_DESIGNATION	Designation	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
02556a21-885a-492e-aa86-1b488378ecbb	en_IN	WBH_MDMS_COMMON_MASTERS_DOCUMENTTYPE	Documenttype	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f982b609-5a29-4a90-b462-0143270de4dc	en_IN	WBH_MDMS_COMMON_MASTERS_GENDERTYPE	Gendertype	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
654a69cb-e2da-4e63-ba17-4089510d97f8	en_IN	WBH_MDMS_COMMON_MASTERS_IDFORMAT	Idformat	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a82580c5-da63-479e-bf54-db1d010fe8c4	en_IN	WBH_MDMS_COMMON_MASTERS_OWNERSHIPCATEGORY	Ownershipcategory	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c9df9d19-75f0-4822-bcc9-54a5c5a6da0a	en_IN	WBH_MDMS_COMMON_MASTERS_OWNERTYPE	Ownertype	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4e923516-7b3c-4a99-a087-b8e851a01e41	en_IN	WBH_MDMS_COMMON_MASTERS_STATEINFO	Stateinfo	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
04d0b24a-aa2d-4911-9775-093b7af84c75	en_IN	WBH_MDMS_COMMON_MASTERS_STRUCTURETYPE	Structuretype	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9a589cfd-47c6-4574-b601-5d0c32297b1f	en_IN	WBH_MDMS_COMMON_MASTERS_TABLEPAGINATIONOPTIONS	Tablepaginationoptions	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0e341fcf-4060-4440-b6ab-6f0f8cbe7fcf	en_IN	WBH_MDMS_COMMON_MASTERS_UICOMMONPAY	Uicommonpay	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ae380971-3186-46e7-9049-b2633cafa822	en_IN	WBH_MDMS_COMMON_MASTERS_UOM	Uom	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e0a478c9-2d16-4fa2-8780-91e22215151b	en_IN	WBH_MDMS_COMMON_MASTERS_UOMCATEGORY	Uomcategory	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
46905499-0431-4160-bd69-9b9a198a3917	en_IN	WBH_MDMS_COMMON_MASTERS_WFSLACONFIG	Wfslaconfig	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6617f14a-c917-42e8-a826-dbde5c35c83e	en_IN	WBH_MDMS_COMMON_MASTER_DEPARTMENT	Department	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7d8d249b-78a9-4c15-b2b6-9f2f9423a470	en_IN	WBH_MDMS_DATASECURITY_DECRYPTIONABAC	DecryptionABAC	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6718a3ec-9412-42c2-ba66-8bf39530c028	en_IN	WBH_MDMS_DATASECURITY_ENCRYPTIONPOLICY	EncryptionPolicy	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6bea6dae-10aa-4ef8-89d2-128e663a5b86	en_IN	WBH_MDMS_DATASECURITY_MASKINGPATTERNS	MaskingPatterns	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4755b15a-758a-4ed6-b749-34a95ea9f810	en_IN	WBH_MDMS_DATASECURITY_SECURITYPOLICY	SecurityPolicy	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0d7f868c-9a1d-456e-ba2e-f105e8266df5	en_IN	WBH_MDMS_DATASECURIT_DATASECURITY	Datasecurity	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6c653acf-5a5f-4115-bbf9-d2b0120034ea	en_IN	WBH_MDMS_EGF_MASTER_FINANCIALYEAR	FinancialYear	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
77da08ae-fdb4-4bba-884e-1b5e26dfe6d2	en_IN	WBH_MDMS_EGOV_HRMS_DEACTIVATIONREASON	DeactivationReason	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
6e3569f5-f035-4b78-ace4-5cf79f5640ee	en_IN	WBH_MDMS_EGOV_HRMS_DEGREE	Degree	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9b79085b-209c-446a-8945-325806886433	en_IN	WBH_MDMS_EGOV_HRMS_EMPLOYEESTATUS	EmployeeStatus	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
528cefa8-a938-4ae1-bee7-8e33f72f75fd	en_IN	WBH_MDMS_EGOV_HRMS_EMPLOYEETYPE	EmployeeType	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a60affab-c6a1-46f3-a592-ac2b30396478	en_IN	WBH_MDMS_EGOV_HRMS_EMPLOYMENTTEST	EmploymentTest	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
af4d215a-8cc3-46f3-8fa3-41209eac6039	en_IN	WBH_MDMS_EGOV_HRMS_SPECALIZATION	Specalization	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
12383e05-3156-465b-9cc3-4e975823f941	en_IN	WBH_MDMS_EGOV_HRM_EGOV_HRMS	Egov-hrms	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
15083292-62a6-4b69-a172-612f317c80a0	en_IN	WBH_MDMS_INBOX_INBOXQUERYCONFIGURATION	InboxQueryConfiguration	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4d3977be-f2be-4c1c-9d3d-cc6ec917dcfb	en_IN	WBH_MDMS_INBOX_V_INBOX_V2	Inbox-v2	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8610452c-2fdb-416f-a695-eb84fc11d0d0	en_IN	WBH_MDMS_MASTER_ACCESSCONTROL_ROLEACTION	Accesscontrol-roleaction	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
da69a6a7-8ae8-49b8-8ba2-02b00f68287e	en_IN	WBH_MDMS_MASTER_ACCESSCONTROL_ROLEACTIONS	ACCESSCONTROL-ROLEACTIONS	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
422147f5-1a72-4d22-8905-a451a770ffa1	en_IN	WBH_MDMS_MASTER_ACCESSCONTROL_ROLES	ACCESSCONTROL-ROLES	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3a0e9101-35d8-440a-8d6d-b72057a40cf1	en_IN	WBH_MDMS_MASTER_BILLINGSERVICE	BillingService	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c6de52e3-5cf5-4cc0-b749-ece89b9effba	en_IN	WBH_MDMS_MASTER_COMMON-MASTERS	common-masters	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0a886a0e-0f12-4bda-8bd8-8bb62ef5df8f	en_IN	WBH_MDMS_MASTER_COMMON_MASTER	common masters	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f8b7b4b4-8011-4cde-9d07-298f346056fd	en_IN	WBH_MDMS_MASTER_COMMON_MASTERS	Common-masters	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
66bf385f-d966-4af0-a071-5a617accbeed	en_IN	WBH_MDMS_MASTER_DATASECURIT	Datasecurit	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ce307a6d-a2e1-425c-8ff2-409bb1fdec59	en_IN	WBH_MDMS_MASTER_DATASECURITY	DataSecurity	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
7d5595c9-c0c2-48db-ace6-fb7e371f5228	en_IN	WBH_MDMS_MASTER_EGF_MASTER	EGF Master	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4b40c54a-a883-48a3-a9e7-4808bba3958f	en_IN	WBH_MDMS_MASTER_EGOV_HRM	Egov-hrm	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e308791b-2dca-43e7-b5b7-3f6a6cf1f12a	en_IN	WBH_MDMS_MASTER_EGOV_HRMS	egov-hrms	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
083e2516-8384-49b6-bc17-8887e32f44fa	en_IN	WBH_MDMS_MASTER_INBOX	INBOX	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
73c3a6f8-e616-4bc7-95fb-1cf18e4dbcc9	en_IN	WBH_MDMS_MASTER_INBOX_V	Inbox-v	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b1c873f4-15e3-4bb8-8213-128af28c373c	en_IN	WBH_MDMS_MASTER_PSPCL_INTEGRATION	PSPCL Integration	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
e551d9e0-21ba-4c0f-aeb6-7edaa79d4b04	en_IN	WBH_MDMS_MASTER_RAINMAKER_PGR	Citizen Complaint Resolution System	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b8547114-fca1-4a91-a0ab-7e4286022dbe	en_IN	WBH_MDMS_MASTER_TENANT	Tenant	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
155697fb-e046-4733-b4bf-46856cbd7dce	en_IN	WBH_MDMS_MASTER_WORKFLO	Workflo	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3e43d438-1337-4dba-97dc-e22e138dea78	en_IN	WBH_MDMS_MASTER_WORKFLOW	Workflow	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
cbe2695b-c054-486f-b7d5-97b49075013b	en_IN	WBH_MDMS_RAINMAKER_PGR_COMPLAINCLOSINGTIME	ComplainClosingTime	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
00ef5eeb-6923-45aa-bf46-d62d0e6e3b47	en_IN	WBH_MDMS_RAINMAKER_PGR_PRIORITYLEVEL	Prioritylevel	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
c6c481d3-a139-4549-84f7-65d595cf014c	en_IN	WBH_MDMS_RAINMAKER_PGR_SERVICEDEFS	ServiceDefs	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
1c0de130-3c6c-41d4-9df4-376b028323fd	en_IN	WBH_MDMS_RAINMAKER_PGR_UICONSTANTS	UIConstants	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
410d313b-c494-43b3-b0fa-2351ffb94945	en_IN	WBH_MDMS_TENANT_ASSESSMENTCONFIG	Assessmentconfig	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
3d6e1dc7-a728-4650-8308-78bd1863f202	en_IN	WBH_MDMS_TENANT_CITYMODULE	Citymodule	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
f1f10622-12e3-463f-82ac-38872123fb02	en_IN	WBH_MDMS_TENANT_FOOTER	Footer	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
8519bbcf-2985-457d-a9b4-e3fd5d0a5827	en_IN	WBH_MDMS_TENANT_NATIONALINFO	Nationalinfo	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
46c15af7-8c83-419a-80f7-228ebd38bf09	en_IN	WBH_MDMS_TENANT_REASSESSMENTCONFIG	Reassessmentconfig	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5f0cbfba-718b-4166-8761-ae1b96a2467a	en_IN	WBH_MDMS_TENANT_TENANTINFO	Tenantinfo	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
91e9cf67-e97c-4a50-acf1-721bff8111c6	en_IN	WBH_MDMS_TENANT_TENANTS	Tenant Master	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
ab519264-1fde-4cf9-8cfd-6e9a7ffa71d6	en_IN	WBH_MDMS_TRADE_FIELDS	Fields	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a049109b-fc11-498f-94dd-57ed5a18f7b9	en_IN	WBH_MDMS_WORKFLOW_AUTOESCALATION	AutoEscalation	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
4abda8f7-545c-4e7d-aa4d-28b05f66c6fc	en_IN	WBH_MDMS_WORKFLOW_AUTOESCALATIONSTATESTOIGNORE	AutoEscalationStatesToIgnore	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9c79a8bc-cf0b-47c7-8b48-70139e9f13a4	en_IN	WBH_MDMS_WORKFLOW_BUSINESSSERVICE	BusinessService	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
d107bddd-ce84-496a-903f-ae3530012a49	en_IN	WBH_MDMS_WORKFLOW_BUSINESSSERVICECONFIG	BusinessServiceConfig	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
a48f098d-b50d-4910-bda3-f967e0e7e454	en_IN	WBH_MDMS_WORKFLOW_BUSINESSSERVICEMASTERCONFIG	BusinessServiceMasterConfig	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
787b7aeb-18e3-4a5d-886f-c177177c13dc	en_IN	WBH_MDMS_WORKFLO_WORKFLOW	Workflow	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
5a597391-61b1-4c19-bdc0-7ad4f2b60f10	en_IN	WBH_SUCCESS_DIS_MDMS_MSG	Data disabled successfully with id	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
9168eb44-d8c8-4e93-b95c-1e71cea4827c	en_IN	WBH_SUCCESS_ENA_MDMS_MSG	Data enabled successfully with id	pg	rainmaker-workbench	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
689d14da-e16f-4f09-b6e5-6b9b7ed6cd75	en_IN	DIGIT_I_ACCEPT	I accept	pg	digit-privacy-policy	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
256655d7-bd16-4ab2-8304-a4c8e7bfe55b	en_IN	DIGIT_I_DO_NOT_ACCEPT	I do not accept	pg	digit-privacy-policy	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
b195f803-345d-4251-982b-ac7aa8b6fa49	en_IN	DIGIT_TABLE_OF_CONTENTS	Privacy Policy	pg	digit-privacy-policy	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
0ccc1700-3837-4573-888d-89baa382ad5f	en_IN	ES_BY_CLICKING	I agree to the DIGIT's	pg	digit-privacy-policy	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
77dd5342-5d3f-4e5b-be5c-fc10b3a98855	en_IN	ES_PRIVACY_POLICY	Privacy Policy	pg	digit-privacy-policy	1	2026-07-28 00:00:00	1	2026-07-28 00:00:00
\.


--
-- Data for Name: pgr_services_schema; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.pgr_services_schema (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	egov	2026-02-09 05:25:12.57243	0	t
2	20200717133931	create table	SQL	main/V20200717133931__create_table.sql	1132569897	egov	2026-02-09 05:25:12.655223	17	t
3	20200810112036	add index	SQL	main/V20200810112036__add_index.sql	418627729	egov	2026-02-09 05:25:12.709256	21	t
4	20201130165150	alter table ddl	SQL	main/V20201130165150__alter_table_ddl.sql	-1604861903	egov	2026-02-09 05:25:12.743597	8	t
\.


--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: egov
--

COPY public.service (id, code, name, enabled, contextroot, displayname, ordernumber, parentmodule, tenantid) FROM stdin;
\.


--
-- Name: eg_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.eg_address_id_seq', 1, false);


--
-- Name: eg_enc_asymmetric_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.eg_enc_asymmetric_keys_id_seq', 5, true);


--
-- Name: eg_enc_symmetric_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.eg_enc_symmetric_keys_id_seq', 5, true);


--
-- Name: eg_hrms_position; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.eg_hrms_position', 13, true);


--
-- Name: eg_url_shorter_id; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.eg_url_shorter_id', 1, false);


--
-- Name: id_generator_id_seq; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.id_generator_id_seq', 1, false);


--
-- Name: seq_ack_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_ack_num', 1, false);


--
-- Name: seq_advocate_code; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_advocate_code', 1, false);


--
-- Name: seq_advocatepayment_code; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_advocatepayment_code', 1, false);


--
-- Name: seq_agency; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_agency', 1, false);


--
-- Name: seq_assesmnt_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_assesmnt_num', 1, false);


--
-- Name: seq_case_advocate; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_case_advocate', 1, false);


--
-- Name: seq_case_reference; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_case_reference', 1, false);


--
-- Name: seq_coll_rcpt_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_coll_rcpt_num', 1, false);


--
-- Name: seq_eg_action; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_action', 1, false);


--
-- Name: seq_eg_filestoremap; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_filestoremap', 8, true);


--
-- Name: seq_eg_hrms_emp_code; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_hrms_emp_code', 1, false);


--
-- Name: seq_eg_ms_role; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_ms_role', 1, false);


--
-- Name: seq_eg_pg_txn; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_pg_txn', 1, false);


--
-- Name: seq_eg_pgr_id; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_pgr_id', 188, true);


--
-- Name: seq_eg_pt_ack; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_pt_ack', 1, false);


--
-- Name: seq_eg_pt_assm; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_pt_assm', 1, false);


--
-- Name: seq_eg_pt_ln; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_pt_ln', 1, false);


--
-- Name: seq_eg_pt_ptid; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_pt_ptid', 1, false);


--
-- Name: seq_eg_role; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_role', 1, false);


--
-- Name: seq_eg_tl_apl; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_tl_apl', 1, false);


--
-- Name: seq_eg_user; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_user', 35, true);


--
-- Name: seq_eg_user_address; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_user_address', 70, true);


--
-- Name: seq_eg_wf_state_v2; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_eg_wf_state_v2', 33, true);


--
-- Name: seq_egf_bill_dft_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_egf_bill_dft_num', 1, false);


--
-- Name: seq_employee_code; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_employee_code', 1, false);


--
-- Name: seq_event; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_event', 1, false);


--
-- Name: seq_hearing_details; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_hearing_details', 1, false);


--
-- Name: seq_message; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_message', 1, false);


--
-- Name: seq_notice; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_notice', 1, false);


--
-- Name: seq_opinion_code; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_opinion_code', 1, false);


--
-- Name: seq_parawise_comments; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_parawise_comments', 1, false);


--
-- Name: seq_personal_details; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_personal_details', 1, false);


--
-- Name: seq_reference_evidence; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_reference_evidence', 1, false);


--
-- Name: seq_register; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_register', 1, false);


--
-- Name: seq_service; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_service', 1, false);


--
-- Name: seq_summon_code; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_summon_code', 1, false);


--
-- Name: seq_summon_reference; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_summon_reference', 1, false);


--
-- Name: seq_swm_ctrt_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_ctrt_num', 1, false);


--
-- Name: seq_swm_shift_code_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_shift_code_num', 1, false);


--
-- Name: seq_swm_snts_trgt_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_snts_trgt_num', 1, false);


--
-- Name: seq_swm_splr_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_splr_num', 1, false);


--
-- Name: seq_swm_stf_trn_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_stf_trn_num', 1, false);


--
-- Name: seq_swm_trn_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_trn_num', 1, false);


--
-- Name: seq_swm_vendor_payment_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_vendor_payment_num', 1, false);


--
-- Name: seq_swm_vhl_trip_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_vhl_trip_num', 1, false);


--
-- Name: seq_swm_vmr_trn_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_vmr_trn_num', 1, false);


--
-- Name: seq_swm_vndr_ctrt_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_vndr_ctrt_num', 1, false);


--
-- Name: seq_swm_vndr_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_vndr_num', 1, false);


--
-- Name: seq_swm_vs_trn_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_swm_vs_trn_num', 1, false);


--
-- Name: seq_tl_app_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_tl_app_num', 1, false);


--
-- Name: seq_tl_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_tl_num', 1, false);


--
-- Name: seq_uc_demand_consumer_code; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_uc_demand_consumer_code', 1, false);


--
-- Name: seq_ulb_code; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_ulb_code', 1, false);


--
-- Name: seq_upic_num; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_upic_num', 1, false);


--
-- Name: seq_voucher_code; Type: SEQUENCE SET; Schema: public; Owner: egov
--

SELECT pg_catalog.setval('public.seq_voucher_code', 1, false);


--
-- Name: accesscontrol_schema_version accesscontrol_schema_version_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.accesscontrol_schema_version
    ADD CONSTRAINT accesscontrol_schema_version_pk PRIMARY KEY (installed_rank);


--
-- Name: boundary boundary_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.boundary
    ADD CONSTRAINT boundary_pkey PRIMARY KEY (id);


--
-- Name: boundary_service_schema boundary_service_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.boundary_service_schema
    ADD CONSTRAINT boundary_service_schema_pk PRIMARY KEY (installed_rank);


--
-- Name: eg_action eg_action_name_key; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_action
    ADD CONSTRAINT eg_action_name_key UNIQUE (name);


--
-- Name: eg_action eg_action_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_action
    ADD CONSTRAINT eg_action_pkey PRIMARY KEY (id);


--
-- Name: eg_action eg_action_url_queryparams_key; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_action
    ADD CONSTRAINT eg_action_url_queryparams_key UNIQUE (url, queryparams);


--
-- Name: eg_address eg_address_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_address
    ADD CONSTRAINT eg_address_pkey PRIMARY KEY (id);


--
-- Name: eg_bm_generated_template eg_bm_generated_template_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_bm_generated_template
    ADD CONSTRAINT eg_bm_generated_template_pkey PRIMARY KEY (id);


--
-- Name: eg_bm_processed_template eg_bm_processed_template_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_bm_processed_template
    ADD CONSTRAINT eg_bm_processed_template_pkey PRIMARY KEY (id);


--
-- Name: eg_enc_asymmetric_keys eg_enc_asymmetric_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_enc_asymmetric_keys
    ADD CONSTRAINT eg_enc_asymmetric_keys_pkey PRIMARY KEY (id);


--
-- Name: eg_enc_symmetric_keys eg_enc_symmetric_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_enc_symmetric_keys
    ADD CONSTRAINT eg_enc_symmetric_keys_pkey PRIMARY KEY (id);


--
-- Name: eg_role eg_role_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_role
    ADD CONSTRAINT eg_role_pk PRIMARY KEY (id, tenantid);


--
-- Name: eg_roleaction eg_roleaction_ukey_tenantid; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_roleaction
    ADD CONSTRAINT eg_roleaction_ukey_tenantid PRIMARY KEY (rolecode, actionid, tenantid);


--
-- Name: eg_role eg_roles_code_tenant; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_role
    ADD CONSTRAINT eg_roles_code_tenant UNIQUE (code, tenantid);


--
-- Name: eg_ms_role eg_roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_ms_role
    ADD CONSTRAINT eg_roles_role_name_key UNIQUE (name);


--
-- Name: service eg_service_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT eg_service_pkey PRIMARY KEY (id, tenantid);


--
-- Name: service eg_service_ukey_tenantid; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT eg_service_ukey_tenantid UNIQUE (name, tenantid);


--
-- Name: eg_token eg_token_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_token
    ADD CONSTRAINT eg_token_pkey PRIMARY KEY (id);


--
-- Name: eg_url_shortener eg_url_shortener_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_url_shortener
    ADD CONSTRAINT eg_url_shortener_pkey PRIMARY KEY (id);


--
-- Name: eg_user_address eg_user_address_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_user_address
    ADD CONSTRAINT eg_user_address_pkey PRIMARY KEY (id);


--
-- Name: eg_user_address eg_user_address_type_unique; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_user_address
    ADD CONSTRAINT eg_user_address_type_unique UNIQUE (userid, tenantid, type);


--
-- Name: eg_user eg_user_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_user
    ADD CONSTRAINT eg_user_pkey PRIMARY KEY (id, tenantid);


--
-- Name: eg_user eg_user_user_name_tenant; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_user
    ADD CONSTRAINT eg_user_user_name_tenant UNIQUE (username, type, tenantid);


--
-- Name: egov-url-shortening_schema egov-url-shortening_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public."egov-url-shortening_schema"
    ADD CONSTRAINT "egov-url-shortening_schema_pk" PRIMARY KEY (installed_rank);


--
-- Name: egov_enc_service_schema egov_enc_service_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.egov_enc_service_schema
    ADD CONSTRAINT egov_enc_service_schema_pk PRIMARY KEY (installed_rank);


--
-- Name: egov_filestore_schema egov_filestore_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.egov_filestore_schema
    ADD CONSTRAINT egov_filestore_schema_pk PRIMARY KEY (installed_rank);


--
-- Name: egov_hrms_schema egov_hrms_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.egov_hrms_schema
    ADD CONSTRAINT egov_hrms_schema_pk PRIMARY KEY (installed_rank);


--
-- Name: egov_idgen_schema egov_idgen_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.egov_idgen_schema
    ADD CONSTRAINT egov_idgen_schema_pk PRIMARY KEY (installed_rank);


--
-- Name: egov_localization_schema egov_localization_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.egov_localization_schema
    ADD CONSTRAINT egov_localization_schema_pk PRIMARY KEY (installed_rank);


--
-- Name: egov_otp_schema egov_otp_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.egov_otp_schema
    ADD CONSTRAINT egov_otp_schema_pk PRIMARY KEY (installed_rank);


--
-- Name: egov_user_schema egov_user_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.egov_user_schema
    ADD CONSTRAINT egov_user_schema_pk PRIMARY KEY (installed_rank);


--
-- Name: egov_workflow_v2_schema egov_workflow_v2_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.egov_workflow_v2_schema
    ADD CONSTRAINT egov_workflow_v2_schema_pk PRIMARY KEY (installed_rank);


--
-- Name: mdms_v2_schema mdms_v2_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.mdms_v2_schema
    ADD CONSTRAINT mdms_v2_schema_pk PRIMARY KEY (installed_rank);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (id);


--
-- Name: pgr_services_schema pgr_services_schema_pk; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.pgr_services_schema
    ADD CONSTRAINT pgr_services_schema_pk PRIMARY KEY (installed_rank);


--
-- Name: boundary_hierarchy pk_boundary_hierarchy; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.boundary_hierarchy
    ADD CONSTRAINT pk_boundary_hierarchy PRIMARY KEY (id);


--
-- Name: boundary_relationship pk_boundary_relationship; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.boundary_relationship
    ADD CONSTRAINT pk_boundary_relationship PRIMARY KEY (tenantid, code, hierarchytype);


--
-- Name: eg_mdms_data pk_eg_mdms_data; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_mdms_data
    ADD CONSTRAINT pk_eg_mdms_data PRIMARY KEY (tenantid, schemacode, uniqueidentifier);


--
-- Name: eg_pgr_address_v2 pk_eg_pgr_address_v2; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_pgr_address_v2
    ADD CONSTRAINT pk_eg_pgr_address_v2 PRIMARY KEY (id);


--
-- Name: eg_pgr_service_v2 pk_eg_pgr_servicereq_v2; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_pgr_service_v2
    ADD CONSTRAINT pk_eg_pgr_servicereq_v2 PRIMARY KEY (tenantid, servicerequestid);


--
-- Name: eg_mdms_schema_definition pk_eg_schema_definition; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_mdms_schema_definition
    ADD CONSTRAINT pk_eg_schema_definition PRIMARY KEY (tenantid, code);


--
-- Name: eg_wf_businessservice_v2 pk_eg_wf_businessservice; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_wf_businessservice_v2
    ADD CONSTRAINT pk_eg_wf_businessservice PRIMARY KEY (uuid);


--
-- Name: eg_wf_state_v2 pk_eg_wf_state_v2; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_wf_state_v2
    ADD CONSTRAINT pk_eg_wf_state_v2 PRIMARY KEY (uuid);


--
-- Name: eg_hrms_assignment pk_eghrms_assignment; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_assignment
    ADD CONSTRAINT pk_eghrms_assignment PRIMARY KEY (uuid);


--
-- Name: eg_hrms_deactivationdetails pk_eghrms_deactivationdetails; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_deactivationdetails
    ADD CONSTRAINT pk_eghrms_deactivationdetails PRIMARY KEY (uuid);


--
-- Name: eg_hrms_departmentaltests pk_eghrms_departmentaltests; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_departmentaltests
    ADD CONSTRAINT pk_eghrms_departmentaltests PRIMARY KEY (uuid);


--
-- Name: eg_hrms_educationaldetails pk_eghrms_educationaldetails; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_educationaldetails
    ADD CONSTRAINT pk_eghrms_educationaldetails PRIMARY KEY (uuid);


--
-- Name: eg_hrms_empdocuments pk_eghrms_empdocuments; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_empdocuments
    ADD CONSTRAINT pk_eghrms_empdocuments PRIMARY KEY (uuid);


--
-- Name: eg_hrms_employee pk_eghrms_employee; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_employee
    ADD CONSTRAINT pk_eghrms_employee PRIMARY KEY (uuid);


--
-- Name: eg_hrms_jurisdiction pk_eghrms_jurisdiction; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_jurisdiction
    ADD CONSTRAINT pk_eghrms_jurisdiction PRIMARY KEY (uuid);


--
-- Name: eg_hrms_reactivationdetails pk_eghrms_reactivationdetails; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_reactivationdetails
    ADD CONSTRAINT pk_eghrms_reactivationdetails PRIMARY KEY (uuid);


--
-- Name: eg_hrms_servicehistory pk_eghrms_servicehistory; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_servicehistory
    ADD CONSTRAINT pk_eghrms_servicehistory PRIMARY KEY (uuid);


--
-- Name: eg_filestoremap pk_filestoremap; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_filestoremap
    ADD CONSTRAINT pk_filestoremap PRIMARY KEY (id);


--
-- Name: id_generator pk_id_generator; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.id_generator
    ADD CONSTRAINT pk_id_generator PRIMARY KEY (idname, tenantid);


--
-- Name: boundary_hierarchy uk_boundary_hierarchy; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.boundary_hierarchy
    ADD CONSTRAINT uk_boundary_hierarchy UNIQUE (tenantid, hierarchytype);


--
-- Name: boundary_relationship uk_boundary_relationship; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.boundary_relationship
    ADD CONSTRAINT uk_boundary_relationship UNIQUE (id);


--
-- Name: eg_mdms_data uk_eg_mdms_data; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_mdms_data
    ADD CONSTRAINT uk_eg_mdms_data UNIQUE (id);


--
-- Name: eg_pgr_service_v2 uk_eg_pgr_service_v2; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_pgr_service_v2
    ADD CONSTRAINT uk_eg_pgr_service_v2 UNIQUE (id);


--
-- Name: eg_wf_action_v2 uk_eg_wf_action; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_wf_action_v2
    ADD CONSTRAINT uk_eg_wf_action PRIMARY KEY (uuid);


--
-- Name: eg_wf_businessservice_v2 uk_eg_wf_businessservice; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_wf_businessservice_v2
    ADD CONSTRAINT uk_eg_wf_businessservice UNIQUE (tenantid, businessservice);


--
-- Name: eg_wf_document_v2 uk_eg_wf_document; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_wf_document_v2
    ADD CONSTRAINT uk_eg_wf_document PRIMARY KEY (id);


--
-- Name: eg_wf_processinstance_v2 uk_eg_wf_processinstance; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_wf_processinstance_v2
    ADD CONSTRAINT uk_eg_wf_processinstance UNIQUE (id);


--
-- Name: eg_wf_state_v2 uk_eg_wf_state_v2; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_wf_state_v2
    ADD CONSTRAINT uk_eg_wf_state_v2 UNIQUE (state, businessserviceid);


--
-- Name: eg_hrms_employee uk_eghrms_employee_code; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_employee
    ADD CONSTRAINT uk_eghrms_employee_code UNIQUE (code, tenantid);


--
-- Name: eg_filestoremap uk_filestoremap_filestoreid; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_filestoremap
    ADD CONSTRAINT uk_filestoremap_filestoreid UNIQUE (filestoreid);


--
-- Name: eg_filestoremap uk_filestoremap_fsid_tenant; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_filestoremap
    ADD CONSTRAINT uk_filestoremap_fsid_tenant UNIQUE (filestoreid, tenantid);


--
-- Name: boundary unique_code_tenantid; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.boundary
    ADD CONSTRAINT unique_code_tenantid UNIQUE (code, tenantid);


--
-- Name: message unique_message_entry; Type: CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT unique_message_entry UNIQUE (tenantid, locale, module, code);


--
-- Name: accesscontrol_schema_version_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX accesscontrol_schema_version_s_idx ON public.accesscontrol_schema_version USING btree (success);


--
-- Name: active_tenant_asymmetric_keys; Type: INDEX; Schema: public; Owner: egov
--

CREATE UNIQUE INDEX active_tenant_asymmetric_keys ON public.eg_enc_asymmetric_keys USING btree (tenant_id) WHERE (active IS TRUE);


--
-- Name: active_tenant_symmetric_keys; Type: INDEX; Schema: public; Owner: egov
--

CREATE UNIQUE INDEX active_tenant_symmetric_keys ON public.eg_enc_symmetric_keys USING btree (tenant_id) WHERE (active IS TRUE);


--
-- Name: boundary_service_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX boundary_service_schema_s_idx ON public.boundary_service_schema USING btree (success);


--
-- Name: code_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX code_idx ON public.eg_hrms_employee USING btree (code);


--
-- Name: dept_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX dept_idx ON public.eg_hrms_assignment USING btree (department);


--
-- Name: desg_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX desg_idx ON public.eg_hrms_assignment USING btree (designation);


--
-- Name: eg_asymmetric_key_id; Type: INDEX; Schema: public; Owner: egov
--

CREATE UNIQUE INDEX eg_asymmetric_key_id ON public.eg_enc_asymmetric_keys USING btree (key_id);


--
-- Name: eg_symmetric_key_id; Type: INDEX; Schema: public; Owner: egov
--

CREATE UNIQUE INDEX eg_symmetric_key_id ON public.eg_enc_symmetric_keys USING btree (key_id);


--
-- Name: egov-url-shortening_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX "egov-url-shortening_schema_s_idx" ON public."egov-url-shortening_schema" USING btree (success);


--
-- Name: egov_enc_service_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX egov_enc_service_schema_s_idx ON public.egov_enc_service_schema USING btree (success);


--
-- Name: egov_filestore_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX egov_filestore_schema_s_idx ON public.egov_filestore_schema USING btree (success);


--
-- Name: egov_hrms_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX egov_hrms_schema_s_idx ON public.egov_hrms_schema USING btree (success);


--
-- Name: egov_idgen_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX egov_idgen_schema_s_idx ON public.egov_idgen_schema USING btree (success);


--
-- Name: egov_localization_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX egov_localization_schema_s_idx ON public.egov_localization_schema USING btree (success);


--
-- Name: egov_otp_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX egov_otp_schema_s_idx ON public.egov_otp_schema USING btree (success);


--
-- Name: egov_user_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX egov_user_schema_s_idx ON public.egov_user_schema USING btree (success);


--
-- Name: egov_workflow_v2_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX egov_workflow_v2_schema_s_idx ON public.egov_workflow_v2_schema USING btree (success);


--
-- Name: idx_bm_gen_template_tenant_hierarchy; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_bm_gen_template_tenant_hierarchy ON public.eg_bm_generated_template USING btree (tenantid, hierarchytype);


--
-- Name: idx_bm_proc_template_tenant_hierarchy; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_bm_proc_template_tenant_hierarchy ON public.eg_bm_processed_template USING btree (tenantid, hierarchytype);


--
-- Name: idx_boundary_hierarchy_tenantid_hierarchytype; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_boundary_hierarchy_tenantid_hierarchytype ON public.boundary_hierarchy USING btree (tenantid, hierarchytype);


--
-- Name: idx_boundary_tenantid_code; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_boundary_tenantid_code ON public.boundary USING btree (tenantid, code);


--
-- Name: idx_eg_hrms_employee_tenantid; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_hrms_employee_tenantid ON public.eg_hrms_employee USING btree (tenantid);


--
-- Name: idx_eg_role_code; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_role_code ON public.eg_role USING btree (code);


--
-- Name: idx_eg_user_active; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_user_active ON public.eg_user USING btree (active);


--
-- Name: idx_eg_user_address_tenantid; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_user_address_tenantid ON public.eg_user_address USING btree (tenantid);


--
-- Name: idx_eg_user_failed_attempts_user_attemptdate; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_user_failed_attempts_user_attemptdate ON public.eg_user_login_failed_attempts USING btree (attempt_date);


--
-- Name: idx_eg_user_failed_attempts_user_uuid; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_user_failed_attempts_user_uuid ON public.eg_user_login_failed_attempts USING btree (user_uuid);


--
-- Name: idx_eg_user_mobile; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_user_mobile ON public.eg_user USING btree (mobilenumber);


--
-- Name: idx_eg_user_name; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_user_name ON public.eg_user USING btree (name);


--
-- Name: idx_eg_user_tenantid; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_user_tenantid ON public.eg_user USING btree (tenantid);


--
-- Name: idx_eg_user_type; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_user_type ON public.eg_user USING btree (type);


--
-- Name: idx_eg_user_username; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_user_username ON public.eg_user USING btree (username);


--
-- Name: idx_eg_user_uuid; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_user_uuid ON public.eg_user USING btree (uuid);


--
-- Name: idx_eg_userrole_v1_rolecode; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_userrole_v1_rolecode ON public.eg_userrole_v1 USING btree (role_code);


--
-- Name: idx_eg_userrole_v1_roletenantid; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_userrole_v1_roletenantid ON public.eg_userrole_v1 USING btree (role_tenantid);


--
-- Name: idx_eg_userrole_v1_userid; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_userrole_v1_userid ON public.eg_userrole_v1 USING btree (user_id);


--
-- Name: idx_eg_userrole_v1_usertenantid; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_userrole_v1_usertenantid ON public.eg_userrole_v1 USING btree (user_tenantid);


--
-- Name: idx_eg_wf_assignee_v2_assignee; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_eg_wf_assignee_v2_assignee ON public.eg_wf_assignee_v2 USING btree (tenantid, assignee);


--
-- Name: idx_pi_wf_action; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_pi_wf_action ON public.eg_wf_action_v2 USING btree (action);


--
-- Name: idx_pi_wf_businessservice_v2; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_pi_wf_businessservice_v2 ON public.eg_wf_businessservice_v2 USING btree (businessservice);


--
-- Name: idx_pi_wf_processinstance_v2; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_pi_wf_processinstance_v2 ON public.eg_wf_processinstance_v2 USING btree (businessid, lastmodifiedtime);


--
-- Name: idx_pi_wf_state_v2; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_pi_wf_state_v2 ON public.eg_wf_state_v2 USING btree (state);


--
-- Name: idx_processinstanceid_eg_wf_assignee_v2; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_processinstanceid_eg_wf_assignee_v2 ON public.eg_wf_assignee_v2 USING btree (processinstanceid);


--
-- Name: idx_tenant_status_eg_wf_processinstance_v2; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_tenant_status_eg_wf_processinstance_v2 ON public.eg_wf_processinstance_v2 USING btree (((((tenantid)::text || ':'::text) || (status)::text)));


--
-- Name: idx_token_number_identity_tenant; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX idx_token_number_identity_tenant ON public.eg_token USING btree (tokennumber, tokenidentity, tenantid);


--
-- Name: index_eg_pgr_address_v2_locality; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX index_eg_pgr_address_v2_locality ON public.eg_pgr_address_v2 USING btree (locality);


--
-- Name: index_eg_pgr_service_v2_accountid; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX index_eg_pgr_service_v2_accountid ON public.eg_pgr_service_v2 USING btree (accountid);


--
-- Name: index_eg_pgr_service_v2_applicationstatus; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX index_eg_pgr_service_v2_applicationstatus ON public.eg_pgr_service_v2 USING btree (applicationstatus);


--
-- Name: index_eg_pgr_service_v2_id; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX index_eg_pgr_service_v2_id ON public.eg_pgr_service_v2 USING btree (id);


--
-- Name: index_eg_pgr_service_v2_servicecode; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX index_eg_pgr_service_v2_servicecode ON public.eg_pgr_service_v2 USING btree (servicecode);


--
-- Name: index_eg_pgr_service_v2_tenantid_servicerequestid; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX index_eg_pgr_service_v2_tenantid_servicerequestid ON public.eg_pgr_service_v2 USING btree (tenantid, servicerequestid);


--
-- Name: mdms_v2_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX mdms_v2_schema_s_idx ON public.mdms_v2_schema USING btree (success);


--
-- Name: message_locale_tenant; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX message_locale_tenant ON public.message USING btree (locale, tenantid);


--
-- Name: pgr_services_schema_s_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX pgr_services_schema_s_idx ON public.pgr_services_schema USING btree (success);


--
-- Name: posn_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX posn_idx ON public.eg_hrms_assignment USING btree ("position");


--
-- Name: reactivation_employeeid_idx; Type: INDEX; Schema: public; Owner: egov
--

CREATE INDEX reactivation_employeeid_idx ON public.eg_hrms_reactivationdetails USING btree (employeeid);


--
-- Name: eg_user_address eg_user_address_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_user_address
    ADD CONSTRAINT eg_user_address_user_fkey FOREIGN KEY (userid, tenantid) REFERENCES public.eg_user(id, tenantid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eg_userrole eg_userrole_roleid_roleidtenantid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_userrole
    ADD CONSTRAINT eg_userrole_roleid_roleidtenantid_fkey FOREIGN KEY (roleid, roleidtenantid) REFERENCES public.eg_role(id, tenantid);


--
-- Name: eg_userrole eg_userrole_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_userrole
    ADD CONSTRAINT eg_userrole_userid_fkey FOREIGN KEY (userid, tenantid) REFERENCES public.eg_user(id, tenantid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eg_pgr_address_v2 fk_eg_pgr_address_v2; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_pgr_address_v2
    ADD CONSTRAINT fk_eg_pgr_address_v2 FOREIGN KEY (parentid) REFERENCES public.eg_pgr_service_v2(id);


--
-- Name: eg_wf_action_v2 fk_eg_wf_action_v2; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_wf_action_v2
    ADD CONSTRAINT fk_eg_wf_action_v2 FOREIGN KEY (currentstate) REFERENCES public.eg_wf_state_v2(uuid);


--
-- Name: eg_wf_assignee_v2 fk_eg_wf_assignee_v2; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_wf_assignee_v2
    ADD CONSTRAINT fk_eg_wf_assignee_v2 FOREIGN KEY (processinstanceid) REFERENCES public.eg_wf_processinstance_v2(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eg_wf_document_v2 fk_eg_wf_document; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_wf_document_v2
    ADD CONSTRAINT fk_eg_wf_document FOREIGN KEY (processinstanceid) REFERENCES public.eg_wf_processinstance_v2(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eg_wf_state_v2 fk_eg_wf_state; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_wf_state_v2
    ADD CONSTRAINT fk_eg_wf_state FOREIGN KEY (businessserviceid) REFERENCES public.eg_wf_businessservice_v2(uuid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eg_hrms_assignment fk_eghrms_assignment_employeeid; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_assignment
    ADD CONSTRAINT fk_eghrms_assignment_employeeid FOREIGN KEY (employeeid) REFERENCES public.eg_hrms_employee(uuid) ON DELETE CASCADE;


--
-- Name: eg_hrms_deactivationdetails fk_eghrms_deactivationdetails_employeeid; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_deactivationdetails
    ADD CONSTRAINT fk_eghrms_deactivationdetails_employeeid FOREIGN KEY (employeeid) REFERENCES public.eg_hrms_employee(uuid) ON DELETE CASCADE;


--
-- Name: eg_hrms_departmentaltests fk_eghrms_departmentaltests_employeeid; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_departmentaltests
    ADD CONSTRAINT fk_eghrms_departmentaltests_employeeid FOREIGN KEY (employeeid) REFERENCES public.eg_hrms_employee(uuid) ON DELETE CASCADE;


--
-- Name: eg_hrms_educationaldetails fk_eghrms_educationaldetails_employeeid; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_educationaldetails
    ADD CONSTRAINT fk_eghrms_educationaldetails_employeeid FOREIGN KEY (employeeid) REFERENCES public.eg_hrms_employee(uuid) ON DELETE CASCADE;


--
-- Name: eg_hrms_empdocuments fk_eghrms_empdocuments_employeeid; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_empdocuments
    ADD CONSTRAINT fk_eghrms_empdocuments_employeeid FOREIGN KEY (employeeid) REFERENCES public.eg_hrms_employee(uuid) ON DELETE CASCADE;


--
-- Name: eg_hrms_jurisdiction fk_eghrms_jurisdiction_employeeid; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_jurisdiction
    ADD CONSTRAINT fk_eghrms_jurisdiction_employeeid FOREIGN KEY (employeeid) REFERENCES public.eg_hrms_employee(uuid) ON DELETE CASCADE;


--
-- Name: eg_hrms_reactivationdetails fk_eghrms_reactivationdetails_employeeid; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_reactivationdetails
    ADD CONSTRAINT fk_eghrms_reactivationdetails_employeeid FOREIGN KEY (employeeid) REFERENCES public.eg_hrms_employee(uuid) ON DELETE CASCADE;


--
-- Name: eg_hrms_servicehistory fk_eghrms_servicehistory_employeeid; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_hrms_servicehistory
    ADD CONSTRAINT fk_eghrms_servicehistory_employeeid FOREIGN KEY (employeeid) REFERENCES public.eg_hrms_employee(uuid) ON DELETE CASCADE;


--
-- Name: eg_userrole_v1 fk_user_role_v1; Type: FK CONSTRAINT; Schema: public; Owner: egov
--

ALTER TABLE ONLY public.eg_userrole_v1
    ADD CONSTRAINT fk_user_role_v1 FOREIGN KEY (user_id, user_tenantid) REFERENCES public.eg_user(id, tenantid);


--
-- PostgreSQL database dump complete
--

\unrestrict khfTsZ1ktr0RAULBk6Bs28kBqKU4Bfrmf02yBc0FejfEp5oIZSwwvgwBY2kwXs5

